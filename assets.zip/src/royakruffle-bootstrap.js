'use strict';
(async () => {
 const status = document.getElementById('status');
 const metrics = document.getElementById('metrics');
 const params = new URLSearchParams(location.search);
 const fail = e => { status.textContent = 'RoyakRuffle: ' + (e?.message || String(e)); console.error('[RoyakRuffle]', e); };
 try {
  const encoded = params.get('payload');
  if (!encoded) throw Error('Missing game launch payload');
  const payload = JSON.parse(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')));
  if (!window.RufflePlayer) throw Error('Local runtime missing. Run npm run setup:ruffle before launching.');
  // The self-hosted bundle resolves WASM from this directory, not the network.
  window.RufflePlayer.config = { ...window.RufflePlayer.config, publicPath: new URL('../vendor/royakruffle/', location.href).href,
    logLevel: 'warn', preferredRenderer: 'wgpu-webgl', autoplay: 'on', unmuteOverlay: 'visible' };
  const player = window.RufflePlayer.newest().createPlayer();
  player.style.width = '100%'; player.style.height = '100%';
  document.getElementById('player').append(player);
  await player.load({ url: payload.swf, parameters: payload.flashvars || {}, quality: payload.quality || 'high', autoplay: 'on', unmuteOverlay: 'visible' });
  status.remove();
  if (payload.diagnostics) {
   metrics.style.display = 'block';
   let frames = 0, last = performance.now();
   const sample = now => { frames++; if (now - last >= 1000) { metrics.textContent = `RoyakRuffle · display callbacks ${Math.round(frames * 1000 / (now - last))}/s\n${performance.memory ? 'JS heap ' + Math.round(performance.memory.usedJSHeapSize / 1048576) + ' MB' : 'Memory unavailable'}\nGPU renderer preference: wgpu-webgl`; frames = 0; last = now; } requestAnimationFrame(sample); };
   requestAnimationFrame(sample);
  }
 } catch(e) { fail(e); }
})();
