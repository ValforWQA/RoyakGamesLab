'use strict';
(async () => {
 const status = document.getElementById('status');
 const metrics = document.getElementById('metrics');
 const params = new URLSearchParams(location.search);
 const fail = e => { status.textContent = 'RoyakFlashEngine: ' + (e?.message || String(e)); console.error('[RoyakRuffle]', e); };
 try {
  const encoded = params.get('payload');
  if (!encoded) throw Error('Missing game launch payload');
  const payload = JSON.parse(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')));
  document.title = String(payload.gameName || 'Game');
  if (!window.RufflePlayer) throw Error('Local runtime missing. Run npm run setup:ruffle before launching.');
  const settingsKey = 'royak-performance-v1';
  const profiles = {maximum:{fps:120,quality:'medium'},balanced:{fps:60,quality:'high'},battery:{fps:30,quality:'low'}};
  let settings;
  try {settings = {...{profile:'balanced',fps:60,quality:'high',stats:false},...JSON.parse(localStorage.getItem(settingsKey)||'{}')};} catch {settings={profile:'balanced',fps:60,quality:'high',stats:false};}
  const panel=document.getElementById('perfPanel'), toggle=document.getElementById('perfToggle');
  const profileEl=document.getElementById('perfProfile'),fpsEl=document.getElementById('fpsTarget'),qualityEl=document.getElementById('perfQuality'),statsEl=document.getElementById('perfStats');
  const sync=()=>{profileEl.value=settings.profile;fpsEl.value=settings.fps;document.getElementById('fpsLabel').textContent=settings.fps;qualityEl.value=settings.quality;statsEl.checked=!!settings.stats;metrics.style.display=settings.stats?'block':'none';};
  const save=()=>{localStorage.setItem(settingsKey,JSON.stringify(settings));sync();};
  toggle.addEventListener('click',()=>panel.style.display=panel.style.display==='block'?'none':'block');
  document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='p'){e.preventDefault();toggle.click();}});
  profileEl.addEventListener('change',()=>{settings.profile=profileEl.value;if(profiles[settings.profile])Object.assign(settings,profiles[settings.profile]);save();});
  fpsEl.addEventListener('input',()=>{settings.profile='custom';settings.fps=Number(fpsEl.value);save();});
  qualityEl.addEventListener('change',()=>{settings.quality=qualityEl.value;settings.profile='custom';save();});
  statsEl.addEventListener('change',()=>{settings.stats=statsEl.checked;save();});
  const drag=document.getElementById('perfDrag');let dragging=null;
  drag.addEventListener('pointerdown',e=>{dragging={x:e.clientX-panel.offsetLeft,y:e.clientY-panel.offsetTop};drag.setPointerCapture(e.pointerId);});
  drag.addEventListener('pointermove',e=>{if(!dragging)return;panel.style.left=Math.max(0,Math.min(innerWidth-panel.offsetWidth,e.clientX-dragging.x))+'px';panel.style.top=Math.max(0,Math.min(innerHeight-panel.offsetHeight,e.clientY-dragging.y))+'px';panel.style.right='auto';});
  drag.addEventListener('pointerup',()=>dragging=null);
  sync();
  // The self-hosted bundle resolves WASM from this directory, not the network.
  window.RufflePlayer.config = { ...window.RufflePlayer.config, publicPath: new URL('../vendor/royakruffle/', location.href).href,
    socketProxy: Array.isArray(payload.socketProxy) ? payload.socketProxy : [],
    logLevel: 'warn', preferredRenderer: 'wgpu-webgl', scale: 'exactfit', forceScale: true, autoplay: 'on', unmuteOverlay: 'visible' };
  const player = window.RufflePlayer.newest().createPlayer();
  player.addEventListener('error', event => { console.error('[RoyakFlashEngine player error]', event); status.textContent = 'RoyakFlashEngine player error — see runtime log'; status.style.display = 'block'; });
  player.style.display = 'block'; player.style.width = '100%'; player.style.height = '100%';
  document.getElementById('player').append(player);
  await player.load({ url: payload.swf, parameters: payload.flashvars || {}, quality: settings.quality || payload.quality || 'high', scale: 'exactfit', forceScale: true, autoplay: 'on', unmuteOverlay: 'visible', allowScriptAccess: true });
  status.remove();
  // Measure browser display callbacks, not the SWF's internal frame rate.
  let frames = 0, last = performance.now();
  const sample = now => { frames++; if (now - last >= 1000) {
   if (settings.stats) metrics.textContent = `Display callbacks: ${Math.round(frames * 1000 / (now-last))}/s (not SWF FPS)\nTarget: ${settings.fps} FPS · ${settings.profile}\n${performance.memory ? 'JS heap: ' + Math.round(performance.memory.usedJSHeapSize/1048576) + ' MB' : 'JS heap: unavailable'}\nRenderer preference: wgpu-webgl`;
   frames=0;last=now;
  } requestAnimationFrame(sample); };
  requestAnimationFrame(sample);
 } catch(e) { fail(e); }
})();
