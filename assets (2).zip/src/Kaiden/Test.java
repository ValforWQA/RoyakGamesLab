package Kaiden;

public class Test {
    private static final int[] arrRanks = new int[10];

    public static void main(String[] args) {
        for (int i = 1; i < arrRanks.length; ++i) {
            int rankExp = (int) (Math.pow(i + 1, 3.0D) * 100.0D);
            if (i > 1) {
                arrRanks[i] = rankExp + arrRanks[i - 1];
            } else {
                arrRanks[i] = rankExp + 100;
            }
        }
    }
}
