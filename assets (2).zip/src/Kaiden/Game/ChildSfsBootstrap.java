package Kaiden.Game;

import Kaiden.Game.Threads.RestartEmulator;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.config.ConfigData;
import java.io.File;

/** Starts a managed child SmartFoxServer with isolated H2 and manager restart control. */
public final class ChildSfsBootstrap {
    private ChildSfsBootstrap(){}
    public static void main(String[] args){
        int h2Port=Integer.getInteger("kaiden.h2.port",9009);
        ConfigData.H2_PORT_CONFIG=h2Port;
        ConfigData.H2_ARGS=new String[]{"-baseDir","./datastore/","-tcpPort",String.valueOf(h2Port)};
        ConfigData.H2_CONN_STRING="jdbc:h2:tcp://localhost:"+h2Port+"/__sfscore__";
        System.out.println("[Manager] Child SFS internal H2 port: "+h2Port);
        startManagerControlWatcher(); SmartFoxServer.main(args);
    }
    private static void startManagerControlWatcher(){
        Thread t=new Thread(new Runnable(){ public void run(){
            File restart=new File(".kaiden-restart"),cancel=new File(".kaiden-cancel-restart");
            for(;;)try{
                if(cancel.exists()){ cancel.delete(); boolean ok=RestartEmulator.cancel(); System.out.println("[Manager] Cancel restart request: "+(ok?"cancelled":"no restart pending")); }
                if(restart.exists()){
                    String request="5"; try{ java.util.List<String> lines=java.nio.file.Files.readAllLines(restart.toPath(), java.nio.charset.StandardCharsets.UTF_8); if(!lines.isEmpty()) request=lines.get(0).trim(); }catch(Throwable ignored){} restart.delete(); int minutes=5; try{ minutes=Math.max(1,Integer.parseInt(request)); }catch(Throwable ignored){} System.out.println("[Manager] Restart request received; scheduling RestartEmulator for "+minutes+" minute(s)...");
                    for(int i=0;i<60&&Kaiden_Extension.getInstance()==null;i++)Thread.sleep(500L);
                    if(Kaiden_Extension.getInstance()!=null){ RestartEmulator.schedule(minutes); System.out.println("[Manager] Restart scheduled for "+minutes+" minute(s). Create .kaiden-cancel-restart to cancel."); }
                    else System.out.println("[Manager] Restart request failed: Kaiden extension is not ready.");
                }
                Thread.sleep(200L);
            }catch(InterruptedException e){Thread.currentThread().interrupt();return;}catch(Throwable e){System.out.println("[Manager] Restart watcher: "+e.getMessage());}
        }},"Kaiden-Manager-Control"); t.setDaemon(true);t.start();
    }
}
