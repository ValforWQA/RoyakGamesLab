package Kaiden.Game;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Kaiden_Engine;
import Kaiden.Game.Threads.RestartEmulator;
import jdbchelper.QueryResult;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.*;

/**
 * Database-driven multi-world manager embedded in KaidenEngine.jar.
 * The servers table is the source of truth. No child BAT files are used.
 * Each started world is still an isolated SmartFox JVM, launched invisibly by this GUI.
 */
public final class ServerManagerUI extends JFrame {
    private static volatile ServerManagerUI INSTANCE;
    private static final Pattern PORT_PATTERN = Pattern.compile("<ServerPort>\\s*(\\d+)\\s*</ServerPort>", Pattern.CASE_INSENSITIVE);
    private final DefaultListModel<Integer> serverListModel = new DefaultListModel<Integer>();
    private final JList<Integer> serverList = new JList<Integer>(serverListModel);
    private final JPanel workspaceCards = new JPanel(new CardLayout());
    private final Map<Integer,JTextPane> consoles = new ConcurrentHashMap<Integer,JTextPane>();
    private final Map<Integer,JTabbedPane> workspaces = new ConcurrentHashMap<Integer,JTabbedPane>();
    private final Map<Integer,JLabel> statusLabels = new ConcurrentHashMap<>();
    private final Map<Integer,ConcurrentLinkedQueue<String>> pending = new ConcurrentHashMap<>();
    private final ExecutorService background = Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"Kaiden-Manager-DB");t.setDaemon(true);return t;});
    private volatile Integer selectedServerId;
    private final JLabel summary = new JLabel("Loading servers...");
    private final Map<Integer,ServerRow> servers = new LinkedHashMap<>();
    private final Map<Integer,Process> processes = new ConcurrentHashMap<>();
    private final Map<Integer,Long> startedAt = new ConcurrentHashMap<>();
    private final Map<Integer,StringBuilder> logs = new ConcurrentHashMap<>();
    private final File templateDir = new File(System.getProperty("user.dir")).getAbsoluteFile();
    private final File runtimeRoot = new File(templateDir, "KaidenRuntime");
    private javax.swing.Timer timer;

    public static void open(Kaiden_Engine engine){
        if(Boolean.parseBoolean(System.getProperty("kaiden.manager.child","false"))) return;
        SwingUtilities.invokeLater(() -> { if(INSTANCE==null) INSTANCE=new ServerManagerUI(); INSTANCE.setVisible(true); INSTANCE.toFront(); });
    }

    private ServerManagerUI(){
        super("Kaiden Engine - Server Manager");
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE); setSize(1220,720); setMinimumSize(new Dimension(960,560)); setLocationRelativeTo(null);
        buildUI(); runtimeRoot.mkdirs(); reloadFromDatabase();
        timer=new javax.swing.Timer(100,e->flushConsoleQueues()); timer.start();
        javax.swing.Timer dbTimer=new javax.swing.Timer(2000,e->reloadFromDatabase()); dbTimer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(this::stopAllChildren,"Kaiden-World-Shutdown"));
    }

    private JButton startButton,stopButton,restartButton,configButton,clearButton;
    private void buildUI(){
        final Color bg=new Color(12,17,21), panel=new Color(18,28,35), fg=new Color(205,219,226);
        JPanel root=new JPanel(new BorderLayout(6,6));root.setBackground(bg);root.setBorder(new EmptyBorder(7,7,7,7));
        JPanel header=new JPanel(new BorderLayout());header.setBackground(bg);JLabel title=new JLabel("  KAIDEN ENGINE   |   Multi-Server Console");title.setForeground(fg);title.setFont(new Font(Font.SANS_SERIF,Font.BOLD,15));
        JPanel tools=new JPanel(new FlowLayout(FlowLayout.RIGHT,4,0));tools.setBackground(bg);JButton create=b("+");JButton refresh=b("↻");JButton settings=b("⚙");tools.add(create);tools.add(refresh);tools.add(settings);header.add(title,BorderLayout.WEST);header.add(tools,BorderLayout.EAST);
        serverList.setBackground(panel);serverList.setForeground(fg);serverList.setSelectionBackground(new Color(18,83,119));serverList.setSelectionForeground(Color.WHITE);serverList.setFixedCellHeight(58);serverList.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));
        serverList.setCellRenderer(new ListCellRenderer<Integer>(){public Component getListCellRendererComponent(JList<? extends Integer> l,Integer id,int index,boolean sel,boolean focus){ServerRow r=servers.get(id);JPanel p=new JPanel(new BorderLayout());p.setBorder(new EmptyBorder(7,9,7,9));p.setBackground(sel?new Color(19,73,102):panel);boolean on=r!=null&&isRunning(r);JLabel n=new JLabel("●  "+(r==null?"":r.name));n.setForeground(on?new Color(83,224,111):new Color(190,198,202));n.setFont(new Font(Font.SANS_SERIF,Font.BOLD,12));JLabel d=new JLabel(r==null?"":r.count+" / "+r.max+"                         :"+r.port);d.setForeground(new Color(166,186,196));d.setFont(new Font(Font.MONOSPACED,Font.PLAIN,11));p.add(n,BorderLayout.NORTH);p.add(d,BorderLayout.SOUTH);return p;}});
        JPanel left=new JPanel(new BorderLayout(0,4));left.setBackground(panel);JLabel sh=new JLabel(" SERVERS");sh.setForeground(fg);sh.setFont(new Font(Font.SANS_SERIF,Font.BOLD,11));sh.setBorder(new EmptyBorder(7,5,5,5));left.add(sh,BorderLayout.NORTH);left.add(new JScrollPane(serverList),BorderLayout.CENTER);left.setPreferredSize(new Dimension(225,400));
        workspaceCards.setBackground(new Color(13,21,27));JSplitPane split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,left,workspaceCards);split.setDividerLocation(225);split.setDividerSize(5);split.setBorder(BorderFactory.createLineBorder(new Color(43,67,80)));split.setResizeWeight(0);
        JPanel actions=new JPanel(new GridLayout(1,5,7,0));actions.setBackground(bg);actions.setBorder(new EmptyBorder(2,225,2,0));startButton=b("▶  START");stopButton=b("■  STOP");restartButton=b("↻  RESTART");configButton=b("⚙  CONFIG");clearButton=b("▣  CLEAR");for(JButton x:new JButton[]{startButton,stopButton,restartButton,configButton,clearButton})actions.add(x);
        summary.setOpaque(true);summary.setBackground(panel);summary.setForeground(fg);summary.setBorder(new EmptyBorder(5,8,5,8));summary.setFont(new Font(Font.MONOSPACED,Font.PLAIN,11));JPanel south=new JPanel(new BorderLayout(0,4));south.setBackground(bg);south.add(actions,BorderLayout.NORTH);south.add(summary,BorderLayout.SOUTH);
        root.add(header,BorderLayout.NORTH);root.add(split,BorderLayout.CENTER);root.add(south,BorderLayout.SOUTH);setContentPane(root);
        serverList.addListSelectionListener(e->{if(!e.getValueIsAdjusting()){Integer id=serverList.getSelectedValue();if(id!=null){selectedServerId=id;((CardLayout)workspaceCards.getLayout()).show(workspaceCards,String.valueOf(id));updateRestartButton();}}});
        create.addActionListener(e->createDialog());refresh.addActionListener(e->reloadFromDatabase());settings.addActionListener(e->withSelected(this::editDialog));startButton.addActionListener(e->withSelected(this::startServer));stopButton.addActionListener(e->withSelected(this::stopServer));restartButton.addActionListener(e->withSelected(this::toggleRestart));configButton.addActionListener(e->withSelected(this::editDialog));clearButton.addActionListener(e->clearSelectedConsole());
    }
    private JButton b(String s){JButton x=new JButton(s);x.setFocusable(false);x.setBackground(new Color(22,33,40));x.setForeground(new Color(215,226,232));x.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(63,83,94)),new EmptyBorder(7,12,7,12)));x.setFont(new Font(Font.SANS_SERIF,Font.BOLD,11));return x;}
    private void reloadFromDatabase(){
        background.submit(()->{
            Map<Integer,ServerRow> fresh=new LinkedHashMap<>(); String failure=null;
            try{QueryResult q=Storage.getInstance().getJdbc().query("SELECT id,Name,IP,Online,Upgrade,Chat,Count,Max,MOTD,Language,Port,DailyPlayers FROM servers ORDER BY id");while(q.next()){ServerRow s=new ServerRow();s.id=q.getInt("id");s.name=q.getString("Name");s.ip=q.getString("IP");s.online=q.getInt("Online");s.count=q.getInt("Count");s.max=q.getInt("Max");s.motd=q.getString("MOTD");s.language=q.getString("Language");s.port=q.getInt("Port");s.daily=q.getInt("DailyPlayers");fresh.put(s.id,s);logs.putIfAbsent(s.id,new StringBuilder());pending.putIfAbsent(s.id,new ConcurrentLinkedQueue<>());}}
            catch(Throwable t){failure=t.getMessage();}
            final String err=failure; SwingUtilities.invokeLater(()->{if(err!=null){summary.setText(" DB ERROR: "+err);return;}servers.clear();servers.putAll(fresh);syncTabs();updateSummary();});
        });
    }
    private void syncTabs(){
        Set<Integer> current=new HashSet<Integer>();for(int i=0;i<serverListModel.size();i++)current.add(serverListModel.get(i));
        for(ServerRow r:servers.values())if(!current.contains(r.id)){serverListModel.addElement(r.id);createServerWorkspace(r);}
        for(int i=serverListModel.size()-1;i>=0;i--){Integer id=serverListModel.get(i);if(!servers.containsKey(id)){serverListModel.remove(i);consoles.remove(id);workspaces.remove(id);}}
        if(selectedServerId==null&&serverListModel.size()>0)selectId(serverListModel.get(0));else if(selectedServerId!=null)selectId(selectedServerId);serverList.repaint();updateRestartButton();
    }
    private void createServerWorkspace(ServerRow r){
        JPanel card=new JPanel(new BorderLayout());card.setBackground(new Color(12,18,22));JTabbedPane inner=new JTabbedPane();inner.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,11));inner.setBackground(new Color(18,28,35));inner.setForeground(new Color(210,220,226));workspaces.put(r.id,inner);
        JTextPane console=new JTextPane();console.setEditable(false);console.setBackground(new Color(4,10,13));console.setForeground(new Color(190,210,218));console.setCaretColor(Color.WHITE);console.setFont(new Font(Font.MONOSPACED,Font.PLAIN,12));console.setMargin(new Insets(8,8,8,8));consoles.put(r.id,console);installConsoleStyles(console);StringBuilder old=logs.get(r.id);if(old!=null)for(String line:old.toString().split("\n",-1))appendStyled(console,line+"\n");
        inner.addTab("Console",new JScrollPane(console));inner.addTab("Players ("+r.count+")",placeholder("Live player list for "+r.name));inner.addTab("Rooms",placeholder("SmartFox rooms for "+r.name));inner.addTab("Logs",placeholder("Runtime / Log4j output is mirrored in Console."));inner.addTab("Config",placeholder("Name: "+r.name+"\nIP: "+r.ip+"\nPort: "+r.port+"\nMax: "+r.max+"\nMOTD: "+r.motd));JLabel port=new JLabel(" PORT: "+r.port+" ");port.setForeground(new Color(241,171,50));port.setFont(new Font(Font.MONOSPACED,Font.BOLD,12));card.add(port,BorderLayout.NORTH);card.add(inner,BorderLayout.CENTER);workspaceCards.add(card,String.valueOf(r.id));
    }
    private JComponent placeholder(String text){JTextArea a=new JTextArea(text);a.setEditable(false);a.setBackground(new Color(9,15,19));a.setForeground(new Color(185,202,211));a.setFont(new Font(Font.MONOSPACED,Font.PLAIN,12));a.setMargin(new Insets(10,10,10,10));return new JScrollPane(a);}
    private void installConsoleStyles(JTextPane p){StyledDocument d=p.getStyledDocument();style(d,"normal",new Color(190,205,212));style(d,"green",new Color(95,220,112));style(d,"yellow",new Color(238,190,61));style(d,"red",new Color(241,88,88));style(d,"blue",new Color(67,168,235));style(d,"cyan",new Color(65,210,213));style(d,"gray",new Color(145,158,165));}
    private void style(StyledDocument d,String n,Color c){Style x=d.addStyle(n,null);StyleConstants.setForeground(x,c);StyleConstants.setFontFamily(x,Font.MONOSPACED);StyleConstants.setFontSize(x,12);}
    private String styleFor(String x){String u=x.toUpperCase();if(u.contains("ERROR")||u.contains("FAILED")||u.contains("SEVERE"))return "red";if(u.contains("WARN"))return "yellow";if(u.contains("[MANAGER]")||u.contains("[SMARTFOX]")||u.contains("PORT:"))return "blue";if(u.contains("[DATABASE]")||u.contains("[ENGINE]")||u.contains("[CACHE]")||u.contains("ONLINE")||u.contains("RUNNING"))return "green";if(u.contains("[PLAYERS]")||u.contains("[SERVERCOUNT]"))return "cyan";if(u.startsWith("---")||u.startsWith("CARD:")||u.startsWith("OS.")||u.startsWith("JAVA."))return "gray";return "normal";}
    private void appendStyled(JTextPane p,String x){try{StyledDocument d=p.getStyledDocument();Pattern ansi=Pattern.compile("\\u001B\\[([0-9;]*)m");Matcher m=ansi.matcher(x);int pos=0;String active=styleFor(x);while(m.find()){if(m.start()>pos)d.insertString(d.getLength(),x.substring(pos,m.start()),d.getStyle(active));String[] codes=m.group(1).split(";");for(String c:codes){if("31".equals(c)||"91".equals(c))active="red";else if("32".equals(c)||"92".equals(c))active="green";else if("33".equals(c)||"93".equals(c))active="yellow";else if("34".equals(c)||"94".equals(c))active="blue";else if("36".equals(c)||"96".equals(c))active="cyan";else if("90".equals(c))active="gray";else if("0".equals(c)||"37".equals(c)||"39".equals(c))active="normal";}pos=m.end();}if(pos<x.length())d.insertString(d.getLength(),x.substring(pos),d.getStyle(active));}catch(BadLocationException ignored){}}
    private boolean isRunning(ServerRow s){Process p=processes.get(s.id);return isManagerRow(s)||(p!=null&&p.isAlive());}
    private void updateSummary(){int running=0,players=0;for(ServerRow s:servers.values()){if(isRunning(s))running++;players+=Math.max(0,s.count);}String rr="";ServerRow sel=selected();if(sel!=null&&isRestartPending(sel)){long rem=isManagerRow(sel)?RestartEmulator.getRemainingMillis():Math.max(0L,TimeUnit.MINUTES.toMillis(restartDelayMinutes.getOrDefault(sel.id,5))-(System.currentTimeMillis()-restartRequestedAt.get(sel.id)));rr="  |  RESTART "+String.format("%02d:%02d",rem/60000,(rem/1000)%60);}summary.setText(" STATUS: "+(sel!=null&&isRunning(sel)?"ONLINE":"OFFLINE")+"  |  PLAYERS "+players+"  |  SERVERS "+running+"/"+servers.size()+rr);}

    private final Map<Integer,Long> restartRequestedAt=new ConcurrentHashMap<Integer,Long>();
    private final Map<Integer,Integer> restartDelayMinutes=new ConcurrentHashMap<Integer,Integer>();
    private void toggleRestart(ServerRow r){if(isRestartPending(r))cancelRestart(r);else scheduleRestart(r);}
    private boolean isRestartPending(ServerRow r){if(isManagerRow(r))return RestartEmulator.isScheduled();Long at=restartRequestedAt.get(r.id);return at!=null&&System.currentTimeMillis()-at<TimeUnit.MINUTES.toMillis(6L);}
    private void scheduleRestart(ServerRow r){
        if(!isRunning(r)){append(r.id,"[Manager] Server is offline; starting it instead.");startServer(r);return;}
        JSpinner delay=new JSpinner(new SpinnerNumberModel(5,1,1440,1));
        JPanel prompt=new JPanel(new BorderLayout(8,8));
        prompt.add(new JLabel("Restart in how many minutes?"),BorderLayout.NORTH); prompt.add(delay,BorderLayout.CENTER);
        if(JOptionPane.showConfirmDialog(this,prompt,"Schedule Restart - "+r.name,JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        int minutes=(Integer)delay.getValue();
        if(isManagerRow(r)){
            RestartEmulator.schedule(minutes);restartRequestedAt.put(r.id,System.currentTimeMillis());restartDelayMinutes.put(r.id,minutes);
            append(r.id,"[Manager] "+minutes+" minute restart scheduled through RestartEmulator.java. Use CANCEL RESTART to abort.");updateRestartButton();return;
        }
        try{
            File cancel=new File(runtimeDir(r),".kaiden-cancel-restart"); if(cancel.exists())cancel.delete();
            Files.write(new File(runtimeDir(r),".kaiden-restart").toPath(),Collections.singletonList(String.valueOf(minutes)),StandardCharsets.UTF_8);
            restartRequestedAt.put(r.id,System.currentTimeMillis());restartDelayMinutes.put(r.id,minutes);
            append(r.id,"[Manager] "+minutes+" minute restart scheduled through RestartEmulator.java. Use CANCEL RESTART to abort.");updateRestartButton();
        }catch(Throwable t){append(r.id,"[Manager] Restart request failed: "+t.getMessage());}
    }
    private void cancelRestart(ServerRow r){
        if(isManagerRow(r)){boolean ok=RestartEmulator.cancel();restartRequestedAt.remove(r.id);restartDelayMinutes.remove(r.id);append(r.id,"[Manager] "+(ok?"Restart cancelled.":"No pending restart."));updateRestartButton();return;}
        try{Files.write(new File(runtimeDir(r),".kaiden-cancel-restart").toPath(),Collections.singletonList("cancel"),StandardCharsets.UTF_8);restartRequestedAt.remove(r.id);restartDelayMinutes.remove(r.id);append(r.id,"[Manager] Cancel restart requested.");updateRestartButton();}catch(Throwable t){append(r.id,"[Manager] Cancel restart failed: "+t.getMessage());}
    }
    private void updateRestartButton(){if(restartButton==null)return;ServerRow r=selected();restartButton.setText(r!=null&&isRestartPending(r)?"✕  CANCEL RESTART":"↻  RESTART");}
    private void flushConsoleQueues(){for(Map.Entry<Integer,ConcurrentLinkedQueue<String>> e:pending.entrySet()){JTextPane p=consoles.get(e.getKey());if(p==null)continue;for(int i=0;i<160;i++){String x=e.getValue().poll();if(x==null)break;appendStyled(p,x+"\n");}trimConsole(p,2600);if(selectedServerId!=null&&selectedServerId.equals(e.getKey()))p.setCaretPosition(p.getDocument().getLength());}updateSummary();serverList.repaint();updateRestartButton();}
    private static void trimConsole(JTextPane p,int maxLines){try{Element root=p.getDocument().getDefaultRootElement();int lines=root.getElementCount();if(lines>maxLines){int end=root.getElement(lines-maxLines).getStartOffset();p.getDocument().remove(0,end);}}catch(Exception ignored){}}
    private void clearSelectedConsole(){ServerRow r=selected();if(r==null)return;StringBuilder l=logs.get(r.id);if(l!=null)synchronized(l){l.setLength(0);}JTextPane p=consoles.get(r.id);if(p!=null)p.setText("");}
    private void createDialog(){
        JTextField name=new JTextField(),ip=new JTextField("0.0.0.0"),max=new JTextField("500"),motd=new JTextField("Testing Server"),lang=new JTextField("en");JSpinner port=new JSpinner(new SpinnerNumberModel(nextPort(),1,65535,1));JCheckBox auto=new JCheckBox("Start after creation",true);
        JPanel p=form("Name",name,"IP",ip,"Port",port,"Max players",max,"MOTD",motd,"Language",lang,"",auto);
        if(JOptionPane.showConfirmDialog(this,p,"Create Server",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        try{
            int po=(Integer)port.getValue(),mx=Integer.parseInt(max.getText().trim());String n=name.getText().trim();if(n.isEmpty())throw new Exception("Server name is required.");
            Storage.getInstance().getJdbc().run("INSERT INTO servers (Name,IP,Online,Upgrade,Chat,Count,Max,MOTD,Language,Port,DailyPlayers) VALUES (?,?,0,0,2,0,?,?,?,?,0)",n,ip.getText().trim(),mx,motd.getText().trim(),lang.getText().trim(),po);
            reloadFromDatabase();ServerRow s=findByName(n);if(s!=null){selectId(s.id);if(auto.isSelected())startServer(s);}
        }catch(Throwable t){error("Create failed: "+t.getMessage());}
    }

    private void editDialog(ServerRow s){
        JTextField name=new JTextField(s.name),ip=new JTextField(s.ip),max=new JTextField(String.valueOf(s.max)),motd=new JTextField(s.motd),lang=new JTextField(s.language);JSpinner port=new JSpinner(new SpinnerNumberModel(s.port,1,65535,1));
        JPanel p=form("Name",name,"IP",ip,"Port",port,"Max players",max,"MOTD",motd,"Language",lang);
        if(JOptionPane.showConfirmDialog(this,p,"Edit Server #"+s.id,JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        try{Storage.getInstance().getJdbc().run("UPDATE servers SET Name=?,IP=?,Max=?,MOTD=?,Language=?,Port=? WHERE id=?",name.getText().trim(),ip.getText().trim(),Integer.parseInt(max.getText().trim()),motd.getText().trim(),lang.getText().trim(),(Integer)port.getValue(),s.id);reloadFromDatabase();selectId(s.id);}catch(Throwable t){error("Save failed: "+t.getMessage());}
    }

    private JPanel form(Object... parts){JPanel p=new JPanel(new GridLayout(0,1,3,3));for(int i=0;i<parts.length;i+=2){String label=String.valueOf(parts[i]);if(!label.isEmpty())p.add(new JLabel(label));p.add((Component)parts[i+1]);}return p;}

    private void startServer(ServerRow s){
        Process old=processes.get(s.id);if(old!=null&&old.isAlive())return;
        ServerRow conflict=runningPortConflict(s);if(conflict!=null){error("Port "+s.port+" is already in use by '"+conflict.name+"'. Change one server's Port first.");return;}
        try{
            File dir=runtimeDir(s); prepareRuntime(s,dir);
            List<String> cmd=new ArrayList<>();File j=new File(System.getProperty("java.home"),"bin"+File.separator+(isWindows()?"java.exe":"java"));cmd.add(j.exists()?j.getAbsolutePath():"java");cmd.add("-server");cmd.add("-Xms256m");cmd.add("-Xmx2048m");cmd.add("-Dkaiden.manager.child=true");cmd.add("-Dkaiden.h2.port="+h2PortFor(s));cmd.add("-Dpython.verbose=error");cmd.add("-Dpython.path=Engine/lib/pycore");cmd.add("-Djava.util.logging.config.file=Configuration/logging.properties");cmd.add("-Dlog4j.configuration=file:Configuration/log4j.properties");cmd.add("-cp");cmd.add(isWindows()?".;Configuration/logs;Engine;Engine/KaidenEngine.jar;Engine/lib/*":".:Configuration/logs:Engine:Engine/KaidenEngine.jar:Engine/lib/*");cmd.add("Kaiden.Game.ChildSfsBootstrap");
            ProcessBuilder pb=new ProcessBuilder(cmd);pb.directory(dir);pb.redirectErrorStream(true);pb.environment().put("KAIDEN_CONFIG",new File(dir,"Configuration/Config.osx").getAbsolutePath());Process proc=pb.start();processes.put(s.id,proc);startedAt.put(s.id,System.currentTimeMillis());try{Storage.getInstance().getJdbc().run("UPDATE servers SET Online=1,Count=0 WHERE id=?",s.id);}catch(Throwable ignored){}append(s.id,"[Manager] Starting "+s.name+" on port "+s.port+" (no BAT file)...");
            new Thread(()->pump(s.id,proc),"Kaiden-Console-"+s.id).start();new Thread(()->waitForExit(s,proc),"Kaiden-Wait-"+s.id).start();
        }catch(Throwable t){append(s.id,"[Manager] START FAILED: "+t.getMessage());error("Could not start "+s.name+": "+t.getMessage());}
    }

    private void prepareRuntime(ServerRow s,File dir)throws IOException{
        if(!dir.exists())copyTemplate(templateDir.toPath(),dir.toPath());
        Files.deleteIfExists(new File(dir,".kaiden-restart").toPath());
        Files.deleteIfExists(new File(dir,".kaiden-cancel-restart").toPath());
        ensureRuntimeLicense(dir);
        File xml=new File(dir,"config.xml");writePort(xml,s.port);File cfg=findConfig(dir);setProperty(cfg,"server.name",s.name);setProperty(cfg,"server.interface","false");
        // Always use the newest emulator JAR from the manager/template realm.
        File srcJar=new File(templateDir,"Engine/KaidenEngine.jar"),dstJar=new File(dir,"Engine/KaidenEngine.jar");if(srcJar.exists()){dstJar.getParentFile().mkdirs();Files.copy(srcJar.toPath(),dstJar.toPath(),StandardCopyOption.REPLACE_EXISTING);}
    }


    private void ensureRuntimeLicense(File dir)throws IOException{
        File src=new File(templateDir,"Configuration/logs/licence.sfl");
        File dst=new File(dir,"Configuration/logs/licence.sfl");
        if(!src.exists())throw new IOException("SmartFox licence.sfl was not found at "+src.getAbsolutePath());
        dst.getParentFile().mkdirs();
        Files.copy(src.toPath(),dst.toPath(),StandardCopyOption.REPLACE_EXISTING);
    }

    private void waitForExit(ServerRow s,Process p){
        try{
            int code=p.waitFor(); processes.remove(s.id,p); startedAt.remove(s.id);
            try{Storage.getInstance().getJdbc().run("UPDATE servers SET Online=0,Count=0 WHERE id=?",s.id);}catch(Throwable ignored){}
            append(s.id,"[Manager] Process exited with code "+code+". Port "+s.port+" will be checked before reuse.");
            boolean restart=restartRequestedAt.remove(s.id)!=null; restartDelayMinutes.remove(s.id);
            if(restart){
                append(s.id,"[Manager] Restart countdown completed. Waiting for port "+s.port+" to be released...");
                if(waitForPortFree(s.port,30000L)){
                    append(s.id,"[Manager] Port "+s.port+" is free. Starting "+s.name+" again...");
                    startServer(s);
                }else{
                    append(s.id,"[Manager] RESTART FAILED: port "+s.port+" is still in use after 30 seconds.");
                    SwingUtilities.invokeLater(()->error("Could not restart "+s.name+": port "+s.port+" is still in use."));
                }
            }
        }catch(InterruptedException ignored){Thread.currentThread().interrupt();}
    }
    private void stopServer(ServerRow s){
        restartRequestedAt.remove(s.id); restartDelayMinutes.remove(s.id);
        try{Files.deleteIfExists(new File(runtimeDir(s),".kaiden-restart").toPath()); Files.deleteIfExists(new File(runtimeDir(s),".kaiden-cancel-restart").toPath());}catch(Throwable ignored){}
        Process p=processes.remove(s.id);if(p!=null&&p.isAlive()){append(s.id,"[Manager] Stopping...");p.destroy();try{if(!p.waitFor(8,TimeUnit.SECONDS))p.destroyForcibly(); if(p.isAlive())p.waitFor(5,TimeUnit.SECONDS);}catch(Exception ignored){}}
        try{Storage.getInstance().getJdbc().run("UPDATE servers SET Online=0,Count=0 WHERE id=?",s.id);}catch(Throwable ignored){}startedAt.remove(s.id);reloadFromDatabase();
    }
    private boolean waitForPortFree(int port,long timeoutMs){
        long end=System.currentTimeMillis()+timeoutMs;
        while(System.currentTimeMillis()<end){
            try(ServerSocket socket=new ServerSocket()){socket.setReuseAddress(false);socket.bind(new InetSocketAddress("0.0.0.0",port));return true;}catch(IOException inUse){try{Thread.sleep(250L);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}}
        }
        return false;
    }
    private void deleteRow(ServerRow s){if(JOptionPane.showConfirmDialog(this,"Delete '"+s.name+"' from servers and remove its generated runtime?","Delete Server",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;stopServer(s);try{Storage.getInstance().getJdbc().run("DELETE FROM servers WHERE id=?",s.id);deleteTree(runtimeDir(s).toPath());logs.remove(s.id);reloadFromDatabase();}catch(Throwable t){error("Delete failed: "+t.getMessage());}}

    private void pump(int id,Process p){try(BufferedReader br=new BufferedReader(new InputStreamReader(p.getInputStream()))){String line;while((line=br.readLine())!=null)append(id,line);}catch(IOException e){append(id,"[Manager] Console: "+e.getMessage());}}
    private void append(int id,String line){StringBuilder b=logs.computeIfAbsent(id,k->new StringBuilder());synchronized(b){b.append(line).append('\n');if(b.length()>180000)b.delete(0,b.length()-140000);}pending.computeIfAbsent(id,k->new ConcurrentLinkedQueue<>()).offer(line);}

    // The host SFS is manager-only and never represents a row in `servers`.
    private boolean isManagerRow(ServerRow s){return false;}
    private ServerRow runningPortConflict(ServerRow target){for(ServerRow s:servers.values()){if(s.id==target.id||s.port!=target.port)continue;Process p=processes.get(s.id);if(p!=null&&p.isAlive())return s;}return null;}
    private File runtimeDir(ServerRow s){return new File(runtimeRoot,"server-"+s.id+"-"+safe(s.name));}
    private int h2PortFor(ServerRow s){return 10000+s.id;}
    private int nextPort(){int p=5587;while(true){boolean used=false;for(ServerRow s:servers.values())if(s.port==p){used=true;break;}if(!used)return p;p++;}}
    private ServerRow findByName(String n){for(ServerRow s:servers.values())if(s.name.equalsIgnoreCase(n))return s;return null;}
    private Integer selectedId(){return selectedServerId;}
    private ServerRow selected(){Integer id=selectedId();return id==null?null:servers.get(id);}
    private void withSelected(Action a){ServerRow s=selected();if(s==null){error("Select a server first.");return;}a.run(s);}private interface Action{void run(ServerRow s);}
    private void selectId(int id){selectedServerId=id;serverList.setSelectedValue(id,true);((CardLayout)workspaceCards.getLayout()).show(workspaceCards,String.valueOf(id));}
    private void stopAllChildren(){for(ServerRow s:new ArrayList<>(servers.values()))stopServer(s);}
    private void error(String s){JOptionPane.showMessageDialog(this,s,"Kaiden Server Manager",JOptionPane.ERROR_MESSAGE);}

    private static File findConfig(File root){File a=new File(root,"Configuration/Config.osx");return a.exists()?a:new File(root,"Configuration/config.osx");}
    private static void setProperty(File f,String k,String v)throws IOException{List<String> ls=Files.readAllLines(f.toPath(),StandardCharsets.UTF_8);boolean found=false;for(int i=0;i<ls.size();i++){String x=ls.get(i).trim();if(!x.startsWith("#")&&x.matches(Pattern.quote(k)+"\\s*=.*")){ls.set(i,k+"="+v);found=true;}}if(!found)ls.add(k+"="+v);Files.write(f.toPath(),ls,StandardCharsets.UTF_8);}
    private static void writePort(File f,int p)throws IOException{String x=new String(Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);Matcher m=PORT_PATTERN.matcher(x);if(!m.find())throw new IOException("<ServerPort> was not found in "+f);Files.write(f.toPath(),m.replaceFirst("<ServerPort>"+p+"</ServerPort>").getBytes(StandardCharsets.UTF_8));}
    private static void copyTemplate(Path src,Path dst)throws IOException{Files.walkFileTree(src,new SimpleFileVisitor<Path>(){public FileVisitResult preVisitDirectory(Path d,BasicFileAttributes a)throws IOException{Path rel=src.relativize(d);String r=rel.toString().replace('\\','/');if(r.equals("KaidenRuntime")||r.startsWith("KaidenRuntime/")||r.equals("Configuration/errors"))return FileVisitResult.SKIP_SUBTREE;if(r.equals("Configuration/logs")){Files.createDirectories(dst.resolve(rel));return FileVisitResult.CONTINUE;}Files.createDirectories(dst.resolve(rel));return FileVisitResult.CONTINUE;}public FileVisitResult visitFile(Path f,BasicFileAttributes a)throws IOException{Path rel=src.relativize(f);String r=rel.toString().replace('\\','/');if(r.startsWith("Configuration/logs/")&&!r.equalsIgnoreCase("Configuration/logs/licence.sfl"))return FileVisitResult.CONTINUE;Files.copy(f,dst.resolve(rel),StandardCopyOption.REPLACE_EXISTING);return FileVisitResult.CONTINUE;}});Files.createDirectories(dst.resolve("Configuration/logs"));Files.createDirectories(dst.resolve("Configuration/errors"));}
    private static void deleteTree(Path p)throws IOException{if(!Files.exists(p))return;Files.walkFileTree(p,new SimpleFileVisitor<Path>(){public FileVisitResult visitFile(Path f,BasicFileAttributes a)throws IOException{Files.deleteIfExists(f);return FileVisitResult.CONTINUE;}public FileVisitResult postVisitDirectory(Path d,IOException e)throws IOException{Files.deleteIfExists(d);return FileVisitResult.CONTINUE;}});}
    private static boolean isWindows(){return System.getProperty("os.name","").toLowerCase().contains("win");}private static String safe(String s){return s.replaceAll("[^A-Za-z0-9._-]","_");}
    private static String pid(Process p){try{return String.valueOf(p.getClass().getMethod("pid").invoke(p));}catch(Throwable t){return "-";}}private static String duration(long ms){long x=ms/1000;return String.format("%02d:%02d:%02d",x/3600,(x%3600)/60,x%60);}
    private static final class ServerRow{int id,online,count,max,port,daily;String name,ip,motd,language;}
}
