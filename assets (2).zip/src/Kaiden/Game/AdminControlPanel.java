package Kaiden.Game;

import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import com.sun.management.OperatingSystemMXBean;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.List;
import java.util.Timer;

import static com.google.common.io.Resources.getResource;


public class AdminControlPanel extends JFrame {

    private final JTable playerTable, banTable;
    private final DefaultTableModel playerModel, banModel;
    private final JTextArea chatArea, logArea, systemStatsArea;
    private final JProgressBar cpuBar, memBar, threadBar, gcBar;
    private final JTextField txtGold, txtLevel, txtClass;
    private final JLabel uptimeLabel;
    private final JButton btnSave, btnKick, btnMute, btnTeleport, btnBan, btnLogs, btnRefresh, btnUnban, btnIPLookup;

    private Timer refreshTimer, uptimeTimer, systemStatsTimer;
    private final long startTime = System.currentTimeMillis();
    private final TimeSeries cpuSeries = new TimeSeries("CPU Usage");
    private final TimeSeries memorySeries = new TimeSeries("Memory Usage");

    public AdminControlPanel() {
        ImageIcon myAppImage = loadIcon("javaextensions/Kaiden/Game/Server/Users/Utils/UI/kaiden_icon.gif");
        if(myAppImage != null)
            setIconImage(myAppImage.getImage());
        //applyKaidenDarkBlueTheme();
        applyFantasyBrownTheme();
        createFantasyHeader();
        SwingUtilities.updateComponentTreeUI(this);

        setTitle("Kaiden Engine");
        setSize(1300, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        playerModel = new DefaultTableModel(new Object[]{"Username", "Level", "Gold", "Class", "Room", "Server", "IP"}, 0);
        playerTable = new JTable(playerModel);
        JScrollPane playerScroll = new JScrollPane(playerTable);

        banModel = new DefaultTableModel(new Object[]{"Username", "Reason", "Time"}, 0);
        banTable = new JTable(banModel);
        JScrollPane banScroll = new JScrollPane(banTable);

        chatArea = new JTextArea(8, 40);
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(30, 30, 30));
        chatArea.setForeground(Color.GREEN);
        JScrollPane chatScroll = new JScrollPane(chatArea);

        logArea = new JTextArea(10, 40);
        logArea.setEditable(false);
        logArea.setBackground(new Color(20, 20, 20));
        logArea.setForeground(Color.LIGHT_GRAY);
        JScrollPane logScroll = new JScrollPane(logArea);

        systemStatsArea = new JTextArea(10, 40);
        systemStatsArea.setEditable(false);
        systemStatsArea.setBackground(new Color(15, 15, 15));
        systemStatsArea.setForeground(Color.GREEN);

        cpuBar = new JProgressBar(0, 100);
        cpuBar.setStringPainted(true);
        cpuBar.setForeground(Color.ORANGE);

        memBar = new JProgressBar(0, 100);
        memBar.setStringPainted(true);
        memBar.setForeground(Color.CYAN);

        threadBar = new JProgressBar(0, 500);
        threadBar.setStringPainted(true);
        threadBar.setForeground(Color.MAGENTA);

        gcBar = new JProgressBar(0, 10000);
        gcBar.setStringPainted(true);
        gcBar.setForeground(Color.GREEN);

        JPanel systemPanel = new JPanel(new BorderLayout());
        systemPanel.add(new JScrollPane(systemStatsArea), BorderLayout.CENTER);

        JPanel usagePanel = new JPanel(new GridLayout(4, 1));
        usagePanel.add(cpuBar);
        usagePanel.add(memBar);
        usagePanel.add(threadBar);
        usagePanel.add(gcBar);
        systemPanel.add(usagePanel, BorderLayout.SOUTH);

        JTabbedPane tabs = new JTabbedPane();

        // ===== USERS TAB =====
        JPanel usersTab = new JPanel(new BorderLayout());
        usersTab.add(playerScroll, BorderLayout.CENTER);
        usersTab.add(chatScroll, BorderLayout.SOUTH);

        txtLevel = new JTextField();
        txtGold = new JTextField();
        txtClass = new JTextField();
        btnSave = new JButton("Save");
        btnKick = new JButton("Kick");
        btnMute = new JButton("Mute");
        btnTeleport = new JButton("Teleport");
        btnBan = new JButton("Ban");
        btnUnban = new JButton("Unban");
        btnLogs = new JButton("Reload Logs");
        btnRefresh = new JButton("Refresh");
        btnIPLookup = new JButton("IP Lookup");
        uptimeLabel = new JLabel("Uptime: 00:00:00");

        JPanel editPanel = new JPanel(new GridLayout(4, 4, 10, 10));
        editPanel.add(new JLabel("Level:"));
        editPanel.add(txtLevel);
        editPanel.add(new JLabel("Gold:"));
        editPanel.add(txtGold);
        editPanel.add(new JLabel("Class:"));
        editPanel.add(txtClass);
        editPanel.add(btnSave);
        editPanel.add(btnKick);
        editPanel.add(btnMute);
        editPanel.add(btnTeleport);
        editPanel.add(btnBan);
        editPanel.add(btnUnban);
        editPanel.add(btnLogs);
        editPanel.add(btnRefresh);
        editPanel.add(btnIPLookup);
        editPanel.add(uptimeLabel);

        JPanel entityTab = new JPanel(new GridLayout(2, 3, 10, 10));
        entityTab.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        Color gold = new Color(218, 165, 32);
        //UIManager.put("Table.foreground", gold);

        UIManager.put("foreground", gold);
        JLabel itemCountLabel = new JLabel("Items: 0");
        JLabel mapCountLabel = new JLabel("Maps: 0");
        JLabel questCountLabel = new JLabel("Quests: 0");
        JLabel monsterCountLabel = new JLabel("Monsters: 0");
        JLabel npcCountLabel = new JLabel("NPCs: 0");
        JLabel userCountLabel = new JLabel("Users: 0");


        Font font = new Font("Consolas", Font.BOLD, 18);
        JLabel[] labels = { itemCountLabel, mapCountLabel, questCountLabel, monsterCountLabel, npcCountLabel, userCountLabel };
        for (JLabel lbl : labels) lbl.setFont(font);
        //labels.

        entityTab.add(wrapInPanel("Items", itemCountLabel));
        entityTab.add(wrapInPanel("Maps", mapCountLabel));
        entityTab.add(wrapInPanel("Quests", questCountLabel));
        entityTab.add(wrapInPanel("Monsters", monsterCountLabel));
        entityTab.add(wrapInPanel("NPCs", npcCountLabel));
        entityTab.add(wrapInPanel("Users", userCountLabel));



        tabs.add("Entity Monitor", entityTab);
        usersTab.add(editPanel, BorderLayout.EAST);
        tabs.add("Users", usersTab);

        // ===== OTHER TABS =====
        tabs.add("Ban List", banScroll);
        tabs.add("Server Logs", logScroll);
        tabs.add("Live System Monitor", systemPanel);

        TimeSeriesCollection cpuDataset = new TimeSeriesCollection(cpuSeries);
        JFreeChart cpuChart = ChartFactory.createTimeSeriesChart("CPU Usage Over Time", "Time", "% CPU", cpuDataset);
        tabs.add("CPU Graph", new ChartPanel(cpuChart));

        TimeSeriesCollection memoryDataset = new TimeSeriesCollection(memorySeries);
        JFreeChart memoryChart = ChartFactory.createTimeSeriesChart("Memory Usage Over Time", "Time", "MB", memoryDataset);
        tabs.add("Memory Graph", new ChartPanel(memoryChart));

        // ===== ENTITY MONITOR =====


        Timer entityTimer = new Timer(true);
        entityTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                int items = StorageCache.getInstance().getItemSize();
                int maps = StorageCache.getInstance().getAreaSize();
                int quests = StorageCache.getInstance().getQuestSize();
                int monsters = StorageCache.getInstance().getMonsterSize();
                int npcs = StorageCache.getInstance().getNpcSize();
                int users = Kaiden_Extension.getInstance().getAllUsers().size();

                SwingUtilities.invokeLater(() -> {
                    itemCountLabel.setText("Items: " + items);
                    mapCountLabel.setText("Maps: " + maps);
                    questCountLabel.setText("Quests: " + quests);
                    monsterCountLabel.setText("Monsters: " + monsters);
                    npcCountLabel.setText("NPCs: " + npcs);
                    userCountLabel.setText("Users: " + users);
                });
            }
        }, 0, 3000);

        add(tabs, BorderLayout.CENTER);

        playerTable.getSelectionModel().addListSelectionListener(e -> {
            int row = playerTable.getSelectedRow();
            if (row >= 0) {
                txtLevel.setText(playerModel.getValueAt(row, 1).toString());
                txtGold.setText(playerModel.getValueAt(row, 2).toString());
                txtClass.setText(playerModel.getValueAt(row, 3).toString());
            }
        });

        btnSave.addActionListener(e -> saveChanges());
        btnKick.addActionListener(e -> kickUser());
        btnMute.addActionListener(e -> muteUser());
        btnTeleport.addActionListener(e -> teleportUser());
        btnBan.addActionListener(e -> banUser());
        btnUnban.addActionListener(e -> unbanUser());
        btnLogs.addActionListener(e -> loadLogs());
        btnRefresh.addActionListener(e -> loadPlayers());
        btnIPLookup.addActionListener(e -> ipLookup());

        loadPlayers();
        loadBans();
        loadLogs();
        startUptimeTimer();
        startAutoRefresh();
        startSystemStatsMonitor();
    }


    private void startSystemStatsMonitor() {
        systemStatsTimer = new Timer(true);
        OperatingSystemMXBean osBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        Runtime runtime = Runtime.getRuntime();
        ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
        List<GarbageCollectorMXBean> gcBeans = ManagementFactory.getGarbageCollectorMXBeans();

        systemStatsTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                long usedMemory = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024);
                long maxMemory = runtime.maxMemory() / (1024 * 1024);
                double cpuLoad = osBean.getSystemCpuLoad() * 100;
                int threadCount = threadBean.getThreadCount();

                long gcTime = gcBeans.stream().mapToLong(GarbageCollectorMXBean::getCollectionTime).sum();

                long uptimeSeconds = (System.currentTimeMillis() - startTime) / 1000;
                long hours = uptimeSeconds / 3600;
                long minutes = (uptimeSeconds % 3600) / 60;
                long seconds = uptimeSeconds % 60;

                String healthCpu = cpuLoad >= 80 ? "⚠️ High" : "✅ OK";
                String healthMem = ((usedMemory * 100) / maxMemory) >= 80 ? "⚠️ High" : "✅ OK";

                String stats = String.format(
                        "=== Live System Monitor ===\n" +
                                "CPU Usage: %.2f%% [%s]\n" +
                                "Memory Usage: %dMB / %dMB [%s]\n" +
                                "Thread Count: %d\n" +
                                "GC Time: %d ms\n" +
                                "Uptime: %02d:%02d:%02d\n" +
                                "\n=== System Info ===\n" +
                                "OS: %s\n" +
                                "Architecture: %s\n" +
                                "Cores: %d\n" +
                                "Java Version: %s",
                        cpuLoad, healthCpu,
                        usedMemory, maxMemory, healthMem,
                        threadCount,
                        gcTime,
                        hours, minutes, seconds,
                        System.getProperty("os.name"),
                        System.getProperty("os.arch"),
                        osBean.getAvailableProcessors(),
                        System.getProperty("java.version")
                );

                SwingUtilities.invokeLater(() -> {
                    systemStatsArea.setText(stats);
                    cpuBar.setValue((int) cpuLoad);
                    cpuBar.setString(String.format("CPU: %.2f%%", cpuLoad));
                    int memPercent = (int)((usedMemory * 100) / maxMemory);
                    memBar.setValue(memPercent);
                    memBar.setString("Memory: " + memPercent + "%");
                    threadBar.setValue(threadCount);
                    threadBar.setString("Threads: " + threadCount);
                    gcBar.setValue((int) gcTime);
                    gcBar.setString("GC Time: " + gcTime + " ms");

                    cpuSeries.addOrUpdate(new Second(), cpuLoad);
                    memorySeries.addOrUpdate(new Second(), usedMemory);

                });
            }
        }, 0, 2000);
    }

    private JPanel wrapInPanel(String title, JLabel label) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.add(label);
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.GRAY), title));
        return panel;
    }

    private void kickUser() {
        User user = getSelectedUser();
        if (user != null) {
            //Users.getInstance().updateClass();
            logChat("[System] Kicked " + user.getName());
        }
    }

    private void muteUser() {
        User user = getSelectedUser();
        if (user != null) {
            user.properties.put("muted", true);
            logChat("[System] Muted " + user.getName());
        }
    }

    private void teleportUser() {
        User user = getSelectedUser();
        if (user != null) {
            String target = JOptionPane.showInputDialog(this, "Enter room name:");
            if (target != null) {
                Rooms.getInstance().basicRoomJoin(user, target, "Enter", "Spawn");
                logChat("[System] Teleported " + user.getName() + " to " + target);
            }
        }
    }

    private void banUser() {
        User user = getSelectedUser();
        if (user != null) {
            String reason = JOptionPane.showInputDialog(this, "Ban reason:");
            if (reason != null) {
                //user.getSession().close();
                try (Connection conn = Storage.getInstance().getJdbc().getConnection()) {
                    PreparedStatement stmt = conn.prepareStatement("INSERT INTO users_bans (username, reason, banned_by, ip_address) VALUES (?, ?, ?, ?)");
                    stmt.setString(1, user.getName());
                    stmt.setString(2, reason);
                    stmt.setString(3, "AdminGUI");
                    stmt.setString(4, user.getIpAddress());
                    stmt.executeUpdate();
                    banModel.addRow(new Object[]{user.getName(), reason, new Date().toString()});
                } catch (Exception e) {
                    logChat("[ERROR] Ban DB insert failed: " + e.getMessage());
                }
                logChat("[System] Banned " + user.getName() + " - " + reason);
            }
        }
    }

    private void unbanUser() {
        int row = banTable.getSelectedRow();
        if (row >= 0) {
            String username = (String) banModel.getValueAt(row, 0);
            try (Connection conn = Storage.getInstance().getJdbc().getConnection()) {
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM users_bans WHERE username = ?");
                stmt.setString(1, username);
                stmt.executeUpdate();
                banModel.removeRow(row);
                logChat("[System] Unbanned " + username);
            } catch (Exception e) {
                logChat("[ERROR] Unban DB failed: " + e.getMessage());
            }
        }
    }

    private void ipLookup() {
        User user = getSelectedUser();
        if (user != null) {
            JOptionPane.showMessageDialog(this, user.getName() + " IP: " + user.getIpAddress());
        }
    }

    private void setCacheCountCounter() {


    }

    private void loadPlayers() {
        playerModel.setRowCount(0);
        for (User user : Kaiden_Extension.getInstance().getAllUsers()) {
            Vector<Object> row = new Vector<>();
            row.add(user.properties.get("username"));
            row.add(user.properties.get("level"));
            row.add(user.properties.get("coins"));
            row.add(user.properties.get("classname"));
            Room room = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
            row.add(room != null ? room.getName() : "Unknown");
            row.add(user.properties.get("currentserver"));
            row.add(user.getIpAddress());
            playerModel.addRow(row);
        }
    }

    private void loadBans() {
        banModel.setRowCount(0);
        try (Connection conn = Storage.getInstance().getJdbc().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT username, reason, banned_at FROM users_bans ORDER BY banned_at DESC")) {
            while (rs.next()) {
                banModel.addRow(new Object[]{
                        rs.getString("username"),
                        rs.getString("reason"),
                        rs.getTimestamp("banned_at").toString()
                });
            }
        } catch (Exception e) {
            logChat("[ERROR] Failed to load bans: " + e.getMessage());
        }
    }

    private void loadLogs() {
        logArea.setText("");
        try (Connection conn = Storage.getInstance().getJdbc().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT log_time, level, message FROM servers_logs ORDER BY log_time DESC LIMIT 50")) {
            while (rs.next()) {
                logArea.append("[" + rs.getTimestamp("log_time") + "] " + rs.getString("level") + ": " + rs.getString("message") + "\n");
            }
        } catch (Exception e) {
            logArea.setText("Error loading logs: " + e.getMessage());
        }
    }

    public static void logMessage(String level, String message, String source, String user) {
        String sql = "INSERT INTO servers_logs (log_time, level, message, source, user) VALUES (NOW(), ?, ?, ?, ?)";
        try {
            Storage.getInstance().getJdbc().execute(sql, level, message, source, user);
        } catch (Exception e) {
            System.err.println("[Logging Error] Could not insert log: " + e.getMessage());
        }
    }

    private User getSelectedUser() {
        int row = playerTable.getSelectedRow();
        if (row >= 0) {
            String username = (String) playerModel.getValueAt(row, 0);
            for (User user : Kaiden_Extension.getInstance().getAllUsers()) {
                if (username.equals(user.properties.get("username"))) {
                    return user;
                }
            }
        }
        return null;
    }

    private void logChat(String message) {
        chatArea.append(message + "\n");
    }


    private void startAutoRefresh() {
        refreshTimer = new Timer(true);
        refreshTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> loadPlayers());
                loadLogs();
            }
        }, 0, 5000);

    }

    private static void applyKaidenDarkBlueTheme() {
        Color black = Color.BLACK;
        Color blue = new Color(0, 204, 255); // Bright blue
        Color gray = new Color(80, 80, 80);  // Medium gray for buttons

        UIManager.put("control", black);
        UIManager.put("info", black);
        UIManager.put("nimbusBase", black);
        UIManager.put("nimbusBlueGrey", black);
        UIManager.put("controlText", blue);
        UIManager.put("text", blue);
        UIManager.put("menuText", blue);
        UIManager.put("window", black);
        UIManager.put("windowBorder", black);
        UIManager.put("textHighlight", Color.DARK_GRAY);
        UIManager.put("textHighlightText", blue);
        UIManager.put("Table.background", black);
        UIManager.put("Table.foreground", blue);
        UIManager.put("Table.selectionBackground", gray);
        UIManager.put("Table.selectionForeground", Color.CYAN);
        UIManager.put("Label.foreground", blue);
        UIManager.put("Panel.background", black);
        UIManager.put("Viewport.background", black);
        UIManager.put("ScrollPane.background", black);
        UIManager.put("TextField.background", gray);
        UIManager.put("TextField.foreground", blue);
        UIManager.put("TextField.caretForeground", Color.CYAN);
        UIManager.put("TextArea.background", black);
        UIManager.put("TextArea.foreground", blue);
        UIManager.put("TextArea.caretForeground", Color.CYAN);
        UIManager.put("Button.background", gray);
        UIManager.put("Button.foreground", blue);
        UIManager.put("TabbedPane.background", black);
        UIManager.put("TabbedPane.foreground", blue);
        UIManager.put("TabbedPane.selected", gray);
        UIManager.put("OptionPane.background", black);
        UIManager.put("OptionPane.messageForeground", blue);
        UIManager.put("ToolTip.background", black);
        UIManager.put("ToolTip.foreground", blue);
    }

    private static void applyFantasyBrownTheme() {
        Color darkBrown = new Color(60, 40, 20);
        Color wood = new Color(94, 62, 35);
        Color parchment = new Color(245, 222, 179);
        Color gold = new Color(218, 165, 32);

        UIManager.put("control", darkBrown);
        UIManager.put("info", wood);
        UIManager.put("nimbusBase", wood);
        UIManager.put("nimbusBlueGrey", darkBrown);
        UIManager.put("controlText", gold);
        UIManager.put("text", parchment);
        UIManager.put("menuText", gold);
        UIManager.put("window", darkBrown);
        UIManager.put("windowBorder", wood);
        UIManager.put("textHighlight", wood);
        UIManager.put("textHighlightText", gold);
        UIManager.put("Table.background", wood);
        UIManager.put("Table.foreground", gold);


        UIManager.put("Table.background", wood);
        UIManager.put("Table.foreground", gold);

        UIManager.put("Label.foreground", wood);
        UIManager.put("Panel.background", gold);

        UIManager.put("Table.selectionBackground", new Color(139, 69, 19));
        UIManager.put("Table.selectionForeground", parchment);
        UIManager.put("Label.foreground", gold);
        UIManager.put("Panel.background", darkBrown);
        UIManager.put("Viewport.background", darkBrown);
        UIManager.put("ScrollPane.background", wood);
        UIManager.put("TextField.background", wood);
        UIManager.put("TextField.foreground", parchment);
        UIManager.put("TextField.caretForeground", gold);
        UIManager.put("TextArea.background", wood);
        UIManager.put("TextArea.foreground", parchment);
        UIManager.put("TextArea.caretForeground", gold);
        UIManager.put("Button.background", new Color(85, 58, 35));
        UIManager.put("Button.foreground", gold);
        UIManager.put("TabbedPane.background", darkBrown);
        UIManager.put("TabbedPane.foreground", gold);
        UIManager.put("TabbedPane.selected", wood);
        UIManager.put("OptionPane.background", darkBrown);
        UIManager.put("OptionPane.messageForeground", gold);
        UIManager.put("ToolTip.background", wood);
        UIManager.put("ToolTip.foreground", parchment);
        UIManager.put("entityTab.foreground", gold);
        UIManager.put("entityTab.background", gold);


    }

    // Add this to the beginning of your constructor to use it:
    // applyFantasyBrownTheme();
    // SwingUtilities.updateComponentTreeUI(this);

    // Optional: Add a custom fantasy-style header
    private JPanel createFantasyHeader() {
        JPanel header = new JPanel();
        header.setBackground(new Color(60, 40, 20));
        JLabel title = new JLabel("⚔️ Kaiden MMORPG Admin Panel ⚔️");
        title.setFont(new Font("Serif", Font.BOLD, 28));
        title.setForeground(new Color(218, 165, 32));
        header.add(title);
        return header;
    }


    private static void applyDarkTheme() {
        UIManager.put("control", Color.BLACK);
        UIManager.put("info", Color.BLACK);
        UIManager.put("nimbusBase", Color.BLACK);
        UIManager.put("nimbusBlueGrey", Color.BLACK);
        UIManager.put("controlText", Color.WHITE);
        UIManager.put("text", Color.WHITE);
        UIManager.put("menuText", Color.WHITE);
        UIManager.put("window", Color.BLACK);
        UIManager.put("windowBorder", Color.BLACK);
        UIManager.put("textHighlight", Color.DARK_GRAY);
        UIManager.put("textHighlightText", Color.WHITE);
        UIManager.put("Table.background", Color.BLACK);
        UIManager.put("Table.foreground", Color.WHITE);
        UIManager.put("Table.selectionBackground", new Color(60, 60, 60));
        UIManager.put("Table.selectionForeground", Color.CYAN);
        UIManager.put("Label.foreground", Color.WHITE);
        UIManager.put("Panel.background", Color.BLACK);
        UIManager.put("Viewport.background", Color.BLACK);
        UIManager.put("ScrollPane.background", Color.BLACK);
        UIManager.put("TextField.background", Color.DARK_GRAY);
        UIManager.put("TextField.foreground", Color.WHITE);
        UIManager.put("TextField.caretForeground", Color.CYAN);
        UIManager.put("TextArea.background", Color.BLACK);
        UIManager.put("TextArea.foreground", Color.LIGHT_GRAY);
        UIManager.put("TextArea.caretForeground", Color.GREEN);
        UIManager.put("Button.background", Color.DARK_GRAY);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("TabbedPane.background", Color.BLACK);
        UIManager.put("TabbedPane.foreground", Color.WHITE);
        UIManager.put("TabbedPane.selected", Color.DARK_GRAY);
        UIManager.put("OptionPane.background", Color.BLACK);
        UIManager.put("OptionPane.messageForeground", Color.WHITE);
        UIManager.put("OptionPane.foreground", Color.WHITE);
        UIManager.put("ToolTip.background", Color.BLACK);
        UIManager.put("ToolTip.foreground", Color.YELLOW);
    }

    private void saveChanges() {
        int row = playerTable.getSelectedRow();
        if (row >= 0) {
            User u = Kaiden_Extension.getInstance().getZone().getUserByName(getSelectedUser().getName());
            playerModel.setValueAt(txtLevel.getText(), row, 1);
            playerModel.setValueAt(txtGold.getText(), row, 2);
            playerModel.setValueAt(txtClass.getText(), row, 3);
            Users.getInstance().createClass(u, txtClass.getText());
            JOptionPane.showMessageDialog(this, "Changes saved locally. Server sync needed.");
        }
    }

    private void startUptimeTimer() {
        uptimeTimer = new Timer(true);
        uptimeTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                long uptimeSeconds = (System.currentTimeMillis() - startTime) / 1000;
                long hours = uptimeSeconds / 3600;
                long minutes = (uptimeSeconds % 3600) / 60;
                long seconds = uptimeSeconds % 60;

                SwingUtilities.invokeLater(() ->
                        uptimeLabel.setText(String.format("Uptime: %02d:%02d:%02d", hours, minutes, seconds))
                );
            }
        }, 0, 1000);
    }

    private ImageIcon loadIcon(String strPath)
    {
        URL imgURL = getResource(strPath);
        if(imgURL != null)
            return new ImageIcon(imgURL);
        else
            return null;
    }
    public static void Interface(Kaiden_Engine engine) {

        SwingUtilities.invokeLater(() -> new AdminControlPanel().setVisible(true));
    }
}
