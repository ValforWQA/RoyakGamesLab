package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;


@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class Mon extends CommandPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params.length < 2) {
            throw new RequestExternalPacketException("Usage: /mon <MonsterID>");
        }

        int monsterId;
        try {
            monsterId = Integer.parseInt(this.params[1]);
        } catch (NumberFormatException e) {
            throw new RequestExternalPacketException("MonsterID must be a number.");
        }

        if (monsterId <= 0) {
            throw new RequestExternalPacketException("MonsterID must be greater than zero.");
        }

        // Find the room the admin is currently in
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("You are not in a valid room.");
        }


        Rooms.getInstance().spawnMonster(room, this.user, monsterId);
    }
}
