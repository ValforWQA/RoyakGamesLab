package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class SpawnBot extends CommandPacketHandler {
    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params.length < 2) {
            throw new RequestExternalPacketException("Usage: /spawnbot <count> [attackMs] [moveMs] [allauras]");
        }

        int count;
        int attackMs = 600;
        int moveMs = 1000;
        boolean allAuras = true;
        try {
            count = Integer.parseInt(this.params[1]);
            if (this.params.length > 2) attackMs = Integer.parseInt(this.params[2]);
            if (this.params.length > 3) moveMs = Integer.parseInt(this.params[3]);
            if (this.params.length > 4) allAuras = Boolean.parseBoolean(this.params[4]) || "allauras".equalsIgnoreCase(this.params[4]);
        } catch (Exception e) {
            throw new RequestExternalPacketException("Usage: /spawnbot <count> [attackMs] [moveMs] [allauras]");
        }

        if (count <= 0) throw new RequestExternalPacketException("Count must be greater than 0.");
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) throw new RequestExternalPacketException("You are not in a valid room.");

        BotManager.getInstance().spawnBots(room, this.user, count, attackMs, moveMs, allAuras);
    }
}
