package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class DevBots extends CommandPacketHandler {
    @Override
    public void handle() throws RequestExternalPacketException {
        if (params.length < 2) throw new RequestExternalPacketException("Usage: /devbots <spawn|clear|idle|stop|move|follow|combat|travel> [count]");
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
        if (room == null) throw new RequestExternalPacketException("Not in a room.");
        String action = params[1].toLowerCase(java.util.Locale.ENGLISH);
        BotManager bots = BotManager.getInstance();
        if ("spawn".equals(action)) {
            int count;
            try { count = Integer.parseInt(params.length > 2 ? params[2] : "1"); }
            catch (NumberFormatException e) { throw new RequestExternalPacketException("Invalid bot count."); }
            if (count < 1 || count > 50) throw new RequestExternalPacketException("Bot count must be 1 to 50.");
            bots.spawnBots(room, user, count, 600, 1000, true);
            return;
        }
        if ("clear".equals(action)) {
            int removed = bots.clearBots(room);
            Kaiden_Extension.getInstance().send(new String[]{"server", "Cleared " + removed + " bots."}, user);
            return;
        }
        if (!("idle".equals(action) || "stop".equals(action) || "move".equals(action) ||
              "follow".equals(action) || "combat".equals(action) || "travel".equals(action)))
            throw new RequestExternalPacketException("Unknown bot action: " + action);
        int changed = bots.controlBots(room, user, action);
        Kaiden_Extension.getInstance().send(new String[]{"server", "Bot mode " + action + " applied to " + changed + " bots."}, user);
    }
}
