
package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

/**
 * /delnpc <NpcMapID>
 *
 * Removes a single dynamic NPC instance from the current room.
 */
@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = false, isAdmin = true)
public class DelNpc extends CommandPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params.length < 2) {
            throw new RequestExternalPacketException("Usage: /delnpc <NpcMapID>");
        }

        int npcMapId;
        try {
            npcMapId = Integer.parseInt(this.params[1]);
        } catch (NumberFormatException e) {
            throw new RequestExternalPacketException("NpcMapID must be a number.");
        }

        if (npcMapId <= 0) {
            throw new RequestExternalPacketException("NpcMapID must be greater than zero.");
        }

        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("You are not in a valid room.");
        }

        Rooms.getInstance().adminRemoveNpc(room, npcMapId);
    }
}
