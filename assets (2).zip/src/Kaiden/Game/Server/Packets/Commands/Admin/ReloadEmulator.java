package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = false, isAdmin = true)
public class ReloadEmulator extends CommandPacketHandler {

    public void handle() {
        long start = System.currentTimeMillis();

        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow",
                    "[Reload] /reloademulator requested by " + (this.user == null ? "unknown" : this.user.getName())
            );

            Kaiden_Engine.getInstance().reloadRuntimeSystems();

            if (this.user != null) {
                Kaiden_Extension.getInstance().send(
                        new String[]{"server", "Emulator runtime reloaded safely in " + (System.currentTimeMillis() - start) + "ms. Online players were not kicked and rooms were not cleared."},
                        this.user
                );
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[Reload] Command failed: " + e.getMessage());

            if (this.user != null) {
                Kaiden_Extension.getInstance().send(
                        new String[]{"server", "Reload failed: " + e.getMessage()},
                        this.user
                );
            }
        }
    }
}
