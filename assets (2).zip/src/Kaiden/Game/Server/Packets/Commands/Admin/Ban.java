package Kaiden.Game.Server.Packets.Commands.Admin;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = false, isAdmin = true)
public class Ban extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        User ban = Kaiden_Extension.getInstance().getZone().getUserByName(this.params[1].toLowerCase());
        if (ban != null) {
            int banTime = (Integer.parseInt(this.params[2]) > 100000) ? 100000 : Integer.parseInt(this.params[2]);
            Users.getInstance().ban(ban, "[Command] Banned by: " + this.user.properties.get(Properties.USERNAME), "You were banned from playing by [" + this.user.properties.get(Properties.USERNAME) + "] for " + banTime + " hour(s)", banTime);
        } else {
            throw new RequestExternalPacketException("Player \"" + this.params[1].toLowerCase() + "\" could not be found.");
        }
    }
}