package Kaiden.Game.Server.Packets.Commands.Admin;


import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.QuestRewardBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = false, isAdmin = true)
public class lookQuest extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        JSONObject q = new JSONObject();
        JSONObject arrQuests = new JSONObject();
        JSONObject reqdArray = new JSONObject();
        JSONArray reqd = new JSONArray();
        String[] arr$ = params;
        int len$ = params.length;

        for (int i$ = 0; i$ < len$; ++i$) {
            String strId = arr$[i$];
            int questId = Integer.parseInt(strId);
            QuestBean questObj = StorageCache.getInstance().getQuest(questId);
            if (questObj != null) {
                if (!questObj.locations.isEmpty()) {
                    int quest = StorageCache.getInstance().getArea(room.getName().split("-")[0]).getId();
                    if (!questObj.locations.contains(quest)) {
                        Users.getInstance().log(user, "Invalid Quest Load", "Quest load triggered at different location.");
                        return;
                    }
                }

                JSONObject var26 = new JSONObject();
                JSONObject oRewards = new JSONObject();
                JSONArray rewC = new JSONArray();
                JSONArray rewS = new JSONArray();
                JSONArray rewR = new JSONArray();
                JSONArray newRand = new JSONArray();
                JSONArray rewards = new JSONArray();
                if (questObj.rewards.size() > 0) {
                    for (QuestRewardBean reward : questObj.rewards) {
                        ItemBean item = StorageCache.getInstance().getItem(reward.itemId);
                        if (item != null) {
                            JSONObject itemJSON = item.getItemJSON();
                            itemJSON.put("iQty", reward.quantity);
                            JSONObject itemObj = new JSONObject();
                            itemObj.put("ItemID", reward.itemId);
                            itemObj.put("QuestID", questId);
                            itemObj.put("iRate", reward.rate);
                            itemObj.put("iType", 0);
                            itemObj.put("iQty", reward.quantity);
                            rewards.add(itemObj);
                            switch (reward.type) {
                                case "C":
                                    rewC.add(itemJSON);
                                    break;
                                case "S":
                                    rewS.add(itemJSON);
                                    break;
                                case "R":
                                    rewR.add(itemJSON);
                                    break;
                                case "rand":
                                    newRand.add(itemJSON);
                                    break;
                            }
                        }
                    }
                    if (!rewC.isEmpty()) {
                        oRewards.put("itemsC", rewC);
                    }
                    if (!rewS.isEmpty()) {
                        oRewards.put("itemsS", rewS);
                    }
                    if (!rewR.isEmpty()) {
                        oRewards.put("itemsR", rewR);
                    }
                    if (!newRand.isEmpty()) {
                        oRewards.put("itemsrand", newRand);
                    }
                }
                for (Map.Entry<Integer, Integer> entry : questObj.required.entrySet()) {
                    int itemId = entry.getKey();
                    int quantity = entry.getValue();
                    ItemBean item = StorageCache.getInstance().getItem(itemId);
                    if (item != null) {
                        JSONObject itemJSON = item.getItemJSON();
                        reqdArray.put(String.valueOf(itemId), itemJSON);
                        JSONObject itemJSONObject = new JSONObject();
                        itemJSONObject.put("ItemID", itemId);
                        itemJSONObject.put("QuestID", questId);
                        itemJSONObject.put("iQty", quantity);
                        reqd.add(itemJSONObject);
                    }
                }
                JSONArray var27 = new JSONArray();
                JSONObject var28 = new JSONObject();
                for (Object o : questObj.requirements.entrySet()) {
                    Map.Entry var30 = (Map.Entry) o;
                    int var31 = (Integer) var30.getKey();
                    int var32 = (Integer) var30.getValue();
                    ItemBean var33 = StorageCache.getInstance().getItem(var31);
                    if (var33 != null) {
                        JSONObject item = var33.getItemJSON();
                        var28.put(var31, item);
                        JSONObject turnInObj = new JSONObject();
                        turnInObj.put("ItemID", String.valueOf(var31));
                        turnInObj.put("QuestID", questId);
                        turnInObj.put("iQty", var32);
                        var27.add(turnInObj);
                    }
                }
                var26.put("FactionID", questObj.getFactionId());
                var26.put("sFaction", StorageCache.getInstance().getFaction(questObj.getFactionId()));
                var26.put("QuestID", questId);
                var26.put("bOnce", questObj.isOnce() ? 1 : 0);
                var26.put("bStaff", 0);
                var26.put("bUpg", questObj.isUpgrade() ? 1 : 0);
                if (questObj.getReqClassId() > 0) {
                    var26.put("sClass", StorageCache.getInstance().getItem(questObj.getReqClassId()).getName());
                }
                var26.put("iClass", questObj.getReqClassId());
                var26.put("iExp", questObj.getExperience());
                var26.put("iGold", questObj.getGold());
                var26.put("iLvl", questObj.getLevel());
                //var26.put("iLvl", questObj.getLevel());
                var26.put("intAmount", questObj.getCoin());
                var26.put("iRep", questObj.getReputation());
                var26.put("iReqCP", questObj.getReqClassPoints());
                var26.put("iReqRep", questObj.getReqReputation());
                var26.put("iSlot", questObj.getSlot());
                var26.put("iValue", questObj.getValue());
                var26.put("iWar", 0);
                var26.put("oItems", var28);
                var26.put("oRewards", oRewards);
                var26.put("reward", rewards);
                var26.put("sDesc", questObj.getDescription());
                var26.put("sEndText", questObj.getEndText());
                var26.put("sName", questObj.getName());
                var26.put("turnin", var27);
                if (questObj.required.size() > 0) {
                    var26.put("reqd", reqd);
                    var26.put("oReqd", reqdArray);
                }
                if (!questObj.getField().isEmpty()) {
                    var26.put("sField", questObj.getField());
                    var26.put("iIndex", questObj.getIndex());
                }
                arrQuests.put(strId, var26);
            }
        }
        q.put("cmd", "getQuests");
        q.put("quests", arrQuests);
        Kaiden_Extension.getInstance().send(q, user);
    }
}
