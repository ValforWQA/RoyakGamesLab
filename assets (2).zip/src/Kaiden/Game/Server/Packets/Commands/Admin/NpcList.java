
package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

/**
 * /npc list
 *
 * Lists all dynamic NPCs currently registered in the room.
 * This simply prints informational messages to the admin.
 */
@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = false, isAdmin = true)
public class NpcList extends CommandPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("You are not in a valid room.");
        }

        Rooms.getInstance().adminListNpcs(room, this.user);
    }
}
