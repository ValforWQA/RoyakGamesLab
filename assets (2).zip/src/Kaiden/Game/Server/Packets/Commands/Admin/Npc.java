
package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

/**
 * /npc <NpcID>
 *
 * Spawns a dynamic NPC in the current room at the admin's position.
 * The heavy lifting is delegated to Rooms.adminSpawnNpc(...)
 * so that all map / persistence logic stays in one place.
 */
@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class Npc extends CommandPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params.length < 2) {
            throw new RequestExternalPacketException("Usage: /npc <NpcID>");
        }

        int npcId;
        try {
            npcId = Integer.parseInt(this.params[1]);
        } catch (NumberFormatException e) {
            throw new RequestExternalPacketException("NpcID must be a number.");
        }

        if (npcId <= 0) {
            throw new RequestExternalPacketException("NpcID must be greater than zero.");
        }

        // Find the room the admin is currently in
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("You are not in a valid room.");
        }

        // Delegate to Rooms, which handles persistence + packet send
        Rooms.getInstance().adminSpawnNpc(room, this.user, npcId);
    }
}
