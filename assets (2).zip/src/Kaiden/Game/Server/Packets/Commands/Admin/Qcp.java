package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Staff-only quest requirement drop tester. Usage: /qcp <questId> */
@CommandHandler(isUser = false, isVIP = false, isHelper = false,
        isGameMaster = false, isModerator = true, isAdmin = true)
public class Qcp extends CommandPacketHandler {
    @Override
    @SuppressWarnings("unchecked")
    public void handle() throws RequestExternalPacketException {
        if (params == null || params.length < 2)
            throw new RequestExternalPacketException("Usage: /qcp <questId>");
        int questId;
        try { questId = Integer.parseInt(params[1]); }
        catch (NumberFormatException e) { throw new RequestExternalPacketException("Invalid QuestID."); }
        if (questId <= 0) throw new RequestExternalPacketException("QuestID must be positive.");
        if (!QuestProgressManager.reloadActiveQuests(user))
            throw new RequestExternalPacketException("Could not verify accepted quests.");
        Set<Integer> active = (Set<Integer>) user.properties.get(Properties.QUESTS);
        if (active == null || !active.contains(questId)) {
            Kaiden_Extension.getInstance().sendToUser("message", "Accept quest " + questId + " first.", user);
            return;
        }
        QuestBean quest = StorageCache.getInstance().getQuest(questId);
        if (quest == null || quest.requirements == null || quest.requirements.isEmpty()) {
            Kaiden_Extension.getInstance().sendToUser("message", "No turn-in items for quest " + questId, user);
            return;
        }
        Set<UserDrop> drops = new HashSet<UserDrop>();
        for (Map.Entry<Integer, Integer> entry : quest.requirements.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null || entry.getValue() <= 0) continue;
            ItemBean item = StorageCache.getInstance().getItem(entry.getKey());
            if (item == null) continue;
            drops.add(new UserDrop(entry.getKey(), Math.min(entry.getValue(), Math.max(1, item.getStack())), false));
        }
        if (drops.isEmpty()) return;
        Users.getInstance().dropItems(user, drops);
        Kaiden_Extension.getInstance().sendToUser("message", "Quest " + questId + ": processed " + drops.size() + " required item type(s).", user);
    }
}
