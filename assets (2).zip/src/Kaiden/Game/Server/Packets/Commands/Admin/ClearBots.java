package Kaiden.Game.Server.Packets.Commands.Admin;

import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class ClearBots extends CommandPacketHandler {
    @Override
    public void handle() throws RequestExternalPacketException {
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) throw new RequestExternalPacketException("You are not in a valid room.");
        int removed = BotManager.getInstance().clearBots(room);
        Kaiden_Extension.getInstance().send(new String[]{"server", "Cleared " + removed + " visible player bots."}, this.user);
    }
}
