package Kaiden.Game.Server.Packets.Commands.Admin;


import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.CommandPacketManager;
import Kaiden.Game.Server.Packets.Manager.ExternalPacketManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.InternalPacketManager;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;


@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class Clear extends CommandPacketHandler {

    public void handle() {
        String command = this.params[1].toLowerCase();
        long start = System.currentTimeMillis();
        if (command.equals("config")) {
            Configuration.load();
        } else {
            if (command.equals("dev")) {
                InternalPacketManager.getInstance();
                ExternalPacketManager.getInstance();
                CommandPacketManager.getInstance();
            }
            StorageCache.getInstance().RetrieveStorageBeans(this.params[1].toLowerCase());
            JSONObject clearshop = new JSONObject();
            clearshop.put("cmd", "rfcs");
            clearshop.put("Clear", true);
            Kaiden_Extension.getInstance().send(clearshop, user);
        }

        Kaiden_Extension.getInstance().send(new String[]{"server", (System.currentTimeMillis() - start) + "ms to clear the cache."}, this.user);
    }
}