package Kaiden.Game.Server.Packets.Commands;



import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Users;

@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class Uopref extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        Users.getInstance().changePreferences(this.user, this.params[1], Boolean.parseBoolean(this.params[2]));
    }
}
