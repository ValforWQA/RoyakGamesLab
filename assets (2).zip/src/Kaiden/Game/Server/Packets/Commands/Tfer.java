package Kaiden.Game.Server.Packets.Commands;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import net.sf.json.JSONObject;

@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class Tfer extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String tfer = this.params[2].toLowerCase();
        if (tfer.contains("guildhall")) {
            int guildId = (int) this.user.properties.get("guildid");
            if (guildId <= 0) {
                throw new RequestExternalPacketException("You are not in a guild!");
            }
            JSONObject roomToJoin = (JSONObject) this.user.properties.get("guildobj");
            String userFrame = roomToJoin.getString("Name");
            //if (!Server.getInstance().manageCache().areas.containsKey(userFrame)) {
            //    Hall userPad = new Hall(guildId);
            //    World.getInstance().manageCache().areas.put(userFrame, userPad);
            //}
            Rooms.getInstance().basicRoomJoin(this.user, userFrame);
        } else {
            Rooms.getInstance().basicRoomJoin(this.user, tfer);
            //SmartFoxServer.log.info("TFER");
        }
    }
}
