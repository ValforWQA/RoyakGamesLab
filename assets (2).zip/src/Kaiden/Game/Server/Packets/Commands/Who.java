package Kaiden.Game.Server.Packets.Commands;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class Who extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        JSONObject who = new JSONObject();
        JSONObject users = new JSONObject();
        for (User _user : Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom()).getAllPlayers()) {
            JSONObject uObj = new JSONObject();
            uObj.put("iLvl", _user.properties.get("level"));
            uObj.put("ID", _user.properties.get("dbId"));
            uObj.put("sName", _user.properties.get("username"));
            uObj.put("sClass", _user.properties.get("classname"));
            users.put(String.valueOf(_user.getUserId()), uObj);
        }
        who.put("cmd", "who");
        who.put("users", users);
        Kaiden_Extension.getInstance().send(who, this.user);
    }
}
