package Kaiden.Game.Server.Packets.Commands;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;

@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class Mute extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        if (this.user.isAdmin() || this.user.isModerator()) {

        } else {

        }
    }
}