package Kaiden.Game.Server.Packets.Commands;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;


@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class ReportLang extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        String player = this.params[1];
        int category = Integer.parseInt(this.params[2]);
        String description = this.params[3];
        if (this.params[3].contains("Type reason for report here.")) {
            throw new RequestExternalPacketException("Please enter valid description");
        } else if ((int) this.user.properties.get(Properties.LEVEL) < 3) {
            throw new RequestExternalPacketException("You can't use this feature while you're level.");
        } else {
            String strCategory = null;
            if (category == 0) {
                strCategory = "Abusive Language (Swearing)";
            } else if (category == 1) {
                strCategory = "Following/Griefing Another Player";
            } else if (category == 2) {
                strCategory = "Harassment/Scamming";
            }
            Storage.getInstance().getJdbc().run("INSERT INTO users_reports (UserID, TargetName, Category, Description, DateSubmitted) VALUES (?, ?, ?, ?, NOW())", this.user.properties.get(Properties.ID), player, strCategory, description);
            Kaiden_Extension.getInstance().send(new String[]{"server", "You have reported " + player + ". Our moderators will review your report as soon as possible!"}, this.user);
        }
    }
}
