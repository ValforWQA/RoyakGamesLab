package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Server;
import Kaiden.Kaiden_Extension;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Iay extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (this.params[1].startsWith("@")) {
            Server.getInstance().sendServerMessage(this.params[1].substring(1));
        } else {
            String username = this.user.getName();
            String message = this.params[1];
            if (this.params[1].contains("@")) {
                username = this.params[1].split("@")[0].toLowerCase();
                message = this.params[1].split("@")[1];
            }
            Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "(" + username + "): " + message});
        }
    }
}