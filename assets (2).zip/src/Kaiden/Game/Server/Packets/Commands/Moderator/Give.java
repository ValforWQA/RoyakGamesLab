package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Database.Beans.AchievementBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Give extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (this.params.length > 3) {
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(this.params[3].toLowerCase());
            if (client != null) {
                switch (this.params[1]) {
                    case "cp": {
                        Users.getInstance().giveRewards(client, 0, 0, Integer.parseInt(this.params[2]), 0, 0, 0, 0,-1, client.getUserId(), "p");
                        break;
                    }
                    case "coin": {
                        Users.getInstance().giveRewards(client, 0, 0, 0, 0, Integer.parseInt(this.params[2]), 0, 0,-1, client.getUserId(), "p");
                        break;
                    }
                    case "gold": {
                        Users.getInstance().giveRewards(client, 0, Integer.parseInt(this.params[2]), 0, 0, 0, 0, 0, -1, client.getUserId(), "p");
                        break;
                    }
                    case "level": {
                        Users.getInstance().levelUp(client, Integer.parseInt(this.params[2]));
                        break;
                    }
                    case "achievement": {
                        AchievementBean achievement = StorageCache.getInstance().getAchievement(Integer.valueOf(this.params[2]));
                        if (achievement != null) {
                            Users.getInstance().giveAchievement(client, achievement.getId());
                        }
                        break;
                    }
                    default: {
                        break;
                    }
                }
            }
        } else {
            switch (this.params[1]) {
                case "cp": {
                    Users.getInstance().giveRewards(this.user, 0, 0, Integer.parseInt(this.params[2]), 0, 0,  0,0,-1, this.user.getUserId(), "p");
                    break;
                }
                case "coin": {
                    Users.getInstance().giveRewards(this.user, 0, 0, 0, 0, Integer.parseInt(this.params[2]), 0, 0, -1, this.user.getUserId(), "p");
                    break;
                }
                case "gold": {
                    Users.getInstance().giveRewards(this.user, 0, Integer.parseInt(this.params[2]), 0, 0, 0, 0,0, -1, this.user.getUserId(), "p");
                    break;
                }
                case "level": {
                    Users.getInstance().levelUp(this.user, Integer.parseInt(this.params[2]));
                    break;
                }
                case "achievement": {
                    AchievementBean achievement = StorageCache.getInstance().getAchievement(Integer.valueOf(this.params[2]));
                    if (achievement != null) {
                        Users.getInstance().giveAchievement(this.user, achievement.getId());
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        }
    }
}
