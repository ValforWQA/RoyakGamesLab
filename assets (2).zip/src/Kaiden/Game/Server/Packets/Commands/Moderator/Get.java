package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Database.Beans.AchievementBean;
import Kaiden.Database.Beans.FactionBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Query.UsersQuery;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Get extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (this.params == null || this.params.length < 3) {
            return;
        }

        String rewardType = this.params[1] == null ? "" : this.params[1].toLowerCase();

        if ("rep".equals(rewardType)) {
            handleRep();
            return;
        }

        User targetUser = this.user;
        if (this.params.length > 3) {
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(this.params[3].toLowerCase());
            if (client == null) {
                return;
            }
            targetUser = client;
        }

        switch (rewardType) {
            case "cp": {
                Users.getInstance().giveRewards(targetUser, 0, 0, Integer.parseInt(this.params[2]), 0, 0, 0, 0, -1, targetUser.getUserId(), "p");
                break;
            }
            case "coin": {
                Users.getInstance().giveRewards(targetUser, 0, 0, 0, 0, Integer.parseInt(this.params[2]), 0, 0, -1, targetUser.getUserId(), "p");
                break;
            }
            case "gold": {
                Users.getInstance().giveRewards(targetUser, 0, Integer.parseInt(this.params[2]), 0, 0, 0, 0, 0, -1, targetUser.getUserId(), "p");
                break;
            }
            case "level": {
                Users.getInstance().levelUp(targetUser, Integer.parseInt(this.params[2]));
                break;
            }
            case "upgradedays": {
                UsersQuery.getInstance().giveUpgradeDays(targetUser, Integer.parseInt(this.params[2]));
                Kaiden_Extension.getInstance().sendZoneMessage("moderator", "You have given yourself " + Integer.parseInt(this.params[2]) + " upgrade days!", targetUser);
                break;
            }
            case "plog": {
                Users.getInstance().processLogin(targetUser);
                Kaiden_Extension.getInstance().sendZoneMessage("dev", "processing you login request.", targetUser);
                break;
            }
            case "achievement": {
                AchievementBean achievement = StorageCache.getInstance().getAchievement(Integer.valueOf(this.params[2]));
                if (achievement != null) {
                    Users.getInstance().giveAchievement(targetUser, achievement.getId());
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    private void handleRep() throws RequestExternalPacketException {
        if (this.params.length < 4) {
            throw new RequestExternalPacketException("Usage: /get rep <amount> <factionId> or /get rep <amount> <player> <factionId>");
        }

        int repAmount;
        int factionId;
        User targetUser = this.user;

        try {
            repAmount = Integer.parseInt(this.params[2]);
        } catch (Exception e) {
            throw new RequestExternalPacketException("Invalid reputation amount.");
        }

        if (this.params.length >= 5) {
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(this.params[3].toLowerCase());
            if (client == null) {
                throw new RequestExternalPacketException("Target player not found: " + this.params[3]);
            }
            targetUser = client;
            try {
                factionId = Integer.parseInt(this.params[4]);
            } catch (Exception e) {
                throw new RequestExternalPacketException("Invalid faction id.");
            }
        } else {
            try {
                factionId = Integer.parseInt(this.params[3]);
            } catch (Exception e) {
                throw new RequestExternalPacketException("Invalid faction id.");
            }
        }

        Users.getInstance().giveRewards(targetUser, 0, 0, 0, repAmount, 0, 0, 0, factionId, targetUser.getUserId(), "p");

        FactionBean faction = StorageCache.getInstance().getFactionInfo(factionId);
        String factionName = faction != null ? faction.getName() : String.valueOf(factionId);
        Kaiden_Extension.getInstance().sendZoneMessage("moderator", "You have received reputation for the faction " + factionName + ".", targetUser);
    }
}
