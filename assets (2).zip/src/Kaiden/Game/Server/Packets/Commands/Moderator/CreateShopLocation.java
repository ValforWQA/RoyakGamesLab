package Kaiden.Game.Server.Packets.Commands.Moderator;

import Kaiden.Database.Beans.ShopBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = false, isModerator = true, isAdmin = true)
public class CreateShopLocation extends CommandPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        int shopId;

        if (this.params.length > 1 && this.params[1] != null && !this.params[1].trim().isEmpty()) {
            try {
                shopId = Integer.parseInt(this.params[1]);
            } catch (NumberFormatException ex) {
                send("Usage: /createshoplocation [shopId] - omit shopId to use the last shop you opened.");
                return;
            }
        } else {
            Object lastShop = this.user.properties.get("lastShopId");
            if (!(lastShop instanceof Integer)) {
                send("Open a shop first, or use /createshoplocation <shopId>.");
                return;
            }
            shopId = (Integer) lastShop;
        }

        ShopBean shop = StorageCache.getInstance().getShop(shopId);
        if (shop == null) {
            send("Shop " + shopId + " does not exist.");
            return;
        }

        Room currentRoom = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (currentRoom == null) {
            send("Could not determine your current room.");
            return;
        }

        String mapName = currentRoom.getName().split("-")[0];
        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area == null) {
            send("Map '" + mapName + "' is not registered in the maps/areas cache.");
            return;
        }

        if (shop.locations != null && shop.locations.contains(area.getId())) {
            send("Shop " + shopId + " already has location " + mapName + " (MapID " + area.getId() + ").");
            return;
        }

        boolean created = StorageCache.getInstance().ensureShopLocation(shopId, area.getId());
        if (created) {
            send("Created shop location: Shop " + shopId + " -> " + mapName + " (MapID " + area.getId() + ").");
        } else {
            send("Shop location was not changed.");
        }
    }

    private void send(String message) {
        Kaiden_Extension.getInstance().send(new String[]{"server", message}, this.user);
    }
}
