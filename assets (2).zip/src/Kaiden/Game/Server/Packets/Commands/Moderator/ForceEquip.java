package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class ForceEquip extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
    int ItemID = Integer.parseInt(this.params[1]);
    ItemBean item = StorageCache.getInstance().getItem(ItemID);
    EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(1);
                JSONObject eqp = (JSONObject) user.properties.get("equipment");
                JSONObject eqpObj;
                int CheckId = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM items WHERE id = ?", ItemID);
                 if(CheckId == 0) {
                           
   eqpObj = new JSONObject();
                JSONObject var28 = new JSONObject();
                var28.put("uid", user.getUserId());
                var28.put("cmd", "equipItem");
                var28.put("ItemID", ItemID);
                var28.put("strES", item.getEquipment());
                var28.put("sFile", item.getFile());
                var28.put("sLink", item.getLink());
                var28.put("sMeta", item.getMeta());
                eqpObj.put("ItemID", ItemID);
                eqpObj.put("sFile", item.getFile());
                eqpObj.put("sLink", item.getLink());
                if (item.getEquipment().equals("Weapon")) {
                    var28.put("sType", item.getType());
                    eqpObj.put("sType", item.getType());
                    user.properties.put("weaponitem", item);
                    user.properties.put("weaponitemenhancement", enhancement);
                }

                eqp.put(item.getEquipment(), eqpObj);
                Kaiden_Extension.getInstance().sendToRoom(var28, user, room);
                if (item.getEquipment().equals("ar") || item.getEquipment().equals("ba") || item.getEquipment().equals("he") || item.getEquipment().equals("Weapon")) {
                    if (item.getEquipment().equals("ar")) {
                        Users.getInstance().updateClass(user, item, 325064);
                    }

                    Users.getInstance().updateStats(user, enhancement, item.getEquipment());
                    Users.getInstance().sendStats(user);
                }
         }
                 
    }
}