package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Help extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
          if((int)this.user.properties.get(Properties.ACCESS) == 50) {
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/get coin, cp, gold, level", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/clear (items, all, maps, settings) ", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/iay (msg)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/kick (user)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/pull (user)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/rates gold, cp, drop, exp , rep (x2)", this.user);
          }
          if((int)this.user.properties.get(Properties.ACCESS) >= 60) {
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/get coin, cp, gold, level ", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/clear (items, all, maps, settings) ", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/iay (msg)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/kick (user)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/pull (user)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/ban (user + time)", this.user);
          Kaiden_Extension.getInstance().sendToStaffUser("moderator", "/rates gold, cp, drop, exp , rep (x2)", this.user);

      }
    }
}