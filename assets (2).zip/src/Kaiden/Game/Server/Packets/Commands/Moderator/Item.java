package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;

import java.util.HashSet;
import java.util.Set;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Item extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (this.user.isAdmin() || this.user.isModerator()) {
        int itemId = Integer.parseInt(this.params[1]);
        int qtyId = Integer.parseInt(this.params[2]);
        
                   Set<UserDrop> dropItems = new HashSet();
                   dropItems.add(new UserDrop(itemId, qtyId, false));
                    Users.getInstance().dropItems(this.user, dropItems);

      } } }
