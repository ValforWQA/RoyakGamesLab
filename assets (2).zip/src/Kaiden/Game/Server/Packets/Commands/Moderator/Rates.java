package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Utils.SpanUtils;
import Kaiden.Kaiden_Extension;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Rates extends CommandPacketHandler {

    public void handle() {
        if (SpanUtils.isInteger(this.params[2])) {
            int stats = Integer.parseInt(this.params[2]);
            switch (this.params[1].toLowerCase()) {
                case "gold":
                    Configuration.GOLD_RATE = stats;
                    Server.getInstance().sendServerMessage("Gold rates has been changed to x" + stats + ".");
                    Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "Gold rates has been changed to x" + stats + "."});
                    break;
                case "drop":
                    Configuration.DROP_RATE = stats;
                    Server.getInstance().sendServerMessage("Drop rates has been changed to x" + stats + ".");
                    Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "Drop rates has been changed to x" + stats + "."});
                    break;
                case "exp":
                    Configuration.EXP_RATE = stats;
                    Server.getInstance().sendServerMessage("Experience rates has been changed to x" + stats + ".");
                    Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "Experience rates has been changed to x" + stats + "."});
                    break;
                case "rep":
                    Configuration.REP_RATE = stats;
                    Server.getInstance().sendServerMessage("Reputation rates has been changed to x" + stats + ".");
                    Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "Reputation rates has been changed to x" + stats + "."});
                    break;
                case "cp":
                    Configuration.CP_RATE = stats;
                    Server.getInstance().sendServerMessage("Class Point rates has been changed to x" + stats + ".");
                    Kaiden_Extension.getInstance().sendToUsers(new String[]{"moderator", "Class Point rates has been changed to x" + stats + "."});
                    break;
            }
        }
    }
}