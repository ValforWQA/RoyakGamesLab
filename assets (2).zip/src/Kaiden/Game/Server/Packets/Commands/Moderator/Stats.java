package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Users.Utils.ServerUtils;
import Kaiden.Kaiden_Extension;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)

public class Stats extends CommandPacketHandler {

    public void handle() {
        Kaiden_Extension.getInstance().send(new String[]{"server", "------------------------------------"}, this.user);
        Kaiden_Extension.getInstance().send(new String[]{"server", "Users: " + Kaiden_Extension.getInstance().getZone().getUserCount()}, this.user);
        Kaiden_Extension.getInstance().send(new String[]{"server", "Rooms: " + Kaiden_Extension.getInstance().getZone().getRoomCount()}, this.user);
        Kaiden_Extension.getInstance().send(new String[]{"server", "Uptime: " + ServerUtils.getUptime()}, this.user);
        Kaiden_Extension.getInstance().send(new String[]{"server", "------------------------------------"}, this.user);
    }
}