package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Pull extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String player = this.params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(player);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + player + "\" could not be found.");
        }
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            return;
        }
        String userFrame = (String) this.user.properties.get("frame");
        String userPad = (String) this.user.properties.get("pad");
        Rooms.getInstance().joinRoom(room, client, userFrame, userPad);
    }
}