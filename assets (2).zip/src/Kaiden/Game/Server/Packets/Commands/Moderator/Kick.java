package Kaiden.Game.Server.Packets.Commands.Moderator;


import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = false, isVIP = false, isHelper = false, isGameMaster = true, isModerator = true, isAdmin = true)
public class Kick extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(this.params[1].toLowerCase());
        if (client != null) {
            if (!client.isAdmin()) {
                Users.getInstance().kick(client, "Kicked by Staff.");
            } else {
                throw new RequestExternalPacketException("You can't kick a admin.");
            }
        }
    }
}