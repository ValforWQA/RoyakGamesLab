package Kaiden.Game.Server.Packets.Commands;

import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

@CommandHandler(isUser = true, isVIP = true, isHelper = true, isGameMaster = true, isModerator = true, isAdmin = true)
public class Goto extends CommandPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String player = this.params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(player);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + player + "\" could not be found.");
        } else if (((State) client.properties.get("state")).onCombat() && (int) this.user.properties.get(Properties.ACCESS) < 39) {
            throw new RequestExternalPacketException(client.getName() + " is currently busy.");
        } else if (!Settings.isAllowed(Settings.GOTO, this.user, client) && (int) this.user.properties.get(Properties.ACCESS) < 39) {
            throw new RequestExternalPacketException(client.getName() + " is ignoring goto requests.", "server");
        } else if (!client.getName().equals(this.user.getName())) {
            Room room = Kaiden_Extension.getInstance().getZone().getRoom(client.getRoom());
            if (Rooms.getInstance().checkLimits(room, this.user) == 0) {
                Rooms.getInstance().joinRoom(room, this.user, (String) client.properties.get(Properties.FRAME), (String) client.properties.get(Properties.PAD));
            }
        }
    }
}
