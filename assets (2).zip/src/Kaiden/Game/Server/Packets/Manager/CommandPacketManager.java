package Kaiden.Game.Server.Packets.Manager;

import Kaiden.Game.Server.Packets.Commands.Admin.*;
import Kaiden.Game.Server.Packets.Commands.*;
import Kaiden.Game.Server.Packets.Commands.Moderator.*;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.concurrent.ConcurrentHashMap;

public class CommandPacketManager {
    private static final Logger LOGGER = Logger.getLogger(CommandPacketManager.class);
    private static CommandPacketManager instance;

    public static CommandPacketManager getInstance() {
        if (instance == null) {
            instance = new CommandPacketManager();
        }
        return instance;
    }

    private final ConcurrentHashMap<String, CommandPacketHandler> commands = new ConcurrentHashMap<String, CommandPacketHandler>();

    public CommandPacketManager() {
        this.reload();
    }

    public synchronized void reload() {
        this.commands.clear();
        this.register("goto", new Goto());
        this.register("reportlang", new ReportLang());
        this.register("tfer", new Tfer());
        this.register("uopref", new Uopref());
        this.register("who", new Who());
        this.register("mute", new Mute());
        this.register("logout", new LogOut());
        this.register("npc", new Npc());
        this.register("delnpc", new DelNpc());
        this.register("cnpc", new Cnpc());
        this.register("npclist", new NpcList());
        this.register("lookQuest", new lookQuest());
        this.register("mon", new Mon());
        // Moderator
        this.register("forceEquip", new ForceEquip());
        this.register("item", new Item());
        this.register("get", new Get());
        this.register("iay", new Iay());
        this.register("kick", new Kick());
        this.register("pull", new Pull());
        this.register("rates", new Rates());
        this.register("stats", new Stats());
        this.register("help", new Help());
        this.register("createshoplocation", new CreateShopLocation());
        // Admin
        this.register("ban", new Ban());
        this.register("clear", new Clear());
        this.register("spawnbot", new SpawnBot());
        this.register("devbots", new DevBots());
        this.register("clearbots", new ClearBots());
        this.register("reload", new ReloadEmulator());
        this.register("reloademulator", new ReloadEmulator());
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Loading : " + commands.size() + " Commands");
    }

    public CommandPacketHandler get(String command) {
        return this.commands.get(command);
    }

    private void register(String external, CommandPacketHandler handler) {
        this.commands.put(external, handler);
    }
}
