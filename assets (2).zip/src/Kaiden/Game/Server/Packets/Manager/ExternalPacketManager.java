package Kaiden.Game.Server.Packets.Manager;

import Kaiden.Database.Beans.ServerFeatureBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Packets.External.Quest.QuestItem;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ExternalPacketManager {
    private static final Logger LOGGER = Logger.getLogger(ExternalPacketManager.class);
    private static ExternalPacketManager instance;

    public static ExternalPacketManager getInstance() {
        if (instance == null) {
            instance = new ExternalPacketManager();
        }
        return instance;
    }

    private final ConcurrentHashMap<String, ExternalPacketHandler> external = new ConcurrentHashMap<String, ExternalPacketHandler>();

    public ExternalPacketManager() {
        this.loadFromServerFeatures();
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Loading : " + external.size() + " Packets");
    }

    public ExternalPacketHandler get(String internalEvent) {
        if (internalEvent == null) {
            return null;
        }
        return this.external.get(internalEvent);
    }

    public boolean contains(String internalEvent) {
        if (internalEvent == null) {
            return false;
        }
        return this.external.containsKey(internalEvent);
    }

    public synchronized void reloadFromStorage() {
        this.loadFromServerFeatures();
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "External packets reloaded: " + external.size());
    }

    private void loadFromServerFeatures() {
        this.external.clear();

        Map<String, ServerFeatureBean> featureMap = StorageCache.getInstance().getServerFeatures();
        if (featureMap == null || featureMap.isEmpty()) {
            LOGGER.warn("No rows found in servers_features. External packets were not loaded.");
            return;
        }

        List<ServerFeatureBean> features = new ArrayList<ServerFeatureBean>(featureMap.values());
        Collections.sort(features, new Comparator<ServerFeatureBean>() {
            @Override
            public int compare(ServerFeatureBean a, ServerFeatureBean b) {
                if (a == null && b == null) {
                    return 0;
                }
                if (a == null) {
                    return 1;
                }
                if (b == null) {
                    return -1;
                }
                String ak = a.getFeatureKey() == null ? "" : a.getFeatureKey();
                String bk = b.getFeatureKey() == null ? "" : b.getFeatureKey();
                return ak.compareToIgnoreCase(bk);
            }
        });

        for (ServerFeatureBean feature : features) {
            this.registerFromFeature(feature);
        }

        registerPTRFallbacks();

        // AQW World.as sends "loadWarVars" with no parameters. Guarantee the
        // handler exists even when the servers_features mapping is absent.
        if (!this.external.containsKey("loadWarVars")) {
            this.external.put("loadWarVars", new Kaiden.Game.Server.Packets.External.War.MapWars());
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow", "Registered fallback external packet: loadWarVars -> MapWars");
        }

        // The AQW client command is literally "getQuestItem". Some legacy
        // servers_features dumps registered this handler as "questItem" (or
        // omitted it entirely), which lets the client-side quest UI change while
        // the authoritative server TEMP_ITEMS/users_quests_items never receives
        // the grant. Always provide the protocol-correct alias.
        if (!this.external.containsKey("getQuestItem")) {
            this.external.put("getQuestItem", new QuestItem());
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow", "Registered fallback external packet: getQuestItem -> QuestItem");
        }
    }

    // Separate OG PTR enhancement endpoints; existing modern endpoints are untouched.
    private void registerPTRFallbacks() {
        if (!external.containsKey("loadPTREnhShop")) {
            external.put("loadPTREnhShop", new Kaiden.Game.Server.Packets.External.Shop.LoadPTREnhShop());
        }
        if (!external.containsKey("enhanceItemPTR")) {
            external.put("enhanceItemPTR", new Kaiden.Game.Server.Packets.External.Item.EnhanceItemPTR());
        }
    }

    private void registerFromFeature(ServerFeatureBean feature) {
        if (feature == null) {
            return;
        }

        String featureKey = feature.getFeatureKey();
        String featurePath = feature.getFeaturePath();

        if (featureKey == null || featureKey.trim().isEmpty()) {
            LOGGER.warn("Skipped servers_features row with empty FeatureKey.");
            return;
        }

        if (featurePath == null || featurePath.trim().isEmpty()) {
            LOGGER.warn("Skipped packet '" + featureKey + "' because FeaturePath is empty.");
            return;
        }

        try {
            Class<?> rawClass = Class.forName(featurePath.trim());
            if (!ExternalPacketHandler.class.isAssignableFrom(rawClass)) {
                LOGGER.warn("Skipped packet '" + featureKey + "' because FeaturePath is not an ExternalPacketHandler: " + featurePath);
                return;
            }

            @SuppressWarnings("unchecked")
            Class<? extends ExternalPacketHandler> handlerClass = (Class<? extends ExternalPacketHandler>) rawClass;
            ExternalPacketHandler handler = handlerClass.newInstance();
            this.external.put(featureKey.trim(), handler);
        } catch (Exception e) {
            LOGGER.error("Failed loading external packet '" + featureKey + "' from FeaturePath '" + featurePath + "'.", e);
        }
    }
}
