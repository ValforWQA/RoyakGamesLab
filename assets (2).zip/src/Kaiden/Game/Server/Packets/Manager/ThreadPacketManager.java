package Kaiden.Game.Server.Packets.Manager;

import Kaiden.Database.Beans.ServerThreadBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Threads.Executor;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;


public class ThreadPacketManager {
    private static final Logger LOGGER = Logger.getLogger(ThreadPacketManager.class);
    private static ThreadPacketManager instance;

    public static ThreadPacketManager getInstance() {
        if (instance == null) {
            instance = new ThreadPacketManager();
        }
        return instance;
    }

    private final ConcurrentHashMap<String, ScheduledFuture<?>> running = new ConcurrentHashMap<String, ScheduledFuture<?>>();
    private final ConcurrentHashMap<String, ServerThreadBean> loaded = new ConcurrentHashMap<String, ServerThreadBean>();

    private ThreadPacketManager() {}

    public synchronized void initializeThreads() {
        this.loadFromServerThreads();

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "cyan",
                "[ThreadPacketManager] Loading " + this.loaded.size() + " DB thread(s) from servers_threads"
        );

        int index = 1;
        int total = this.loaded.size();

        List<ServerThreadBean> threads = new ArrayList<ServerThreadBean>(this.loaded.values());
        Collections.sort(threads, new Comparator<ServerThreadBean>() {
            @Override
            public int compare(ServerThreadBean a, ServerThreadBean b) {
                String ak = a == null || a.getThreadKey() == null ? "" : a.getThreadKey();
                String bk = b == null || b.getThreadKey() == null ? "" : b.getThreadKey();
                return ak.compareToIgnoreCase(bk);
            }
        });

        for (ServerThreadBean thread : threads) {
            startThread(thread, index, total);
            index++;
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "[ThreadPacketManager] Threads loaded: " + this.running.size() + "/" + total
        );
    }

    public synchronized void reloadFromStorage() {
        stopAll();
        StorageCache.getInstance().RetrieveStorageBeans("threads");
        initializeThreads();
    }

    public synchronized void stopAll() {
        for (Map.Entry<String, ScheduledFuture<?>> entry : this.running.entrySet()) {
            try {
                ScheduledFuture<?> future = entry.getValue();
                if (future != null) {
                    future.cancel(false);
                }
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "yellow",
                        "[ThreadPacketManager] Stopped " + entry.getKey()
                );
            } catch (Exception e) {
                LOGGER.warn("Failed stopping thread " + entry.getKey() + ": " + e.getMessage());
            }
        }
        this.running.clear();
    }

    public int getRunningCount() {
        return this.running.size();
    }

    public boolean isRunning(String threadKey) {
        if (threadKey == null) {
            return false;
        }
        ScheduledFuture<?> future = this.running.get(threadKey.trim().toLowerCase());
        return future != null && !future.isCancelled() && !future.isDone();
    }

    private void loadFromServerThreads() {
        this.loaded.clear();

        Map<String, ServerThreadBean> threadMap = StorageCache.getInstance().getServerThreads();
        if (threadMap == null) {
            StorageCache.getInstance().RetrieveStorageBeans("threads");
            threadMap = StorageCache.getInstance().getServerThreads();
        }
        if (threadMap == null || threadMap.isEmpty()) {
            LOGGER.warn("No rows found in servers_threads. Thread tasks were not loaded.");
            return;
        }

        for (ServerThreadBean thread : threadMap.values()) {
            if (thread == null) {
                continue;
            }

            String key = thread.getThreadKey();
            if (key == null || key.trim().isEmpty()) {
                LOGGER.warn("Skipped servers_threads row with empty ThreadKey.");
                continue;
            }

            if (!thread.isEnabled()) {
                LOGGER.info("Skipped disabled thread: " + key);
                continue;
            }

            this.loaded.put(key.trim().toLowerCase(), thread);
        }
    }

    private void startThread(ServerThreadBean thread, int index, int total) {
        if (thread == null) {
            return;
        }

        String threadKey = thread.getThreadKey();
        String threadPath = thread.getThreadPath();

        // These old maintenance loops are intentionally blocked here.
        // DeadConnection COUNT polling and aggressive idle-pool cleanup both cause
        // lag spikes / random disconnect waves on long uptime. Login/logout events
        // and Storage keepalive now handle this safely.
        if (threadPath != null) {
            String normalizedPath = threadPath.trim().toLowerCase();
            if (normalizedPath.endsWith("deadconnection") || normalizedPath.endsWith("freedbpool")) {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "yellow",
                        "[ThreadPacketManager] Skipped legacy lag thread " + threadPath
                );
                return;
            }
        }

        if (threadKey == null || threadKey.trim().isEmpty()) {
            LOGGER.warn("Skipped thread with empty ThreadKey.");
            return;
        }

        String key = threadKey.trim().toLowerCase();

        if (this.running.containsKey(key)) {
            LOGGER.warn("Skipped already running thread: " + threadKey);
            return;
        }

        if (threadPath == null || threadPath.trim().isEmpty()) {
            LOGGER.warn("Skipped thread '" + threadKey + "' because ThreadPath is empty.");
            return;
        }

        try {
            Class<?> rawClass = Class.forName(threadPath.trim());
            if (!Runnable.class.isAssignableFrom(rawClass)) {
                LOGGER.warn("Skipped thread '" + threadKey + "' because ThreadPath is not a Runnable: " + threadPath);
                return;
            }

            @SuppressWarnings("unchecked")
            Class<? extends Runnable> runnableClass = (Class<? extends Runnable>) rawClass;
            Runnable runnable = runnableClass.newInstance();

            long startDelay = Math.max(0L, thread.getStartDelay());
            long delay = Math.max(1L, thread.getDelay());
            TimeUnit unit = resolveUnit(thread.getTimeUnit());
            boolean repeat = thread.isRepeat();

            ScheduledFuture<?> future = Executor.getInstance().scheduleTask(
                    runnable,
                    startDelay,
                    delay,
                    unit,
                    repeat
            );

            this.running.put(key, future);

            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[ThreadPacketManager] (" + index + "/" + total + ") Started "
                            + threadKey
                            + " type=" + (repeat ? "REPEATING" : "ONE_SHOT")
                            + " start=" + startDelay
                            + " delay=" + delay
                            + " unit=" + unit
            );
        } catch (Exception e) {
            LOGGER.error("Failed loading thread '" + threadKey + "' from ThreadPath '" + threadPath + "'.", e);
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[ThreadPacketManager] Failed " + threadKey + ": " + e.getMessage()
            );
        }
    }

    private TimeUnit resolveUnit(String raw) {
        if (raw != null && !raw.trim().isEmpty()) {
            try {
                return TimeUnit.valueOf(raw.trim().toUpperCase());
            } catch (Exception ignored) {}
        }
        return TimeUnit.SECONDS;
    }
}
