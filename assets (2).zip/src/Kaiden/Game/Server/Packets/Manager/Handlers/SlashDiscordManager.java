package Kaiden.Game.Server.Packets.Manager.Handlers;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.DiscordException;

public interface SlashDiscordManager {
    void processSlash(Object slashEvent) throws DiscordException;
}
