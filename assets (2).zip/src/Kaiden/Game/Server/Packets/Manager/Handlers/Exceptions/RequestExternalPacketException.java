package Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions;

public class RequestExternalPacketException extends Exception {
    private static final long serialVersionUID = 1L;
    private String type = "warning";

    public RequestExternalPacketException(String msg) {
        super(msg);
    }

    public RequestExternalPacketException(String msg, String type) {
        super(msg);
        this.type = type;
    }

    public String getType() {
        return this.type;
    }
}