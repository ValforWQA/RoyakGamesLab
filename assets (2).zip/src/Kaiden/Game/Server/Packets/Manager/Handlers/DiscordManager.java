package Kaiden.Game.Server.Packets.Manager.Handlers;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.DiscordException;
import org.javacord.api.event.interaction.SlashCommandCreateEvent;
import org.javacord.api.event.message.MessageCreateEvent;


public abstract class DiscordManager {

    public void process(MessageCreateEvent event) throws DiscordException {
        throw new UnsupportedOperationException("Not implemented");
    }

    public void process(SlashCommandCreateEvent event) throws DiscordException {
        throw new UnsupportedOperationException("Not implemented");
    }
}
