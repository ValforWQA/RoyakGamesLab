package Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions;

public class UnknownPacketException extends RuntimeException {

    public UnknownPacketException(String msg) {
        super(msg);
    }
}