package Kaiden.Game.Server.Packets.Manager.Handlers;

import java.lang.annotation.*;

@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface CommandHandler {
    boolean isUser();

    boolean isVIP();

    boolean isHelper();

    boolean isGameMaster();

    boolean isModerator();

    boolean isAdmin();
}