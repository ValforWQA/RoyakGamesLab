package Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions;

public class RequestInternalPacketException extends Exception {
    private static final long serialVersionUID = 1L;
    private String type = "warning";

    public RequestInternalPacketException(String msg) {
        super(msg);
    }

    public RequestInternalPacketException(String msg, String type) {
        super(msg);
        this.type = type;
    }

    public String getType() {
        return this.type;
    }
}
