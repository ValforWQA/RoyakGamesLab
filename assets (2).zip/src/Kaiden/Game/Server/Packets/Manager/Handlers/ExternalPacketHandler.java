package Kaiden.Game.Server.Packets.Manager.Handlers;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

public abstract class ExternalPacketHandler {

    public Room room;

    public User user;

    public String[] params;

    public User getUser() { return this.user;}

    public abstract void handle() throws RequestExternalPacketException;
}