package Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions;
import org.javacord.api.event.message.MessageCreateEvent;

public class DiscordException extends Exception {
    public DiscordException(String text, MessageCreateEvent event) {
        event.getChannel().sendMessage(text);
    }
}