package Kaiden.Game.Server.Packets.Manager.Handlers;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestInternalPacketException;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public abstract class InternalPacketHandler {

    public abstract void handle(InternalEventObject ieo) throws RequestInternalPacketException;
}