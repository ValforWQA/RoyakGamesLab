package Kaiden.Game.Server.Packets.Manager.Handlers;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

public interface RequestPacketManager {
    void process(String[] params, User user, Room room) throws RequestExternalPacketException;
}
