package Kaiden.Game.Server.Packets.Manager;

import Kaiden.Game.Server.Packets.Internal.*;
import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.concurrent.ConcurrentHashMap;

public class InternalPacketManager {
    private static final Logger LOGGER = Logger.getLogger(InternalPacketManager.class);
    private static InternalPacketManager instance;

    public static InternalPacketManager getInstance() {
        if (instance == null) {
            instance = new InternalPacketManager();
        }
        return instance;
    }

    private final ConcurrentHashMap<String, InternalPacketHandler> internal = new ConcurrentHashMap<String, InternalPacketHandler>();

    public InternalPacketManager() {
        this.reload();
    }

    public synchronized void reload() {
        this.internal.clear();
        this.register("loginRequest", new LoginRequestEvent());
        this.register("serverReady", new ServerReadyEvent());
        this.register("userJoin", new UserJoinEvent());
        this.register("userExit", new UserExitEvent());
        this.register("userLost", new UserLostEvent());
        this.register("newRoom", new NewRoomEvent());
        this.register("roomLost", new RoomLostEvent());
        this.register("unknown", new UnknownEvent());
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Loading : " + internal.size() + " Internal Packets");
    }

    public InternalPacketHandler get(String internalEvent) {
        if (this.internal.containsKey(internalEvent)) {
            return this.internal.get(internalEvent);
        }
        return this.internal.get("unknown");
    }

    private void register(String internal, InternalPacketHandler handler) {
        this.internal.put(internal, handler);
    }
}
