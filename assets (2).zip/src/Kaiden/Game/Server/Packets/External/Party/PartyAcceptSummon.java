package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

public class PartyAcceptSummon implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        int partyId = (Integer) user.properties.get("partyId");
        PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
        User client = pi.getOwnerObject();
        if (!Settings.isAllowed(Settings.GOTO, client, user)) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", user.getName() + " failed to be summoned."}, client);
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Summon failed. Please do not block goto requests."}, user);
        } else {
            Kaiden_Extension.getInstance().send(new String[]{"server", user.getName() + " accepted your summon."}, client);
        }

    }
}
