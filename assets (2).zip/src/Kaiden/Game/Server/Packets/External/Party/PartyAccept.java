package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;

public class PartyAccept implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        if ((Integer) user.properties.get("partyId") > 0) {
            throw new RequestExternalPacketException("You are already in a party!");
        } else {
            int partyId = Integer.parseInt(params[1]);
            Set<Integer> requestedParty = (Set) user.properties.get("requestedparty");
            if (requestedParty.contains(partyId)) {
                PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
                pi.addMember(user);
                JSONObject pa = new JSONObject();
                JSONArray ul = new JSONArray();
                ul.add(user.properties.get(Properties.USERNAME));
                pa.put("cmd", "pa");
                pa.put("pid", partyId);
                pa.put("ul", ul);
                pa.put("owner", pi.getOwner());
                Kaiden_Extension.getInstance().send(pa, pi.getChannelListButOne(user));
                pa.put("ul", pi.getUsers());
                Kaiden_Extension.getInstance().send(pa, user);
                requestedParty.remove(partyId);
            } else {
                Users.getInstance().log(user, "Packet Edit [PartyAccept]", "Forcing party accept");
                Users.getInstance().kick(user, "Forcing party accept.");
            }

        }
    }
}
