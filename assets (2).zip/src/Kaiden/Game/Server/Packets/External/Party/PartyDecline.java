package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class PartyDecline implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        int partyId = Integer.parseInt(params[1]);
        PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
        JSONObject pd = new JSONObject();
        pd.put("unm", user.properties.get(Properties.USERNAME));
        pd.put("cmd", "pd");
        if (pi.getMemberCount() <= 0) {
            ManageParties.getInstance().removeParty(partyId);
            pi.getOwnerObject().properties.put("partyId", -1);
        }

        Kaiden_Extension.getInstance().send(pd, pi.getOwnerObject());
        Kaiden_Extension.getInstance().send(new String[]{"server", "You have declined the invitation."}, user);
    }
}
