package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class PartySummon implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        String username = params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + params[1].toLowerCase() + "\" could not be found.");
        } else {
            int partyId = (Integer) user.properties.get("partyId");
            int clientPID = (Integer) client.properties.get("partyId");
            if (partyId < 0) {
                throw new RequestExternalPacketException("You are not in a party!");
            } else if (partyId != clientPID) {
                throw new RequestExternalPacketException("The user you are trying to summon is not in your party.");
            } else {
                JSONObject pd = new JSONObject();
                pd.put("unm", user.properties.get(Properties.USERNAME));
                pd.put("cmd", "ps");
                Kaiden_Extension.getInstance().send(pd, client);
                Kaiden_Extension.getInstance().send(new String[]{"server", "You attempt to summon " + client.getName() + " to you."}, user);
            }
        }
    }
}
