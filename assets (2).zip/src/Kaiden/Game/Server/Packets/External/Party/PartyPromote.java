package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class PartyPromote implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        String username = params[1].toLowerCase();
        User newOwner = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (newOwner == null) {
            throw new RequestExternalPacketException("Player \"" + params[1].toLowerCase() + "\" could not be found.");
        } else {
            int partyId = (Integer) user.properties.get("partyId");
            PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
            if (!pi.isMember(newOwner)) {
                throw new RequestExternalPacketException("That player is not in your party.");
            } else {
                pi.setOwner(newOwner);
                JSONObject pp = new JSONObject();
                pp.put("cmd", "pp");
                pp.put("owner", newOwner.getName());
                Kaiden_Extension.getInstance().send(pp, pi.getChannelList());
            }
        }
    }
}
