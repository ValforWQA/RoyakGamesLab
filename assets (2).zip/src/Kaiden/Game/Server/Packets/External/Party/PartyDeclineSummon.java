package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

public class PartyDeclineSummon implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        String username = params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client != null) {
            Kaiden_Extension.getInstance().send(new String[]{"server", client.getName() + " declined your summon."}, client);
        }
    }
}
