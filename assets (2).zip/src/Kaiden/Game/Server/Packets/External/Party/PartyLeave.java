package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class PartyLeave implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int partyId = (Integer) user.properties.get("partyId");
        if (partyId <= 0) {
            throw new RequestExternalPacketException("You are not in a party.");
        } else {
            PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
            if (pi.getOwner().equals(user.properties.get(Properties.USERNAME))) {
                pi.setOwner(pi.getNextOwner());
            }

            pi.removeMember(user);
            JSONObject pr = new JSONObject();
            pr.put("cmd", "pr");
            pr.put("owner", pi.getOwner());
            pr.put("typ", "l");
            pr.put("unm", user.properties.get(Properties.USERNAME));
            Kaiden_Extension.getInstance().send(pr, pi.getChannelListButOne(user));
            Kaiden_Extension.getInstance().send(pr, user);
            if (pi.getMemberCount() <= 0) {
                JSONObject pc = new JSONObject();
                pc.put("cmd", "pc");
                Kaiden_Extension.getInstance().send(pc, pi.getOwnerObject());
                ManageParties.getInstance().removeParty(partyId);
                pi.getOwnerObject().properties.put("partyId", -1);
            }

        }
    }
}
