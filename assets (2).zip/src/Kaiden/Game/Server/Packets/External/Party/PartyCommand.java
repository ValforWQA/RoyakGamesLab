package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;

public class PartyCommand extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        switch (params[0]) {
            case "pi":
                (new PartyInvite()).process(params, user, room);
                break;
            case "pk":
                (new PartyKick()).process(params, user,  room);
                break;
            case "pl":
                (new PartyLeave()).process(params, user,  room);
                break;
            case "ps":
                (new PartySummon()).process(params, user,  room);
                break;
            case "psa":
                (new PartyAcceptSummon()).process(params, user,  room);
                break;
            case "psd":
                (new PartyDeclineSummon()).process(params, user,  room);
                break;
            case "pp":
                (new PartyPromote()).process(params, user, room);
                break;
            case "pa":
                (new PartyAccept()).process(params, user,  room);
                break;
            case "pd":
                (new PartyDecline()).process(params, user,  room);
                break;
        }
    }
}
