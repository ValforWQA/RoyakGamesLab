package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.Set;

public class PartyInvite implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        String username = params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
        } else {
            int partyId = (Integer) user.properties.get("partyId");
            int clientPID = (Integer) client.properties.get("partyId");
            if (!Settings.isAllowed(Settings.PARTY, user, client)) {
                throw new RequestExternalPacketException(client.getName() + " cannot recieve party invitations.");
            } else if (((State) client.properties.get("state")).onCombat()) {
                throw new RequestExternalPacketException(client.getName() + " is currently busy.");
            } else if (clientPID > 0) {
                throw new RequestExternalPacketException("User is already in a party!");
            } else {
                if (partyId < 0 && !ManageParties.getInstance().contains(partyId)) {
                    partyId = ManageParties.getInstance().create(user);
                }

                Set<Integer> requestedParty = (Set) client.properties.get("requestedparty");
                requestedParty.add(partyId);
                JSONObject pi = new JSONObject();
                pi.put("cmd", "pi");
                pi.put("pid", partyId);
                pi.put("owner", user.properties.get(Properties.USERNAME));
                Kaiden_Extension.getInstance().send(pi, client);
                Kaiden_Extension.getInstance().send(new String[]{"server", "You have invited " + client.getName() + " to join your party."}, user);
            }
        }
    }
}
