package Kaiden.Game.Server.Packets.External.Party;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class PartyKick implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        String username = params[1].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
        } else {
            int partyId = (Integer) user.properties.get("partyId");
            PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
            if (!pi.isMember(client)) {
                throw new RequestExternalPacketException("That player is not in your party.");
            } else {
                JSONObject pr = new JSONObject();
                pr.put("cmd", "pr");
                pr.put("owner", pi.getOwner());
                pr.put("typ", "k");
                pr.put("unm", user.properties.get(Properties.USERNAME));
                Kaiden_Extension.getInstance().send(pr, pi.getChannelList());
                pi.removeMember(client);
                if (pi.getMemberCount() <= 0 && pi.getOwner().equals(user.getName())) {
                    JSONObject pc = new JSONObject();
                    pc.put("cmd", "pc");
                    Kaiden_Extension.getInstance().send(pc, pi.getOwnerObject());
                    ManageParties.getInstance().removeParty(partyId);
                    pi.getOwnerObject().properties.put("partyId", -1);
                }

            }
        }
    }
}
