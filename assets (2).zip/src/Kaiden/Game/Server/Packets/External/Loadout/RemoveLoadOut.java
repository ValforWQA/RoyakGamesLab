package Kaiden.Game.Server.Packets.External.Loadout;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

public class RemoveLoadOut extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String name = params[0];

        JSONObject o = new JSONObject();
        o.put("cmd", "removeLoadout");
        o.put("success", true);
        o.put("setName", name);

        Storage.getInstance().getJdbc().beginTransaction();
        try {
            Storage.getInstance().getJdbc().execute("DELETE FROM users_outfits WHERE Name = ? AND UserID = ?", name, user.properties.get(Properties.ID));
            Storage.getInstance().getJdbc().commitTransaction();
        } catch (JdbcException jdbcException) {
            if (Storage.getInstance().getJdbc().isInTransaction())
                Storage.getInstance().getJdbc().rollbackTransaction();

            o.put("success", false);
            o.put("msg", "error remove loadout!");
        }

        Kaiden_Extension.getInstance().send(o, user);
    }

}
