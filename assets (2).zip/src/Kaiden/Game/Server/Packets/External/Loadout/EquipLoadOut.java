package Kaiden.Game.Server.Packets.External.Loadout;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.External.Item.EquipItem;
import Kaiden.Game.Server.Packets.External.Item.UnequipItem;
import Kaiden.Game.Server.Packets.External.Player.ChangeArmorColor;
import Kaiden.Game.Server.Packets.External.Player.ChangeColor;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import java.util.HashSet;

public class EquipLoadOut extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
        String name = params[1];
        int keepColor = Integer.parseInt(params[2]);
        QueryResult outfit = Storage.getInstance().getJdbc().query("SELECT * FROM users_outfits WHERE Name = ? AND UserID = ?", name, user.properties.get(Properties.ID));
        if (!outfit.next()) throw new RequestExternalPacketException("Loadout not found");
        String[] equipments = outfit.getString("Equipments").split(",");
        String colorAccessory = outfit.getString("ColorAccessory");
        String colorBase = outfit.getString("ColorBase");
        String colorTrim = outfit.getString("ColorTrim");
        String colorHair = outfit.getString("ColorHair");
        String colorSkin = outfit.getString("ColorSkin");
        String colorEye = outfit.getString("ColorEye");
        outfit.close();
        HashSet<Integer> keep = new HashSet<Integer>();
        for (String eq : equipments) {
            if (eq == null || eq.trim().isEmpty()) continue;
            int itemId = Integer.parseInt(eq.trim());
            keep.add(itemId);
            EquipItem equip = new EquipItem();
            equip.user = user; equip.room = room; equip.params = new String[]{String.valueOf(itemId)};
            equip.handle();
        }
        QueryResult equipped = Storage.getInstance().getJdbc().query("SELECT ItemID FROM users_items WHERE UserID = ? AND Equipped = 1 AND Bank = 0", user.properties.get(Properties.ID));
        while (equipped.next()) {
            int itemId = equipped.getInt("ItemID");
            if (!keep.contains(itemId)) {
                UnequipItem un = new UnequipItem();
                un.user = user; un.room = room; un.params = new String[]{String.valueOf(itemId)};
                un.handle();
            }
        }
        equipped.close();
        if (keepColor == 1) {
            ChangeColor color = new ChangeColor();
            color.user = user; color.room = room;
            color.params = new String[]{colorSkin,colorHair,colorEye,String.valueOf(user.properties.get("HairID"))};
            color.handle();
            ChangeArmorColor armor = new ChangeArmorColor();
            armor.user = user; armor.room = room;
            armor.params = new String[]{colorBase,colorTrim,colorAccessory};
            armor.handle();
        }
        Kaiden_Extension.getInstance().send(new String[]{"server","Loadout equipped successfully."}, user);
    }
}
