package Kaiden.Game.Server.Packets.External.Loadout;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

import java.util.ArrayList;

public class AddLoadOut extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        String name = params[0];
        JSONObject data = JSONObject.fromObject(params[1]);
        JSONObject colors = (JSONObject) data.get("colors");

        //System.out.println(colors);

        JSONObject o = new JSONObject();
        o.put("cmd", "addLoadout");
        o.put("success", true);

        Storage.getInstance().getJdbc().beginTransaction();
        try {
            String equipment = getEquipment(data);
            String colorAccessory = colors.getString("accessory");
            String colorBase = colors.getString("base");
            String colorTrim = colors.getString("trim");
            String colorHair = colors.getString("hair");
            String colorSkin = colors.getString("skin");
            String colorEye = colors.getString("eye");

            if (params.length == 2) {
                Storage.getInstance().getJdbc().execute("INSERT INTO users_outfits (Name, UserID, Equipments, ColorAccessory, ColorBase, ColorTrim, ColorHair, ColorSkin, ColorEye) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", name, user.properties.get(Properties.ID), equipment, colorAccessory, colorBase, colorTrim, colorHair, colorSkin, colorEye);
            } else if (params.length == 3) {
                String originalName = params[2];
                Storage.getInstance().getJdbc().execute("UPDATE users_outfits SET Name = ?, Equipments = ?, ColorAccessory = ?, ColorBase = ?, ColorTrim = ?, ColorHair = ?, ColorSkin = ?, ColorEye = ? WHERE Name = ? AND UserID = ?", name, equipment, colorAccessory, colorBase, colorTrim, colorHair, colorSkin, colorEye, originalName, user.properties.get(Properties.ID));
            } else {
                Users.getInstance().kick(user, "Failed during addLoadout");
            }

            Storage.getInstance().getJdbc().commitTransaction();
        } catch (JdbcException jdbcException) {
            if (Storage.getInstance().getJdbc().isInTransaction())
                Storage.getInstance().getJdbc().rollbackTransaction();

            o.put("success" , false);
        }

       Kaiden_Extension.getInstance().send(o, user);
    }

    private String getEquipment(JSONObject data) {
        ArrayList<String> equipments = new ArrayList<>();

        for (String equipment : new String[] { "ar", "co", "he", "ba", "Weapon", "mi" }) {
            if (!data.has(equipment)) continue;

            equipments.add(String.valueOf(data.get(equipment)));
        }

        return String.join(",", equipments);
    }

}
