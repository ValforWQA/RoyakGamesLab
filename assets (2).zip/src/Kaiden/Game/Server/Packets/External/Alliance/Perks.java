package Kaiden.Game.Server.Packets.External.Alliance;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class Perks extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int perkid = Integer.valueOf(this.params[0].toLowerCase());
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM users WHERE id = ?", user.properties.get(Properties.ID));
        if (result.next()) {
            if(result.getInt("PerkID") > 0) {
             Kaiden_Extension.getInstance().sendNormalModal("You have already chosen a perk!", "red", this.user);
                return;
            }
            switch (perkid) {
                case 1:
                    Kaiden_Extension.getInstance().sendNormalModal("You have chosen Brute Force as your perk!", "green", this.user);
                    Storage.getInstance().getJdbc().run("UPDATE users SET PerkID = 1 WHERE id = ?", this.user.properties.get(Properties.ID));
                    Users.getInstance().sendUotls(user, true, true, true, true, true, false, false);
                    break;
                case 2:
                    Kaiden_Extension.getInstance().sendNormalModal("You have chosen Cleric's Visual as your perk!", "green", this.user);
                    Storage.getInstance().getJdbc().run("UPDATE users SET PerkID = 2 WHERE id = ?", this.user.properties.get(Properties.ID));
                    Users.getInstance().sendUotls(user, true, true, true, true, true, false, false);
                    break;
               }
              } else {
              throw new RequestExternalPacketException("Invalid user");
              }
           }
        }
