package Kaiden.Game.Server.Packets.External.Alliance;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class Good extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        QueryResult player_session = Storage.getInstance().getJdbc().query("SELECT * FROM users WHERE id =?",this.user.properties.get(Properties.ID));
        if(player_session.next()) {
        if (player_session.getInt("FactionID") == 0) {
            JSONObject modal = new JSONObject();
            modal.put("cmd", "modalmc");
            modal.put("msg", "You are now apart of the Good Alliance!");
            modal.put("glow", "green");
            Kaiden_Extension.getInstance().send(modal, this.user);
            Storage.getInstance().getJdbc().run("UPDATE users SET FactionID = 1 WHERE id = ?", this.user.properties.get(Properties.ID));
        } else
            if (player_session.getInt("FactionID") == 1) {
                JSONObject modal = new JSONObject();
                modal.put("cmd", "modalmc");
                modal.put("msg", "You are already apart of the Good Alliance!");
                modal.put("glow", "green");
                Kaiden_Extension.getInstance().send(modal, this.user);

            } else {
            if (player_session.getInt("FactionID") == 2) {

                    JSONObject modal = new JSONObject();
                    modal.put("cmd", "modalmc");
                    modal.put("msg", "You are apart of the Evil Alliance!");
                    modal.put("glow", "red");
                    Kaiden_Extension.getInstance().send(modal, this.user);
                       }
                    }
                }
             }
        }
