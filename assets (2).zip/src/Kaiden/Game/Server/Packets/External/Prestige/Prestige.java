package Kaiden.Game.Server.Packets.External.Prestige;

import Kaiden.Database.Beans.PrestigeLevelBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import net.sf.json.JSONObject;

public class Prestige extends ExternalPacketHandler {

    @SuppressWarnings("unchecked")
    public void handle() throws RequestExternalPacketException {
        int prestigeid = Integer.parseInt(params[0]);
        int newprestige = Integer.parseInt(params[2]);
        PrestigeLevelBean currentPrestige = StorageCache.getInstance().getPrestigeLevel((int)user.properties.get(Properties.PRESTIGE_LEVEL));
        JSONObject sell = new JSONObject();
        sell.put("cmd", "prestige");

    }
}
