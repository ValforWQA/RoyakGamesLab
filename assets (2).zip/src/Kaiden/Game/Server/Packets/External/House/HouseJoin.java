package Kaiden.Game.Server.Packets.External.House;

import Kaiden.Database.Beans.HouseBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import jdbchelper.NoResultException;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.sql.SQLException;
import java.util.Date;

public class HouseJoin extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        String username = params[0].toLowerCase();

        QueryResult result = Storage.getInstance().getJdbc()
                .query("SELECT id, Name, HouseInfo FROM users WHERE Name = ?", username);
        result.setAutoClose(true);

        if (!result.next()) {
            result.close();
            throw new RequestExternalPacketException("Player \"" + username + "\" could not be found!");
        }

        int userDbId = result.getInt("id");

        try {

            String areaName = "house-" + userDbId;


            if (!StorageCache.getInstance().containsArea(areaName)) {


                JSONArray items = getHouseItems(userDbId);


                int hoItemId = Storage.getInstance().getJdbc().queryForInt(
                        "SELECT ItemID FROM users_items " +
                                "LEFT JOIN items ON items.id = ItemID " +
                                "WHERE Equipment = 'ho' AND Equipped = 1 AND UserID = ?",
                        userDbId
                );

                ItemBean hoItem = StorageCache.getInstance().getItem(hoItemId);
// ... null check, etc.

                HouseBean houseArea = new HouseBean(
                        items,
                        result.getString("HouseInfo"),
                        result.getString("Name"),
                        userDbId,
                        hoItemId          // ⬅️ this is now the HouseItemID
                );

                houseArea.setFile(hoItem.getFile());
                houseArea.setHouseItemId(hoItemId);
                StorageCache.getInstance().addHouse(areaName, houseArea);
                //Kaiden_Engine.LOGGER.info("[HouseJoin] Cached house area " + areaName + " for userId=" + userDbId);
            } else {
                // Refresh cached house inventory every time the house is joined.
                // This fixes users_items changes made while the house area is already cached.
                HouseBean houseArea = (HouseBean) StorageCache.getInstance().getArea(areaName);

                int hoItemId = Storage.getInstance().getJdbc().queryForInt(
                        "SELECT ItemID FROM users_items " +
                                "LEFT JOIN items ON items.id = ItemID " +
                                "WHERE Equipment = 'ho' AND Equipped = 1 AND Bank = 0 AND UserID = ?",
                        userDbId
                );

                ItemBean hoItem = StorageCache.getInstance().getItem(hoItemId);

                houseArea.setHouseItems(getHouseItems(userDbId));
                houseArea.setHouseInfo(result.getString("HouseInfo"));
                houseArea.setHouseItemId(hoItemId);

                if (hoItem != null) {
                    houseArea.setFile(hoItem.getFile());
                }
            }

            Rooms.getInstance().basicRoomJoin(user, areaName);

            // Send a fresh house inventory packet after joining.
            // The client listens for cmd=loadHouseInventory and fills myAvatar.houseitems.
            Kaiden_Extension.getInstance().send(Users.getInstance().loadHouseInventory(userDbId,
                    ((HouseBean) StorageCache.getInstance().getArea(areaName)).getHouseItemId()), user);

        } catch (NoResultException e) {

            if (result.getString("Name").equalsIgnoreCase(user.getName())) {

                Kaiden_Extension.getInstance().send(
                        new String[]{"warning", "Oops, maybe you forgot to equip the house."},
                        user
                );
                Rooms.getInstance().basicRoomJoin(user, "buyhouse");
            } else {
                Kaiden_Extension.getInstance().send(
                        new String[]{"warning", "This player does not own a house!"},
                        user
                );
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            result.close();
        }
    }

    private JSONArray getHouseItems(int userDbId) {
        JSONArray items = new JSONArray();

        QueryResult result = Storage.getInstance().getJdbc().query(
                "SELECT users_items.id, ItemID, Equipped, users_items.Quantity, DatePurchased " +
                        "FROM users_items " +
                        "LEFT JOIN items ON items.id = ItemID " +
                        "WHERE Equipment IN ('ho','hi') AND UserID = ?",
                userDbId
        );

        result.setAutoClose(true);

        while (result.next()) {
            int itemId = result.getInt("ItemID");
            ItemBean itemObj = StorageCache.getInstance().getItem(itemId);

            if (itemObj == null) {
                //Kaiden_Engine.LOGGER.warn("[HouseJoin] Missing ItemBean for ItemID=" + itemId + " (UserID=" + userDbId + ")");
                continue;
            }

            JSONObject item = itemObj.getItemJSON();

            item.put("ItemID", itemId);


            item.put("CharItemID", result.getInt("id"));
            item.put("bEquip", result.getString("Equipped"));   // 'ho' or 'hi'
            item.put("iQty", result.getString("Quantity"));


            if (itemObj.isCoins()) {
                Date startDate = result.getDate("DatePurchased");
                Date endDate = new Date();
                long diffMs = endDate.getTime() - startDate.getTime();
                long diffHours = diffMs / (60L * 60L * 1000L);

                item.put("iHrs", diffHours);
                item.put("dPurchase", result.getString("DatePurchased").replace(" ", "T"));
            }

            items.add(item);
        }

        result.close();
        return items;
    }
}