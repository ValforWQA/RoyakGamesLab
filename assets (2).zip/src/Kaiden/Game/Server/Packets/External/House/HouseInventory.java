package Kaiden.Game.Server.Packets.External.House;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;

public class HouseInventory extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
    }

}
