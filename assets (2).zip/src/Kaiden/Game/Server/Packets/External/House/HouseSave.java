package Kaiden.Game.Server.Packets.External.House;

import Kaiden.Database.Beans.HouseBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.Room;

public class HouseSave extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        Storage.getInstance().getJdbc().run("UPDATE users_characters SET HouseInfo = ? WHERE id = ?", params[0], user.properties.get(Properties.ID));
        Room house = Kaiden_Extension.getInstance().getZone().getRoomByName("house-" + user.properties.get(Properties.ID));

        if (house == null) return;
        HouseBean houseObj = (HouseBean) StorageCache.getInstance().getArea(house.getName());
        //SmartFoxServer.log.info(houseObj.toString());
        if(houseObj == null) return;
        houseObj.setHouseInfo(params[0]);
        SmartFoxServer.log.info(params[0]);
    }

}
        //String houseInfo = params.length > 0 ? params[0] : "";
        //SmartFoxServer.log.info("hoid:"+houseInfo);
        //Storage.getInstance().getJdbc().run("UPDATE users SET HouseInfo = ? WHERE id = ?", houseInfo, user.properties.get(Properties.ID));
        //Room house = Kaiden_Extension.getInstance().getZone().getRoomByName("house-" + user.properties.get(Properties.ID));
        //if (house != null) {
           // HouseBean houseObj = (HouseBean) StorageCache.getInstance().getArea(house.getName());
            //if (houseObj != null) {
                //houseObj.setHouseInfo(houseInfo);
                //SmartFoxServer.log.info("hoi:"+houseObj.getData());
            //}
       // }
   // }
//}
