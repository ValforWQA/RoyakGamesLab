
package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;

import java.sql.ResultSet;
import java.util.Set;

public class QuestItem extends ExternalPacketHandler {

    @Override
    public void handle() {

        int itemId;

        try {
            itemId = Integer.parseInt(this.params[0]);
        } catch (Exception e) {
            return;
        }

        if (itemId <= 0) {
            Kaiden_Extension.getInstance().sendToUser(
                    "message",
                    "Invalid quest item.",
                    this.user
            );
            return;
        }

        ItemBean item = StorageCache.getInstance().getItem(itemId);

        if (item == null) {
            return;
        }

        ZoneBean area = StorageCache.getInstance()
                .getArea(this.room.getName().split("-")[0]);

        if (area == null) {
            return;
        }

        // Validate against authoritative DB state, not stale login snapshots.
        if (!QuestProgressManager.reloadActiveQuests(this.user)) return;
        boolean allowed = false;

        Set<Integer> activeQuests =
                (Set<Integer>) this.user.properties.get(Properties.QUESTS);

        // First check active quests and their item requirements.
        if (activeQuests != null) {
            for (Integer questId : activeQuests) {

                if (questId == null) continue;

                QuestBean quest = StorageCache.getInstance()
                        .getQuest(questId);

                if (quest != null &&
                        quest.requirements != null &&
                        quest.requirements.containsKey(itemId)) {

                    allowed = true;
                    break;
                }
            }
        }

        // Also allow items explicitly linked to an active quest
        // through their ReqQuests field.
        if (!allowed && activeQuests != null) {

            String required = item.getReqQuests();

            if (required != null && !required.trim().isEmpty()) {

                for (String value : required.split("[,;|\\s]+")) {
                    try {
                        int requiredQuestId =
                                Integer.parseInt(value.trim());

                        if (activeQuests.contains(requiredQuestId)) {
                            allowed = true;
                            break;
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }

        // If memory is outdated, verify active quest state
        // against users_quests_active before rejecting.
        if (!allowed) {

            String required = item.getReqQuests();

            if (required != null && !required.trim().isEmpty()) {

                for (String value : required.split("[,;|\\s]+")) {

                    try {
                        int requiredQuestId =
                                Integer.parseInt(value.trim());

                        // Use your existing Storage/JDBC query API here.
                        // Query must check UserID, QuestID and ExpiresAt.
                        // Set allowed only if a matching active row exists.

                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }

        if (!allowed) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow",
                    "[QuestItem] rejected user=" + this.user.getName()
                            + " ItemID=" + itemId
                            + " ReqQuests=" + item.getReqQuests()
                            + " ActiveQuests=" + activeQuests
            );
            return;
        }

        Users.getInstance().giveMapQuestItem(this.user, itemId, 1);
    }
}
