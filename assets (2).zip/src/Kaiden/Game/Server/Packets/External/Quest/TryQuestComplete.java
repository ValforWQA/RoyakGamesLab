package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Beans.QuestRewardBean;
import Kaiden.Database.StorageCache;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.External.War.WarProgress;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.*;

public class TryQuestComplete extends ExternalPacketHandler {

    @Override
    public void handle() {
        int questId = Integer.parseInt(this.params[0]);
        int selectedItemId = Integer.parseInt(this.params[1]);

        int qty = 1;
        if (this.params.length > 3) {
            try {
                qty = Integer.parseInt(this.params[3]);
            } catch (Exception ignored) {
                qty = 1;
            }
        }

        if (qty < 1) {
            qty = 1;
        }
        if (qty > 250) {
            qty = 250;
        }

        Set<Integer> userQuests = (Set<Integer>) this.user.properties.get("quests");
        QuestBean quest = StorageCache.getInstance().getQuest(questId);

        JSONObject ccqr1 = new JSONObject();
        JSONObject turnin = new JSONObject();

        ccqr1.put("cmd", "ccqr");
        ccqr1.put("QuestID", questId);
        turnin.put("cmd", "turnIn");

        if (quest == null) {
            ccqr1.put("bSuccess", 0);
            ccqr1.put("msg", "Quest not found.");
            Kaiden_Extension.getInstance().send(ccqr1, this.user);
            return;
        }

        // Map scripts can request completion without first opening/accepting the quest.
        // Auto-accept only the requested quest, using the same location check as AcceptQuest.
        // Do not grant missing items or bypass the ordinary turn-in validation.

        if (QuestProgressManager.isTimedQuestExpired(this.user, questId)) {
            QuestProgressManager.expireTimedQuest(this.user, questId);
            ccqr1.put("bSuccess", 0);
            ccqr1.put("msg", "Trial has expired try again.");
            Kaiden_Extension.getInstance().send(ccqr1, this.user);
            return;
        }

        if (userQuests == null) {
            ccqr1.put("bSuccess", 0);
            ccqr1.put("msg", "Quest system unavailable.");
            Kaiden_Extension.getInstance().send(ccqr1, this.user);
            return;
        }

        if (!userQuests.contains(questId)) {
            ZoneBean area = StorageCache.getInstance().getArea(this.room.getName().split("-")[0]);
            // Map-triggered auto-accept: register the current map only if the
            // quest has no configured locations yet.
            if ((quest.locations == null || quest.locations.isEmpty()) && area != null) {
                try {
                    StorageCache.getInstance().ensureQuestLocation(questId, area.getId());
                } catch (Exception e) {
                    ccqr1.put("bSuccess", 0);
                    ccqr1.put("msg", "Unable to save quest location.");
                    Kaiden_Extension.getInstance().send(ccqr1, this.user);
                    return;
                }
            }
            if (quest.locations == null || quest.locations.isEmpty()
                    || area == null || !quest.locations.contains(area.getId())) {
                ccqr1.put("bSuccess", 0);
                ccqr1.put("msg", "Wrong location to accepted for this quest!");
                Kaiden_Extension.getInstance().send(ccqr1, this.user);

                if(user.isModerator()) {
                    Kaiden_Extension.getInstance().sendZoneMessage("server", ""+ questId, this.user);
                }

                return;
            }

            // Use the normal quest persistence/timer path before checking items.
            QuestProgressManager.acceptQuest(this.user, questId);
            if (!userQuests.contains(questId)) {
                ccqr1.put("bSuccess", 0);
                ccqr1.put("msg", "Unable to activate quest.");
                Kaiden_Extension.getInstance().send(ccqr1, this.user);
                return;
            }

            // Keep client quest state in sync so the tracker can collect missing items.
            JSONObject accepted = new JSONObject();
            accepted.put("cmd", "acceptQuest");
            accepted.put("QuestID", questId);
            accepted.put("bSuccess", 1);
            accepted.put("bAccepted", 1);
            accepted.put("status", "p");
            accepted.put("strStatus", "p");
            accepted.put("MapID", QuestProgressManager.getQuestMapId(quest));
            accepted.put("iMap", QuestProgressManager.getQuestMapId(quest));
            accepted.put("msg", "Quest Accepted!");
            if (quest.isTimed()) {
                int seconds = QuestProgressManager.getTimedQuestSecondsLeft(this.user, questId, quest.getTimeLimitTotalSeconds());
                accepted.put("bTimed", 1);
                accepted.put("timeLimitMinutes", quest.getTimeLimitMinutes());
                accepted.put("timeLimitSeconds", quest.getTimeLimitSeconds());
                accepted.put("timeLimitTotalSeconds", quest.getTimeLimitTotalSeconds());
                accepted.put("timeLeftMinutes", seconds / 60);
                accepted.put("timeLeftSeconds", seconds % 60);
                accepted.put("timeLeftTotalSeconds", seconds);
                accepted.put("sTimeLeft", (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60));
            }
            Kaiden_Extension.getInstance().send(accepted, this.user);
        }

        if (quest.isOnce()) {
            qty = 1;
        }
        if (quest.getField() != null && !quest.getField().trim().isEmpty()) {
            qty = 1;
        }

        boolean hasChoiceReward = false;
        boolean validChoiceReward = false;

        if (quest.rewards != null) {
            for (QuestRewardBean reward : quest.rewards) {
                if (reward == null || reward.type == null) {
                    continue;
                }

                if ("C".equalsIgnoreCase(reward.type)) {
                    hasChoiceReward = true;
                    if (reward.itemId == selectedItemId) {
                        validChoiceReward = true;
                    }
                }
            }
        }

        if (hasChoiceReward && !validChoiceReward) {
            ccqr1.put("bSuccess", 0);
            ccqr1.put("msg", "Please choose a valid reward.");
            Kaiden_Extension.getInstance().send(ccqr1, this.user);
            return;
        }
        
        if (qty <= 0) {
            qty = 1;
        }

        int completedCount = 0;
        Map<Integer, Integer> rewardTotals = new LinkedHashMap<Integer, Integer>();

        for (int i = 0; i < qty; i++) {
            if (quest.requirements != null && !quest.requirements.isEmpty()) {
                // Log actual server requirements, not the client quest tracker.
                for (Map.Entry<Integer, Integer> requirement : quest.requirements.entrySet()) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage("yellow",
                            "[QuestTurnIn] quest=" + questId + " item=" + requirement.getKey()
                            + " required=" + requirement.getValue()
                            + " available=" + getOwnedRequirementQuantity(requirement.getKey())
                            + " accepted=" + userQuests.contains(questId));
                }
                if (!Users.getInstance().turnInItems(this.user, quest.requirements)) {
                    if (completedCount == 0) {
                        ccqr1.put("bSuccess", 0);
                        ccqr1.put("msg", "Failed to turn in required items.");
                        Kaiden_Extension.getInstance().send(ccqr1, this.user);
                        return;
                    }
                    break;
                }
            }

            completedCount++;

            Set<UserDrop> completionDrops = buildCompletionDrops(quest, selectedItemId);

            if (!completionDrops.isEmpty()) {
                Users.getInstance().dropQuestRewards(this.user, completionDrops);

                for (UserDrop drop : completionDrops) {
                    Integer oldQty = rewardTotals.get(drop.getItemId());
                    rewardTotals.put(drop.getItemId(), (oldQty == null ? 0 : oldQty) + drop.getQuantity());

                    ItemBean dropI = StorageCache.getInstance().getItem(drop.getItemId());
                    if (dropI != null && Users.getInstance().scanInventoryItem(this.user, dropI, drop.getQuantity())) {
                        Kaiden_Extension.getInstance().sendToUser(
                                "warning",
                                "You missed the drop " + dropI.getName() + " due to it already being in your inventory.",
                                this.user
                        );
                    }
                }
            }

            Users.getInstance().UsersQuestLog(this.user, questId);

            Users.getInstance().giveRewards(
                    this.user,
                    quest.getExperience(),
                    quest.getGold(),
                    quest.getClassPoints(),
                    quest.getReputation(),
                    quest.getCoin(),
                    0,
                    0,
                    quest.getFactionId(),
                    this.user.getUserId(),
                    "p"
            );
        }

        if (completedCount <= 0) {
            ccqr1.put("bSuccess", 0);
            ccqr1.put("msg", "Failed to complete quest.");
            Kaiden_Extension.getInstance().send(ccqr1, this.user);
            return;
        }

        if (quest.getSlot() != -1) {
            Users.getInstance().setQuestValue(this.user, quest.getSlot(), quest.getValue());
        }

        if (quest.getField() != null && !quest.getField().isEmpty()) {
            Users.getInstance().setAchievement(quest.getField(), quest.getIndex(), quest.getValue(), user);
            //Kaiden_Engine.getInstance().sendEmulatorMessage("pinkb", "setting achievement " + achievement.getField());
        }
        if(quest.getAchievement() > 0 ) {
            Users.getInstance().giveAchievement(this.user, quest.getAchievement());
        }

        QuestProgressManager.removeQuest(this.user, questId);
        //handles quest progression for wars
        WarProgress.contributeForQuest(questId, this.user.getUserId(), completedCount);

        JSONObject rewardObj = new JSONObject();
        rewardObj.put("intGold", quest.getGold() * completedCount);
        rewardObj.put("intExp", quest.getExperience() * completedCount);
        rewardObj.put("iCP", quest.getClassPoints() * completedCount);
        rewardObj.put("iRep", quest.getReputation() * completedCount);
        rewardObj.put("intAmount", quest.getCoin() * completedCount);

        ccqr1.put("rewardObj", rewardObj);
        ccqr1.put("sName", quest.getName());
        ccqr1.put("bSuccess", 1);

        JSONArray itemArray = new JSONArray();
        for (Map.Entry<Integer, Integer> entry : rewardTotals.entrySet()) {
            JSONObject item = new JSONObject();
            item.put("ItemID", entry.getKey());
            item.put("iQty", entry.getValue());
            itemArray.add(item);
        }

        turnin.put("sItems", itemArray);

        Kaiden_Extension.getInstance().send(ccqr1, this.user);
        Kaiden_Extension.getInstance().send(turnin, this.user);
    }

    private int getMaxPossibleTurnIns(QuestBean quest) {
        if (quest.requirements == null || quest.requirements.isEmpty()) {
            return 1;
        }

        int max = -1;

        for (Map.Entry<Integer, Integer> entry : quest.requirements.entrySet()) {
            int itemId = entry.getKey();
            int requiredQty = entry.getValue();

            if (requiredQty <= 0) {
                continue;
            }

            int ownedQty = getOwnedRequirementQuantity(itemId);
            if (ownedQty < requiredQty) {
                return 0;
            }

            int possible = ownedQty / requiredQty;
            if (max == -1 || possible < max) {
                max = possible;
            }
        }

        if (max < 0) {
            max = 1;
        }

        return Math.min(max, 250);
    }

    private int getOwnedRequirementQuantity(int itemId) {
        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item == null) {
            return 0;
        }

        // Quest items from old maps/databases are not always flagged Temporary
        // consistently.  The client can legitimately show the requirement while
        // the item lives in the other server-side container, so count whichever
        // container actually owns it instead of trusting only Item.isTemporary().
        int tempQty = 0;
        Map<Integer, Integer> tempInventory =
                (Map<Integer, Integer>) this.user.properties.get(Properties.TEMP_ITEMS);
        if (tempInventory != null) {
            Integer value = tempInventory.get(itemId);
            tempQty = value == null ? 0 : Math.max(value, 0);
        }

        int inventoryQty = 0;
        Map<Integer, UserItem> inventory =
                (Map<Integer, UserItem>) this.user.properties.get(Properties.INVENTORY_ITEMS);
        if (inventory != null) {
            UserItem userItem = inventory.get(itemId);
            if (userItem != null) {
                inventoryQty = Math.max(userItem.getQuantity(), 0);
            }
        }

        // Also check the database. A legacy packet path can persist an item but
        // leave the live in-memory inventory stale until the next login/map load.
        int dbQuestQty = 0;
        int dbInventoryQty = 0;
        try {
            dbQuestQty = Storage.getInstance().getJdbc().queryForInt(
                    "SELECT COALESCE(MAX(Quantity),0) FROM users_quests_items WHERE UserID=? AND ItemID=?",
                    this.user.properties.get(Properties.ID), itemId);
        } catch (Exception ignored) {}
        try {
            dbInventoryQty = Storage.getInstance().getJdbc().queryForInt(
                    "SELECT COALESCE(SUM(Quantity),0) FROM users_items WHERE UserID=? AND ItemID=?",
                    this.user.properties.get(Properties.ID), itemId);
        } catch (Exception ignored) {}

        int owned = Math.max(Math.max(tempQty, inventoryQty), Math.max(dbQuestQty, dbInventoryQty));
        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "yellow", "[QuestTurnIn] user=" + this.user.getName() +
                        " ItemID=" + itemId + " tempQty=" + tempQty +
                        " inv=" + inventoryQty + " dbQuest=" + dbQuestQty +
                        " dbInv=" + dbInventoryQty + " owned=" + owned);
        return owned;
    }

    private Set<UserDrop> buildCompletionDrops(QuestBean quest, int selectedItemId) {
        Set<UserDrop> drops = new HashSet<UserDrop>();
        List<QuestRewardBean> rollRewards = new ArrayList<QuestRewardBean>();
        List<QuestRewardBean> randRewards = new ArrayList<QuestRewardBean>();

        if (quest.rewards == null || quest.rewards.isEmpty()) {
            return drops;
        }

        for (QuestRewardBean reward : quest.rewards) {
            if (reward == null || reward.type == null) {
                continue;
            }

            String rewardType = reward.type.trim();

            if ("S".equalsIgnoreCase(rewardType)) {
                drops.add(new UserDrop(reward.itemId, reward.quantity, false));
            } else if ("C".equalsIgnoreCase(rewardType)) {
                if (reward.itemId == selectedItemId) {
                    drops.add(new UserDrop(reward.itemId, reward.quantity, false));
                }
            } else if ("rand".equalsIgnoreCase(rewardType)) {
                randRewards.add(reward);
            } else if ("R".equalsIgnoreCase(rewardType)) {
                rollRewards.add(reward);
            }
        }

        if (!rollRewards.isEmpty()) {
            QuestRewardBean roll = rollRewards.get(new Random().nextInt(rollRewards.size()));
            drops.add(new UserDrop(roll.itemId, roll.quantity, false));
        }

        if (!randRewards.isEmpty()) {
            QuestRewardBean roll = pickRandomReward(randRewards);
            if (roll != null) {
                drops.add(new UserDrop(roll.itemId, roll.quantity, false));
            }
        }

        return drops;
    }
    private QuestRewardBean pickRandomReward(List<QuestRewardBean> rewards) {
        if (rewards == null || rewards.isEmpty()) {
            return null;
        }

        double totalWeight = 0.0D;
        for (QuestRewardBean reward : rewards) {
            if (reward != null) {
                totalWeight += reward.rate > 0.0D ? reward.rate : 1.0D;
            }
        }

        if (totalWeight <= 0.0D) {
            return rewards.get(new Random().nextInt(rewards.size()));
        }

        double roll = Math.random() * totalWeight;
        double running = 0.0D;
        for (QuestRewardBean reward : rewards) {
            if (reward == null) {
                continue;
            }
            running += reward.rate > 0.0D ? reward.rate : 1.0D;
            if (roll <= running) {
                return reward;
            }
        }

        return rewards.get(rewards.size() - 1);
    }
}
