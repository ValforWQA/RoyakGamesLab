package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;
import Kaiden.Game.Server.Users.Properties;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("ALL")
public class AbandonQuest extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params == null || this.params.length <= 0) {
            return;
        }

        int questId = Integer.parseInt(this.params[0]);
        // Snapshot server-owned temporary inventory before authoritative cleanup.
        Map<Integer, Integer> before = new HashMap<Integer, Integer>();
        ConcurrentHashMap<Integer, Integer> tempBefore =
                (ConcurrentHashMap<Integer, Integer>) this.user.properties.get(Properties.TEMP_ITEMS);
        if (tempBefore != null) before.putAll(tempBefore);

        boolean abandoned = QuestProgressManager.abandonQuest(this.user, questId);
        if (!abandoned) {
            JSONObject failure = new JSONObject();
            failure.put("cmd", "abandonQuest");
            failure.put("QuestID", questId);
            failure.put("bSuccess", 0);
            failure.put("bAccepted", 1);
            failure.put("msg", "Unable to abandon quest. Please retry.");
            Kaiden_Extension.getInstance().send(failure, this.user);
            return;
        }

        // The existing AS3 client understands turnIn.sItems as item removals.
        // Only report quantities actually removed, never items shared with active quests.
        ConcurrentHashMap<Integer, Integer> tempAfter =
                (ConcurrentHashMap<Integer, Integer>) this.user.properties.get(Properties.TEMP_ITEMS);
        StringBuilder removed = new StringBuilder();
        for (Map.Entry<Integer, Integer> entry : before.entrySet()) {
            int prior = entry.getValue() == null ? 0 : entry.getValue();
            Integer remaining = tempAfter == null ? null : tempAfter.get(entry.getKey());
            int current = remaining == null ? 0 : remaining;
            int difference = prior - current;
            if (difference <= 0) continue;
            if (removed.length() > 0) removed.append(",");
            removed.append(entry.getKey()).append(":").append(difference);
        }
        if (removed.length() > 0) {
            JSONObject removal = new JSONObject();
            removal.put("cmd", "turnIn");
            removal.put("sItems", removed.toString());
            Kaiden_Extension.getInstance().send(removal, this.user);
        }

        JSONObject qObj = new JSONObject();
        qObj.put("cmd", "abandonQuest");
        qObj.put("QuestID", questId);
        qObj.put("bSuccess", 1);
        qObj.put("bAccepted", 0);
        qObj.put("status", "");
        qObj.put("strStatus", "");
        qObj.put("msg", "Quest abandoned.");
        Kaiden_Extension.getInstance().send(qObj, this.user);
        // Refresh the client's active quest tracker from DB-confirmed state.
        java.util.Set<Integer> active = (java.util.Set<Integer>) this.user.properties.get(Properties.QUESTS);
        Kaiden_Extension.getInstance().send(
                QuestProgressManager.buildGetQuestsPayload(this.user, active), this.user);
    }
}
