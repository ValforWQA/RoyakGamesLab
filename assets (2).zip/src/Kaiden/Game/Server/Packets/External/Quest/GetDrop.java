package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("ALL")
public class GetDrop extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(this.params[0]);
        acceptPendingDrop(this.user, itemId, true);
    }

    /*
     * Used by LiveRewards after Users.dropItems(...) sends the normal dropItem packet.
     * This accepts the same pending drop through the normal inventory logic.
     */
    public static boolean acceptPendingDrop(User user, int itemId, boolean markQuestDrop) {
        if (user == null || user.properties == null) {
            return false;
        }

        ConcurrentHashMap<Integer, UserDrop> drops =
                (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");
        ConcurrentHashMap<Integer, UserItem> inventoryItems =
                (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems =
                (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.BANK_ITEMS);

        if (drops == null || inventoryItems == null || bankItems == null || !drops.containsKey(itemId)) {
            return false;
        }

        // Only genuine Quest Items are subject to the quest-drop acceptance guard.
        // Regular item types can be collected from the server-issued in-memory drop
        // even if ReqQuests contains legacy quest metadata or no DB pending row exists.
        ItemBean pendingItem = StorageCache.getInstance().getItem(itemId);
        if (pendingItem == null) {
            drops.remove(itemId);
            showFailed(user, itemId);
            return false;
        }
        String itemType = pendingItem.getType();
        boolean questItem = itemType != null &&
                ("Quest Item".equalsIgnoreCase(itemType.trim()) ||
                 "QuestItem".equalsIgnoreCase(itemType.trim()));
        if (questItem && !QuestProgressManager.isQuestDropPickupAllowed(user, itemId)) {
            drops.remove(itemId);
            QuestProgressManager.markDropDeclined(user, itemId);
            showFailed(user, itemId);
            return false;
        }

        boolean success = false;
        UserDrop userDrop = drops.get(itemId);
        int quantityToDrop = userDrop.getQuantity();
        ItemBean item = StorageCache.getInstance().getItem(itemId);

        if (item == null) {
            drops.remove(itemId);
            if (markQuestDrop) {
                QuestProgressManager.markDropDeclined(user, itemId);
            }
            return false;
        }

        // A pending drop may be stale; never insert more than the item's stack.
        quantityToDrop = Math.min(Math.max(0, quantityToDrop), Math.max(1, item.getStack()));
        if (quantityToDrop <= 0) {
            showFailed(user, itemId);
            return false;
        }

        // Recheck the combined inventory + bank quantity at acceptance time.
        // The authoritative cap is item.getStack(), even if the player moved
        // items while the pending drop popup was open.
        int inventoryOwned = inventoryItems.containsKey(itemId)
                ? Math.max(0, inventoryItems.get(itemId).getQuantity()) : 0;
        int bankOwned = bankItems.containsKey(itemId)
                ? Math.max(0, bankItems.get(itemId).getQuantity()) : 0;
        int remaining = Math.max(0, item.getStack() - inventoryOwned - bankOwned);
        quantityToDrop = Math.min(quantityToDrop, remaining);
        if (quantityToDrop <= 0) {
            showFailed(user, itemId);
            return false;
        }

        if (inventoryItems.containsKey(itemId)) {
            UserItem userItem = inventoryItems.get(itemId);

            if (item.getStack() > 1) {
                int quantity = userItem.getQuantity();

                if (quantity >= item.getStack()) {
                    showFailed(user, itemId);
                } else {
                    int newQty = Math.min(item.getStack(), quantity + quantityToDrop);
                    int addedQty = Math.max(0, newQty - quantity);

                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ? AND Bank = 0",
                            newQty,
                            itemId,
                            user.properties.get(Properties.ID)
                    );

                    userItem.setQuantity(newQty);
                    showDrop(user, userItem.getCharItemId(), item, addedQty, false);
                    success = true;
                }
            } else if (item.getStack() == 1) {
                showFailed(user, itemId);
            }
        } else if (bankItems.containsKey(itemId)) {
            UserItem userItem = bankItems.get(itemId);

            if (item.getStack() > 1) {
                int quantity = userItem.getQuantity();

                if (quantity >= item.getStack()) {
                    showFailed(user, itemId);
                } else {
                    int newQty = Math.min(item.getStack(), quantity + quantityToDrop);
                    int addedQty = Math.max(0, newQty - quantity);

                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?",
                            newQty,
                            itemId,
                            user.properties.get(Properties.ID)
                    );

                    userItem.setQuantity(newQty);
                    showDrop(user, userItem.getCharItemId(), item, addedQty, true);
                    success = true;
                }
            } else if (item.getStack() == 1) {
                showFailed(user, itemId);
            }
        } else {
            try {
                Storage.getInstance().getJdbc().beginTransaction();

                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_items (UserID, ItemID, EnhID, Equipped, Quantity, Bank, DatePurchased) VALUES (?, ?, ?, 0, ?, 0, NOW())",
                        user.properties.get(Properties.ID),
                        itemId,
                        item.getEnhId(),
                        quantityToDrop
                );

                int charItemId = Long.valueOf(Storage.getInstance().getJdbc().getLastInsertId()).intValue();
                inventoryItems.put(itemId, new UserItem(charItemId, quantityToDrop, item.getId(), item.getEnhId()));
                showDrop(user, charItemId, item, quantityToDrop, false);
                success = true;
            } catch (JdbcException e) {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                }

                Log.error(GetDrop.class.getName(), e);
                showFailed(user, itemId);
            } finally {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().commitTransaction();
                }
            }
        }

        if (success) {
            drops.remove(itemId);

            if (markQuestDrop) {
                QuestProgressManager.markDropAccepted(user, itemId);
            }
        }

        return success;
    }

    private static void showFailed(User user, int itemId) {
        JSONObject gd = new JSONObject();
        gd.put("cmd", "getDrop");
        gd.put("ItemID", itemId);
        gd.put("bSuccess", "0");
        Kaiden_Extension.getInstance().send(gd, user);
    }

    private static void showDrop(User user, int charItemId, ItemBean item, int quantityDrop, boolean bank) {
        JSONObject gd = new JSONObject();
        gd.put("cmd", "getDrop");
        gd.put("ItemID", item.getId());
        gd.put("bSuccess", "1");
        gd.put("CharItemID", charItemId);
        gd.put("bBank", bank);
        gd.put("bHouse", item.isHouse() ? 1 : 0);
        gd.put("iQty", quantityDrop);
        gd.put("showDrop", "1");

        if (item.getEnhId() > 0) {
            EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(item.getEnhId());

            if (enhancement == null) {
                enhancement = StorageCache.getInstance().getEnhancement(1);
            }

            gd.put("EnhID", item.getEnhId());
            gd.put("EnhLvl", enhancement.getLevel());
            gd.put("EnhPatternID", enhancement.getClientPatternId());
            gd.put("EnhRty", enhancement.getRarity());
            gd.put("ProcID", enhancement.getProcId());
        }

        Kaiden_Extension.getInstance().send(gd, user);
    }
}
