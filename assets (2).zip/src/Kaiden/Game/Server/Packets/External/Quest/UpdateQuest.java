package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;


public class UpdateQuest extends ExternalPacketHandler {

    public void handle() {
        int slot = Integer.parseInt(this.params[0]);
        int value = Integer.parseInt(this.params[1]);
        Users.getInstance().setQuestValue(this.user, slot, value);
        QuestProgressManager.saveAll(this.user);
    }
}
