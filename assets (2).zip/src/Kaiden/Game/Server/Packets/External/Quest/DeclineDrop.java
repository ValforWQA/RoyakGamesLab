package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;

import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("ALL")
public class DeclineDrop extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params == null || this.params.length <= 0) {
            return;
        }

        int itemId = Integer.parseInt(this.params[0]);
        ConcurrentHashMap<Integer, UserDrop> drops = (ConcurrentHashMap<Integer, UserDrop>) this.user.properties.get("drops");
        if (drops != null) {
            drops.remove(itemId);
        }

        QuestProgressManager.markDropDeclined(this.user, itemId);
    }
}
