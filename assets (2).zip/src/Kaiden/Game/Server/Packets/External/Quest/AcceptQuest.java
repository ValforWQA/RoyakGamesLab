package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.Set;

public class AcceptQuest extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        int questId = Integer.parseInt(this.params[0]);

        JSONObject qObj = new JSONObject();
        qObj.put("cmd", "acceptQuest");
        qObj.put("QuestID", questId);

        Set<Integer> quests = (Set<Integer>) this.user.properties.get("quests");
        QuestBean quest = StorageCache.getInstance().getQuest(questId);

        if(user.isModerator()) {
            Kaiden_Extension.getInstance().sendZoneMessage("server", ""+ questId, this.user);
        }

        if (quest == null) {
            qObj.put("bSuccess", 0);
            qObj.put("msg", "Quest not found.");
            Kaiden_Extension.getInstance().send(qObj, this.user);

            if(user.isModerator()) {
                Kaiden_Extension.getInstance().sendZoneMessage("server", ""+ questId, this.user);
            }

            return;
        }

        //goes along with time trial
        //if(quest.getReqSouls() < (int) this.user.properties.get(Properties.SOULS)) {
           // qObj.put("bSuccess", 0);
            //qObj.put("msg", "You do not have enough souls to accept this quest!");
            //Kaiden_Extension.getInstance().send(qObj, this.user);
            //return;
        //}

        if (quests == null) {
            qObj.put("bSuccess", 0);

            qObj.put("msg", "Quest system unavailable.");
            Kaiden_Extension.getInstance().send(qObj, this.user);
            return;
        }

        // A location-less quest learns the map where it is first accepted.
        // Existing quest locations are never modified by this fallback.
        if (quest.locations == null || quest.locations.isEmpty()) {
            ZoneBean currentArea = this.room == null ? null : StorageCache.getInstance()
                    .getArea(this.room.getName().split("-")[0]);
            if (currentArea != null) {
                try {
                    StorageCache.getInstance().ensureQuestLocation(questId, currentArea.getId());
                } catch (Exception e) {
                    qObj.put("bSuccess", 0);
                    qObj.put("msg", "Unable to save quest location.");
                    Kaiden_Extension.getInstance().send(qObj, this.user);
                    return;
                }
            }
            if (quest.locations == null || quest.locations.isEmpty()) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Unable to resolve current quest map.");
                Kaiden_Extension.getInstance().send(qObj, this.user);
                return;
            }
        }

        qObj.put("status", "p");
        qObj.put("strStatus", "p");
        qObj.put("bAccepted", 1);
        qObj.put("MapID", QuestProgressManager.getQuestMapId(quest));
        qObj.put("iMap", QuestProgressManager.getQuestMapId(quest));
        if (quest.isTimed()) {
            int totalSeconds = quest.getTimeLimitTotalSeconds();
            qObj.put("timeLimitMinutes", quest.getTimeLimitMinutes());
            qObj.put("timeLimitSeconds", quest.getTimeLimitSeconds());
            qObj.put("timeLimitTotalSeconds", totalSeconds);
            qObj.put("timeLeftMinutes", totalSeconds / 60);
            qObj.put("timeLeftSeconds", totalSeconds % 60);
            qObj.put("timeLeftTotalSeconds", totalSeconds);
            qObj.put("sTimeLeft", (totalSeconds / 60) + ":" + ((totalSeconds % 60) < 10 ? "0" + (totalSeconds % 60) : String.valueOf(totalSeconds % 60)));
            qObj.put("bTimed", 1);
        }

        ZoneBean area = StorageCache.getInstance()
                .getArea(this.room.getName().split("-")[0]);

        if (area == null || !quest.locations.contains(area.getId())) {
            qObj.put("bSuccess", 0);
            qObj.put("msg", "Wrong location to accept for this quest!");
            Users.getInstance().log(
                    this.user,
                    "Invalid Quest Accept",
                    "Quest accept triggered at different location."
            );
            Kaiden_Extension.getInstance().send(qObj, this.user);
            return;
        }

        // Important compatibility fix:
        // Latest client abandon only clears local quest status.
        // If the quest is already server-active, treat this as success
        // instead of rejecting with "Quest already accepted."
        if (quests.contains(questId)) {
            QuestProgressManager.acceptQuest(this.user, questId);
            qObj.put("bSuccess", 1);
            qObj.put("msg", "Quest Accepted!");
            Kaiden_Extension.getInstance().send(qObj, this.user);
            return;
        }

        quests.add(questId);
        QuestProgressManager.acceptQuest(this.user, questId);

        qObj.put("bSuccess", 1);
        qObj.put("msg", "Quest Accepted!");
        Kaiden_Extension.getInstance().send(qObj, this.user);
    }
}