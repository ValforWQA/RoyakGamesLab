package Kaiden.Game.Server.Packets.External.Quest;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.QuestRewardBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map.Entry;
import java.util.Set;

public class GetQuests extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        JSONObject q = new JSONObject();
        JSONObject arrQuests = new JSONObject();

        Set<Integer> activeQuests =
                (Set<Integer>) this.user.properties.get(Properties.QUESTS);

        StringBuilder requestedIds = new StringBuilder();
        StringBuilder missingIds = new StringBuilder();
        StringBuilder blockedIds = new StringBuilder();
        StringBuilder failedIds = new StringBuilder();

        // Old AQW maps can pass multiple IDs in one string, while newer
        // clients may send each ID as a separate parameter.
        ZoneBean currentArea = StorageCache.getInstance()
                .getArea(room.getName().split("-")[0]);

        if (params != null) {
            for (String rawParam : params) {
                if (rawParam == null) {
                    continue;
                }
                for (String rawId : rawParam.split(",")) {
                    String strId = rawId.trim();
                    if (strId.isEmpty()) {
                        continue;
                    }
                    final int questId;
                    try {
                        questId = Integer.parseInt(strId);
                    } catch (NumberFormatException ex) {
                        appendDiagnostic(failedIds, strId);
                        continue;
                    }
                    appendDiagnostic(requestedIds, String.valueOf(questId));

                    try {
                        QuestBean questObj = StorageCache.getInstance().getQuest(questId);
                        if (questObj == null) {
                            appendDiagnostic(missingIds, strId);
                            continue;
                        }

                        // Preserve location restrictions. Never abort the entire
                        // batch: other quests still need their response.
                        if ((questObj.locations == null || questObj.locations.isEmpty())
                                && currentArea != null) {
                            StorageCache.getInstance()
                                    .ensureQuestLocation(questId, currentArea.getId());
                        }
                        if (questObj.locations != null && !questObj.locations.isEmpty()
                                && (currentArea == null
                                || !questObj.locations.contains(currentArea.getId()))) {
                            appendDiagnostic(blockedIds, strId);
                            Users.getInstance().log(user, "Invalid Quest Load",
                                    "Quest " + questId + " requested outside its location.");
                            continue;
                        }

                        boolean active = activeQuests != null
                                && activeQuests.contains(questId);
                        JSONObject questJson = buildQuestJson(questObj, questId, active);
                        QuestProgressManager.putQuestTimerFields(
                                this.user, questId, questObj, questJson);
                        arrQuests.put(String.valueOf(questId), questJson);
                    } catch (RuntimeException ex) {
                        // An invalid quest record must not suppress all other
                        // quest data or the response packet.
                        appendDiagnostic(failedIds, strId);
                        Users.getInstance().log(user, "Quest Load Error",
                                "Quest " + questId + ": " + ex.toString());
                    }
                }
            }
        }

        if (user.isAdmin() || user.isModerator()) {
            Kaiden_Extension.getInstance().sendZoneMessage("server",
                    "getQuests requested=[" + requestedIds + "] returned="
                    + arrQuests.size() + " missing=[" + missingIds
                    + "] locationBlocked=[" + blockedIds
                    + "] failed=[" + failedIds + "]", this.user);
        }

        q.put("cmd", "getQuests");
        q.put("quests", arrQuests);

        Kaiden_Extension.getInstance().send(q, user);
    }

    private static void appendDiagnostic(StringBuilder target, String value) {
        if (target.length() > 0) {
            target.append(",");
        }
        target.append(value);
    }

    public static JSONObject buildQuestJson(
            QuestBean questObj,
            int questId,
            boolean active) {

        JSONObject questJson = new JSONObject();

        JSONObject oRewards = new JSONObject();
        JSONArray rewC = new JSONArray();
        JSONArray rewS = new JSONArray();
        JSONArray rewR = new JSONArray();
        JSONArray rewRand = new JSONArray();
        JSONArray rewardsFlat = new JSONArray();

        if (questObj.rewards != null && !questObj.rewards.isEmpty()) {
            for (QuestRewardBean reward : questObj.rewards) {
                ItemBean item = StorageCache.getInstance()
                        .getItem(reward.itemId);

                if (item == null) {
                    continue;
                }

                int ratePercent = (int) Math.round(reward.rate * 100);

                JSONObject itemJSON = item.getItemJSON();
                itemJSON.put("ItemID", reward.itemId);
                itemJSON.put("iQty", reward.quantity);
                itemJSON.put("iRate", ratePercent);

                if ("C".equalsIgnoreCase(reward.type)) {
                    rewC.add(itemJSON);
                } else if ("S".equalsIgnoreCase(reward.type)) {
                    rewS.add(itemJSON);
                } else if ("R".equalsIgnoreCase(reward.type)) {
                    rewR.add(itemJSON);
                } else if ("rand".equalsIgnoreCase(reward.type)) {
                    rewRand.add(itemJSON);
                }

                JSONObject r = new JSONObject();
                r.put("ItemID", reward.itemId);
                r.put("QuestID", questId);
                r.put("iRate", ratePercent);
                r.put("iQty", reward.quantity);
                rewardsFlat.add(r);
            }

            if (!rewS.isEmpty()) {
                oRewards.put("itemsS", rewS);
            }

            if (!rewC.isEmpty()) {
                oRewards.put("itemsC", rewC);
            }

            if (!rewR.isEmpty()) {
                oRewards.put("itemsR", rewR);
            }

            if (!rewRand.isEmpty()) {
                oRewards.put("itemsrand", rewRand);
            }
        }

        JSONObject reqdArray = new JSONObject();
        JSONArray reqd = new JSONArray();

        for (Entry<Integer, Integer> entry : questObj.required.entrySet()) {
            int itemId = entry.getKey();
            int quantity = entry.getValue();

            ItemBean item = StorageCache.getInstance().getItem(itemId);

            if (item == null) {
                continue;
            }

            JSONObject itemJSON = item.getItemJSON();
            itemJSON.put("ItemID", itemId);

            reqdArray.put(String.valueOf(itemId), itemJSON);

            JSONObject itemJSONObject = new JSONObject();
            itemJSONObject.put("ItemID", itemId);
            itemJSONObject.put("QuestID", questId);
            itemJSONObject.put("iQty", quantity);

            reqd.add(itemJSONObject);
        }

        JSONArray turnin = new JSONArray();
        JSONObject oItems = new JSONObject();

        for (Object o : questObj.requirements.entrySet()) {
            Entry e = (Entry) o;

            int reqItemId = (Integer) e.getKey();
            int reqQty = (Integer) e.getValue();

            ItemBean reqItem = StorageCache.getInstance()
                    .getItem(reqItemId);

            if (reqItem == null) {
                continue;
            }

            JSONObject item = reqItem.getItemJSON();
            item.put("ItemID", reqItemId);

            oItems.put(reqItemId, item);

            JSONObject turnInObj = new JSONObject();
            turnInObj.put("ItemID", String.valueOf(reqItemId));
            turnInObj.put("QuestID", questId);
            turnInObj.put("iQty", reqQty);

            turnin.add(turnInObj);
        }

        questJson.put("FactionID", questObj.getFactionId());
        questJson.put(
                "sFaction",
                StorageCache.getInstance().getFaction(questObj.getFactionId())
        );

        questJson.put("QuestID", questId);
        questJson.put("bOnce", questObj.isOnce() ? 1 : 0);
        questJson.put("bStaff", 0);
        questJson.put("bUpg", questObj.isUpgrade() ? 1 : 0);

        if (questObj.getReqClassId() > 0) {
            ItemBean cls = StorageCache.getInstance()
                    .getItem(questObj.getReqClassId());

            if (cls != null) {
                questJson.put("sClass", cls.getName());
            }
        }

        questJson.put("iClass", questObj.getReqClassId());
        questJson.put("iExp", questObj.getExperience());
        questJson.put("iGold", questObj.getGold());
        questJson.put("iLvl", questObj.getLevel());
        questJson.put("iCoins", questObj.getCoin());
        questJson.put("intAmount", questObj.getCoin());
        questJson.put("iRep", questObj.getReputation());
        questJson.put("iReqCP", questObj.getReqClassPoints());
        questJson.put("iReqRep", questObj.getReqReputation());
        questJson.put("iSlot", questObj.getSlot());
        questJson.put("iValue", questObj.getValue());
        questJson.put("iWar", questObj.getWar());

        questJson.put("oItems", oItems);
        questJson.put("oRewards", oRewards);
        questJson.put("reward", rewardsFlat);

        questJson.put("sDesc", questObj.getDescription());
        questJson.put("sEndText", questObj.getEndText());
        questJson.put("sName", questObj.getName());
        questJson.put("turnin", turnin);

        if (!questObj.required.isEmpty()) {
            questJson.put("reqd", reqd);
            questJson.put("oReqd", reqdArray);
        }

        if (!questObj.getField().isEmpty()) {
            questJson.put("sField", questObj.getField());
            questJson.put("iIndex", questObj.getIndex());
        }

        if (questObj.isTimed()) {
            int totalSeconds = questObj.getTimeLimitTotalSeconds();

            questJson.put(
                    "timeLimitMinutes",
                    questObj.getTimeLimitMinutes()
            );

            questJson.put(
                    "timeLimitSeconds",
                    questObj.getTimeLimitSeconds()
            );

            questJson.put(
                    "timeLimitTotalSeconds",
                    totalSeconds
            );

            questJson.put(
                    "timeLeftMinutes",
                    totalSeconds / 60
            );

            questJson.put(
                    "timeLeftSeconds",
                    totalSeconds % 60
            );

            questJson.put(
                    "timeLeftTotalSeconds",
                    totalSeconds
            );

            questJson.put(
                    "sTimeLeft",
                    (totalSeconds / 60) + ":"
                            + ((totalSeconds % 60) < 10
                            ? "0" + (totalSeconds % 60)
                            : String.valueOf(totalSeconds % 60))
            );

            questJson.put("bTimed", 1);
        }

        if (active) {
            questJson.put("status", "p");
            questJson.put("strStatus", "p");
            questJson.put("bAccepted", 1);
        }

        return questJson;
    }
}