package Kaiden.Game.Server.Packets.External.Redeem;


import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class Redeem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        QueryResult code = Storage.getInstance().getJdbc().query("SELECT * FROM codes WHERE Code = ?", this.params[0].trim().toLowerCase());
        if(code.next()) {
            //String[] split = code.getString("").split(",");
            if(new Date().before(code.getDate("DateExpire"))) {
                int id = code.getInt("id");
                Set redeemed = (Set) user.properties.get(Properties.CODED_REDEEMS);
                if (!redeemed.contains(id)) {
                    int experience = code.getInt("Experience");
                    int gold = code.getInt("Gold");
                    int classpoint = code.getInt("ClassPoints");
                    int coin = code.getInt("Coins");
                    int upgradedays = code.getInt("UpgradeDays");

                    QueryResult items = Storage.getInstance().getJdbc().query("SELECT * FROM codes_items WHERE CodeID = ?", code.getInt("id"));
                    Set<UserDrop> dropItems = new HashSet();
                    while (items.next()) {
                        dropItems.add(new UserDrop(items.getInt("ItemID"), items.getInt("Quantity"), false));
                    }
                    Users.getInstance().dropItems(this.user, dropItems);
                    items.close();

                    QueryResult achievements = Storage.getInstance().getJdbc().query("SELECT * FROM codes_achievements WHERE CodeID = ?", code.getInt("id"));
                    while (achievements.next()) {
                        Users.getInstance().giveAchievement(this.user, achievements.getInt("AchID"));
                    }
                    achievements.close();

                    Users.getInstance().giveRewards(this.user, experience, gold, classpoint, 0, coin, 0, 0, -1, this.user.getUserId(), "p");

                    if(experience > 0) {
                        Kaiden_Extension.getInstance().send(new String[] {"server", "You received " + experience + " experience from the code!"}, this.user); }
                    if(gold > 0) {
                        Kaiden_Extension.getInstance().send(new String[] {"server", "You received " + gold + " gold from the code!"}, this.user);
                    }
                    if(classpoint > 0) {
                        Kaiden_Extension.getInstance().send(new String[] {"server", "You received " + coin + " class points from the code!"}, this.user);
                    }
                    if(coin > 0) {
                        Kaiden_Extension.getInstance().send(new String[] {"server", "You received " + coin + " rubies from the code!"}, this.user);
                    }

                    if(upgradedays > 0) {
                        Users.getInstance().giveUpgradeDays(this.user, upgradedays);
                        Kaiden_Extension.getInstance().send(new String[] {"server", "You received " + upgradedays + " upgrade days from the code!"}, this.user);
                    }

                    JSONObject modal = new JSONObject();
                    modal.put("cmd", "modalmc");
                    modal.put("msg", "You successfully redeemed the code!");
                    modal.put("glow", "green");
                    Kaiden_Extension.getInstance().send(modal, this.user);
                    Storage.getInstance().getJdbc().run("INSERT INTO users_codes (UserID, CodeID, Date) VALUES (?, ?, NOW())", this.user.properties.get(Properties.ID), id);
                    redeemed.add(id);
                    code.close();
                } else {
                    code.close();
                    throw new RequestExternalPacketException("You already redeemed this code!");
                }
            } else {
                code.close();
                throw new RequestExternalPacketException("The code you're trying to redeem is already expired!");
            }
        } else {
            code.close();
            throw new RequestExternalPacketException("The code you're trying to redeem is invalid!");
        }
    }
}