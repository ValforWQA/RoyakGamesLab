package Kaiden.Game.Server.Packets.External.Shop;

import Kaiden.Database.Beans.HairBean;
import Kaiden.Database.Beans.HairshopBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;

public class LoadEnhShop extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
          int enhShopID = Integer.parseInt(params[0]);
          Kaiden_Extension.getInstance().sendZoneMessage("moderator", ""+ enhShopID, this.user);

    }
}
