package Kaiden.Game.Server.Packets.External.Shop;

import Kaiden.Database.Beans.HairBean;
import Kaiden.Database.Beans.HairshopBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;

public class LoadHairshop extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int shopId = Integer.parseInt(params[0]);
        HairshopBean hairshopObj = StorageCache.getInstance().getHairShop(shopId);
        if (hairshopObj != null) {
            JSONObject hairshop = new JSONObject();
            JSONArray arrHairs = new JSONArray();
            Set<Integer> shopItems = hairshopObj.getShopItems((String) user.properties.get("gender"));
            for (Integer hairId : shopItems) {
                HairBean hairObj = StorageCache.getInstance().getHair(hairId);
                if (hairObj != null) {
                    JSONObject hair = new JSONObject();
                    hair.put("sFile", hairObj.getFile());
                    hair.put("HairID", hairId);
                    hair.put("sName", hairObj.getName());
                    hair.put("sGen", hairObj.getGender());
                    arrHairs.add(hair);
                }
            }
            hairshop.put("HairShopID", shopId);
            hairshop.put("cmd", "loadHairShop");
            hairshop.put("hair", arrHairs);
            Kaiden_Extension.getInstance().send(hairshop, user);
        }
    }
}
