package Kaiden.Game.Server.Packets.External.Shop;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.ShopBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map.Entry;

public class LoadPTREnhShop extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        int shopId = Integer.parseInt(params[0]);
        if (shopId != 141 && shopId != 142 && shopId != 144 && shopId != 145) return;
        ShopBean shopObj = StorageCache.getInstance().getShop(shopId);
        if (shopObj != null) {
            if (!shopObj.isUpgrade() || (Integer) user.properties.get("upgdays") > 0) {
                ZoneBean area = StorageCache.getInstance().getArea(room.getName().split("-")[0]);

                if (shopObj.locations != null && !shopObj.locations.isEmpty() && !user.isAdmin() && !user.isModerator()) {
                    if (area != null && !shopObj.locations.contains(area.getId())) {
                        Users.getInstance().log(user, "Invalid Shop Load", "Shop load triggered at different location.");
                        return;
                    }
                }

                // Remember the last shop opened so /createshoplocation can be used with no ID.
                if(user.isAdmin() || user.isModerator()) {
                Kaiden_Extension.getInstance().sendZoneMessage("server", ""+ shopId, this.user);
                }

                user.properties.put("lastShopId", shopId);

                JSONObject shop1 = new JSONObject();
                JSONObject shopinfo = new JSONObject();
                JSONArray items = new JSONArray();

                for (Object o1 : shopObj.items.entrySet()) {
                    Entry entry = (Entry) o1;
                    int shopItemId = (Integer) entry.getKey();
                    int itemId = (Integer) entry.getValue();
                    ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
                    if (itemObj != null) {
                        EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(itemObj.getEnhId());
                        JSONObject item;
                        if (!this.user.isAdmin() && !this.user.isModerator() && shopObj.isStaff()) {
                            item = itemObj.getItemJSON();
                            item.put("ItemID", item.hashCode());
                            item.put("sName", itemObj.getName() + " Preview");
                            item.put("bStaff", 1);
                        } else {
                            item = itemObj.getItemJSON(enhancement);
                        }

                        if (shopObj.isLimited()) {
                            int turnInArr = Storage.getInstance().getJdbc().queryForInt("SELECT QuantityRemain FROM shops_items WHERE id = ?", shopItemId);
                            item.put("iQtyRemain", turnInArr);
                        } else {
                            item.put("iQtyRemain", -1);
                        }

                        item.put("ShopItemID", shopItemId);
                        item.put("iQty", itemObj.getQuantity());
                        item.put("iQSindex", itemObj.getQuestStringIndex());
                        item.put("iQSvalue", itemObj.getQuestStringValue());
                        item.put("iReqCP", itemObj.getReqClassPoints());
                        item.put("iReqRep", itemObj.getReqReputation());
                        item.put("FactionID", itemObj.getFactionId());
                        item.put("sFaction", StorageCache.getInstance().getFaction(itemObj.getFactionId()));
                        item.put("iCost", itemObj.getCost() * itemObj.getQuantity());
                        if (itemObj.getReqClassId() > 0) {
                            item.put("iClass", itemObj.getReqClassId());
                            item.put("sClass", StorageCache.getInstance().getItem(itemObj.getReqClassId()).getName());
                        }

                        if (!itemObj.getRequirements().isEmpty()) {
                            JSONArray turnInArr1 = new JSONArray();

                            for (Entry require : itemObj.getRequirements().entrySet()) {
                                int reqItemId = (Integer) require.getKey();
                                ItemBean reqItemObj = StorageCache.getInstance().getItem(reqItemId);
                                int quantityNeeded = (Integer) require.getValue() >= reqItemObj.getStack() ? reqItemObj.getStack() : (Integer) require.getValue();
                                JSONObject wObj = new JSONObject();
                                wObj.put("ItemID", reqItemId);
                                wObj.put("iQty", quantityNeeded);
                                wObj.put("sName", reqItemObj.getName());
                                turnInArr1.add(wObj);
                            }

                            item.put("turnin", turnInArr1);
                        }

                        items.add(item);
                    }
                }

                shopinfo.put("bHouse", shopObj.isHouse() ? 1 : 0);
                shopinfo.put("bStaff", shopObj.isStaff() ? 1 : 0);
                shopinfo.put("bUpgrd", shopObj.isUpgrade() ? 1 : 0);
                shopinfo.put("bLimited", shopObj.isLimited() ? 1 : 0);
                shopinfo.put("iIndex", shopObj.getIndex());
                shopinfo.put("items", items);
                shopinfo.put("ShopID", shopId);
                shopinfo.put("sField", shopObj.getField());
                shopinfo.put("sName", shopObj.getName());
                shop1.put("cmd", "loadEnhShop");
                shop1.put("shopinfo", shopinfo);
                Kaiden_Extension.getInstance().send(shop1, user);
            }
        }
    }
}
