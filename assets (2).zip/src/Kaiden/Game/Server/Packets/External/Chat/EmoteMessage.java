package Kaiden.Game.Server.Packets.External.Chat;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;


public class EmoteMessage extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if ((Integer) user.properties.get("permamute") > 0) {
            throw new RequestExternalPacketException("You are muted! Chat privileges have been permanently revoked.");
        } else {
            Kaiden_Extension.getInstance().sendToRoom(new String[]{"em", user.getName(), params[0]}, user, room);
        }
    }
}
