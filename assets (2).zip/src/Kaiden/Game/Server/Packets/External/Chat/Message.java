package Kaiden.Game.Server.Packets.External.Chat;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class Message extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        if ((Integer) this.user.properties.get("permamute") > 0) {
            throw new RequestExternalPacketException("You are muted! Chat privileges have been permanently revoked.");
        }

        String channel = this.params.length > 1 ? this.params[1] : "zone";
        String message = this.params.length > 0 ? this.params[0] : "";

        if (message.length() > 150) {
            message = message.substring(0, 150);
        }

        switch (channel) {
            case "staff":
                if ((int) this.user.properties.get("access") >= 15) {
                    Kaiden_Extension.getInstance().sendToStaff(
                            new String[]{
                                    "chatm",
                                    getChannelStr("staff", "staff") + "~" + message,
                                    this.user.getName(),
                                    String.valueOf(1)
                            },
                            user
                    );
                }
                break;

            case "world":
                Storage.getInstance().getJdbc().beginTransaction();

                try {
                    int souls = (int) this.user.properties.get(Properties.SOULS);
                    int soulcost = 15;

                    if (souls < soulcost) {
                        throw new RequestExternalPacketException(
                                "You need at least 15 souls to send a message to world channel.",
                                "server"
                        );
                    }

                    Users.getInstance().subtraceSouls(this.user, soulcost);

                    Kaiden_Extension.getInstance().sendToUsers(
                            new String[]{
                                    "chatm",
                                    getChannelStr("world", "world") + "~" + message,
                                    this.user.getName(),
                                    String.valueOf(1)
                            }
                    );
                } catch (JdbcException e) {
                    if (Storage.getInstance().getJdbc().isInTransaction()) {
                        Storage.getInstance().getJdbc().rollbackTransaction();
                    }

                    Log.error(this.getClass().getName(), e);
                } finally {
                    if (Storage.getInstance().getJdbc().isInTransaction()) {
                        Storage.getInstance().getJdbc().commitTransaction();
                    }
                }
                break;

            case "party":
                int partyId = ((Integer) this.user.properties.get("partyId"));

                if (partyId < 0) {
                    throw new RequestExternalPacketException("You are not in a party.", "server");
                }

                PartyInfo party = ManageParties.getInstance().getPartyInfo(partyId);

                if (party == null) {
                    throw new RequestExternalPacketException("Party could not be found.", "server");
                }

                Kaiden_Extension.getInstance().send(
                        new String[]{
                                "chatm",
                                getChannelStr("party", "party") + "~" + message,
                                user.getName(),
                                String.valueOf(1)
                        },
                        party.getChannelList()
                );
                break;

            case "guild":
                if ((Integer) this.user.properties.get("guildid") <= 0) {
                    throw new RequestExternalPacketException("You are not in a guild.", "server");
                }

                JSONObject guildObj = (JSONObject) this.user.properties.get("guildobj");

                if (guildObj == null || !guildObj.containsKey("ul")) {
                    throw new RequestExternalPacketException("Guild data could not be found.", "server");
                }

                JSONArray members = (JSONArray) guildObj.get("ul");

                if (members != null && members.size() > 0) {
                    for (Object member1 : members) {
                        JSONObject member = (JSONObject) member1;

                        User guildUser = Kaiden_Extension.getInstance().getZone().getUserByName(
                                member.get("userName").toString().toLowerCase()
                        );

                        if (guildUser != null) {
                            Kaiden_Extension.getInstance().send(
                                    new String[]{
                                            "chatm",
                                            getChannelStr("guild", "guild") + "~" + message,
                                            this.user.getName(),
                                            String.valueOf(1)
                                    },
                                    guildUser
                            );
                        }
                    }
                }
                break;

            default:
                String chatChannel = getChatChannelByAccess((Integer) this.user.properties.get("access"));

                Kaiden_Extension.getInstance().sendToRoom(
                        new String[]{
                                "chatm",
                                chatChannel + "~" + message,
                                this.user.getName(),
                                String.valueOf(this.room.getId())
                        },
                        this.user,
                        this.room
                );
                break;
        }
    }

    private String getChatChannelByAccess(int userAccess) {
        String channel = "zone";

        try {
            String query =
                    "SELECT `Str` " +
                            "FROM `chat_channels` " +
                            "WHERE `Active` = 1 " +
                            "AND `Access` <= ? " +
                            "AND `ChannelKey` IN (" +
                            "'zone'," +
                            "'hlp'," +
                            "'amb'," +
                            "'moderator'," +
                            "'admin'," +
                            "'dev'" +
                            ") " +
                            "ORDER BY `Access` DESC " +
                            "LIMIT 1";

            channel = Storage.getInstance().getJdbc().queryForString(query, userAccess);

            if (channel == null || channel.trim().length() <= 0) {
                channel = "zone";
            }
        } catch (Exception e) {
            channel = "zone";
        }

        return channel;
    }

    private String getChannelStr(String channelKey, String fallback) {
        String channel = fallback;

        try {
            String query;

            if ("guild".equals(channelKey) || "party".equals(channelKey) || "world".equals(channelKey)) {
                query =
                        "SELECT `Str` " +
                                "FROM `chat_channels` " +
                                "WHERE `ChannelKey` = ? " +
                                "LIMIT 1";
            } else {
                query =
                        "SELECT `Str` " +
                                "FROM `chat_channels` " +
                                "WHERE `Active` = 1 " +
                                "AND `ChannelKey` = ? " +
                                "LIMIT 1";
            }

            channel = Storage.getInstance().getJdbc().queryForString(query, channelKey);

            if (channel == null || channel.trim().length() <= 0) {
                channel = fallback;
            }
        } catch (Exception e) {
            channel = fallback;
        }

        return channel;
    }
}