package Kaiden.Game.Server.Packets.External.Chat;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;


public class CannedChat extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        Kaiden_Extension.getInstance().sendToRoom(new String[]{"cc", params[0], user.getName()}, user, room);
    }
}
