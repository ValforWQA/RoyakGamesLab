package Kaiden.Game.Server.Packets.External.Chat;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

public class Whisper extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if ((Integer) this.user.properties.get("permamute") > 0) {
            throw new RequestExternalPacketException("You are muted! Chat privileges have been permanently revoked.");
        } else {
            String message = this.params[0];
            String username = this.params[1].toLowerCase();
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
            if (client == null) {
                throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
            } else {
                if (!Settings.isAllowed(Settings.WHISPER, this.user, client)) {
                    throw new RequestExternalPacketException("Player " + client.getName() + " is not accepting PMs at this time.");
                } else {
                    String[] msg = new String[]{"whisper", message, this.user.getName(), username, "0"};
                    Kaiden_Extension.getInstance().send(msg, this.user);
                    Kaiden_Extension.getInstance().send(msg, client);
                }
            }
        }
    }
}