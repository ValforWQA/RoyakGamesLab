package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;


public class BuyHouseSlots extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int slotsToPurchase = Integer.parseInt(this.params[0]);
        int houseSlots = (Integer) this.user.properties.get("houseslots") + slotsToPurchase;
        int totalCost = slotsToPurchase * 200;
        if (houseSlots > 40) {
            throw new RequestExternalPacketException("You have already purchased the maximum amount!");
        } else {
            int coins = (int) this.user.properties.get(Properties.COINS);
            int coinsLeft = coins - totalCost;
            if (coinsLeft < 0) {
                Users.getInstance();
                throw new RequestExternalPacketException("You don't have enough " + Users.CURRENCY1 + " !");
            }
            Storage.getInstance().getJdbc().run("UPDATE users SET SlotsHouse = ? WHERE id = ?", houseSlots, this.user.properties.get(Properties.ID));
            this.user.properties.replace(Properties.COINS, coinsLeft);
            this.user.properties.put("houseslots", houseSlots);
            JSONObject object = new JSONObject();
            object.put("cmd", "buyHouseSlots");
            object.put("iSlots", slotsToPurchase);
            object.put("bitSuccess", "1");
            Kaiden_Extension.getInstance().send(object, this.user);
            if (houseSlots == 40) {
                Users.getInstance().giveAchievement(this.user, 9);
            }
        }
    }
}
