package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public class BankSwapInventory extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int bankItemID = Integer.parseInt(params[2]);
        int bankCharItemID = Integer.parseInt(params[3]);
        int invItemID = Integer.parseInt(params[0]);
        int invCharItemID = Integer.parseInt(params[1]);

        ItemBean invItem = StorageCache.getInstance().getItem(invItemID);
        ItemBean bankItem = StorageCache.getInstance().getItem(bankItemID);
        ConcurrentHashMap<Integer, UserItem> inventoryItems = (ConcurrentHashMap) this.user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) this.user.properties.get(Properties.BANK_ITEMS);

        JSONObject modal = new JSONObject();
        modal.put("cmd", "modal");
        modal.put("glow", "red");

        JSONObject bankSwap = new JSONObject();
        bankSwap.put("cmd", "bankSwapInv");
        bankSwap.put("invItemID", invItemID);
        bankSwap.put("bankItemID", bankItemID);

        if(invItem == null || bankItem == null) {
            modal.put("msg", "This item does not exists!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (invItem.isTemporary() || bankItem.isTemporary()) {
            modal.put("msg", "You can't swap temporary items!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (invItem.getEquipment().equals("ho") || invItem.getEquipment().equals("hi") || bankItem.getEquipment().equals("ho") || bankItem.getEquipment().equals("hi")) {
            modal.put("msg", "You can't transfer house items to the bank!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (!invItem.isCoins() && (bankItems.size() >= (Integer) user.properties.get("bankslots"))) {
            modal.put("msg", "Your bank inventory is full!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (inventoryItems.size() >= (Integer) user.properties.get("bagslots")) {
            modal.put("msg", "Your inventory is full!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (!inventoryItems.containsKey(invItemID)) {
            modal.put("msg", "You don't have the item " + invItem.getName() + " in your inventory!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (!bankItems.containsKey(bankItemID)) {
            modal.put("msg", "You don't have the item " + bankItem.getName() + " in your bank inventory!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else {
            Storage.getInstance().getJdbc().run("UPDATE users_items SET Bank = 1 WHERE id = ?", invCharItemID);
            Storage.getInstance().getJdbc().run("UPDATE users_items SET Bank = 0 WHERE id = ?", bankCharItemID);

            UserItem _bankItem = bankItems.get(invItemID);
            UserItem _inventoryItem = inventoryItems.get(bankItemID);

            bankItems.remove(bankItemID);
            inventoryItems.put(bankItemID, _bankItem);

            inventoryItems.remove(invItemID);
            bankItems.put(invItemID, _inventoryItem);
            Kaiden_Extension.getInstance().send(bankSwap, user);
        }
    }
}
