package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;


public class BuyLoadoutSlots extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        int slotsToPurchase = Integer.parseInt(params[0]);
        int loadOutSlots = (Integer) user.properties.get(Properties.LOADOUT_SLOTS) + slotsToPurchase;
        int totalCost = (slotsToPurchase * 250);
                //StorageCache.getInstance().getCoreValue("intLoadoutSpacePrice").intValue());

        Storage.getInstance().getJdbc().beginTransaction();
        try {
            int coins = Storage.getInstance().getJdbc().queryForInt("SELECT Coins FROM users WHERE id = ? FOR UPDATE", user.properties.get(Properties.ID));
            int coinsLeft = (coins - totalCost);
            if (coinsLeft >= 0) {
                Storage.getInstance().getJdbc().run("UPDATE users SET SlotsLoadout = ?, Coins = ? WHERE id = ?", loadOutSlots, coinsLeft, user.properties.get(Properties.ID));

                user.properties.put(Properties.LOADOUT_SLOTS, loadOutSlots);

                JSONObject object = new JSONObject();
                object.put("cmd", "buyLoadoutSlots");
                object.put("iSlots", slotsToPurchase);
                object.put("bitSuccess", "1");

                Kaiden_Extension.getInstance().send(object, user);
            } else
                throw new RequestExternalPacketException("You don't have enough coins!");
        } catch (JdbcException je) {
            if (Storage.getInstance().getJdbc().isInTransaction())
                Storage.getInstance().getJdbc().rollbackTransaction();
            SmartFoxServer.log.severe("Error in buy loadout slots transaction: " + je.getMessage());
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction())
                Storage.getInstance().getJdbc().commitTransaction();
        }
    }
}