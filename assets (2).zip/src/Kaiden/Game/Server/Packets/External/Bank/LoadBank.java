package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class LoadBank extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        List types = Arrays.asList(params);
        JSONObject lb = new JSONObject();
        JSONArray items = new JSONArray();
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) this.user.properties.get(Properties.BANK_ITEMS);
        for (UserItem bankItem : bankItems.values()) {
            ItemBean item = StorageCache.getInstance().getItem(bankItem.getItemId());
            EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(bankItem.getEnhId());
            if (types.contains(item.getType())) {
                JSONObject itemObj = item.getItemJSON(enhancement);
                itemObj.put("bBank", "1");
                itemObj.put("CharItemID", bankItem.getCharItemId());
                itemObj.put("iQty", bankItem.getQuantity());
                items.add(itemObj);
            }
        }
        lb.put("cmd", "loadBank");
        lb.put("items", items);
        lb.put("bitSuccess", 1);
        Kaiden_Extension.getInstance().send(lb, user);
    }
}
