package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;


public class BuyBagSlots extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        int slotsToPurchase = Integer.parseInt(this.params[0]);
        int bagSlots = (Integer) this.user.properties.get("bagslots") + slotsToPurchase;
        int totalCost = slotsToPurchase * 200;
        if (bagSlots > 200) {
            throw new RequestExternalPacketException("You have already purchased the maximum amount!");
        } else {
            int coins = (int) this.user.properties.get(Properties.COINS);
            int coinsLeft = coins - totalCost;
            if (coinsLeft < 0) {
                Users.getInstance();
                throw new RequestExternalPacketException("You don't have enough " + Users.CURRENCY1 + " !");
            }
            Storage.getInstance().getJdbc().run("UPDATE users SET SlotsBag = ? WHERE id = ?", bagSlots, this.user.properties.get(Properties.ID));
            this.user.properties.replace(Properties.COINS, coinsLeft);
            this.user.properties.put("bagslots", bagSlots);
            JSONObject buyBagSlots = new JSONObject();
            buyBagSlots.put("cmd", "buyBagSlots");
            buyBagSlots.put("iSlots", slotsToPurchase);
            buyBagSlots.put("bitSuccess", "1");
            Kaiden_Extension.getInstance().send(buyBagSlots, this.user);
            if (bagSlots == 200) {
                Users.getInstance().giveAchievement(this.user, 7);
            }
        }
    }
}
