package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public class BankFromInventory extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        int itemId = Integer.parseInt(params[0]);
        int charItemId = Integer.parseInt(params[1]);

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        ConcurrentHashMap<Integer, UserItem> inventoryItems = (ConcurrentHashMap) this.user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) this.user.properties.get(Properties.BANK_ITEMS);

        JSONObject bankFromInv = new JSONObject();
        bankFromInv.put("cmd", "bankFromInv");
        bankFromInv.put("ItemID", itemId);
        bankFromInv.put("bSuccess", 0);

        if(item == null) {
            bankFromInv.put("msg", "This item does not exists!");
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        } else if (item.isTemporary()) {
            bankFromInv.put("msg", "You can't transfer temporary items to the bank!");
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        } else if (item.getEquipment().equals("ho") || item.getEquipment().equals("hi")) {
            bankFromInv.put("msg", "You can't transfer house items to the bank!");
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        } else if (!item.isCoins() && (bankItems.size() >= (Integer) user.properties.get("bankslots"))) {
            bankFromInv.put("msg", "Your bank inventory is full!");
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        } else if(!inventoryItems.containsKey(itemId)) {
            bankFromInv.put("msg", "You don't have the item " + item.getName() + " in your inventory!");
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        } else {
            int success = Storage.getInstance().getJdbc().execute("UPDATE users_items SET Bank = 1 WHERE id = ?", charItemId);
            bankFromInv.replace("bSuccess", success);
            if (success == 0) {
                bankFromInv.put("msg", "An error occurred while transferring your item to bank.");
                Kaiden_Extension.getInstance().send(bankFromInv, user);
                return;
            }
            bankItems.put(itemId, inventoryItems.get(itemId));
            inventoryItems.remove(itemId);
            Kaiden_Extension.getInstance().send(bankFromInv, user);
        }
    }
}