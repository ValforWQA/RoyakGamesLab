package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;


public class BuyBankSlots extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int slotsToPurchase = Integer.parseInt(params[0]);
        int bankSlots = (Integer) user.properties.get("bankslots") + slotsToPurchase;
        int totalCost = slotsToPurchase * 200;
        if (bankSlots > 250) {
            throw new RequestExternalPacketException("You have already purchased the maximum amount!");
        } else {
            int coins = (int) this.user.properties.get(Properties.COINS);
            int coinsLeft = coins - totalCost;
            if (coinsLeft < 0) {
                Users.getInstance();
                throw new RequestExternalPacketException("You don't have enough " + Users.CURRENCY1 + " !");
            }
            Storage.getInstance().getJdbc().run("UPDATE users SET SlotsBank = ? WHERE id = ?", bankSlots, this.user.properties.get(Properties.ID));
            this.user.properties.replace(Properties.COINS, coinsLeft);
            this.user.properties.put("bankslots", bankSlots);
            JSONObject buyBankSlots = new JSONObject();
            buyBankSlots.put("cmd", "buyBankSlots");
            buyBankSlots.put("iSlots", slotsToPurchase);
            buyBankSlots.put("bitSuccess", "1");
            Kaiden_Extension.getInstance().send(buyBankSlots, user);
            if (bankSlots == 250) {
                Users.getInstance().giveAchievement(this.user, 8);
            }
        }
    }
}
