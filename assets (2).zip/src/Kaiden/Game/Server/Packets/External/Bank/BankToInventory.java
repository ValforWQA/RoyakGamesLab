package Kaiden.Game.Server.Packets.External.Bank;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public class BankToInventory extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        int charItemId = Integer.parseInt(params[1]);

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        ConcurrentHashMap<Integer, UserItem> inventoryItems = (ConcurrentHashMap) this.user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) this.user.properties.get(Properties.BANK_ITEMS);

        JSONObject bankToInventory = new JSONObject();
        bankToInventory.put("cmd", "bankToInv");
        bankToInventory.put("ItemID", itemId);

        JSONObject modal = new JSONObject();
        modal.put("cmd", "modal");
        modal.put("glow", "red");

        if(item == null) {
            modal.put("msg", "This item does not exists!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (item.isTemporary()) {
            modal.put("msg", "You can't transfer temporary items to your inventory!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if (inventoryItems.size() >= (Integer) user.properties.get("bagslots")) {
            modal.put("msg", "Your inventory is full!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else if(!bankItems.containsKey(itemId)) {
            modal.put("msg", "You don't have the item " + item.getName() + " in your bank inventory!");
            Kaiden_Extension.getInstance().send(modal, user);
        } else {
            Storage.getInstance().getJdbc().run("UPDATE users_items SET Bank = 0 WHERE id = ?", charItemId);
            Kaiden_Extension.getInstance().send(bankToInventory, user);
            inventoryItems.put(itemId, bankItems.get(itemId));
            bankItems.remove(itemId, charItemId);
        }
    }
}