package Kaiden.Game.Server.Packets.External.Duel;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import net.sf.json.JSONObject;

public class PvpInviteReply extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        JSONObject PVPQ = new JSONObject();
        PVPQ.put("cmd", "PVPQ");
        PVPQ.put("bitSuccess", 0);
        if (this.params[0].equals("1")) {
            Room warzoneRoom = (Room) this.user.properties.get("roomqueued");
            Rooms.getInstance().joinRoom(warzoneRoom, this.user, "Enter" + this.user.properties.get("pvpteam"), "Spawn");
        }
        Kaiden_Extension.getInstance().send(PVPQ, this.user);
    }
}
