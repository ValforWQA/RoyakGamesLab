package Kaiden.Game.Server.Packets.External.Duel;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.WarzoneQueue;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.concurrent.LinkedBlockingQueue;

public class PvpQueueRequest extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String warzone = this.params[0];
        JSONObject PVPQ = new JSONObject();
        PVPQ.put("cmd", "PVPQ");
        PVPQ.put("bitSuccess", 0);
        if (warzone.equals("none")) {
            if (WarzoneQueue.getInstance().remove(this.user)) {
                Kaiden_Extension.getInstance().send(PVPQ, this.user);
                Kaiden_Extension.getInstance().send(new String[]{"server", "You have been removed from the Warzone's queue"}, this.user);
            }
        } else {
            LinkedBlockingQueue<User> queue = WarzoneQueue.getInstance().get(warzone);
            if (queue != null) {
                if (!queue.contains(this.user)) {
                    WarzoneQueue.getInstance().queue(warzone, this.user);
                    PVPQ.put("bitSuccess", 1);
                    PVPQ.put("warzone", warzone);
                    PVPQ.put("avgWait", -1);
                    Kaiden_Extension.getInstance().send(PVPQ, this.user);
                    Kaiden_Extension.getInstance().send(new String[]{"server", "You joined the Warzone queue for " + warzone + "!"}, this.user);
                    WarzoneQueue.getInstance().check(warzone);
                }
            }
        }
    }
}
