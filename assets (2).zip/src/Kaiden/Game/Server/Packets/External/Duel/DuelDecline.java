package Kaiden.Game.Server.Packets.External.Duel;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.Set;

public class DuelDecline extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (Configuration.SERVER_PVP) {
            String username = this.params[0].toLowerCase();
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
            if (client != null) {
                Set<Integer> requestedDuel = (Set) user.properties.get("requestedduel");
                requestedDuel.remove(client.getUserId());
                Kaiden_Extension.getInstance().send(new String[]{"server", this.user.getName() + " declined your duel challenge."}, client);
            }
        }
    }
}
