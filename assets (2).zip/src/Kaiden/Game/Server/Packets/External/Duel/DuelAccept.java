package Kaiden.Game.Server.Packets.External.Duel;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;

public class DuelAccept extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (Configuration.SERVER_PVP) {
            String username = this.params[0].toLowerCase();
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
            if (client != null) {
                Set<Integer> userRequestedDuel = (Set) user.properties.get("requestedduel");
                if (userRequestedDuel.contains(client.getUserId())) {
                    userRequestedDuel.remove(client.getUserId());
                    String roomNumber = "duel-" + user.hashCode();
                    Room newRoom = Rooms.getInstance().createRoom(roomNumber, this.user);
                    JSONObject b = new JSONObject();
                    b.put("id", user.getUserId());
                    b.put("sName", user.properties.get(Properties.USERNAME));
                    newRoom.properties.put("bteamname", user.properties.get(Properties.USERNAME));
                    JSONObject r = new JSONObject();
                    r.put("id", client.getUserId());
                    r.put("sName", client.properties.get(Properties.USERNAME));
                    newRoom.properties.put("rteamname", client.properties.get(Properties.USERNAME));
                    JSONArray PVPFactions = new JSONArray();
                    PVPFactions.add(b);
                    PVPFactions.add(r);
                    newRoom.properties.put("pvpfactions", PVPFactions);
                    user.properties.put("pvpteam", 0);
                    client.properties.put("pvpteam", 1);
                    Rooms.getInstance().joinRoom(newRoom, user, "Enter0", "Spawn");
                    Rooms.getInstance().joinRoom(newRoom, client, "Enter1", "Spawn");
                    JSONObject duelEx = new JSONObject();
                    duelEx.put("cmd", "DuelEX");
                    for (Object anUserRequestedDuel : userRequestedDuel) {
                        int userId = (Integer) anUserRequestedDuel;
                        User challenger = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
                        if (challenger != null) {
                            Kaiden_Extension.getInstance().send(duelEx, challenger);
                        }
                    }
                } else {
                    Users.getInstance().log(user, "Packet Edit [DuelAccept]", "Force duel accept.");
                    Users.getInstance().kick(user, "Force duel accept.");
                }
            }
        }
    }
}