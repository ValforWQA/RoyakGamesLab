package Kaiden.Game.Server.Packets.External.Duel;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.Set;

public class DuelInvite extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (Configuration.SERVER_PVP) {
            String username = this.params[0].toLowerCase();
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
            if (client == null) {
                throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
            } else {
                boolean bypassSelfLock =
                        user.isAdmin() || user.isModerator();

                if (!bypassSelfLock
                        && (client.getName().equals(this.user.getName())
                        || client.getIpAddress().equals(this.user.getIpAddress()))) {

                    throw new RequestExternalPacketException(
                            "You cannot challenge yourself to a duel!"
                    );
                } else if (!Settings.isAllowed(Settings.DUEL, this.user, client)) {
                    throw new RequestExternalPacketException("Player \"" + username + "\" is not accepting duel invites.");
                } else if (((State) client.properties.get("state")).onCombat()) {
                    throw new RequestExternalPacketException(client.getName() + " is currently busy.");
                } else {
                    Set<Integer> requestedDuel = (Set) client.properties.get("requestedduel");
                    requestedDuel.add(this.user.getUserId());
                    JSONObject di = new JSONObject();
                    di.put("owner", this.user.getName());
                    di.put("cmd", "di");
                    Kaiden_Extension.getInstance().send(di, client);
                    Kaiden_Extension.getInstance().send(new String[]{"server", "You have challenged " + username + " to a duel."}, user);
                }
            }
        }
    }
}
