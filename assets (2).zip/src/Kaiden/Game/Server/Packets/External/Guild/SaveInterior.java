package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class SaveInterior implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        String interior = params[1];
        String cell = params[2];
        int guildId = (Integer) user.properties.get("guildid");
        int hallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", cell, guildId);
        Storage.getInstance().getJdbc().run("UPDATE guilds_halls SET Interior = ? WHERE id = ?", interior, hallId);
        JSONObject guildhall = new JSONObject();
        guildhall.put("cmd", "guildhall");
        guildhall.put("gCmd", "updateInterior");
        guildhall.put("interior", interior);
        Kaiden_Extension.getInstance().sendToRoom(guildhall, user, room);
    }
}
