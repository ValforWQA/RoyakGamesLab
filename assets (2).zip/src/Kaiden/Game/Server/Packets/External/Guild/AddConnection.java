package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Pad;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class AddConnection implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        String curCell = params[1];
        String toCell = params[2];
        String pad = params[3];
        int guildId = (Integer) user.properties.get("guildid");
        int hallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", curCell, guildId);
        int otherHallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", toCell, guildId);
        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", hallId, pad, toCell, Pad.getPad(pad));
        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", otherHallId, Pad.getPair(pad), curCell, Pad.getPad(Pad.getPair(pad)));
        JSONObject guildhall = new JSONObject();
        JSONObject cellB = new JSONObject();
        JSONObject cellA = new JSONObject();
        cellB.put("strFrame", toCell);
        cellB.put("strConnections", Users.getInstance().getConnectionsString(otherHallId));
        cellA.put("strFrame", curCell);
        cellA.put("strConnections", Users.getInstance().getConnectionsString(hallId));
        guildhall.put("cmd", "guildhall");
        guildhall.put("gCmd", "addconnection");
        guildhall.put("cellA", cellA);
        guildhall.put("cellB", cellB);
        Kaiden_Extension.getInstance().sendToRoom(guildhall, user, room);
    }
}
