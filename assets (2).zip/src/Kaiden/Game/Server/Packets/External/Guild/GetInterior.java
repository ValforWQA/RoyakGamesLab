package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class GetInterior implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        JSONObject interior = new JSONObject();
        JSONObject items = new JSONObject();

        for (int i = 1; i < params.length; ++i) {
            String itemId = params[1];
            ItemBean item = StorageCache.getInstance().getItem(Integer.parseInt(itemId));
            items.put(itemId, item.getItemJSON());
        }

        interior.put("cmd", "interior");
        interior.put("items", items);
        Kaiden_Extension.getInstance().send(interior, user);
    }
}
