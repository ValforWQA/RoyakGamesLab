package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class RemoveBuilding implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        String curCell = params[1];
        int slot = Integer.parseInt(params[2]);
        int guildId = (Integer) user.properties.get("guildid");
        int hallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", curCell, guildId);
        Storage.getInstance().getJdbc().run("DELETE FROM guilds_halls_buildings WHERE HallID = ? AND Slot = ?", hallId, slot);
        JSONObject guildhall = new JSONObject();
        guildhall.put("cmd", "guildhall");
        guildhall.put("gCmd", "removeBuilding");
        guildhall.put("Lot", slot);
        guildhall.put("Cell", curCell);
        Kaiden_Extension.getInstance().sendToRoom(guildhall, user, room);
    }
}
