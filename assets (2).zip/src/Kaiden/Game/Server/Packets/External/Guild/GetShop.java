package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.ShopBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map.Entry;

public class GetShop implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        int shopId = Integer.parseInt(params[1]);
        ShopBean shopObj = StorageCache.getInstance().getShop(shopId);
        if (shopObj != null) {
            JSONObject guildhall = new JSONObject();
            JSONObject shopinfo = new JSONObject();
            JSONArray items = new JSONArray();

            for (Object o1 : shopObj.items.entrySet()) {
                Entry entry = (Entry) o1;
                int shopItemId = (Integer) entry.getKey();
                int itemId = (Integer) entry.getValue();
                ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
                if (itemObj != null) {
                    EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(itemObj.getEnhId());
                    JSONObject item;
                    if (!user.isAdmin() && !user.isModerator() && shopObj.isStaff()) {
                        item = itemObj.getItemJSON(StorageCache.getInstance().getEnhancement(1));
                        item.put("ItemID", item.hashCode());
                        item.put("sName", itemObj.getName() + " Preview");
                        item.put("bStaff", 1);
                    } else {
                        item = itemObj.getItemJSON(enhancement);
                    }

                    if (shopObj.isLimited()) {
                        int turnInArr = Storage.getInstance().getJdbc().queryForInt("SELECT QuantityRemain FROM shops_items WHERE id = ?", shopItemId);
                        item.put("iQtyRemain", turnInArr);
                    } else {
                        item.put("iQtyRemain", -1);
                    }

                    item.put("ShopItemID", shopItemId);
                    item.put("iQty", itemObj.getQuantity());
                    item.put("iQSindex", itemObj.getQuestStringIndex());
                    item.put("iQSvalue", itemObj.getQuestStringValue());
                    item.put("iReqCP", itemObj.getReqClassPoints());
                    item.put("iReqRep", itemObj.getReqReputation());
                    item.put("FactionID", itemObj.getFactionId());
                    item.put("sFaction", StorageCache.getInstance().getFaction(itemObj.getFactionId()));
                    item.put("iCost", itemObj.getCost() * itemObj.getQuantity());
                    if (itemObj.getReqClassId() > 0) {
                        item.put("iClass", itemObj.getReqClassId());
                        item.put("sClass", StorageCache.getInstance().getItem(itemObj.getReqClassId()).getName());
                    }

                    if (!itemObj.getRequirements().isEmpty()) {
                        JSONArray turnInArr1 = new JSONArray();

                        for (Object o : itemObj.getRequirements().entrySet()) {
                            Entry require = (Entry) o;
                            int reqItemId = (Integer) require.getKey();
                            ItemBean reqItemObj = StorageCache.getInstance().getItem(reqItemId);
                            int quantityNeeded = (Integer) require.getValue() >= reqItemObj.getStack() ? reqItemObj.getStack() : (Integer) require.getValue();
                            JSONObject wObj = new JSONObject();
                            wObj.put("ItemID", reqItemId);
                            wObj.put("iQty", quantityNeeded);
                            wObj.put("sName", reqItemObj.getName());
                            turnInArr1.add(wObj);
                        }

                        item.put("turnin", turnInArr1);
                    }

                    items.add(item);
                }
            }

            shopinfo.put("bHouse", shopObj.isHouse() ? 1 : 0);
            shopinfo.put("bStaff", shopObj.isStaff() ? 1 : 0);
            shopinfo.put("bUpgrd", shopObj.isUpgrade() ? 1 : 0);
            shopinfo.put("bLimited", shopObj.isLimited() ? 1 : 0);
            shopinfo.put("iIndex", "-1");
            shopinfo.put("items", items);
            shopinfo.put("ShopID", shopId);
            shopinfo.put("sField", shopObj.getField());
            shopinfo.put("sName", shopObj.getName());
            guildhall.put("shopinfo", shopinfo);
            guildhall.put("cmd", "guildhall");
            guildhall.put("gCmd", "guildShop");
            Kaiden_Extension.getInstance().send(guildhall, user);
        }
    }
}
