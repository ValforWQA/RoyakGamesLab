package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class GuildSellItem implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[1]);
        int shopId = Integer.parseInt(params[2]);
        int guildId = (Integer) user.properties.get("guildid");
        int userId = (Integer) user.properties.get(Properties.ID);
        Storage.getInstance().getJdbc().beginTransaction();

        try {
            int je = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM guilds_inventory WHERE GuildID = ? AND ItemID = ? AND UserID = ?", guildId, itemId, userId);
            if (je > 0) {
                QueryResult userResult = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ? FOR UPDATE", userId);
                userResult.setAutoClose(true);
                if (userResult.next()) {
                    int coins = userResult.getInt("Coins");
                    int gold = userResult.getInt("Gold");
                    userResult.close();
                    ItemBean item = StorageCache.getInstance().getItem(itemId);
                    JSONObject guildhall = new JSONObject();
                    guildhall.put("cmd", "guildhall");
                    guildhall.put("gCmd", "removeItem");
                    guildhall.put("ItemID", itemId);
                    guildhall.put("bitSuccess", 1);
                    Kaiden_Extension.getInstance().send(guildhall, user);
                    int coinPrice;
                    int totalCoins;
                    if (!item.isCoins()) {
                        coinPrice = item.getCost() / 5 / 2;
                        totalCoins = gold + coinPrice;
                        guildhall.put("iCost", coinPrice);
                        Storage.getInstance().getJdbc().run("UPDATE users SET Gold = ? WHERE id = ?", totalCoins, userId);
                    } else {
                        coinPrice = item.getCost() / 4;
                        totalCoins = coins + coinPrice;
                        guildhall.put("iCost", coinPrice);
                        Storage.getInstance().getJdbc().run("UPDATE users SET Coins = ? WHERE id = ?", totalCoins, userId);
                    }

                    Storage.getInstance().getJdbc().run("DELETE FROM guilds_inventory WHERE GuildID = ? AND ItemID = ? AND UserID = ?", guildId, itemId, userId);
                    Kaiden_Extension.getInstance().send(guildhall, user);
                }

                userResult.close();
            } else {
                Users.getInstance().log(user, "Packet Edit [GuildSellItem]", "Attempted to sell an item not in possession");
            }
        } catch (JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }

        }

    }
}
