package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class GuildDeclineInvite implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(params[2].toLowerCase());
        if (client != null) {
            JSONObject gd = new JSONObject();
            gd.put("cmd", "gd");
            gd.put("unm", user.getName());
            Kaiden_Extension.getInstance().send(new String[]{"server", "You declined the invitation."}, user);
            Kaiden_Extension.getInstance().send(gd, client);
        }
    }
}
