package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;

public class GuildCommand extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        switch (this.params[0]) {
            case "gc":
                (new GuildCreate()).process(params, user, room);
                break;
            case "gi":
                (new GuildInvite()).process(params, user,  room);
                break;
            case "ga":
                (new GuildAccept()).process(params, user,  room);
                break;
            case "gr":
                (new GuildRemove()).process(params, user,  room);
                break;
            case "gdi":
                (new GuildDeclineInvite()).process(params, user,  room);
                break;
            case "rename":
                (new GuildRename()).process(params, user,  room);
                break;
            case "gp":
                (new GuildPromote()).process(params, user,  room);
                break;
            case "gd":
                (new GuildDemote()).process(params, user,  room);
                break;
            case "motd":
                (new GuildMOTD()).process(params, user,  room);
                break;
            case "slots":
                (new GuildSlots()).process(params, user,  room);
                break;
            case "getInterior":
                (new GetInterior()).process(params, user,  room);
                break;
            case "buyplot":
                (new BuyPlot()).process(params, user,  room);
                break;
            case "getInv":
                (new GetInventory()).process(params, user,  room);
                break;
            case "getShop":
                (new GetShop()).process(params, user,  room);
                break;
            case "saveInt":
                (new SaveInterior()).process(params, user,  room);
                break;
            case "addFrame":
                (new AddFrame()).process(params, user,  room);
                break;
            case "addBuilding":
                (new AddBuilding()).process(params, user,  room);
                break;
            case "removeBuilding":
                (new RemoveBuilding()).process(params, user,  room);
                break;
            case "buyItem":
                (new GuildBuyItem()).process(params, user,  room);
                break;
            case "sellItem":
                (new GuildSellItem()).process(params, user,  room);
                break;
            case "addConnection":
                (new AddConnection()).process(params, user,  room);
                break;
            case "removeConnection":
                (new RemoveConnection()).process(params, user,  room);
                break;
        }
    }
}
