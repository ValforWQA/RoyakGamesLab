package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class GuildRemove implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int guildId = (Integer) user.properties.get("guildid");
        int userRank = (Integer) user.properties.get("guildrank");
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT users.id, users.Name, users_guilds.GuildID, users_guilds.Rank FROM users LEFT JOIN users_guilds ON UserID = id WHERE Name = ?", params[1]);
        if (!result.next()) {
            result.close();
            throw new RequestExternalPacketException("Player \"" + params[1].toLowerCase() + "\" could not be found.");
        } else {
            String username = result.getString("Name");
            int clientId = result.getInt("id");
            int clientRank = result.getInt("Rank");
            int clientGuildID = result.getInt("GuildID");
            result.close();
            if (clientGuildID <= 0) {
                throw new RequestExternalPacketException(username + " does belong to a guild!");
            } else if (clientGuildID != guildId) {
                throw new RequestExternalPacketException(username + " is not in your guild!");
            } else if ((clientRank > userRank || userRank < 2) && !user.getName().equals(username.toLowerCase())) {
                throw new RequestExternalPacketException("Invalid /gr request.");
            } else {
                int remainingMembers = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM users_guilds WHERE GuildID = ?", guildId);
                if (clientRank == 3 && remainingMembers > 1) {
                    throw new RequestExternalPacketException("Invalid /gr request.");
                } else {
                    Storage.getInstance().getJdbc().run("DELETE FROM users_guilds WHERE GuildID = ? AND UserID = ?", guildId, clientId);
                    if (clientRank == 3 && remainingMembers == 1) {
                        Storage.getInstance().getJdbc().run("DELETE FROM guilds WHERE id = ?", guildId);
                    }

                    JSONObject guildObj = Users.getInstance().getGuildObject(guildId);
                    Kaiden_Extension.getInstance().sendGuildUpdate(guildObj);
                    if (user.getName().equals(username.toLowerCase())) {
                        Kaiden_Extension.getInstance().sendToGuild(new String[]{"server", username.toLowerCase() + " has left the guild."}, guildObj);
                    } else {
                        Kaiden_Extension.getInstance().sendToGuild(new String[]{"server", username.toLowerCase() + " has been kicked."}, guildObj);
                    }
                    User client = Kaiden_Extension.getInstance().getZone().getUserByName(username.toLowerCase());
                    if (client != null) {
                        JSONObject object = new JSONObject();
                        object.put("cmd", params[0]);
                        object.put("unm", username);
                        object.put("guild", guildObj);
                        client.properties.put("guildid", 0);
                        client.properties.put("guildrank", 0);
                        client.properties.put("guildobj", new JSONObject());
                        Zone zone = Kaiden_Extension.getInstance().getZone();
                        Kaiden_Extension.getInstance().send(object, zone.getRoom(client.getRoom()).getChannellList());
                    }

                    result.close();
                }
            }
        }
    }
}
