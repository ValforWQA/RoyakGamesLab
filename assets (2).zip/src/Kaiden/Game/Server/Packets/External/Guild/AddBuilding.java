package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class AddBuilding implements RequestPacketManager {

    public void process(String[] params, User user, Room room) {
        String curCell = params[1];
        int slot = Integer.parseInt(params[2]);
        int itemId = Integer.parseInt(params[3]);
        int guildId = (int) user.properties.get("guildid");
        int size = StorageCache.getInstance().getItem(itemId).getStack();
        int hallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", curCell, guildId);
        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_buildings (HallID, ItemID, Slot, Size) VALUES (?, ?, ?)", hallId, itemId, slot, size);
        JSONObject guildhall = new JSONObject();
        guildhall.put("cmd", "guildhall");
        guildhall.put("gCmd", "addbuilding");
        guildhall.put("Buildings", Users.getInstance().getBuildingString(hallId));
        guildhall.put("Cell", curCell);
        Kaiden_Extension.getInstance().sendToRoom(guildhall, user, room);
    }
}
