package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class GetInventory implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        int guildId = (Integer) user.properties.get("guildid");
        JSONObject guildinv = new JSONObject();
        JSONObject guildInventory = new JSONObject();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT guilds_inventory.*, users.Name FROM guilds_inventory LEFT JOIN users ON UserId = users.id WHERE GuildID = ?", guildId);

        while (result.next()) {
            ItemBean item = StorageCache.getInstance().getItem(result.getInt("ItemID"));
            String username = result.getString("Name");
            JSONObject items;
            if (guildInventory.containsKey(username)) {
                items = guildInventory.getJSONObject(username);
                items.put(String.valueOf(item.getId()), item.getItemJSON());
            } else {
                items = new JSONObject();
                items.put(String.valueOf(item.getId()), item.getItemJSON());
                guildInventory.put(username, items);
            }
        }

        result.close();
        guildinv.put("cmd", "guildinv");
        guildinv.put("guildInventory", guildInventory);
        Kaiden_Extension.getInstance().send(guildinv, user);
    }
}
