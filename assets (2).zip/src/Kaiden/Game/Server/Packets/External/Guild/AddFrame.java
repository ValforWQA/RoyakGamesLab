package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Pad;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class AddFrame implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        String newCell = params[1];
        String linkage = params[2];
        String curCell = params[3];
        String toPad = params[4];
        int purchase = Integer.parseInt(params[5]);
        int cost = Integer.parseInt(params[6]);
        boolean isCoins = Boolean.parseBoolean(params[7]);
        int guildId = (Integer) user.properties.get("guildid");
        int hallId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM guilds_halls WHERE Cell = ? AND GuildID = ?", curCell, guildId);
        Storage.getInstance().getJdbc().beginTransaction();

        try {
            if (purchase > 0) {
                QueryResult guildhall = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ? FOR UPDATE", user.properties.get(Properties.ID));
                if (guildhall.next()) {
                    int coins = guildhall.getInt("Coins");
                    int gold = guildhall.getInt("Gold");
                    guildhall.close();
                    boolean valid = isCoins && cost <= coins || cost <= gold;
                    if (valid) {
                        int newHallId;
                        if (!isCoins) {
                            newHallId = gold - cost;
                            Storage.getInstance().getJdbc().run("UPDATE users SET Gold = ? WHERE id=?", newHallId, user.properties.get(Properties.ID));
                        } else {
                            newHallId = coins - cost;
                            Storage.getInstance().getJdbc().run("UPDATE users SET Coins = ? WHERE id=?", newHallId, user.properties.get(Properties.ID));
                        }

                        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls (GuildID, Linkage, Cell, Interior) VALUES (?, ?, ?, ?)", guildId, linkage, newCell, "|||");
                        newHallId = Long.valueOf(Storage.getInstance().getJdbc().getLastInsertId()).intValue();
                        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", hallId, toPad, newCell, Pad.getPad(toPad));
                        Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", newHallId, Pad.getPair(toPad), curCell, Pad.getPad(Pad.getPair(toPad)));
                    }
                }

                guildhall.close();
            } else {
                Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls (GuildID, Linkage, Cell) VALUES (?, ?, ?)", guildId, linkage, newCell);
                int guildhall1 = Long.valueOf(Storage.getInstance().getJdbc().getLastInsertId()).intValue();
                Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", hallId, toPad, newCell, Pad.getPad(toPad));
                Storage.getInstance().getJdbc().run("INSERT INTO guilds_halls_connections (HallID, Pad, Cell, PadPosition) VALUES (? ,? ,? ,?)", guildhall1, Pad.getPair(toPad), curCell, Pad.getPad(Pad.getPair(toPad)));
            }
        } catch (JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }

        }

        JSONObject guildhall2 = new JSONObject();
        guildhall2.put("cmd", "guildhall");
        guildhall2.put("gCmd", "addframe");
        guildhall2.put("guildHall", Users.getInstance().getGuildHallData(guildId));
        guildhall2.put("bitSuccess", 1);
        Kaiden_Extension.getInstance().sendToRoom(guildhall2, user, room);
    }
}
