package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;

public class GuildInvite implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        if ((Integer) user.properties.get("guildrank") < 2) {
            throw new RequestExternalPacketException("Invalid /gi request.");
        } else {
            String username = params[1].toLowerCase();
            User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
            if (client == null) {
                throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
            } else {
                int clientGuildID = (Integer) client.properties.get("guildid");
                int userGuildID = (Integer) user.properties.get("guildid");
                if (userGuildID <= 0) {
                    throw new RequestExternalPacketException("You are not in a guild!");
                } else if (clientGuildID > 0) {
                    throw new RequestExternalPacketException(client.getName() + " already belongs to a guild.");
                } else if (!Settings.isAllowed(Settings.GUILD, user, client)) {
                    throw new RequestExternalPacketException("Player " + client.getName() + " is not accepting guild invites.", "server");
                } else if (((State) client.properties.get("state")).onCombat()) {
                    throw new RequestExternalPacketException(client.getName() + " is currently busy.");
                } else {
                    JSONObject guildData = (JSONObject) user.properties.get("guildobj");
                    JSONArray members = (JSONArray) guildData.get("ul");
                    if (members.size() > 0) {

                        for (Object member : members) {
                            JSONObject requestedGuild = (JSONObject) member;
                            if (requestedGuild.get("ID").toString().equals(client.properties.get(Properties.ID).toString())) {
                                throw new RequestExternalPacketException(client.getName() + " is already in your guild!");
                            }
                        }
                    }

                    if (members.size() >= (Integer) guildData.get("MaxMembers")) {
                        throw new RequestExternalPacketException("Your guild has reached the maximum number of members.");
                    } else {
                        JSONObject gi1 = new JSONObject();
                        gi1.put("cmd", params[0]);
                        gi1.put("owner", user.getName());
                        gi1.put("gName", guildData.get("Name"));
                        gi1.put("guildID", userGuildID);
                        Set<Integer> requestedGuild1 = (Set) client.properties.get("requestedguild");
                        requestedGuild1.add(userGuildID);
                        Kaiden_Extension.getInstance().send(new String[]{"server", "You have invited " + client.getName() + " to join your guild."}, user);
                        Kaiden_Extension.getInstance().send(gi1, client);
                    }
                }
            }
        }
    }
}
