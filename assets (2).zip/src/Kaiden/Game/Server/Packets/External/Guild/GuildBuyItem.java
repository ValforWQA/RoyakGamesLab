package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;


public class GuildBuyItem implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int guildId = (Integer) user.properties.get("guildid");
        int userId = (Integer) user.properties.get(Properties.ID);
        int itemId = Integer.parseInt(params[1]);
        Storage.getInstance().getJdbc().beginTransaction();

        try {
            ItemBean je = StorageCache.getInstance().getItem(itemId);
            int cost = je.getCost();
            QueryResult userResult = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ? FOR UPDATE", user.properties.get(Properties.ID));
            userResult.setAutoClose(true);
            if (userResult.next()) {
                int coins = userResult.getInt("Coins");
                int gold = userResult.getInt("Gold");
                userResult.close();
                boolean valid = je.isCoins() && cost <= coins || cost <= gold;
                if (valid) {
                    Storage.getInstance().getJdbc().run("INSERT INTO guilds_inventory (GuildID, ItemID, UserID) VALUES (? ,? ,?)", guildId, itemId, userId);
                    int guildhall;
                    if (!je.isCoins()) {
                        guildhall = gold - cost;
                        Storage.getInstance().getJdbc().run("UPDATE users SET Gold = ? WHERE id=?", guildhall, user.properties.get(Properties.ID));
                    } else {
                        guildhall = coins - cost;
                        Storage.getInstance().getJdbc().run("UPDATE users SET Coins = ? WHERE id=?", guildhall, user.properties.get(Properties.ID));
                    }

                    JSONObject guildhall1 = new JSONObject();
                    guildhall1.put("cmd", "guildhall");
                    guildhall1.put("gCmd", "buyItem");
                    guildhall1.put("Item", je.getItemJSON());
                    guildhall1.put("bitSuccess", 1);
                    Kaiden_Extension.getInstance().send(guildhall1, user);
                }
            }

            userResult.close();
        } catch (JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }

        }

    }
}
