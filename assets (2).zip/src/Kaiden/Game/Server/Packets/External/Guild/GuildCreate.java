package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

public class GuildCreate implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {

        String guildName = params[1].trim();
        if (guildName.length() > 25) {
            throw new RequestExternalPacketException("Guild names must be 25 characters or less.", "server");
        } else if ((int) user.properties.get("upgdays") < 0) {
            throw new RequestExternalPacketException("Only members may create guilds.", "server");
        } else if (guildName.length() <= 0) {
            throw new RequestExternalPacketException("Please specify a name for your guild.", "server");
        } else if ((int) user.properties.get(Properties.COINS) <= 1000) {
            throw new RequestExternalPacketException("You do not have enough ACs.", "server");
        }
        Storage.getInstance().getJdbc().beginTransaction();
        try {
            int rowcount = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM users_guilds WHERE UserID = ?", user.properties.get(Properties.ID));
            if (rowcount > 0) {
                Storage.getInstance().getJdbc().rollbackTransaction();
                throw new RequestExternalPacketException("You already have a guild!");
            }
            rowcount = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM guilds WHERE Name = ?", guildName);
            if (rowcount > 0) {
                Storage.getInstance().getJdbc().rollbackTransaction();
                throw new RequestExternalPacketException("Guild name is already in use.");
            }

            Storage.getInstance().getJdbc().run("INSERT INTO guilds (Name, MessageOfTheDay) VALUES (?, 'Hello World!')", guildName);
            int guildId = Long.valueOf(Storage.getInstance().getJdbc().getLastInsertId()).intValue();
            if (guildId <= 0) {
                Storage.getInstance().getJdbc().rollbackTransaction();
                throw new RequestExternalPacketException("There was an error during guild creation!");
            }

            Storage.getInstance().getJdbc().run("INSERT INTO users_guilds (`GuildID`, `UserID`, `Rank`) VALUES (?, ?, 3)", guildId, user.properties.get(Properties.ID));
            Storage.getInstance().getJdbc().commitTransaction();

            Properties.updateCoins(user, (int) user.properties.get(Properties.COINS) - 1000, -1000);
            JSONObject guildData = Users.getInstance().getGuildObject(guildId);
            user.properties.put("guildid", guildId);
            user.properties.put("guildobj", guildData);
            user.properties.put("guildrank", 3);
            JSONObject object = new JSONObject();
            object.put("cmd", params[0]);
            object.put("uid", user.getUserId());
            object.put("guild", guildData);
            Kaiden_Extension.getInstance().sendToRoom(object, user, room);
            Kaiden_Extension.getInstance().send(new String[]{"server", "Guild " + guildName + " successfuly created."}, user);
        } catch (JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }

        }

    }
}
