package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.Set;

public class GuildAccept implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(params[2].toLowerCase());
        if (client != null) {
            int guildId = Integer.parseInt(params[1]);
            int clientGuildID = (Integer) client.properties.get("guildid");
            if (clientGuildID != guildId) {
                Users.getInstance().log(user, "Packet Edit [GuildAccept]", "Guild id does not match with requesting client");
                Users.getInstance().kick(user, "Guild id does not match with requesting client.");
            } else {
                Set<Integer> requestedGuild = (Set) user.properties.get("requestedguild");
                if (requestedGuild.contains(clientGuildID)) {
                    requestedGuild.remove(clientGuildID);
                    Storage.getInstance().getJdbc().beginTransaction();

                    try {
                        QueryResult object = Storage.getInstance().getJdbc().query("SELECT * FROM users_guilds WHERE UserID = ? FOR UPDATE", user.properties.get(Properties.ID));
                        if (object.next()) {
                            Storage.getInstance().getJdbc().run("UPDATE users_guilds SET GuildID = ?, Rank = 0 WHERE UserID = ?", guildId, user.properties.get(Properties.ID));
                        } else {
                            Storage.getInstance().getJdbc().run("INSERT INTO users_guilds (`GuildID`, `UserID`, `Rank`) VALUES (?, ?, 0)", guildId, user.properties.get(Properties.ID));
                        }

                        object.close();
                    } catch (JdbcException e) {
                        if (Storage.getInstance().getJdbc().isInTransaction()) {
                            Storage.getInstance().getJdbc().rollbackTransaction();
                        }
                        Log.error(this.getClass().getName(), e);
                    } finally {
                        if (Storage.getInstance().getJdbc().isInTransaction()) {
                            Storage.getInstance().getJdbc().commitTransaction();
                        }

                    }

                    user.properties.put("guildid", guildId);
                    user.properties.put("guildrank", 0);
                    user.properties.put("guildobj", Users.getInstance().getGuildObject(guildId));
                    client.properties.put("guildobj", user.properties.get("guildobj"));
                    JSONObject object1 = new JSONObject();
                    object1.put("cmd", params[0]);
                    object1.put("unm", user.properties.get(Properties.USERNAME));
                    object1.put("guild", user.properties.get("guildobj"));
                    Kaiden_Extension.getInstance().sendToRoom(object1, user, room);
                    Kaiden_Extension.getInstance().sendGuildUpdate((JSONObject) user.properties.get("guildobj"));
                } else {
                    Users.getInstance().log(user, "Packet Edit [GuildAccept]", "Forcing guild accept");
                    Users.getInstance().kick(user, "Forcing guild accept.");
                }
            }
        }
    }
}
