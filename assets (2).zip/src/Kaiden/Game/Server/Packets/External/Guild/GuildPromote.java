package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class GuildPromote implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int guildId = (Integer) user.properties.get("guildid");
        int userRank = (Integer) user.properties.get("guildrank");
        String username = params[1].toLowerCase();
        if (guildId <= 0) {
            throw new RequestExternalPacketException("You do not have a guild!");
        } else if (userRank < 2) {
            throw new RequestExternalPacketException("Invalid /gp request.");
        } else {
            QueryResult result = Storage.getInstance().getJdbc().query("SELECT users.id, users_guilds.GuildID, users_guilds.Rank FROM users LEFT JOIN users_guilds ON UserID = id WHERE Name = ?", username);
            result.setAutoClose(true);
            if (!result.next()) {
                throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
            } else {
                int clientGuildID = result.getInt("GuildID");
                int clientRank = result.getInt("Rank");
                int clientDbId = result.getInt("id");
                result.close();
                ++clientRank;
                if (clientGuildID <= 0) {
                    throw new RequestExternalPacketException(username + " does belong to a guild!");
                } else if (clientGuildID != guildId) {
                    throw new RequestExternalPacketException(username + " is not in your guild!");
                } else if (clientRank >= userRank) {
                    throw new RequestExternalPacketException("Invalid /gp request.");
                } else {
                    Storage.getInstance().getJdbc().run("UPDATE users_guilds SET Rank = ? WHERE UserID = ?", clientRank, clientDbId);
                    Kaiden_Extension.getInstance().sendGuildUpdate(Users.getInstance().getGuildObject((Integer) user.properties.get("guildid")));
                    Kaiden_Extension.getInstance().sendToGuild(new String[]{"server", username + "'s rank has been changed to " + Users.getInstance().getGuildRank(clientRank)}, (JSONObject) user.properties.get("guildobj"));
                    User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
                    if (client != null) {
                        client.properties.put("guildrank", clientRank);
                    }
                }
            }
        }
    }
}
