package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class GuildMOTD implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        if ((Integer) user.properties.get("guildid") > 0 && (Integer) user.properties.get("guildrank") >= 2) {
            String message = params[1].trim();
            Storage.getInstance().getJdbc().run("UPDATE guilds SET MessageOfTheDay = ? WHERE id = ?", message, user.properties.get("guildid"));
            JSONObject object = new JSONObject();
            object.put("cmd", "gMOTD");
            object.put("unm", user.properties.get(Properties.USERNAME));
            object.put("msg", message);
            JSONObject guildObj = (JSONObject) user.properties.get("guildobj");
            guildObj.put("MOTD", message);
            Kaiden_Extension.getInstance().sendToGuild(object, guildObj);
            Kaiden_Extension.getInstance().sendToGuild(new String[]{"server", "Guild message has been changed."}, guildObj);
            Kaiden_Extension.getInstance().sendGuildUpdate(guildObj);
        }

    }
}
