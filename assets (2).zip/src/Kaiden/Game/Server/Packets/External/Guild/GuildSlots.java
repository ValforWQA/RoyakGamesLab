package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

public class GuildSlots implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        int slotsToPurchase = Integer.parseInt(params[1]);
        if ((Integer) user.properties.get("guildid") > 0 && (Integer) user.properties.get("guildrank") == 3) {
            Storage.getInstance().getJdbc().beginTransaction();

            try {
                int je = Storage.getInstance().getJdbc().queryForInt("SELECT MaxMembers FROM guilds WHERE id = ? FOR UPDATE", user.properties.get("guildid")) + slotsToPurchase;
                int totalCost = slotsToPurchase * 200;
                if (je > 50) {
                    throw new RequestExternalPacketException("You have already reached the maximum amount of guild member slots.");
                }

                int coins = (int) user.properties.get(Properties.COINS);
                int coinsLeft = coins - totalCost;
                if (coinsLeft < 0) {
                    throw new RequestExternalPacketException("You don't have enough coins!");
                }
                Storage.getInstance().getJdbc().run("UPDATE users SET Coins = ? WHERE id = ?", coinsLeft, user.properties.get(Properties.ID));
                Storage.getInstance().getJdbc().run("UPDATE guilds SET MaxMembers = ? WHERE id = ?", je, user.properties.get("guildid"));
                Storage.getInstance().getJdbc().commitTransaction();
                user.properties.put("guildobj", Users.getInstance().getGuildObject((Integer) user.properties.get("guildid")));
                Kaiden_Extension.getInstance().sendGuildUpdate((JSONObject) user.properties.get("guildobj"));
                Kaiden_Extension.getInstance().send(new String[]{"buyGSlots", params[1]}, user);
            } catch (JdbcException e) {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                }
                Log.error(this.getClass().getName(), e);
            } finally {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().commitTransaction();
                }

            }
        }

    }
}
