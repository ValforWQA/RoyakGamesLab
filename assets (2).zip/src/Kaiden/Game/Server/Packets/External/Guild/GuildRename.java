package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

public class GuildRename implements RequestPacketManager {
    private static final Logger LOGGER = Logger.getLogger(GuildRename.class);

    public void process(String[] params, User user,  Room room) throws RequestExternalPacketException {
        if ((Integer) user.properties.get("guildid") <= 0) {
            throw new RequestExternalPacketException("You do not belong to a guild.", "server");
        } else if ((Integer) user.properties.get("guildrank") < 3) {
            throw new RequestExternalPacketException("Invalid /rename request.");
        } else {
            String guildName = params[1].trim();
            int coins = (int) user.properties.get(Properties.COINS);
            if (guildName.length() > 25) {
                throw new RequestExternalPacketException("Guild names must be 25 characters or less.", "server");
            } else if (guildName.length() <= 0) {
                throw new RequestExternalPacketException("Please specify a name for your guild.", "server");
            } else if (coins <= 1000) {
                throw new RequestExternalPacketException("You do not have enough ACs.", "server");
            }
            Storage.getInstance().getJdbc().beginTransaction();
            try {
                int rowcount = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM guilds WHERE Name = ?", guildName);
                if (rowcount > 0) {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                    throw new RequestExternalPacketException("Guild name is already in use.");
                }
                Properties.updateCoins(user, coins - 1000, -1000);
                JSONObject guildData = (JSONObject) user.properties.get("guildobj");
                guildData.put("Name", params[1].trim());
                Storage.getInstance().getJdbc().run("UPDATE guilds SET Name = ? WHERE id = ?", params[1].trim(), user.properties.get("guildid"));
                Kaiden_Extension.getInstance().send(new String[]{"gRename"}, user);
                Kaiden_Extension.getInstance().sendGuildUpdate(guildData);
                Kaiden_Extension.getInstance().sendToGuild(new String[]{"server", "Guild has been renamed to " + guildName + "."}, guildData);
            } catch (JdbcException e) {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                }
                Log.error(this.getClass().getName(), e);
            } finally {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().commitTransaction();
                }
            }
        }
    }
}
