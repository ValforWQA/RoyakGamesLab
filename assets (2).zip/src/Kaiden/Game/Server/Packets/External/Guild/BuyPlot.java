package Kaiden.Game.Server.Packets.External.Guild;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.RequestPacketManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

public class BuyPlot implements RequestPacketManager {

    public void process(String[] params, User user,  Room room) {
        int guildId = (Integer) user.properties.get("guildid");
        int guildRank = (Integer) user.properties.get("guildrank");
        if (guildRank >= 2) {
            Storage.getInstance().getJdbc().beginTransaction();

            try {
                int je = Storage.getInstance().getJdbc().queryForInt("SELECT Gold FROM users WHERE id = ? FOR UPDATE", user.properties.get(Properties.ID));
                int hallSize = Storage.getInstance().getJdbc().queryForInt("SELECT HallSize FROM guilds WHERE id = ? FOR UPDATE", guildId);
                if (je >= 1000) {
                    if (hallSize < 16) {
                        int deltaGold = je - 1000;
                        Storage.getInstance().getJdbc().run("UPDATE users SET Gold = ? WHERE id = ?", deltaGold, user.properties.get(Properties.ID));
                        ++hallSize;
                        Storage.getInstance().getJdbc().run("UPDATE guilds SET HallSize = ? WHERE id = ?", hallSize, guildId);
                        JSONObject guildhall = new JSONObject();
                        guildhall.put("cmd", "guildhall");
                        guildhall.put("gCmd", "buyPlot");
                        guildhall.put("bitSuccess", 1);
                        Kaiden_Extension.getInstance().send(guildhall, user);
                    }

                }
            } catch (JdbcException e) {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                }
                Log.error(this.getClass().getName(), e);
            } finally {
                if (Storage.getInstance().getJdbc().isInTransaction()) {
                    Storage.getInstance().getJdbc().commitTransaction();
                }

            }

        }
    }
}
