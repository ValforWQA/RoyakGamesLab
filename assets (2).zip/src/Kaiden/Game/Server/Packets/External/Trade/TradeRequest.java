package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.Set;

/* Programmed by ValforWqa. for Onclax  & StarChronicles 2019 */
public class TradeRequest extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException{
        
      String UserName = params[0].toLowerCase();
      User client = Kaiden_Extension.getInstance().getZone().getUserByName(UserName);
       if(client == null) 
         throw new RequestExternalPacketException("Player \"" + UserName + "\" could not be found.");
       else if((Integer) user.properties.get("level") < 10)
         throw new RequestExternalPacketException("You must be at least level 10 to trade!");
       else if(((State) client.properties.get("state")).onCombat())
         throw new RequestExternalPacketException("The user you're trying to trade with is currently busy!");
       else if(!Settings.isAllowed("bDuel", user, client))
         throw new RequestExternalPacketException("Player \"" + UserName + "\" is not accepting trade invites.");
       else if((Integer) client.properties.get("tradetgt") > -1)
         throw new RequestExternalPacketException(UserName + " is already in trade session with someone!");
      // else if(client.getIpAddress().equals(user.getIpAddress()))
       //throw new RequestExternalPacketException("Self trade is not allowed .");
      
         Set<Integer> requestedTrade = (Set<Integer>) client.properties.get("requestedtrade");
         requestedTrade.add(user.getUserId());
         JSONObject tradeRequest = new JSONObject();
         tradeRequest.element("cmd", "ti");
         tradeRequest.element("owner", user.properties.get("username"));
         Kaiden_Extension.getInstance().send(tradeRequest, client);
         Kaiden_Extension.getInstance().send(new String[]{"server", "You have requested " + client.getName() + " to a trade session."}, user);
      
   }
}
