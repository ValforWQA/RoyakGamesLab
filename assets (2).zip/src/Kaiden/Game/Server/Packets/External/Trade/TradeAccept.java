package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.Set;

public class TradeAccept extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
        
      String UserName = params[0].toLowerCase();
      User client = Kaiden_Extension.getInstance().getZone().getUserByName(UserName);
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      } else if(user.getName().equals(client.getName())) {
         throw new RequestExternalPacketException("You can't do this.");
      } else if(((Integer)user.properties.get("tradetgt")).intValue() > -1) {
         throw new RequestExternalPacketException("You can't do this.");
      } else if((Integer)user.properties.get("level") < 10) {
         throw new RequestExternalPacketException("You must be at least level 10 to trade!");
      } else if(((Integer)client.properties.get("tradetgt")).intValue() > -1) {
         throw new RequestExternalPacketException("You can't do this.");
      } else {
         Set requestedTrade = (Set)user.properties.get("requestedtrade");
         if(requestedTrade.contains(Integer.valueOf(client.getUserId()))) {
            requestedTrade.remove(Integer.valueOf(user.getUserId()));
            

           //if(Objects.equals(user.getIpAddress(), client.getIpAddress())) {
             //throw new RequestExternalPacketException("Self trade is forbidden!");
           //}

            user.properties.put("offer", new HashMap());
            user.properties.put("offerenh", new HashMap());
            user.properties.put("tradetgt", Integer.valueOf(client.getUserId()));
            user.properties.put("tradegold", Integer.valueOf(0));
            user.properties.put("tradecoins", Integer.valueOf(0));
            user.properties.put("tradelock", Boolean.valueOf(false));
            user.properties.put("tradedeal", Boolean.valueOf(false));
            client.properties.put("offer", new HashMap());
            client.properties.put("offerenh", new HashMap());
            client.properties.put("tradetgt", Integer.valueOf(user.getUserId()));
            client.properties.put("tradegold", Integer.valueOf(0));
            client.properties.put("tradecoins", Integer.valueOf(0));
            client.properties.put("tradelock", Boolean.valueOf(false));
            client.properties.put("tradedeal", Boolean.valueOf(false));
            
            JSONObject ti = new JSONObject();
            ti.element("userid", user.getUserId());
            ti.element("cmd", "startTrade");
            Kaiden_Extension.getInstance().send(ti, client);
            ti.element("userid", client.getUserId());
            Kaiden_Extension.getInstance().send(ti, user);
         }

      }
   }
}
