package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.ClassRank;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map;

public class TradeFromInventory extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
      // Defensive param validation (prevents random null/array exceptions)
      if (params == null || params.length < 4) {
         throw new RequestExternalPacketException("Invalid trade request.");
      }

      int userDbId = ((Integer)user.properties.get(Properties.ID)).intValue();

      int itemId;
      int charItemId;
      int quantity;
      try {
         itemId = Integer.parseInt(params[0]);
         charItemId = Integer.parseInt(params[1]);
         quantity = Integer.parseInt(params[3]);
      } catch (Exception e) {
         // Do not cancel an active trade for malformed add-item packets.
         JSONObject bad = new JSONObject();
         bad.element("cmd", "tradeFromInv");
         bad.element("bitSuccess", 0);
         bad.element("msg", "Invalid trade request.");
         Kaiden_Extension.getInstance().send(bad, user);
         return;
      }

      // Ensure trade maps exist
      TradeSupport.ensureTradeMaps(user);

      ItemBean item = (ItemBean) StorageCache.getInstance().getItem(Integer.valueOf(itemId));

      // IMPORTANT: do not trust the client-provided user id for trade packets.
      // Some clients send the sender's id here, which caused instant trade cancels.
      User client = TradeSupport.resolveTarget(user);
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      }

      // Validate mutual trade session.
      if(((Integer)client.properties.get(Properties.TRADE_TARGET)).intValue() != user.getUserId()) {
         TradeSupport.cancelWithTarget(user, client, "Trade session is no longer available.");
         throw new RequestExternalPacketException("Trade session is no longer available.");
      }

      // From here on: NEVER cancel the trade for normal add-item validation.
      if(item == null) {
         JSONObject offers = new JSONObject();
         offers.element("cmd", "tradeFromInv");
         offers.element("bitSuccess", 0);
         offers.element("msg", "Item could not be found.");
         Kaiden_Extension.getInstance().send(offers, user);
         return;
      }

      if(item.isTemporary()) {
         JSONObject offers = new JSONObject();
         offers.element("cmd", "tradeFromInv");
         offers.element("bitSuccess", 0);
         offers.element("msg", "You're not able to trade temporary items!");
         Kaiden_Extension.getInstance().send(offers, user);
         return;
      }

      if(!item.isTradeable()) {
         JSONObject offers = new JSONObject();
         offers.element("cmd", "tradeFromInv");
         offers.element("bitSuccess", 0);
         offers.element("msg", "Selected item is untradeable!");
         Kaiden_Extension.getInstance().send(offers, user);
         return;
      }

      if(quantity <= 0) {
         JSONObject offers = new JSONObject();
         offers.element("cmd", "tradeFromInv");
         offers.element("bitSuccess", 0);
         offers.element("msg", "Invalid quantity amount!");
         Kaiden_Extension.getInstance().send(offers, user);
         SmartFoxServer.log.warning("Attempting to put invalid item quantity amount: " + user.getName());
         return;
      }

      {
         if(item.getFactionId() > 1) {
            Map je = (Map)client.properties.get("factions");
            JSONObject offers;
            if(je == null || !je.containsKey(Integer.valueOf(item.getFactionId()))) {
               offers = new JSONObject();
               offers.element("cmd", "tradeFromInv");
               offers.element("bitSuccess", 0);
               offers.element("msg", "Reputation requirement not met for " + client.getName() + "! " + item.getName() + " requires " + StorageCache.getInstance().getFaction(Integer.valueOf(item.getFactionId())) + ", Rank " + ClassRank.getRankFromPoints(item.getReqReputation()) + ".");
               Kaiden_Extension.getInstance().send(offers, user);
               return;
            }

            if(((Integer)je.get(Integer.valueOf(item.getFactionId()))).intValue() < item.getReqReputation()) {
               offers = new JSONObject();
               offers.element("cmd", "tradeFromInv");
               offers.element("bitSuccess", 0);
               offers.element("msg", "Reputation requirement not met for " + client.getName() + "! " + item.getName() + " requires " + StorageCache.getInstance().getFaction(Integer.valueOf(item.getFactionId())) + ", Rank " + ClassRank.getRankFromPoints(item.getReqReputation()) + ".");
               Kaiden_Extension.getInstance().send(offers, user);
               return;
            }
         }

         Storage.getInstance().getJdbc().beginTransaction();

         try {
            QueryResult je1 = Storage.getInstance().getJdbc().query("SELECT * FROM users_items WHERE id = ? FOR UPDATE", new Object[]{Integer.valueOf(charItemId)});
            if(je1.next() && userDbId == je1.getInt("UserID") && itemId == je1.getInt("ItemID")) {
               if(item.getEquipment().equals("ar")) {
                  quantity = je1.getInt("Quantity");
               }

               Users.getInstance().addOfferItem(user, itemId, quantity, je1.getInt("EnhID"));
               Map offers1 = (Map)user.properties.get("offer");
               JSONObject tfi;
               if(je1.getInt("Quantity") < ((Integer)offers1.get(Integer.valueOf(itemId))).intValue()) {
                  tfi = new JSONObject();
                  tfi.element("cmd", "tradeFromInv");
                  tfi.element("bitSuccess", 0);
                  tfi.element("msg", "Invalid quantity amount!");
                  Kaiden_Extension.getInstance().send(tfi, user);
               } else {
                  tfi = new JSONObject();
                  tfi.element("cmd", "tradeFromInv");
                  tfi.element("ItemID", itemId);
                  tfi.element("bSuccess", 1);
                  tfi.element("Type", 1);
                  tfi.element("Quantity", offers1.get(Integer.valueOf(itemId)));
                  Kaiden_Extension.getInstance().send(tfi, user);
                  JSONObject lb = new JSONObject();
                  JSONArray items = new JSONArray();
                  int enhId = je1.getInt("EnhID");
                  
                  int itemidArray = Integer.parseInt(je1.getString("ItemID"));
                  int itemquantityArray = Integer.parseInt(je1.getString("Quantity"));
                  int enhanceidoffer = Integer.parseInt(je1.getString("EnhID"));
              
                  EnhancementBean enhancement = (EnhancementBean)StorageCache.getInstance().getEnhancement(Integer.valueOf(enhId));
                  JSONObject itemObj = Users.getInstance().getItemObject(itemidArray, enhanceidoffer);
                  itemObj.put("CharItemID", je1.getString("id"));
                  itemObj.put("iQty", offers1.get(Integer.valueOf(itemId)));
                  itemObj.put("iReqCP", Integer.valueOf(item.getReqClassPoints()));
                  itemObj.put("iReqRep", Integer.valueOf(item.getReqReputation()));
                  itemObj.put("FactionID", Integer.valueOf(item.getFactionId()));
                  itemObj.put("sFaction", StorageCache.getInstance().getFaction(Integer.valueOf(item.getFactionId())));
                  items.add(itemObj);
                  lb.put("cmd", "loadOffer");
                  lb.put("itemsB", items);
                  lb.put("bitSuccess", Integer.valueOf(1));
                  Kaiden_Extension.getInstance().send(lb, client);
                  // Offer changed -> unlock both if either side was locked.
                  TradeSupport.unlockBothIfLocked(user, client);
               }
            }

            je1.close();
         } catch (JdbcException var23) {
            if(Storage.getInstance().getJdbc().isInTransaction()) {
               Storage.getInstance().getJdbc().rollbackTransaction();
            }

            SmartFoxServer.log.severe("Error in trade from inventory transaction: " + var23.getMessage());
         } finally {
            if(Storage.getInstance().getJdbc().isInTransaction()) {
               Storage.getInstance().getJdbc().commitTransaction();
            }

         }

      }
   }
}