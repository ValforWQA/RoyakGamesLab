package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.Map;

public class TradeToInventory extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {

      if (params == null || params.length < 3) {
         throw new RequestExternalPacketException("Invalid trade request.");
      }

      int userDbId = ((Integer)user.properties.get(Properties.ID)).intValue();
      int itemId;
      int charItemId;
      try {
         itemId = Integer.parseInt(params[0]);
         charItemId = Integer.parseInt(params[1]);
      } catch (Exception e) {
         JSONObject bad = new JSONObject();
         bad.element("cmd", "tradeToInv");
         bad.element("bitSuccess", 0);
         bad.element("msg", "Invalid trade request.");
         Kaiden_Extension.getInstance().send(bad, user);
         return;
      }

      TradeSupport.ensureTradeMaps(user);

      // Resolve trade target from server-side state (don't trust params[2]).
      User client = TradeSupport.resolveTarget(user);
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      }

      if(((Integer)client.properties.get(Properties.TRADE_TARGET)).intValue() != user.getUserId()) {
         TradeSupport.cancelWithTarget(user, client, "Trade session is no longer available.");
         throw new RequestExternalPacketException("Trade session is no longer available.");
      }

      {
         Storage.getInstance().getJdbc().beginTransaction();

         try {
            QueryResult je = Storage.getInstance().getJdbc().query("SELECT ItemID, EnhID, UserID, Quantity FROM users_items WHERE id = ? FOR UPDATE", new Object[]{Integer.valueOf(charItemId)});
            if(je.next() && userDbId == je.getInt("UserID") && itemId == je.getInt("ItemID")) {
               je.close();
               Map offers = (Map)user.properties.get("offer");
               if(offers.get(Integer.valueOf(itemId)) != null) {
                  Users.getInstance().removeOfferItem(user, itemId, ((Integer)offers.get(Integer.valueOf(itemId))).intValue());
               }

               JSONObject tfi = new JSONObject();
               tfi.element("cmd", "tradeToInv");
               tfi.element("ItemID", itemId);
               tfi.element("Type", 1);
               Kaiden_Extension.getInstance().send(tfi, user);
               tfi.element("Type", 2);
               Kaiden_Extension.getInstance().send(tfi, client);
               // Offer changed -> unlock both if either side was locked.
               TradeSupport.unlockBothIfLocked(user, client);
            }
            je.close();
         } catch (JdbcException var16) {
            if(Storage.getInstance().getJdbc().isInTransaction()) {
               Storage.getInstance().getJdbc().rollbackTransaction();
            }

            SmartFoxServer.log.severe("Error in trade to inventory transaction: " + var16.getMessage());
         } finally {
            if(Storage.getInstance().getJdbc().isInTransaction()) {
               Storage.getInstance().getJdbc().commitTransaction();
            }

         }

      }
   }
}
