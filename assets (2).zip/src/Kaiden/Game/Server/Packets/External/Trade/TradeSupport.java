package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashMap;

/**
 * TradeSupport
 *
 * NOTE:
 * Trade handlers previously instantiated packet handlers directly:
 *   (new TradeCancel()).handle();
 * Those instances are not wired by the packet manager, so their `user` and `params`
 * fields are null which causes random NPEs.
 *
 * This utility provides a safe, centralized cancellation + reset implementation
 * that can be called from any trade handler.
 */
public final class TradeSupport {

    private TradeSupport() {}

    public static void cancelSelf(User user, String reason) {
        if (user == null) return;
        resetTradeState(user);
        sendTradeCancel(user);
        if (reason != null && reason.trim().length() > 0) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", reason}, user);
        }
    }

    public static void cancelBoth(User user, User other, String reasonForUser, String reasonForOther) {
        cancelSelf(user, reasonForUser);
        cancelSelf(other, reasonForOther);
    }

    /**
     * Cancel the current trade session for `user` and (if present) the trade target.
     *
     * If `other` is null, this method will try to resolve it from TRADE_TARGET.
     */
    public static void cancelWithTarget(User user, User other, String reason) {
        if (user == null) return;

        int targetId = getInt(user, Properties.TRADE_TARGET, -1);
        if (other == null && targetId > -1) {
            other = SmartFoxServer.getInstance().getUserById(Integer.valueOf(targetId));
        }

        // Always cancel the caller.
        cancelSelf(user, reason);

        // Only cancel the other side if it is actually pointing back to the caller.
        if (other != null) {
            int otherTargetId = getInt(other, Properties.TRADE_TARGET, -1);
            if (otherTargetId == user.getUserId()) {
                cancelSelf(other, reason);
            }
        }
    }

    /**
     * Resolve the current trade target for {@code user} from TRADE_TARGET.
     *
     * NOTE: Do not trust client-provided user IDs for trade packets. Some clients
     * send the sender's userId or stale values which would incorrectly cancel a
     * valid trade.
     */
    public static User resolveTarget(User user) {
        if (user == null) return null;
        int targetId = getInt(user, Properties.TRADE_TARGET, -1);
        if (targetId < 0) return null;
        return SmartFoxServer.getInstance().getUserById(Integer.valueOf(targetId));
    }

    public static boolean getBool(User user, String key, boolean fallback) {
        if (user == null || user.properties == null) return fallback;
        Object v = user.properties.get(key);
        if (v instanceof Boolean) return ((Boolean) v).booleanValue();
        if (v instanceof Integer) return ((Integer) v).intValue() == 1;
        if (v == null) return fallback;
        try {
            return Integer.parseInt(String.valueOf(v)) == 1;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    public static void setBool(User user, String key, boolean value) {
        if (user == null || user.properties == null) return;
        // Many older handlers store booleans, newer reset stores ints.
        user.properties.put(key, Boolean.valueOf(value));
    }

    /**
     * If either side is locked, unlock both sides when an offer changes.
     * This matches AQW-style trading: changing an offer never cancels the trade.
     */
    public static void unlockBothIfLocked(User user, User other) {
        if (user == null || other == null) return;

        boolean userLocked = getBool(user, Properties.TRADE_LOCK, false);
        boolean otherLocked = getBool(other, Properties.TRADE_LOCK, false);

        if (!userLocked && !otherLocked) return;

        setBool(user, Properties.TRADE_LOCK, false);
        setBool(user, Properties.TRADE_DEAL, false);
        setBool(other, Properties.TRADE_LOCK, false);
        setBool(other, Properties.TRADE_DEAL, false);

        JSONObject tr = new JSONObject();
        tr.put("cmd", "tradeUnlock");
        tr.put("bitSuccess", Integer.valueOf(1));
        Kaiden_Extension.getInstance().send(tr, user);
        Kaiden_Extension.getInstance().send(tr, other);
    }

    public static void resetTradeState(User user) {
        if (user == null) return;
        if (user.properties == null) return;

        user.properties.put(Properties.TRADE_OFFERS, new HashMap());
        user.properties.put(Properties.TRADE_OFFERS_ENHID, new HashMap());
        user.properties.put(Properties.TRADE_TARGET, Integer.valueOf(-1));
        user.properties.put(Properties.TRADE_GOLD, Integer.valueOf(0));
        user.properties.put(Properties.TRADE_COINS, Integer.valueOf(0));
        user.properties.put(Properties.TRADE_LOCK, Integer.valueOf(0));
        user.properties.put(Properties.TRADE_DEAL, Integer.valueOf(0));
    }

    public static void ensureTradeMaps(User user) {
        if (user == null || user.properties == null) return;
        if (user.properties.get(Properties.TRADE_OFFERS) == null) user.properties.put(Properties.TRADE_OFFERS, new HashMap());
        if (user.properties.get(Properties.TRADE_OFFERS_ENHID) == null) user.properties.put(Properties.TRADE_OFFERS_ENHID, new HashMap());
    }

    public static void sendTradeCancel(User user) {
        if (user == null) return;

        JSONObject ex = new JSONObject();
        ex.element("cmd", "tradeCancel");
        ex.element("bitSuccess", 1);
        Kaiden_Extension.getInstance().send(ex, user);
    }

    private static int getInt(User user, String key, int fallback) {
        if (user == null || user.properties == null) return fallback;
        Object v = user.properties.get(key);
        if (v instanceof Integer) return ((Integer) v).intValue();
        if (v == null) return fallback;
        try {
            return Integer.parseInt(String.valueOf(v));
        } catch (Exception ignored) {
            return fallback;
        }
    }
}
