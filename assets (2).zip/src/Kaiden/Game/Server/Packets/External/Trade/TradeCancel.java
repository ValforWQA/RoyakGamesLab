package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashMap;

public class TradeCancel extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
      try {
         JSONObject ex = new JSONObject();
         ex.element("cmd", "tradeCancel");
         ex.element("bitSuccess", 1);
         // Capture target before reset so we can notify the other side.
         Object tgtObj = (user != null && user.properties != null) ? user.properties.get(Properties.TRADE_TARGET) : null;
         int tgtId = (tgtObj instanceof Integer) ? ((Integer) tgtObj).intValue() : -1;

         TradeSupport.resetTradeState(user);
         Kaiden_Extension.getInstance().send(ex, user);
         // If user was actually in a trade, show a friendly reason
         if(tgtId > -1) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Trade session is no longer available."}, user);
         }

         // TradeCancel is often called as a cleanup from many places.
         // Be defensive: params can be missing or malformed.
         if (params == null || params.length < 1 || params[0] == null) {
            return;
         }

         User client = SmartFoxServer.getInstance().getUserById(Integer.valueOf(Integer.parseInt(params[0])));
         if(client == null) {
            return;
         }

         if(((Integer)client.properties.get(Properties.TRADE_TARGET)).intValue() == user.getUserId()) {
         TradeSupport.resetTradeState(client);
            Kaiden_Extension.getInstance().send(ex, client);
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Trade session is no longer available."}, client);
         }
      } catch (NumberFormatException var7) {
         Kaiden_Extension.getInstance().send(new String[]{"warning", "Invalid Input!"}, user);
      }

   }
}
