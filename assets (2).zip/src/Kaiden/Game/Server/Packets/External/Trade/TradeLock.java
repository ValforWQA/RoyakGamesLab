package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;


public class TradeLock extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException{
      if (params == null || params.length < 3) {
         throw new RequestExternalPacketException("Invalid trade request.");
      }

      int gold = 0;
      int coins = 0;

      try {
         gold = Integer.parseInt(params[1]);
         coins = Integer.parseInt(params[2]);
      } catch (NumberFormatException var10) {
         JSONObject userResult = new JSONObject();
         userResult.put("cmd", "tradeLock");
         userResult.put("bitSuccess", Integer.valueOf(0));
         userResult.put("msg", "Invalid gold/coins input!");
         Kaiden_Extension.getInstance().send(userResult, user);
         return;
      }

      // Resolve trade target from server state (don't trust client-provided id).
      User client = TradeSupport.resolveTarget(user);
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      }
      if(user.getName().equals(client.getName())) {
         TradeSupport.cancelWithTarget(user, client, client.getName() + " has canceled the trade.");
         throw new RequestExternalPacketException(client.getName() + " has canceled the trade.");
      } 
      if(gold < 0 || coins < 0) {
         TradeSupport.cancelWithTarget(user, client, "Negative value detected.");
         throw new RequestExternalPacketException("Negative value haxerino detected.");
      }
      if(((Integer)client.properties.get(Properties.TRADE_TARGET)).intValue() != user.getUserId()) {
         TradeSupport.cancelWithTarget(user, client, "Trade session is no longer available.");
         throw new RequestExternalPacketException("Trade session is no longer available.");
      }
      // Avoid NPE when tradedeal is missing
      boolean userDeal = TradeSupport.getBool(user, Properties.TRADE_DEAL, false);
      boolean clientDeal = TradeSupport.getBool(client, Properties.TRADE_DEAL, false);
      if(userDeal || clientDeal) {
         return;
      }
            QueryResult userResult1 = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ?", new Object[]{user.properties.get(Properties.ID)});
            if(userResult1.next() && userResult1.getInt("Coins") >= ((Integer)user.properties.get("tradecoins")).intValue() && userResult1.getInt("Gold") >= ((Integer)user.properties.get("tradegold")).intValue()) {
               //SmartFoxServer.log.fine("" + user.getName() + " Locking->GOLD : " + user.properties.get("tradegold"));
               //SmartFoxServer.log.fine("" + client.getName() + " Locking->COINS : " + user.properties.get("tradecoins"));
               TradeSupport.setBool(user, Properties.TRADE_LOCK, true);
               user.properties.put("tradegold", Integer.valueOf(gold));
               user.properties.put("tradecoins", Integer.valueOf(coins));
               JSONObject di = new JSONObject();
               if(TradeSupport.getBool(client, Properties.TRADE_LOCK, false) && TradeSupport.getBool(user, Properties.TRADE_LOCK, false)) {
                  di.put("Deal", Integer.valueOf(1));
               }

               di.put("cmd", "tradeLock");
               di.put("bitSuccess", Integer.valueOf(1));
               di.put("gold", (Integer)user.properties.get("tradegold"));
               di.put("coins", (Integer)user.properties.get("tradecoins"));
               //Extension.getInstance().send(new String[]{"server", "UGOLD:" +user.properties.get("tradegold")+ "/cOINS:"+user.properties.get("tradecoins")}, user);
               Kaiden_Extension.getInstance().send(di, client);
               di.put("gold", client.properties.get("tradegold"));
               di.put("coins", client.properties.get("tradecoins"));
               di.put("Self", Integer.valueOf(1));
               Kaiden_Extension.getInstance().send(di, user);
            }
            userResult1.close();
         }
      }
