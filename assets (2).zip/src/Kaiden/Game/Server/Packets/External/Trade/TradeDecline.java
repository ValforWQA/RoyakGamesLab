package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.ArrayList;


public class TradeDecline extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
    
    String UserName = params[0].toLowerCase();
    User client = Kaiden_Extension.getInstance().getZone().getUserByName(UserName);
    
    ArrayList<Integer> SenderrequestedTrade = (ArrayList)user.properties.get(Properties.REQUESTED_TRADE);
    SenderrequestedTrade.clear();
    if (client != null) {
      client.properties.put(Properties.TRADE_INVITE, Integer.valueOf(-1));
    }
    Kaiden_Extension.getInstance().send(new String[] { "server", user.getName() + " declined your trade request." }, client);
  }
}
