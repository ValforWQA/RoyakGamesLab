package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

/* Programmed by ValforWqa. for Onclax  & StarChronicles 2019 */
public class TradeUnlock extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
    User client = SmartFoxServer.getInstance().getUserById(Integer.valueOf(Integer.parseInt(params[0])));
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      } else if(client.getUserId() != ((Integer)user.properties.get("tradetgt")).intValue()) {
         TradeSupport.cancelWithTarget(user, client, client.getName() + " has canceled the trade.");
         throw new RequestExternalPacketException(client.getName() + " has canceled the trade.");
      } else if(user.getUserId() != ((Integer)client.properties.get("tradetgt")).intValue()) {
         TradeSupport.cancelWithTarget(user, client, client.getName() + " has canceled the trade.");
         throw new RequestExternalPacketException(client.getName() + " has canceled the trade.");
      } else if(user.getName().equals(client.getName())) {
         TradeSupport.cancelWithTarget(user, client, client.getName() + " has canceled the trade.");
         throw new RequestExternalPacketException(client.getName() + " has canceled the trade.");
      } else {
         user.properties.put("tradelock", Boolean.valueOf(false));
         user.properties.put("tradedeal", Boolean.valueOf(false));
         client.properties.put("tradelock", Boolean.valueOf(false));
         client.properties.put("tradedeal", Boolean.valueOf(false));
         JSONObject tr = new JSONObject();
         tr.element("cmd", "tradeUnlock");
         tr.element("bitSuccess", 1);
         Kaiden_Extension.getInstance().send(tr, user);
         Kaiden_Extension.getInstance().send(tr, client);
      }
   }
}
