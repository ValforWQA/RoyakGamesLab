package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.NoResultException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class TradeDeal extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {

       if (params == null || params.length < 1 || params[0] == null) {
          throw new RequestExternalPacketException("Invalid trade request.");
       }

       // Resolve trade target from server state (don't trust client-provided id).
       User client = TradeSupport.resolveTarget(user);
      if(client == null) {
         TradeSupport.cancelWithTarget(user, null, "Trade has been canceled because the other player can't be found.");
         throw new RequestExternalPacketException("Trade has been canceled due to other player can't be found!");
      } else if(((Integer)client.properties.get(Properties.TRADE_TARGET)).intValue() != user.getUserId()) {
         TradeSupport.cancelWithTarget(user, client, "Trade session is no longer available.");
         throw new RequestExternalPacketException("Trade session is no longer available.");
      } else if(user.getName().equals(client.getName())) {
         TradeSupport.cancelWithTarget(user, client, client.getName() + " has canceled the trade.");
         throw new RequestExternalPacketException(client.getName() + " has canceled the trade.");
      } else {
         JSONObject tr = new JSONObject();
         tr.element("cmd", "tradeDeal");
         tr.element("bitSuccess", 0);
         TradeSupport.setBool(user, Properties.TRADE_DEAL, true);
         if(!TradeSupport.getBool(client, Properties.TRADE_DEAL, false)) {
            tr.element("bitSuccess", 1);
            tr.element("onHold", 1);
            Kaiden_Extension.getInstance().send(tr, user);
         } else if(TradeSupport.getBool(client, Properties.TRADE_LOCK, false) && TradeSupport.getBool(user, Properties.TRADE_LOCK, false)) {
            Map offers1 = (Map)user.properties.get("offer");
            Map offers2 = (Map)client.properties.get("offer");
            boolean currencyCheck1 = false;
            boolean currencyCheck2 = false;
            boolean stackCheck1 = true;
            boolean stackCheck2 = true;
            ItemBean item1 = null;
            ItemBean item2 = null;
            int coins1 = 0;
            int gold1 = 0;
            int coins2 = 0;
            int gold2 = 0;
            int inventoryCount1 = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM users_items LEFT JOIN items ON items.id = users_items.ItemID WHERE Equipment NOT IN ('ho','hi') AND Bank = 0 AND UserID = ?", new Object[]{user.properties.get(Properties.ID)});
            int inventoryCount2 = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM users_items LEFT JOIN items ON items.id = users_items.ItemID WHERE Equipment NOT IN ('ho','hi') AND Bank = 0 AND UserID = ?", new Object[]{client.properties.get(Properties.ID)});
            QueryResult userResult = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ?", new Object[]{user.properties.get(Properties.ID)});
            if(userResult.next()) {
               coins1 = userResult.getInt("Coins");
               gold1 = userResult.getInt("Gold");
               if(coins1 >= ((Integer)user.properties.get("tradecoins")).intValue() && gold1 >= ((Integer)user.properties.get("tradegold")).intValue()) {
                  currencyCheck1 = true;
               }
            }

            userResult.close();
            userResult = Storage.getInstance().getJdbc().query("SELECT Gold, Coins FROM users WHERE id = ?", new Object[]{client.properties.get(Properties.ID)});
            if(userResult.next()) {
               coins2 = userResult.getInt("Coins");
               gold2 = userResult.getInt("Gold");
               if(coins2 >= ((Integer)client.properties.get("tradecoins")).intValue() && gold2 >= ((Integer)client.properties.get("tradegold")).intValue()) {
                  currencyCheck2 = true;
               }
            }

            userResult.close();
            Iterator i$ = offers1.entrySet().iterator();

            Entry entry;
            int itemId;
            int quantity;
            int itemObj;
            while(i$.hasNext()) {
               entry = (Entry)i$.next();
               itemId = ((Integer)entry.getKey()).intValue();
               quantity = ((Integer)entry.getValue()).intValue();
               item1 = (ItemBean) StorageCache.getInstance().getItem((itemId));

               try {
                  itemObj = Storage.getInstance().getJdbc().queryForInt("SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemId), client.properties.get(Properties.ID)});
                  if(item1.getStack() <= 1) {
                     stackCheck1 = false;
                     break;
                  }

                  if(itemObj + quantity > item1.getStack()) {
                     stackCheck1 = false;
                     break;
                  }
               } catch (NoResultException var29) {
               }
            }

            i$ = offers2.entrySet().iterator();

            while(i$.hasNext()) {
               entry = (Entry)i$.next();
               itemId = ((Integer)entry.getKey()).intValue();
               quantity = ((Integer)entry.getValue()).intValue();
               item2 = (ItemBean)StorageCache.getInstance().getItem((itemId));

               try {
                  itemObj = Storage.getInstance().getJdbc().queryForInt("SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemId), user.properties.get(Properties.ID)});
                  if(item2.getStack() <= 1) {
                     stackCheck2 = false;
                     break;
                  }

                  if(itemObj + quantity > item2.getStack()) {
                     stackCheck2 = false;
                     break;
                  }
               } catch (NoResultException var28) {
               }
            }

            if(inventoryCount1 >= ((Integer)user.properties.get("bagslots")).intValue()) {
               tr.element("msg", "Your inventory is full!");
               Kaiden_Extension.getInstance().send(tr, user);
               tr.element("msg", user.getName() + "'s inventory is full!");
               Kaiden_Extension.getInstance().send(tr, client);
            } else if(inventoryCount2 >= ((Integer)client.properties.get("bagslots")).intValue()) {
               tr.element("msg", "Your inventory is full!");
               Kaiden_Extension.getInstance().send(tr, client);
               tr.element("msg", client.getName() + "'s inventory is full!");
               Kaiden_Extension.getInstance().send(tr, user);
            } else if(!currencyCheck1) {
               TradeSupport.cancelWithTarget(user, client, "Insufficient gold/coins!");
               throw new RequestExternalPacketException("Insufficient gold/coins!");
            } else if(!currencyCheck2) {
               TradeSupport.cancelWithTarget(user, client, "Insufficient gold/coins!");
               throw new RequestExternalPacketException("Insufficient gold/coins!");
            } else if(!stackCheck1) {
               tr.element("msg", "You cannot have more than " + item1.getStack() + " of " + item1.getName() + "!");
               Kaiden_Extension.getInstance().send(tr, client);
               tr.element("msg", client.getName() + " cannot have more than " + item1.getStack() + " of " + item1.getName() + "!");
               Kaiden_Extension.getInstance().send(tr, user);
            } else if(!stackCheck2) {
               tr.element("msg", "You cannot have more than " + item2.getStack() + " of " + item2.getName() + "!");
               Kaiden_Extension.getInstance().send(tr, user);
               tr.element("msg", user.getName() + " cannot have more than " + item2.getStack() + " of " + item2.getName() + "!");
               Kaiden_Extension.getInstance().send(tr, client);
            } else if(this.turnInItems(user, offers1, client, offers2)) {
               user.properties.put("tradetgt", Integer.valueOf(-1));
               user.properties.put("tradelock", Boolean.valueOf(false));
               user.properties.put("tradedeal", Boolean.valueOf(false));
               client.properties.put("tradetgt", Integer.valueOf(-1));
               client.properties.put("tradelock", Boolean.valueOf(false));
               client.properties.put("tradedeal", Boolean.valueOf(false));
               i$ = offers1.entrySet().iterator();

               Map enhances;
               ItemBean itemObj1;
               while(i$.hasNext()) {
                  entry = (Entry)i$.next();
                  itemId = ((Integer)entry.getKey()).intValue();
                  quantity = ((Integer)entry.getValue()).intValue();
                  itemObj1 = (ItemBean)StorageCache.getInstance().getItem((itemId));
                  if(itemObj1 != null) {
                     enhances = (Map)user.properties.get("offerenh");
                     this.sendItem(client, itemObj1, quantity, ((Integer)enhances.get(Integer.valueOf(itemId))).intValue());
                  }
               }

               i$ = offers2.entrySet().iterator();

               while(i$.hasNext()) {
                  entry = (Entry)i$.next();
                  itemId = ((Integer)entry.getKey()).intValue();
                  quantity = ((Integer)entry.getValue()).intValue();
                  itemObj1 = (ItemBean)StorageCache.getInstance().getItem((itemId));
                  if(itemObj1 != null) {
                     enhances = (Map)client.properties.get("offerenh");
                     this.sendItem(user, itemObj1, quantity, ((Integer)enhances.get(Integer.valueOf(itemId))).intValue());
                  }
               }

               user.properties.put("offer", new HashMap());
               user.properties.put("offerenh", new HashMap());
               client.properties.put("offer", new HashMap());
               client.properties.put("offerenh", new HashMap());
               Properties.updateGoldCoins(user, gold1 - ((Integer)user.properties.get("tradegold")).intValue() + ((Integer)client.properties.get("tradegold")).intValue(), coins1 - ((Integer)user.properties.get("tradecoins")).intValue() + ((Integer)client.properties.get("tradecoins")).intValue());
               Properties.updateGoldCoins(client, gold2 - ((Integer)client.properties.get("tradegold")).intValue() + ((Integer)user.properties.get("tradegold")).intValue(), coins2 - ((Integer)client.properties.get("tradecoins")).intValue() + ((Integer)user.properties.get("tradecoins")).intValue());
               user.properties.put("tradegold", Integer.valueOf(0));
               user.properties.put("tradecoins", Integer.valueOf(0));
               client.properties.put("tradegold", Integer.valueOf(0));
               client.properties.put("tradecoins", Integer.valueOf(0));
               
               //if (((Integer)user.properties.get("tradecoins") > 0)){
               //Users.getInstance().giveRewards(user, 0, 0, 0, 0, (Integer)user.properties.get("tradecoins"), -1, user.getUserId(), "p");
                        //Users.getInstance().giveRewards(client, 0, Integer.parseInt(this.params[2]), 0, 0, 0, -1, client.getUserId(), "p");
                 //       Kaiden_Extension.getInstance().send(new String[]{"server", "Testing: You have traded " + (Integer)user.properties.get("tradecoins")+ "Coins!"}, user);
               //}
               //if (((Integer)client.properties.get("tradecoins") > 0)){
               //Users.getInstance().giveRewards(client, 0, 0, 0, 0, (Integer)client.properties.get("tradecoins"), -1, client.getUserId(), "p");
                        //Users.getInstance().giveRewards(client, 0, Integer.parseInt(this.params[2]), 0, 0, 0, -1, client.getUserId(), "p");
               //Kaiden_Extension.getInstance().send(new String[]{"server", "Testing: You have traded " + (Integer)client.properties.get("tradecoins")+ "Coins!"}, user);
               //Kaiden_Extension.getInstance().send(new String[]{"server", "Your trade session has been completed!"}, client);
               //}
               
               
           
            
               tr.element("bitSuccess", 1);
               Kaiden_Extension.getInstance().send(tr, user);
               Kaiden_Extension.getInstance().send(tr, client);
               Users.getInstance().log(user, "Complete Transaction[Trade]", "User: " + user.getName() + " completed transaction with User: " + client.getName());
               //UserQuery.getInstance().log(user, violation, details);
               //Kaiden_Extension.getInstance().send(new String[]{"server", "Test: #TRG:"+gold2+"URG:"+gold1+"TRC:"+coins2+"URC"+coins1}, user);
               Kaiden_Extension.getInstance().send(new String[]{"server", "Your trade session has been completed!"}, user);
               Kaiden_Extension.getInstance().send(new String[]{"server", "Your trade session has been completed!"}, client);
            } else {
               tr.element("msg", "You're experiencing technical difficulties.. Please relog!");
               Kaiden_Extension.getInstance().send(tr, client);
               Kaiden_Extension.getInstance().send(tr, user);
            }
         } else {
            tr.element("msg", "Your/His offer/s is not yet confirmed!");
            Kaiden_Extension.getInstance().send(tr, user);
            Kaiden_Extension.getInstance().send(tr, client);
         }

      }
   }

   

   private void sendItem(User user, ItemBean itemObj, int quantity, int enhId) throws RequestExternalPacketException {
      int itemId = itemObj.getId();
      int itemEnh = itemObj.getEnhId();
      JSONObject di = new JSONObject();
      JSONObject arrItems = new JSONObject();
      EnhancementBean enhancement = (EnhancementBean)StorageCache.getInstance().getEnhancement(Integer.valueOf(enhId));
      JSONObject item = Users.getInstance().getItemObject(itemId, itemEnh);
      item.element("iQty", quantity);
      item.element("iReqCP", itemObj.getReqClassPoints());
      item.element("iReqRep", itemObj.getReqReputation());
      item.element("FactionID", itemObj.getFactionId());
      item.element("sFaction", StorageCache.getInstance().getFaction(Integer.valueOf(itemObj.getFactionId())));
      arrItems.put(Integer.valueOf(itemId), item);
      di.element("items", arrItems);
      di.element("addItem", 1);
      di.element("cmd", "dropItem");
      Kaiden_Extension.getInstance().send(di, user);
      JSONObject gd = new JSONObject();
      gd.element("cmd", "getDrop");
      gd.element("ItemID", itemId);
      gd.element("bSuccess", "0");
      Storage.getInstance().getJdbc().beginTransaction();

      try {
         QueryResult je = Storage.getInstance().getJdbc().query("SELECT id FROM users_items WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemId), user.properties.get(Properties.ID)});
         int charItemId;
         if(je.next()) {
            charItemId = je.getInt("id");
            je.close();
            if(itemObj.getStack() > 1) {
               int itemQty = Storage.getInstance().getJdbc().queryForInt("SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ? FOR UPDATE", new Object[]{Integer.valueOf(itemId), user.properties.get(Properties.ID)});
               if(itemQty >= itemObj.getStack()) {
                  Storage.getInstance().getJdbc().rollbackTransaction();
                  Kaiden_Extension.getInstance().send(gd, user);
                  return;
               }

               Storage.getInstance().getJdbc().run("UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemQty + quantity), Integer.valueOf(itemId), user.properties.get(Properties.ID)});
            } else if(itemObj.getStack() == 1) {
               Storage.getInstance().getJdbc().rollbackTransaction();
               Kaiden_Extension.getInstance().send(gd, user);
            }
         } else {
            je.close();
            Storage.getInstance().getJdbc().run("INSERT INTO users_items (UserID, ItemID, EnhID, Equipped, Quantity, Bank, DatePurchased) VALUES (?, ?, ?, 0, ?, 0, '2012-12-12 01:00:00')", new Object[]{user.properties.get(Properties.ID), Integer.valueOf(itemId), Integer.valueOf(enhId), Integer.valueOf(quantity)});
            charItemId = Long.valueOf(Storage.getInstance().getJdbc().getLastInsertId()).intValue();
         }

         je.close();
         if(charItemId > 0) {
            gd.element("CharItemID", charItemId);
            gd.element("bBank", false);
            gd.element("iQty", quantity);
            gd.element("bSuccess", "1");
            if(enhancement.getId() > 0) {
               gd.element("EnhID", enhancement.getId());
               gd.element("EnhLvl", enhancement.getLevel());
               gd.element("EnhPatternID", enhancement.getClientPatternId());
               gd.element("EnhRty", enhancement.getRarity());
               gd.element("iRng", itemObj.getClientRange());
               gd.element("EnhRng", itemObj.getClientRange());
               gd.element("InvEnhPatternID", enhancement.getClientPatternId());
               gd.element("EnhDPS", enhancement.getDPS());
            }

            Kaiden_Extension.getInstance().send(gd, user);
         } else {
            Storage.getInstance().getJdbc().rollbackTransaction();
         }
      } catch (JdbcException var17) {
         if(Storage.getInstance().getJdbc().isInTransaction()) {
            Storage.getInstance().getJdbc().rollbackTransaction();
         }
      } finally {
         if(Storage.getInstance().getJdbc().isInTransaction()) {
            Storage.getInstance().getJdbc().commitTransaction();
         }

      }

   }

   private boolean turnInItems(User user, Map<Integer, Integer> items, User user2, Map<Integer, Integer> items2) {
      boolean valid = true;
      Storage.getInstance().getJdbc().beginTransaction();

      try {
         Iterator e;
         Entry entry;
         int itemId;
         int quantityRequirement;
         QueryResult itemResult;
         int quantity;
         int quantityLeft;
         for(e = items.entrySet().iterator(); e.hasNext(); itemResult.close()) {
            entry = (Entry)e.next();
            itemId = ((Integer)entry.getKey()).intValue();
            quantityRequirement = ((Integer)entry.getValue()).intValue();
            itemResult = Storage.getInstance().getJdbc().query("SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ? FOR UPDATE", new Object[]{Integer.valueOf(itemId), user.properties.get(Properties.ID)});
            if(!itemResult.next()) {
               valid = false;
               itemResult.close();
               Storage.getInstance().getJdbc().rollbackTransaction();
               Users.getInstance().log(user, "Suspicous TurnIn", "Item to turn in not found in database.");
               break;
            }

            quantity = itemResult.getInt("Quantity");
            quantityLeft = quantity - quantityRequirement;
            itemResult.close();
            if(quantityLeft > 0) {
               valid = true;
               Storage.getInstance().getJdbc().run("UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(quantityLeft), Integer.valueOf(itemId), user.properties.get(Properties.ID)});
            } else {
               if(quantityLeft < 0) {
                  valid = false;
                  Storage.getInstance().getJdbc().rollbackTransaction();
                  Users.getInstance().log(user, "Suspicous TurnIn", "Quantity requirement for turning in item is lacking.");
                  break;
               }

               valid = true;
               Storage.getInstance().getJdbc().run("DELETE FROM users_items WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemId), user.properties.get(Properties.ID)});
            }
         }

         if(Storage.getInstance().getJdbc().isInTransaction()) {
            for(e = items2.entrySet().iterator(); e.hasNext(); itemResult.close()) {
               entry = (Entry)e.next();
               itemId = ((Integer)entry.getKey()).intValue();
               quantityRequirement = ((Integer)entry.getValue()).intValue();
               itemResult = Storage.getInstance().getJdbc().query("SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ? FOR UPDATE", new Object[]{Integer.valueOf(itemId), user2.properties.get(Properties.ID)});
               if(!itemResult.next()) {
                  valid = false;
                  itemResult.close();
                  Storage.getInstance().getJdbc().rollbackTransaction();
                  Users.getInstance().log(user, "Suspicous TurnIn", "Item to turn in not found in database.");
                  break;
               }

               quantity = itemResult.getInt("Quantity");
               quantityLeft = quantity - quantityRequirement;
               itemResult.close();
               if(quantityLeft > 0) {
                  valid = true;
                  Storage.getInstance().getJdbc().run("UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(quantityLeft), Integer.valueOf(itemId), user2.properties.get(Properties.ID)});
               } else {
                  if(quantityLeft < 0) {
                     valid = false;
                     Storage.getInstance().getJdbc().rollbackTransaction();
                     Users.getInstance().log(user, "Suspicous TurnIn", "Quantity requirement for turning in item is lacking.");
                     break;
                  }

                  valid = true;
                  Storage.getInstance().getJdbc().run("DELETE FROM users_items WHERE ItemID = ? AND UserID = ?", new Object[]{Integer.valueOf(itemId), user2.properties.get(Properties.ID)});
               }
            }
         }
      } catch (Exception var16) {
         if(Storage.getInstance().getJdbc().isInTransaction()) {
            Storage.getInstance().getJdbc().rollbackTransaction();
         }
      } finally {
         if(Storage.getInstance().getJdbc().isInTransaction()) {
            Storage.getInstance().getJdbc().commitTransaction();
         }

      }

      return valid;
   }
}