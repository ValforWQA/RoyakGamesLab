package Kaiden.Game.Server.Packets.External.Trade;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class TradeLoadOffer extends ExternalPacketHandler {
    public void handle() {
      List types = Arrays.asList(params);
      JSONObject lb = new JSONObject();
      JSONArray items = new JSONArray();
      Map offers = (Map)user.properties.get("offer");
      Iterator i$ = offers.entrySet().iterator();

      while(i$.hasNext()) {
         Entry entry = (Entry)i$.next();
         int itemId = ((Integer)entry.getKey()).intValue();
         int quantity = ((Integer)entry.getValue()).intValue();
         ItemBean item = (ItemBean) StorageCache.getInstance().getItem(Integer.valueOf(itemId));
         if(item != null) {
            QueryResult result = Storage.getInstance().getJdbc().query("SELECT id, EnhID FROM users_items WHERE  UserID = ? AND ItemID = ?", new Object[]{user.properties.get(Properties.ID), Integer.valueOf(item.getId())});
            if(result.next()) {
               int enhId = result.getInt("EnhID");
               int itemidArray = Integer.parseInt(result.getString("ItemID"));
                  int itemquantityArray = Integer.parseInt(result.getString("Quantity"));
                  int enhanceidoffer = Integer.parseInt(result.getString("EnhID"));
               EnhancementBean enhancement = (EnhancementBean)StorageCache.getInstance().getEnhancement(Integer.valueOf(enhId));
               if(types.contains(item.getType())) {
                  JSONObject itemObj = Users.getInstance().getItemObject(itemidArray, enhanceidoffer);
                  itemObj.element("bBank", "1");
                  itemObj.element("CharItemID", result.getString("id"));
                  itemObj.element("iQty", quantity);
                  itemObj.element("iReqCP", item.getReqClassPoints());
                  itemObj.element("iReqRep", item.getReqReputation());
                  itemObj.element("FactionID", item.getFactionId());
                  itemObj.element("sFaction", StorageCache.getInstance().getFaction(Integer.valueOf(item.getFactionId())));
                  items.add(itemObj);
               }
            }

            result.close();
         }
      }

      lb.element("cmd", "loadOffer");
      lb.element("itemsA", items);
      lb.element("bitSuccess", 1);
      Kaiden_Extension.getInstance().send(lb, user);
   }
}
