package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class SellItem extends ExternalPacketHandler {

    @SuppressWarnings("unchecked")
    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        int charItemId = Integer.parseInt(params[2]);

        JSONObject sell = new JSONObject();
        sell.put("cmd", "sellItem");

        Storage.getInstance().getJdbc().beginTransaction();

        try {
            ConcurrentHashMap<Integer, UserItem> inventoryItems =
                    (ConcurrentHashMap<Integer, UserItem>) this.user.properties.get(Properties.INVENTORY_ITEMS);

            if (inventoryItems == null || !inventoryItems.containsKey(itemId)) {
                Users.getInstance().log(user, "Packet Edit [SellItem]", "Attempted to sell an item not in possession");
                Storage.getInstance().getJdbc().rollbackTransaction();
                return;
            }

            UserItem userItem = inventoryItems.get(itemId);
            int quantity = userItem.getQuantity();
            int itemDbId = userItem.getItemId();
            Date purchase = userItem.getDatePurchased();

            ItemBean item = StorageCache.getInstance().getItem(itemId);
            if (item == null) {
                Users.getInstance().log(user, "SellItem", "Item not found in cache: " + itemId);
                Storage.getInstance().getJdbc().rollbackTransaction();
                return;
            }

            // Extra guard (your original check)
            if (itemDbId != itemId) {
                Users.getInstance().log(user, "SellItem", "ItemID mismatch. inv=" + itemDbId + " sell=" + itemId);
                Storage.getInstance().getJdbc().rollbackTransaction();
                return;
            }

            // ===== Calculate refund amount (DO NOT reuse for stack qty) =====
            int refundAmount;
            if (!item.isCoins()) {
                // gold refund
                refundAmount = item.getCost() / 5 / 2; // your original formula
                int gold = (int) user.properties.get(Properties.GOLD);
                user.properties.replace(Properties.GOLD, gold + refundAmount);
                sell.put("intAmount", refundAmount);
            } else {
                // coins refund (varies by time since purchase)
                long nowMs = System.currentTimeMillis();
                long diffHours = (nowMs - purchase.getTime()) / 3600000L;

                refundAmount = (diffHours < 24L) ? (item.getCost() / 10 * 9) : (item.getCost() / 4);

                int coins = (int) user.properties.get(Properties.COINS);
                user.properties.replace(Properties.COINS, coins + refundAmount);
                sell.put("intAmount", refundAmount);
            }

            // ===== Remove 1 from stack or delete item =====
            final int soldQty = 1;

            if (item.getStack() > 1) {
                int newQuantity = quantity - soldQty;

                if (newQuantity > 0) {
                    Storage.getInstance().getJdbc().execute(
                            "UPDATE users_items SET Quantity = ? WHERE id = ?",
                            newQuantity, charItemId
                    );
                    inventoryItems.get(itemId).setQuantity(newQuantity);
                } else {
                    // log 1 sold, then delete row
                    Storage.getInstance().getJdbc().run(
                            "INSERT INTO users_items_sold (UserID, ItemID, Quantity, DateSold) VALUES (?, ?, ?, NOW())",
                            user.properties.get(Properties.ID), itemId, soldQty
                    );
                    inventoryItems.remove(itemId);
                    Storage.getInstance().getJdbc().execute("DELETE FROM users_items WHERE id = ?", charItemId);
                }
            } else {
                // non-stack item: log 1 sold and delete
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_items_sold (UserID, ItemID, Quantity, DateSold) VALUES (?, ?, ?, NOW())",
                        user.properties.get(Properties.ID), itemId, soldQty
                );
                inventoryItems.remove(itemId);
                Storage.getInstance().getJdbc().execute("DELETE FROM users_items WHERE id = ?", charItemId);
            }

            // ===== Response packet =====
            sell.put("CharItemID", charItemId);
            sell.put("bCoins", item.isCoins() ? 1 : 0);
            sell.put("bGold", !item.isCoins()); // more truthful than always true

            Storage.getInstance().getJdbc().commitTransaction();

            Kaiden_Extension.getInstance().send(sell, user);

        } catch (Exception e) {
            try { Storage.getInstance().getJdbc().rollbackTransaction(); } catch (Exception ignore) {}
            Users.getInstance().log(user, "SellItem", "Exception: " + e.getMessage());
            // If you want: throw new RequestExternalPacketException("SellItem failed");
        }
    }
}
