package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public class RemoveItem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        int charItemId = Integer.parseInt(params[1]);
        int quantityToRemove = params.length > 2 ? Integer.parseInt(params[2]) : 1;
        ConcurrentHashMap<Integer, UserItem> inventoryItems = (ConcurrentHashMap) this.user.properties.get(Properties.INVENTORY_ITEMS);

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (quantityToRemove < 1) {
            Users.getInstance().log(user, "Packet Edit [RemoveItem]", "Quantity should not be lesser than 1");
        } else {
            if(inventoryItems.containsKey(itemId)) {
                UserItem userItem = inventoryItems.get(itemId);
                int quantity = userItem.getQuantity();
                int itemDbId = userItem.getItemId();
                if (itemDbId == itemId) {
                    if (item.getStack() > 1) {
                        int delete = quantity - quantityToRemove;
                        if (delete > 0) {
                            Storage.getInstance().getJdbc().run("UPDATE users_items SET Quantity = ? WHERE id = ?", delete, charItemId);
                            inventoryItems.get(itemId).setQuantity(delete);
                        } else {
                            Storage.getInstance().getJdbc().run("DELETE FROM users_items WHERE id = ?", charItemId);
                            inventoryItems.remove(itemId);
                        }
                    } else {
                        Storage.getInstance().getJdbc().run("DELETE FROM users_items WHERE id = ?", charItemId);
                        inventoryItems.remove(itemId);
                    }

                    JSONObject delete1 = new JSONObject();
                    delete1.put("cmd", "removeItem");
                    delete1.put("bitSuccess", 1);
                    delete1.put("CharItemID", charItemId);
                    if (quantityToRemove > 1) {
                        delete1.put("iQty", quantityToRemove);
                    }

                    Kaiden_Extension.getInstance().send(delete1, this.user);
                } else {
                    Users.getInstance().log(this.user, "Packet Edit [RemoveItem]", "Attempted to delete an item not in possession");
                }
            }
        }
    }
}
