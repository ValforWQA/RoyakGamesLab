package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.ShopBean;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class BuyItem extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        int shopId = Integer.parseInt(params[1]);

        // Client sends:
        // [ItemID, ShopID, ShopItemID, iQty]
        int shopItemId = -1;
        int requestedQty = 1;

        if (params.length > 2) {
            try {
                shopItemId = Integer.parseInt(params[2]);
            } catch (Exception ignored) {
                shopItemId = -1;
            }
        }

        if (params.length > 3) {
            try {
                requestedQty = Integer.parseInt(params[3]);
            } catch (Exception ignored) {
                requestedQty = 1;
            }
        }

        if (requestedQty <= 0) {
            requestedQty = 1;
        }

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        ShopBean shop = StorageCache.getInstance().getShop(shopId);

        if (item == null || shop == null) {
            throw new RequestExternalPacketException("Invalid item or shop.");
        }

        if (!shop.items.containsValue(itemId)) {
            Users.getInstance().log(user, "Packet Edit [BuyItem]", "Attempted to purchase an item from wrong shop");
            return;
        } else if (shop.isStaff() && !user.isAdmin() && !user.isModerator()) {
            Users.getInstance().log(user, "Packet Edit [BuyItem]", "Attempted to purchase from staff shop");
            return;
        }

        int userLevel = (Integer) user.properties.get(Properties.LEVEL);
        int houseCount = Storage.getInstance().getJdbc().queryForInt(
                "SELECT COUNT(*) AS rowcount FROM users_items " +
                        "LEFT JOIN items ON items.id = users_items.ItemID " +
                        "WHERE Equipment IN ('ho','hi') AND Bank = 0 AND UserID = ?",
                user.properties.get(Properties.ID)
        );
        int inventoryCount = Storage.getInstance().getJdbc().queryForInt(
                "SELECT COUNT(*) AS rowcount FROM users_items " +
                        "LEFT JOIN items ON items.id = users_items.ItemID " +
                        "WHERE Equipment NOT IN ('ho','hi') AND Bank = 0 AND UserID = ?",
                user.properties.get(Properties.ID)
        );
        boolean upgrade = (Integer) user.properties.get("upgdays") > 0;

        JSONObject buy = new JSONObject();
        buy.put("cmd", "buyItem");
        buy.put("bitSuccess", 0);
        buy.put("CharItemID", -1);

        if (item.isUpgrade() && !upgrade) {
            buy.put("strMessage", "This item is member only!");
            Kaiden_Extension.getInstance().send(buy, user);
            return;
        } else if (item.getLevel() > userLevel) {
            buy.put("strMessage", "Level requirement not met!");
            Kaiden_Extension.getInstance().send(buy, user);
            return;
        } else if (item.isStaff() && !user.isAdmin() && !user.isModerator()) {
            buy.put("strMessage", "Test Item: Cannot be purchased yet!");
            Kaiden_Extension.getInstance().send(buy, user);
            return;
        } else if (!shop.isHouse() && inventoryCount >= (Integer) user.properties.get("bagslots")) {
            buy.put("strMessage", "Inventory Full!");
            Kaiden_Extension.getInstance().send(buy, user);
            return;
        } else if (shop.isHouse() && houseCount >= (Integer) user.properties.get("houseslots")) {
            buy.put("strMessage", "House Inventory Full!");
            Kaiden_Extension.getInstance().send(buy, user);
            return;
        } else if (!shop.getField().isEmpty() && shop.getIndex() > -1) {
            int ach = Users.getInstance().getAchievement(shop.getField(), shop.getIndex(), user);
            if (ach <= 0) {
                buy.put("strMessage", "Item Locked: Special requirement not met.");
                Kaiden_Extension.getInstance().send(buy, user);
                return;
            }
        }

        int purchaseQty = shop.isLimited() ? 1 : requestedQty;

        // Preserve bundled item quantity behavior if the item itself grants more than 1 per purchase
        if (item.getQuantity() > 1) {
            long bundledQty = (long) purchaseQty * (long) item.getQuantity();
            if (bundledQty > Integer.MAX_VALUE) {
                buy.put("strMessage", "Requested quantity is too large.");
                Kaiden_Extension.getInstance().send(buy, user);
                return;
            }
            purchaseQty = (int) bundledQty;
        }

        if (purchaseQty <= 0) {
            purchaseQty = 1;
        }

        if (shop.isLimited()) {
            int qtyRemain = Storage.getInstance().getJdbc().queryForInt(
                    "SELECT QuantityRemain FROM shops_items WHERE ShopID = ? AND ItemID = ?",
                    shopId,
                    itemId
            );
            if (qtyRemain <= 0) {
                buy.put("strMessage", item.getName());
                buy.put("bSoldOut", 1);
                Kaiden_Extension.getInstance().send(buy, user);
                return;
            }
        }

        if (!item.getRequirements().isEmpty()) {
            for (Object o : item.getRequirements().entrySet()) {
                @SuppressWarnings("rawtypes")
                Entry requirement = (Entry) o;
                int requiredItemId = (Integer) requirement.getKey();
                ItemBean requiredItemBean = StorageCache.getInstance().getItem(requiredItemId);

                int requiredAmount = (Integer) requirement.getValue();
                if (requiredItemBean != null && requiredAmount > requiredItemBean.getStack()) {
                    requiredAmount = requiredItemBean.getStack();
                }

                QueryResult charItemId = Storage.getInstance().getJdbc().query(
                        "SELECT Quantity FROM users_items WHERE ItemID = ? AND UserID = ?",
                        requiredItemId,
                        user.properties.get(Properties.ID)
                );

                if (!charItemId.next()) {
                    charItemId.close();
                    buy.put("strMessage", "You do not meet the requirements to buy this item.");
                    Kaiden_Extension.getInstance().send(buy, user);
                    return;
                }

                int userReqQty = charItemId.getInt("Quantity");
                charItemId.close();

                if (userReqQty < requiredAmount) {
                    buy.put("strMessage", "You do not meet the requirements to buy this item.");
                    Kaiden_Extension.getInstance().send(buy, user);
                    return;
                }
            }

            Users.getInstance().turnInItems(user, item.getRequirements());
        }

        Storage.getInstance().getJdbc().beginTransaction();

        try {
            int coins1 = (Integer) user.properties.get(Properties.COINS);
            int gold = (Integer) user.properties.get(Properties.GOLD);

            long costLong = (long) item.getCost() * (long) purchaseQty;
            if (costLong > Integer.MAX_VALUE) {
                Storage.getInstance().getJdbc().rollbackTransaction();
                buy.put("strMessage", "This item is too expensive to purchase.");
                Kaiden_Extension.getInstance().send(buy, user);
                return;
            }
            int cost = (int) costLong;

            boolean payWithCoins = item.isCoins();
            boolean hasEnough = payWithCoins ? (cost <= coins1) : (cost <= gold);

            if (!hasEnough) {
                Storage.getInstance().getJdbc().rollbackTransaction();
                buy.put("strMessage", "Insufficient funds!");
                Kaiden_Extension.getInstance().send(buy, user);
                return;
            }

            QueryResult itemResult = Storage.getInstance().getJdbc().query(
                    "SELECT id, Quantity FROM users_items WHERE ItemID = ? AND UserID = ? FOR UPDATE",
                    itemId,
                    user.properties.get(Properties.ID)
            );

            int charItemId;

            if (itemResult.next()) {
                charItemId = itemResult.getInt("id");
                int currentQty = itemResult.getInt("Quantity");

                if (item.getStack() > 1) {
                    long newQtyLong = (long) currentQty + (long) purchaseQty;
                    if (newQtyLong > item.getStack()) {
                        Storage.getInstance().getJdbc().rollbackTransaction();
                        buy.put("strMessage", "You cannot have more than " + item.getStack() + " of that item!");
                        Kaiden_Extension.getInstance().send(buy, user);
                        Users.getInstance().log(user, "Packet Edit [BuyItem]", "Attempted to purchase more than stack value");
                        itemResult.close();
                        return;
                    }

                    int newQty = (int) newQtyLong;
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?",
                            newQty,
                            itemId,
                            user.properties.get(Properties.ID)
                    );
                } else {
                    Storage.getInstance().getJdbc().rollbackTransaction();
                    buy.put("strMessage", "You cannot have more than " + item.getStack() + " of that item!");
                    Kaiden_Extension.getInstance().send(buy, user);
                    Users.getInstance().log(user, "Packet Edit [BuyItem]", "Attempted to purchase more than stack value");
                    itemResult.close();
                    return;
                }
            } else {
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_items (UserID, ItemID, EnhID, Equipped, Quantity, Bank, DatePurchased) " +
                                "VALUES (?, ?, ?, 0, ?, 0, NOW())",
                        user.properties.get(Properties.ID),
                        itemId,
                        item.getEnhId(),
                        purchaseQty
                );
                charItemId = (int) Storage.getInstance().getJdbc().getLastInsertId();

                @SuppressWarnings("unchecked")
                ConcurrentHashMap<Integer, UserItem> inventoryItems =
                        (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.INVENTORY_ITEMS);
                inventoryItems.put(itemId, new UserItem(charItemId, purchaseQty, item.getId(), item.getEnhId()));
            }

            itemResult.close();

            if (charItemId > 0) {
                if (payWithCoins) {
                    int newCoins = coins1 - cost;
                    if (newCoins < 0) newCoins = 0;
                    user.properties.replace(Properties.COINS, newCoins);
                    buy.put("intCoins", newCoins);
                } else {
                    int newGold = gold - cost;
                    if (newGold < 0) newGold = 0;
                    user.properties.replace(Properties.GOLD, newGold);
                    buy.put("intGold", newGold);
                }

                if (shop.isLimited()) {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE shops_items SET QuantityRemain = (QuantityRemain - 1) WHERE ShopID = ? AND ItemID = ?",
                            shopId,
                            itemId
                    );
                }

                buy.put("iQty", purchaseQty);
                buy.put("bBank", false);
                buy.put("virtual", false);
                buy.put("bitSuccess", 1);
                buy.put("CharItemID", charItemId);

                // Optional debug echoes
                buy.put("ShopItemID", shopItemId);
            } else {
                Storage.getInstance().getJdbc().rollbackTransaction();
                buy.put("strMessage", "An error occured while purchasing the item!");
            }

        } catch (JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);
        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }
        }

        Kaiden_Extension.getInstance().send(buy, user);
    }
}