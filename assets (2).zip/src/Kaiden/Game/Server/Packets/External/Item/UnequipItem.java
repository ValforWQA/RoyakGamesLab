package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.BoostContainer;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class UnequipItem extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        ItemBean item = StorageCache.getInstance().getItem(itemId);

        if (item == null) {
            throw new RequestExternalPacketException("Item not found.");
        }

        String es = item.getEquipment();

        JSONObject uni = new JSONObject();
        uni.put("cmd", "unequipItem");
        uni.put("ItemID", itemId);
        uni.put("uid", user.getUserId());
        uni.put("bUnload", true);
        uni.put("strES", es);

        Stats eqp = (Stats) user.properties.get("stats");
        if (eqp != null) {
            if ("ar".equals(es)) {
                clearStatMap(eqp.armor);
                user.properties.remove("armoritem");
                user.properties.remove("armoritemenhancement");
            }

            if ("ba".equals(es)) {
                clearStatMap(eqp.cape);
                user.properties.remove("capeitem");
                user.properties.remove("capeitemenhancement");
            }

            if ("he".equals(es)) {
                clearStatMap(eqp.helm);
                user.properties.remove("helmitem");
                user.properties.remove("helmitemenhancement");
            }

            if ("Weapon".equals(es)) {
                clearStatMap(eqp.weapon);
                user.properties.remove("weaponitem");
                user.properties.remove("weaponitemenhancement");
            }

            // Recalculate stats immediately so wDPS/minDmg/maxDmg are refreshed
            eqp.update();
            Users.getInstance().sendStats(user);
        }

        JSONObject equipment = (JSONObject) user.properties.get("equipment");
        if (equipment != null) {
            equipment.remove(es);
        }

        // Rebuild boosts from currently equipped items so removed meta stops applying immediately
        BoostContainer.getInstance().rebuildFromEquipment(this.user);

        Kaiden_Extension.getInstance().sendToRoom(uni, user, room);

        Storage.getInstance().getJdbc().run(
                "UPDATE users_items SET Equipped = 0 WHERE ItemID = ? AND UserID = ?",
                itemId,
                user.properties.get(Properties.ID)
        );
    }

    private void clearStatMap(Map map) {
        Iterator i$ = map.entrySet().iterator();
        while (i$.hasNext()) {
            Entry entry = (Entry) i$.next();
            map.put(entry.getKey(), 0.0D);
        }
    }
}