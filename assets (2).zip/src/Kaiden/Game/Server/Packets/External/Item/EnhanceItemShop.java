package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/*
  yeah ill help when i can i dont use reg gamefiles anymore
 */

public class EnhanceItemShop extends ExternalPacketHandler {

    private static final class SelectedItem {
        private final int itemId;
        private final int charItemId;
        private SelectedItem(int itemId, int charItemId) {
            this.itemId = itemId;
            this.charItemId = charItemId;
        }
    }

    private boolean isEnhanceableSlot(String slot) {
        return "Weapon".equals(slot) || "ar".equals(slot) || "ba".equals(slot) || "he".equals(slot);
    }

    public void handle() throws RequestExternalPacketException {
        JSONObject eis = new JSONObject();
        List<SelectedItem> selectedItems = parseSelectedItems(params[0]);
        if (selectedItems.isEmpty()) {
            throw new RequestExternalPacketException("EnhanceItemShop: no target items");
        }

        int enhancementItemId = Integer.parseInt(params[1]);
        ItemBean enhancementItem = StorageCache.getInstance().getItem(enhancementItemId);
        EnhancementBean enhance = StorageCache.getInstance().getEnhancement(enhancementItem.getEnhId());
        if (enhancementItem == null || enhance == null) {
            throw new RequestExternalPacketException("EnhanceItemShop: invalid enhancement item");
        }
        if (!enhancementItem.getRequirements().isEmpty()) {
            Users.getInstance().log(user, "Packet Edit [EnhanceItemShop]", "Trying to use an enhancement that can only be use locally.");
            Users.getInstance().kick(user, "Trying to use an enhancement that can only be use locally.");
            return;
        }

        int gold = (int) user.properties.get(Properties.GOLD);
        int coins = (int) user.properties.get(Properties.COINS);
        int totalCost = enhancementItem.getCost() * selectedItems.size();
        if (enhancementItem.isCoins()) {
            if (totalCost > coins) {
                Users.getInstance().log(user, "Packet Edit [EnhanceItemShop]", "Sent an enhancement request while lacking coins.");
                return;
            }
            user.properties.replace(Properties.COINS, coins - totalCost);
        } else {
            if (totalCost > gold) {
                Users.getInstance().log(user, "Packet Edit [EnhanceItemShop]", "Sent an enhancement request while lacking funds.");
                return;
            }
            user.properties.replace(Properties.GOLD, gold - totalCost);
        }

        SelectedItem first = selectedItems.get(0);
        eis.put("EnhName", enhance.getName());
        eis.put("EnhPID", enhance.getClientPatternId());
        eis.put("EnhRng", enhancementItem.getClientRange());
        eis.put("EnhRty", enhance.getRarity());
        eis.put("ProcID", enhance.getProcId());
        eis.put("iCost", totalCost);
        eis.put("bSuccess", 1);
        eis.put("EnhDPS", enhance.getDPS());
        eis.put("EnhLvl", enhance.getLevel());
        eis.put("EnhID", enhancementItemId);
        eis.put("cmd", "enhanceItemShop");
        eis.put("ItemID", first.itemId);
        eis.put("CharItemID", first.charItemId);

        JSONArray itemIds = new JSONArray();
        JSONArray charItemIds = new JSONArray();
        Set<String> changedSlots = new LinkedHashSet<String>();
        for (SelectedItem si : selectedItems) {
            itemIds.add(si.itemId);
            charItemIds.add(si.charItemId);
            Storage.getInstance().getJdbc().run(
                    "UPDATE users_items SET EnhID = ? WHERE ItemID = ? AND UserID = ?",
                    enhancementItem.getEnhId(),
                    si.itemId,
                    user.properties.get(Properties.ID)
            );
            //if(user.properties.get(Properties.ACCESS).equals(80)) {
                //Kaiden_Extension.getInstance().sendToStaffUser("moderator", "charItemID:"+si.charItemId+" itemId:"+si.itemId+ " enhId:"+enhancementItem.getEnhId(), this.user);
            //}
            //}
            ItemBean targetItem = StorageCache.getInstance().getItem(si.itemId);
            if (targetItem != null) {
                //if ("mi".equals(targetItem.getEquipment())) {
                    //continue;
                //}
                changedSlots.add(targetItem.getEquipment());
            }
        }
        eis.put("ItemIDs", itemIds);
        eis.put("CharItemIDs", charItemIds);
        Kaiden_Extension.getInstance().send(eis, user);

        for (String slot : changedSlots) {
            if (slot == null) continue;
            if (slot.equals("ar") || slot.equals("ba") || slot.equals("he") || slot.equals("Weapon")) {
                Users.getInstance().updateStats(user, enhance, slot);
                if (slot.equals("Weapon")) {
                    user.properties.put("weaponitemenhancement", enhance);
                }
            }
        }
        Users.getInstance().sendStats(user);
    }

    private List<SelectedItem> parseSelectedItems(String raw) {
        List<SelectedItem> out = new ArrayList<SelectedItem>();
        if (raw == null) return out;
        raw = raw.trim();
        if (raw.isEmpty()) return out;

        String[] parts = raw.split(",");
        List<Integer> nums = new ArrayList<Integer>();
        for (String p : parts) {
            if (p == null) continue;
            String s = p.trim();
            if (s.isEmpty()) continue;
            try {
                nums.add(Integer.parseInt(s));
            } catch (Exception ignored) {}
        }
        if (nums.isEmpty()) return out;
        if (nums.size() % 2 == 0) {
            for (int i = 0; i < nums.size(); i += 2) {
                int itemId = nums.get(i);
                int charItemId = nums.get(i + 1);
                if (itemId > 0 && charItemId > 0) out.add(new SelectedItem(itemId, charItemId));
            }
        } else {
            for (Integer itemId : nums) {
                if (itemId != null && itemId > 0) out.add(new SelectedItem(itemId, itemId));
            }
        }
        return out;
    }
}
