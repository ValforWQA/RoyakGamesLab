package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;

public class EnhanceItemPTR extends EnhanceItemShop {
    @Override
    public void handle() throws RequestExternalPacketException {
        super.handle();
    }
}
