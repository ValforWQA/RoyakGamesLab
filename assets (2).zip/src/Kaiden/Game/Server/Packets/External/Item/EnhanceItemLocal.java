package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;


public class EnhanceItemLocal extends ExternalPacketHandler {

    private static final class SelectedItem {
        private final int itemId;
        private final int charItemId;
        private SelectedItem(int itemId, int charItemId) {
            this.itemId = itemId;
            this.charItemId = charItemId;
        }
    }

    private boolean isEnhanceableSlot(String slot) {
        return "Weapon".equals(slot) || "ar".equals(slot) || "ba".equals(slot) || "he".equals(slot);
    }

    public void handle() throws RequestExternalPacketException {
        JSONObject eil = new JSONObject();
        List<SelectedItem> selectedItems = parseSelectedItems(params[0]);
        if (selectedItems.isEmpty()) {
            throw new RequestExternalPacketException("EnhanceItemLocal: no target items");
        }

        int enhancementItemId = Integer.parseInt(params[1]);
        ItemBean enhancementItem = StorageCache.getInstance().getItem(enhancementItemId);
        EnhancementBean enhance = StorageCache.getInstance().getEnhancement(enhancementItem.getEnhId());
        if (enhancementItem == null || enhance == null) {
            throw new RequestExternalPacketException("EnhanceItemLocal: invalid enhancement item");
        }

        if (Users.getInstance().turnInItem(user, enhancementItemId, selectedItems.size())) {
            SelectedItem first = selectedItems.get(0);
            eil.put("EnhName", enhance.getName());
            eil.put("EnhPID", enhance.getClientPatternId());
            eil.put("EnhRng", enhancementItem.getClientRange());
            eil.put("EnhRty", enhance.getRarity());
            eil.put("iCost", enhancementItem.getCost() * selectedItems.size());
            eil.put("ProcID", enhance.getProcId());
            eil.put("bSuccess", 1);
            eil.put("EnhDPS", enhance.getDPS());
            eil.put("EnhLvl", enhance.getLevel());
            eil.put("EnhID", enhancementItemId);
            eil.put("cmd", "enhanceItemLocal");
            eil.put("ItemID", first.itemId);
            eil.put("CharItemID", first.charItemId);

            JSONArray itemIds = new JSONArray();
            JSONArray charItemIds = new JSONArray();
            Set<String> changedSlots = new LinkedHashSet<String>();
            for (SelectedItem si : selectedItems) {
                itemIds.add(si.itemId);
                charItemIds.add(si.charItemId);
                Storage.getInstance().getJdbc().run(
                        "UPDATE users_items SET EnhID = ? WHERE ItemID = ? AND UserID = ?",
                        enhancementItem.getEnhId(),
                        si.itemId,
                        user.properties.get(Properties.ID)
                );
                //if(user.properties.get(Properties.ACCESS).equals(80)) {
                    //Kaiden_Extension.getInstance().sendToStaffUser("moderator", "charItemID:"+si.charItemId+" itemId:"+si.itemId+ " enhId:"+enhancementItem.getEnhId(), this.user);
               // }
                ItemBean targetItem = StorageCache.getInstance().getItem(si.itemId);
                if (targetItem != null) {
                    if (!isEnhanceableSlot(targetItem.getEquipment())) {
                        throw new RequestExternalPacketException("This item slot cannot be enhanced: " + targetItem.getEquipment());
                    }
                    changedSlots.add(targetItem.getEquipment());
                }
            }
            eil.put("ItemIDs", itemIds);
            eil.put("CharItemIDs", charItemIds);
            Kaiden_Extension.getInstance().send(eil, user);

            JSONObject delete1 = new JSONObject();
            delete1.put("cmd", "removeItem");
            delete1.put("bitSuccess", 1);
            delete1.put("CharItemID", enhancementItemId);
            if (Users.getInstance().getItemQuantity(user, enhancementItemId) > 1) {
                delete1.put("iQty", 1);
            }
            Kaiden_Extension.getInstance().send(delete1, this.user);

            for (String slot : changedSlots) {
                if (slot == null) continue;
                if (slot.equals("ar") || slot.equals("ba") || slot.equals("he") || slot.equals("Weapon")) {
                    Users.getInstance().updateStats(user, enhance, slot);
                    if (slot.equals("Weapon")) {
                        user.properties.put("weaponitemenhancement", enhance);
                    }
                }
            }
            Users.getInstance().sendStats(user);
        }
    }

    private List<SelectedItem> parseSelectedItems(String raw) {
        List<SelectedItem> out = new ArrayList<SelectedItem>();
        if (raw == null) return out;
        raw = raw.trim();
        if (raw.isEmpty()) return out;

        String[] parts = raw.split(",");
        List<Integer> nums = new ArrayList<Integer>();
        for (String p : parts) {
            if (p == null) continue;
            String s = p.trim();
            if (s.isEmpty()) continue;
            try {
                nums.add(Integer.parseInt(s));
            } catch (Exception ignored) {}
        }
        if (nums.isEmpty()) return out;
        if (nums.size() % 2 == 0) {
            for (int i = 0; i < nums.size(); i += 2) {
                int itemId = nums.get(i);
                int charItemId = nums.get(i + 1);
                if (itemId > 0 && charItemId > 0) out.add(new SelectedItem(itemId, charItemId));
            }
        } else {
            for (Integer itemId : nums) {
                if (itemId != null && itemId > 0) out.add(new SelectedItem(itemId, itemId));
            }
        }
        return out;
    }
}
