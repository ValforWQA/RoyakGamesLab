// ===============================
// EquipItem.java (FULL, updated)
// ===============================
package Kaiden.Game.Server.Packets.External.Item;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.HouseBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.BoostContainer;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.JdbcException;
import jdbchelper.NoResultException;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class EquipItem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int itemId = Integer.parseInt(params[0]);
        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item.isStaff() && !this.user.isAdmin() && !this.user.isModerator()) {
            Users.getInstance().ban(this.user, "Packet Edit [EquipItem]", "Banned for item id exploit.", 120);
            return;
        }

        Storage.getInstance().getJdbc().beginTransaction();

        try {
            QueryResult je = Storage.getInstance().getJdbc().query(
                    "SELECT EnhID, Quantity FROM users_items WHERE ItemID = ? AND UserID = ? FOR UPDATE",
                    itemId,
                    user.properties.get(Properties.ID)
            );

            if (je.next()) {
                int quantity = je.getInt("Quantity");
                EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(je.getInt("EnhID"));

                JSONObject eqp = (JSONObject) user.properties.get("equipment");
                JSONObject eqpObj;

                if (eqp.has(item.getEquipment())) {
                    eqpObj = eqp.getJSONObject(item.getEquipment());
                    int ei = eqpObj.getInt("ItemID");
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_items SET Equipped = 0 WHERE ItemID = ? AND UserID = ?",
                            ei,
                            user.properties.get(Properties.ID)
                    );
                }

                Storage.getInstance().getJdbc().run(
                        "UPDATE users_items SET Equipped = 1 WHERE ItemID = ? AND UserID = ?",
                        itemId,
                        user.properties.get(Properties.ID)
                );

                eqpObj = new JSONObject();

                JSONObject pkt = new JSONObject();
                pkt.put("uid", user.getUserId());
                pkt.put("cmd", "equipItem");
                pkt.put("ItemID", itemId);
                pkt.put("strES", item.getEquipment());
                pkt.put("sFile", item.getFile());
                pkt.put("sLink", item.getLink());
                pkt.put("sMeta", item.getMeta());

                eqpObj.put("ItemID", itemId);
                eqpObj.put("sFile", item.getFile());
                eqpObj.put("sLink", item.getLink());
                pkt.put("sName", item.getName());
                pkt.put("sES", item.getEquipment());
                eqpObj.put("sName", item.getName());
                eqpObj.put("sES", item.getEquipment());
                eqpObj.put("sMeta", item.getMeta());

                if (enhancement != null) {
                    pkt.put("EnhID", enhancement.getId());
                    pkt.put("EnhLvl", enhancement.getLevel());
                    pkt.put("EnhPatternID", enhancement.getClientPatternId());
                    pkt.put("EnhRty", enhancement.getRarity());
                    pkt.put("ProcID", enhancement.getProcId());
                    pkt.put("EnhDPS", enhancement.getDPS());
                    eqpObj.put("EnhID", enhancement.getId());
                    eqpObj.put("EnhLvl", enhancement.getLevel());
                    eqpObj.put("EnhPatternID", enhancement.getClientPatternId());
                    eqpObj.put("EnhRty", enhancement.getRarity());
                    eqpObj.put("ProcID", enhancement.getProcId());
                    eqpObj.put("EnhDPS", enhancement.getDPS());
                }

                pkt.put("iDPS", item.getDPS());
                pkt.put("iRng", item.getClientRange());
                pkt.put("EnhRng", item.getClientRange());
                eqpObj.put("iDPS", item.getDPS());
                eqpObj.put("iRng", item.getClientRange());
                eqpObj.put("EnhRng", item.getClientRange());

                if (item.getEquipment().equals("Weapon")) {
                    pkt.put("sType", item.getType());
                    eqpObj.put("sType", item.getType());
                    user.properties.put("weaponitem", item);
                    user.properties.put("weaponitemenhancement", enhancement);
                }

                // update equipment json first
                eqp.put(item.getEquipment(), eqpObj);

                // ✅ Rebuild boosts from equipment so they never stick (equip/replace safe)
                BoostContainer.getInstance().rebuildFromEquipment(this.user);

                Kaiden_Extension.getInstance().sendToRoom(pkt, user, room);

                if (item.getEquipment().equals("ar") || item.getEquipment().equals("ba") ||
                        item.getEquipment().equals("he") || item.getEquipment().equals("Weapon")) {

                    if (item.getEquipment().equals("ar")) {
                        Users.getInstance().updateClass(user, item, quantity);
                    }

                    Users.getInstance().updateStats(user, enhancement, item.getEquipment());
                    Users.getInstance().sendStats(user);
                }

                if (item.getEquipment().equals("ho")) {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users SET HouseInfo = '' WHERE id = ?",
                            user.properties.get(Properties.ID)
                    );

                    String houseId = "house-" + user.properties.get(Properties.ID);
                    Room house = Kaiden_Extension.getInstance().getZone().getRoomByName(houseId);

                    if (house != null) {
                        HouseBean houseObj = (HouseBean) StorageCache.getInstance().getArea("house-" + user.properties.get(Properties.ID));
                        houseObj.setHouseInfo("");
                        houseObj.setFile(item.getFile());
                        houseObj.setHouseItemId(item.getId());

                        User[] arrUsers = house.getAllUsers();
                        for (User playerInRoom : arrUsers) {
                            Kaiden_Extension.getInstance().send(
                                    new String[]{"server", "Current house is being swapped. You may join in a few minutes."},
                                    playerInRoom
                            );
                            Rooms.getInstance().basicRoomJoin(user, Configuration.DEFAULT_MAP);
                        }
                    }
                }
            }

            je.close();

        } catch (NoResultException | JdbcException e) {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().rollbackTransaction();
            }
            Log.error(this.getClass().getName(), e);

        } finally {
            if (Storage.getInstance().getJdbc().isInTransaction()) {
                Storage.getInstance().getJdbc().commitTransaction();
            }
        }
    }
}