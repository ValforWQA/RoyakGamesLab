package Kaiden.Game.Server.Packets.External.Player;

import Kaiden.Game.Server.Packets.Manager.CommandPacketManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.CommandPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;

public class UserCommand extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        CommandPacketHandler handler = CommandPacketManager.getInstance().get(this.params[0]);
        if (handler != null) {
            if (handler.getClass().getAnnotations().length > 0) {
                CommandHandler command = handler.getClass().getAnnotation(CommandHandler.class);
                if ((command.isAdmin() && this.user.isAdmin()) || (command.isModerator() && this.user.isModerator()) || (command.isVIP() && (int) this.user.properties.get("upgdays") >= 1) || (command.isUser() && (int) this.user.properties.get("access") >= 1)) {
                    handler.user = this.user;
                    handler.params = this.params;
                    handler.handle();
                }
            }
        }
    }
}
