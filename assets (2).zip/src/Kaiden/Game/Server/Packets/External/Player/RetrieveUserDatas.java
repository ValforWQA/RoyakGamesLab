package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Bots.BotSession;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

public class RetrieveUserDatas extends ExternalPacketHandler {
    private static final Logger LOGGER = Logger.getLogger(RetrieveUserDatas.class);
    public void handle() {
        
          JSONObject iud = new JSONObject();
        JSONArray a = new JSONArray();
        for (String userId : this.params) {
            int reqId = Integer.parseInt(userId);
            User client = Kaiden_Extension.getInstance().getHelper().getUserById(reqId);
            if (client != null) {
                boolean addInfo = this.user.getUserId() == reqId;
                JSONObject userInfo = new JSONObject();
                userInfo.put("uid", reqId);
                userInfo.put("strFrame", client.properties.get("frame"));
                userInfo.put("strPad", client.properties.get("pad"));
                userInfo.put("data", Users.getInstance().getUserData(client, addInfo));
                a.add(userInfo);
                continue;
            }
            BotSession bot = BotManager.getInstance().getBotByEntId(reqId);
            if (bot != null) {
                a.add(BotManager.getInstance().getInitUserDatasEntry(bot));
            }
        }
        iud.put("a", a);
        iud.put("cmd", "initUserDatas");
        Kaiden_Extension.getInstance().send(iud, this.user);
    }
}
  


       