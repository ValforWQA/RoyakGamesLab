package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Bots.BotSession;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

public class RetrieveUserData extends ExternalPacketHandler {
    private static final Logger LOGGER = Logger.getLogger(RetrieveUserData.class);
    public void handle() {

        int reqId = Integer.parseInt(this.params[0]);
        User client = Kaiden_Extension.getInstance().getHelper().getUserById(reqId);
        if (client != null) {
            JSONObject data = Users.getInstance().getUserData(client, false);
            if (data != null) {
                JSONObject uid = new JSONObject();
                uid.put("cmd", "initUserData");
                uid.put("data", data);
                uid.put("strFrame", client.properties.get("frame"));
                uid.put("strPad", client.properties.get("pad"));
                uid.put("uid", reqId);
                Kaiden_Extension.getInstance().send(uid, this.user);
            }
            return;
        }

        BotSession bot = BotManager.getInstance().getBotByEntId(reqId);
        if (bot != null) {
            Kaiden_Extension.getInstance().send(BotManager.getInstance().getInitUserDataPacket(bot), this.user);
        }
    }
}
    