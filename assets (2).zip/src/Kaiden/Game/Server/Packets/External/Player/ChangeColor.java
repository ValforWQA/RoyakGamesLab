package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Database.Beans.HairBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;




public class ChangeColor extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        JSONObject cc = new JSONObject();
        int skinColor = Integer.parseInt(params[0]);
        int hairColor = Integer.parseInt(params[1]);
        int eyeColor = Integer.parseInt(params[2]);
        int hairId = Integer.parseInt(params[3]);
        HairBean hair = StorageCache.getInstance().getHair(hairId);
        Storage.getInstance().getJdbc().run("UPDATE users SET ColorSkin = ?, ColorHair = ?, ColorEye = ?, HairID = ? WHERE id = ?", Integer.toHexString(skinColor & 16777215).toUpperCase(), Integer.toHexString(hairColor & 16777215).toUpperCase(), Integer.toHexString(eyeColor & 16777215).toUpperCase(), hairId, user.properties.get(Properties.ID));
        cc.put("uid", user.getUserId());
        cc.put("cmd", "changeColor");
        cc.put("HairID", hairId);
        cc.put("strHairName", hair.getName());
        cc.put("strHairFilename", hair.getFile());
        cc.put("intColorSkin", skinColor);
        cc.put("intColorHair", hairColor);
        cc.put("intColorEye", eyeColor);
        Kaiden_Extension.getInstance().sendToRoomButOne(cc, user, room);
        user.properties.put("hairId", hairId);
        user.properties.put("colorhair", hairColor);
        user.properties.put("colorskin", skinColor);
        user.properties.put("coloreye", eyeColor);
    }
}
