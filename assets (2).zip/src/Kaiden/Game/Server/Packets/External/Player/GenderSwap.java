package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Database.Beans.HairBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;




public class GenderSwap extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        int genderCost = 1000;
        int deltaCoins = (int) this.user.properties.get(Properties.COINS) - genderCost;
        if ((int) this.user.properties.get(Properties.COINS) < genderCost) {
            throw new RequestExternalPacketException("You don't have enough coins!");
        } else {
            if (this.user.properties.get("gender").equals("M")) {
                this.changeGender(StorageCache.getInstance().getHair(16), "F", genderCost, deltaCoins);
            } else {
                this.changeGender(StorageCache.getInstance().getHair(52), "M", genderCost, deltaCoins);
            }
        }
    }

    private void changeGender(HairBean hair, String gender, int cost, int coins) {
        JSONObject genderSwap = new JSONObject();
        genderSwap.put("gender", gender);
        genderSwap.put("HairID", hair.getId());
        genderSwap.put("strHairName", hair.getName());
        genderSwap.put("strHairFilename", hair.getFile());
        genderSwap.put("uid", this.user.getUserId());
        genderSwap.put("cmd", "genderSwap");
        genderSwap.put("bitSuccess", 1);
        genderSwap.put("intCoins", cost);
        Kaiden_Extension.getInstance().sendToRoom(genderSwap, this.user, this.room);
        this.user.properties.put("hairId", hair.getId());
        this.user.properties.put("gender", gender);
        this.user.properties.replace(Properties.COINS, coins);
        Storage.getInstance().getJdbc().run("UPDATE users SET Gender = ?, HairID = ? WHERE id = ?", gender, hair.getId(), user.properties.get(Properties.ID));
    }
}