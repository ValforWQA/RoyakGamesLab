package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;




public class Afk extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        boolean afk = Boolean.parseBoolean(params[0]);
        if (afk != (Boolean) user.properties.get("afk")) {
            if (!afk) {
                Kaiden_Extension.getInstance().send(new String[]{"server", "You are no longer Away From Keyboard (AFK)."}, user);
            } else {
                Kaiden_Extension.getInstance().send(new String[]{"server", "You are now Away From Keyboard (AFK)."}, user);
            }

            user.properties.put("afk", afk);
            Kaiden_Extension.getInstance().send(new String[]{"uotls", user.getName(), "afk:" + Boolean.valueOf(params[0])}, room.getChannellList());
        }

    }
}
