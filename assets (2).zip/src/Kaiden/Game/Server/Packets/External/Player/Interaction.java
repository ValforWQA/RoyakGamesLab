package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.Random;

public class Interaction extends ExternalPacketHandler {
    
        public void handle() throws RequestExternalPacketException {
        JSONObject ia = new JSONObject();
        ia.put("iAccessLevel", this.user.properties.get("access"));
        ia.put("cmd", "ia");
        ia.put("oName", this.params[1]);
        ia.put("typ", this.params[0]);
        ia.put("iUpgDays", 0);
        ia.put("unm", this.user.getName());
        if (this.params[0].equals("rval")) {
            ia.put("val", new Random().nextInt(9000));
        } else if (this.params[0].equals("str")) {
            if (this.params[2].equals("aaaa")) {
                String username = params[3].toLowerCase();
                User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
                if (client == null) {
                    throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
                }
                Rooms.getInstance().basicRoomJoin(client, Configuration.DEFAULT_MAP);
            }
            ia.put("val", this.params[2]);
        }
        Kaiden_Extension.getInstance().sendToRoom(ia, user, room);
    }
}
