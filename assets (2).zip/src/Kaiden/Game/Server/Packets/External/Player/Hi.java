package Kaiden.Game.Server.Packets.External.Player;

import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;

public class Hi extends ExternalPacketHandler {
    public void handle() {
        Kaiden_Extension.getInstance().send(new String[] { "hi" }, user.getChannel());
        
    }
}
