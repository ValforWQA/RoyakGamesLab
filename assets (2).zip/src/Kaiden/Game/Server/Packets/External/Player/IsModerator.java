package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public class IsModerator extends ExternalPacketHandler {
    
        public void handle() {
        String username = params[0].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client != null) {
            JSONObject isModerator = new JSONObject();
            isModerator.put("cmd", "isModerator");
            isModerator.put("val", client.isAdmin() || client.isModerator());
            isModerator.put("unm", client.properties.get(Properties.USERNAME));
            Kaiden_Extension.getInstance().send(isModerator, this.user);
        }
    }
}
