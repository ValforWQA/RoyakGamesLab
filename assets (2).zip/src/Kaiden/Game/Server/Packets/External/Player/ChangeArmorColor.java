package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;




public class ChangeArmorColor extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        int base = Integer.parseInt(params[0]);
        int trim = Integer.parseInt(params[1]);
        int accessory = Integer.parseInt(params[2]);
        Storage.getInstance().getJdbc().run("UPDATE users SET ColorBase = ?, ColorAccessory = ?, ColorTrim = ? WHERE id = ?", Integer.toHexString(base & 16777215).toUpperCase(), Integer.toHexString(accessory & 16777215).toUpperCase(), Integer.toHexString(trim & 16777215).toUpperCase(), user.properties.get(Properties.ID));
        JSONObject cac = new JSONObject();
        cac.put("uid", user.getUserId());
        cac.put("cmd", "changeArmorColor");
        cac.put("intColorBase", base);
        cac.put("intColorTrim", trim);
        cac.put("intColorAccessory", accessory);
        Kaiden_Extension.getInstance().sendToRoomButOne(cac, user, room);
        user.properties.put("colortrim", trim);
        user.properties.put("colorbase", base);
        user.properties.put("coloraccessory", accessory);
    }
}
