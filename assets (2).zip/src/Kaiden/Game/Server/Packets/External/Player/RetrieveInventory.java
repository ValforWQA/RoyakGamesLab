package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.EnhancementPatternBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.SpanUtils;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;




public class RetrieveInventory extends ExternalPacketHandler{

    public void handle() {
   
JSONArray hitems = new JSONArray();
        JSONArray items = new JSONArray();
        JSONObject eqp = new JSONObject();
        ConcurrentHashMap<Integer, UserItem> inventoryItems = (ConcurrentHashMap) this.user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) this.user.properties.get(Properties.BANK_ITEMS);
        //Properties.updateLastLogin(this.user);
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM users_items WHERE UserID = ?", user.properties.get(Properties.ID));
        while (result.next()) {
            int charItemId = result.getInt("id");
            int quantity = result.getInt("Quantity");
            int itemId = result.getInt("ItemID");
            int enhId = result.getInt("EnhID");
            boolean equipped = result.getBoolean("Equipped");
            ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
            EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(enhId);
            JSONObject item = itemObj.getItemJSON(enhancement);
            item.put("bBank", result.getInt("Bank"));
            item.put("CharItemID", charItemId);
            item.put("iQty", quantity);
            if (itemObj.isCoins()) {
                Date date = new Date();
                item.put("iHrs", SpanUtils.millisToHours(result.getDate("DatePurchased").getTime() - date.getTime()));
                item.put("dPurchase", result.getString("DatePurchased").replaceAll(" ", "T"));
            }

            if (equipped) {
                item.put("bEquip", result.getString("Equipped"));
                JSONObject eqpObj1 = new JSONObject();
                eqpObj1.put("ItemID", itemId);
                eqpObj1.put("sFile", itemObj.getFile());
                eqpObj1.put("sLink", itemObj.getLink());
                eqpObj1.put("sMeta", itemObj.getMeta());
                eqpObj1.put("sName", itemObj.getName());
                eqpObj1.put("sES", itemObj.getEquipment());
                eqpObj1.put("iDPS", itemObj.getDPS());
                eqpObj1.put("iRng", itemObj.getClientRange());
                eqpObj1.put("EnhRng", itemObj.getClientRange());
                JSONObject ei1 = new JSONObject();
                ei1.put("uid", user.getUserId());
                ei1.put("cmd", "equipItem");
                ei1.put("ItemID", itemId);
                ei1.put("strES", itemObj.getEquipment());
                ei1.put("sFile", itemObj.getFile());
                ei1.put("sLink", itemObj.getLink());
                ei1.put("sMeta", itemObj.getMeta());
                ei1.put("sName", itemObj.getName());
                ei1.put("sES", itemObj.getEquipment());
                ei1.put("iDPS", itemObj.getDPS());
                ei1.put("iRng", itemObj.getClientRange());
                ei1.put("EnhRng", itemObj.getClientRange());
                if (enhancement != null) {
                    eqpObj1.put("EnhID", enhancement.getId());
                    eqpObj1.put("EnhLvl", enhancement.getLevel());
                    eqpObj1.put("EnhPatternID", enhancement.getClientPatternId());
                    eqpObj1.put("EnhRty", enhancement.getRarity());
                    eqpObj1.put("ProcID", enhancement.getProcId());
                    eqpObj1.put("EnhDPS", enhancement.getDPS());
                    ei1.put("EnhID", enhancement.getId());
                    ei1.put("EnhLvl", enhancement.getLevel());
                    ei1.put("EnhPatternID", enhancement.getClientPatternId());
                    ei1.put("EnhRty", enhancement.getRarity());
                    ei1.put("ProcID", enhancement.getProcId());
                    ei1.put("EnhDPS", enhancement.getDPS());
                }
                if (itemObj.getEquipment().equals("Weapon")) {
                    eqpObj1.put("sType", itemObj.getType());
                    ei1.put("sType", itemObj.getType());
                    user.properties.put("weaponitem", itemObj);
                    if (enhancement != null) {
                        user.properties.put("weaponitemenhancement", enhancement);
                    }
                }

                if (!eqp.has(itemObj.getEquipment())) {
                    Kaiden_Extension.getInstance().sendToRoom(ei1, user, room);
                    if (itemObj.getEquipment().equals("ar") || itemObj.getEquipment().equals("ba") || itemObj.getEquipment().equals("he") || itemObj.getEquipment().equals("Weapon")) {
                        if (itemObj.getEquipment().equals("ar")) {
                            Users.getInstance().updateClass(user, itemObj, quantity);
                        }

                       Users.getInstance().updateStats(user, enhancement, itemObj.getEquipment());
                    }

                    eqp.put(itemObj.getEquipment(), eqpObj1);
                }
            }

            if (result.getInt("Bank") == 0) {
                if (!itemObj.getEquipment().equals("ho") && !itemObj.getEquipment().equals("hi")) {
                    inventoryItems.put(itemObj.getId(), new UserItem(result));
                    items.add(item);
                } else {
                    hitems.add(item);
                }
            } else {
                bankItems.put(itemObj.getId(), new UserItem(result));
            }
        }
        result.close();
        user.properties.put("equipment", eqp);
        this.sendEnhancementPatterns(user);
        JSONObject lib = new JSONObject();
        lib.put("bankCount", Users.getInstance().getBankCount(user));
        lib.put("cmd", "loadInventoryBig");
        lib.put("items", items);
        lib.put("hitems", hitems);
        lib.put("factions", this.getFactions(user));
        if ((Integer) user.properties.get("guildid") > 0) {
            lib.put("guild", user.properties.get("guildobj"));
        }

        Kaiden_Extension.getInstance().send(lib, user);
        JSONObject updateFriend = new JSONObject();
        JSONObject friendInfo = new JSONObject();
        updateFriend.put("cmd", "updateFriend");
        friendInfo.put("iLvl", user.properties.get(Properties.LEVEL));
        friendInfo.put("ID", user.properties.get(Properties.ID));
        friendInfo.put("sName", user.properties.get(Properties.USERNAME));
        friendInfo.put("sServer", Configuration.SERVER_NAME);
        updateFriend.put("friend", friendInfo);
        QueryResult friends = Storage.getInstance().getJdbc().query("SELECT Name FROM users LEFT JOIN users_friends ON FriendID = id WHERE UserID = ?", user.properties.get(Properties.ID));
        while (friends.next()) {
            User userOnline = Kaiden_Extension.getInstance().getZone().getUserByName(friends.getString("Name").toLowerCase());
            if (userOnline != null) {
                Kaiden_Extension.getInstance().send(updateFriend, userOnline);
                Kaiden_Extension.getInstance().send(new String[]{"server", user.getName() + " has logged in."}, userOnline);
            }
        }
        friends.close();
        int guildId1 = (Integer) user.properties.get("guildid");
        if (guildId1 > 0) {
           Kaiden_Extension.getInstance().sendGuildUpdate(Users.getInstance().getGuildObject(guildId1));
        }



        this.retrieveLoadouts(this.user);
        this.retrieveBoosts(this.user);
        Users.getInstance().sendStats(user);
    }

    private JSONArray getFactions(User user) {
        JSONArray factions = new JSONArray();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM users_factions WHERE UserID = ?", user.properties.get(Properties.ID));

        while (result.next()) {
            JSONObject faction = new JSONObject();
            faction.put("FactionID", result.getString("FactionID"));
            faction.put("CharFactionID", result.getString("id"));
            faction.put("sName", StorageCache.getInstance().getFaction(result.getInt("FactionID")));
            faction.put("iRep", result.getInt("Reputation"));
            factions.add(faction);
        }

        result.close();
        return factions;
    }

    private void sendEnhancementPatterns(User user) {
        JSONObject enhp = new JSONObject();
        JSONObject o = new JSONObject();

        for (EnhancementPatternBean ep : StorageCache.getInstance().getEnhancementPatterns()) {
            JSONObject pattern = new JSONObject();
            Map<String, Double> stats = ep.getStats();
            pattern.put("ID", String.valueOf(ep.getId()));
            pattern.put("sName", ep.getName());
            pattern.put("sDesc", ep.getDescription());
            pattern.put("iWIS", String.valueOf(stats.get("WIS")));
            pattern.put("iEND", String.valueOf(stats.get("END")));
            pattern.put("iLCK", String.valueOf(stats.get("LCK")));
            pattern.put("iSTR", String.valueOf(stats.get("STR")));
            pattern.put("iDEX", String.valueOf(stats.get("DEX")));
            pattern.put("iINT", String.valueOf(stats.get("INT")));
            o.put(String.valueOf(ep.getId()), pattern);
        }

        enhp.put("cmd", "enhp");
        enhp.put("o", o);
        Kaiden_Extension.getInstance().send(enhp, user);
    }

    private void retrieveLoadouts(User user) {
        JSONObject o = new JSONObject();
        JSONObject resultObj = new JSONObject();
        JSONObject loadOutObj = new JSONObject();
        JSONObject wearEquipment = new JSONObject();

        Object wearObj = user.properties.get(Properties.WEAR_EQUIPMENT);
        if (wearObj instanceof JSONObject) {
            wearEquipment = (JSONObject) wearObj;
        }

        QueryResult costumes = Storage.getInstance().getJdbc().query(
                "SELECT ItemID FROM users_items WHERE UserID = ? AND Wear = 1 AND Bank = 0",
                user.properties.get(Properties.ID)
        );

        while (costumes.next()) {
            int itemId = costumes.getInt("ItemID");
            ItemBean item = StorageCache.getInstance().getItem(itemId);

            if (item == null) continue;

            JSONObject itemObj = new JSONObject();
            itemObj.put("ItemID", itemId);
            itemObj.put("sFile", item.getFile());
            itemObj.put("sLink", item.getLink());
            itemObj.put("iRty", item.getRarity());
            itemObj.put("sType", item.getType());

            wearEquipment.put(item.getEquipment(), itemObj);
        }
        costumes.close();

        QueryResult loadOuts = Storage.getInstance().getJdbc().query(
                "SELECT * FROM users_outfits WHERE UserID = ?",
                user.properties.get(Properties.ID)
        );

        while (loadOuts.next()) {
            JSONObject loadOutData = new JSONObject();

            String name = loadOuts.getString("Name");
            String equipments = loadOuts.getString("Equipments");
            String colorAccessory = safe(loadOuts.getString("ColorAccessory"));
            String colorBase = safe(loadOuts.getString("ColorBase"));
            String colorTrim = safe(loadOuts.getString("ColorTrim"));
            String colorHair = safe(loadOuts.getString("ColorHair"));
            String colorSkin = safe(loadOuts.getString("ColorSkin"));
            String colorEye = safe(loadOuts.getString("ColorEye"));

            if (equipments != null && !equipments.trim().isEmpty()) {
                String[] equipmentArr = equipments.split(",");

                for (String equipment : equipmentArr) {
                    if (equipment == null || equipment.trim().isEmpty()) continue;

                    int itemId;
                    try {
                        itemId = Integer.parseInt(equipment.trim());
                    } catch (Exception ignored) {
                        continue;
                    }

                    ItemBean item = StorageCache.getInstance().getItem(itemId);
                    if (item == null) continue;

                    loadOutData.put(item.getEquipment(), item.getId());
                }
            }

            JSONObject colorObj = new JSONObject();
            colorObj.put("accessory", parseColor(colorAccessory));
            colorObj.put("base", parseColor(colorBase));
            colorObj.put("trim", parseColor(colorTrim));
            colorObj.put("hair", parseColor(colorHair));
            colorObj.put("skin", parseColor(colorSkin));
            colorObj.put("eye", parseColor(colorEye));

            loadOutData.put("colors", colorObj);
            loadOutObj.put(name, loadOutData);
        }

        loadOuts.close();

        resultObj.put("costumes", wearEquipment);
        resultObj.put("loadouts", loadOutObj);
        resultObj.put("prefs", new JSONObject());

        o.put("cmd", "loadPrefs");
        o.put("success", true);
        o.put("result", resultObj);

        Kaiden_Extension.getInstance().send(o, user);
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private int parseColor(String value) {
        if (value == null || value.trim().isEmpty()) return 0;

        String v = value.trim();

        try {
            if (v.startsWith("#")) {
                return Integer.parseInt(v.substring(1), 16);
            }
            if (v.startsWith("0x") || v.startsWith("0X")) {
                return Integer.parseInt(v.substring(2), 16);
            }
            return Integer.parseInt(v);
        } catch (Exception e) {
            return 0;
        }
    }

    private void retrieveBoosts(User user) {
        QueryResult boosts = null;
        try {
            boosts = Storage.getInstance().getJdbc().query(
                    "SELECT " +
                            "TIMESTAMPDIFF(SECOND, NOW(), ExpBoostExpire) AS ExpSecsLeft, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), CpBoostExpire) AS CpSecsLeft, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), RepBoostExpire) AS RepSecsLeft, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), GoldBoostExpire) AS GoldSecsLeft " +
                            "FROM users WHERE id = ?",
                    user.properties.get(Properties.ID)
            );

            if (boosts.next()) {
                sendBoostIfActive("xpboost", "xpboost", boosts.getInt("ExpSecsLeft"));
                sendBoostIfActive("cpboost", "cpboost", boosts.getInt("CpSecsLeft"));
                sendBoostIfActive("repboost", "repboost", boosts.getInt("RepSecsLeft"));
                sendBoostIfActive("gboost", "goldboost", boosts.getInt("GoldSecsLeft"));
            }
        } finally {
            try {
                if (boosts != null) {
                    boosts.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private void sendBoostIfActive(String clientCmd, String propertyKey, int secondsLeft) {
        if (secondsLeft <= 0) {
            this.user.properties.put(propertyKey, Boolean.FALSE);
            return;
        }

        JSONObject boost = new JSONObject();
        boost.put("cmd", clientCmd);
        boost.put("bShowShop", false);
        boost.put("op", "+");
        addBoostPacketFields(boost, clientCmd, secondsLeft);

        Kaiden_Extension.getInstance().send(boost, this.user);
        this.user.properties.put(propertyKey, Boolean.TRUE);
    }

    private void addBoostPacketFields(JSONObject boost, String clientCmd, int secondsLeft) {
        if (secondsLeft < 0) {
            secondsLeft = 0;
        }

        boost.put("iSecsLeft", secondsLeft);
        boost.put("boostTS", System.currentTimeMillis());

        if ("xpboost".equals(clientCmd)) {
            boost.put("iBoostXP", secondsLeft);
        } else if ("gboost".equals(clientCmd)) {
            boost.put("iBoostG", secondsLeft);
        } else if ("cpboost".equals(clientCmd)) {
            boost.put("iBoostCP", secondsLeft);
        } else if ("repboost".equals(clientCmd)) {
            boost.put("iBoostRep", secondsLeft);
        }
    }
}
