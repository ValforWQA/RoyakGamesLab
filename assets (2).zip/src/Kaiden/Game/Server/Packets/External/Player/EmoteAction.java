package Kaiden.Game.Server.Packets.External.Player;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;

public class EmoteAction extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        Kaiden_Extension.getInstance().sendToRoomButOne(new String[]{"emotea", params[0], Integer.toString(user.getUserId())}, user, room);
    }
}
