package Kaiden.Game.Server.Packets.External.Friend;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;


public class DeleteFriend extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String friendName = this.params[1].toLowerCase();
        int friendId = Storage.getInstance().getJdbc().queryForInt("SELECT id FROM users WHERE Name = ?", friendName);
        this.deleteFriend((Integer) this.user.properties.get(Properties.ID), friendId);
        this.deleteFriend(friendId, (Integer) this.user.properties.get(Properties.ID));
        JSONObject deleteFriend = new JSONObject();
        deleteFriend.put("cmd", "deleteFriend");
        deleteFriend.put("ID", friendId);
        Kaiden_Extension.getInstance().send(deleteFriend, this.user);
        User user = Kaiden_Extension.getInstance().getZone().getUserByName(friendName);
        if (user != null) {
            deleteFriend.put("ID", this.user.properties.get(Properties.ID));
            Kaiden_Extension.getInstance().send(deleteFriend, user);
        }
    }

    private void deleteFriend(int fromUser, int deleteId) {
        Storage.getInstance().getJdbc().run("DELETE FROM users_friends WHERE UserID = ? AND FriendID = ?", fromUser, deleteId);
    }
}
