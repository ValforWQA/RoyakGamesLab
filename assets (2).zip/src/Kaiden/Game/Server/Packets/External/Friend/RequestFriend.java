package Kaiden.Game.Server.Packets.External.Friend;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Iterator;
import java.util.Set;

public class RequestFriend extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String username = this.params[0].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client == null) {
            throw new RequestExternalPacketException("Player \"" + username + "\" could not be found.");
        } else {
            if (!Settings.isAllowed(Settings.FRIEND, this.user, client)) {
                throw new RequestExternalPacketException(client.getName() + " is not accepting friend requests.");
            } else if (((State) client.properties.get("state")).onCombat()) {
                throw new RequestExternalPacketException(client.getName() + " is currently busy.");
            } else {
                Set<Integer> requestedFriends = (Set) client.properties.get("requestedfriend");
                requestedFriends.add(this.user.getUserId());
                JSONArray friends = Users.getInstance().getFriends(this.user);
                Iterator friendRequest = friends.iterator();
                JSONObject friend;
                do {
                    if (!friendRequest.hasNext()) {
                        JSONObject friendRequest1 = new JSONObject();
                        friendRequest1.put("cmd", "requestFriend");
                        friendRequest1.put("unm", this.user.properties.get(Properties.USERNAME));
                        Kaiden_Extension.getInstance().send(friendRequest1, client);
                        Kaiden_Extension.getInstance().send(new String[]{"server", "You have requested " + client.getName() + " to be friends."}, this.user);
                        return;
                    }

                    Object o = friendRequest.next();
                    friend = (JSONObject) o;
                } while (!friend.containsValue(client.properties.get(Properties.USERNAME)));

                throw new RequestExternalPacketException(client.getName() + " was already added to your friends list.");
            }
        }
    }
}
