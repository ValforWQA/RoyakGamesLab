package Kaiden.Game.Server.Packets.External.Friend;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

public class DeclineFriend extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        String username = this.params[0].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client != null) {
            Kaiden_Extension.getInstance().send(new String[]{"server", user.getName() + " declined your friend request."}, client);
        }
    }
}