package Kaiden.Game.Server.Packets.External.Friend;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;


public class GetFriendList extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        JSONObject friends = new JSONObject();
        friends.put("cmd", "friends");
        friends.put("friends", Users.getInstance().getFriends(user));
        Kaiden_Extension.getInstance().send(friends, user);
    }
}
