package Kaiden.Game.Server.Packets.External.Friend;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.Set;

public class AddFriend extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        String username = this.params[0].toLowerCase();
        User client = Kaiden_Extension.getInstance().getZone().getUserByName(username);
        if (client != null) {
            Set<Integer> userRequestedFriends = (Set) this.user.properties.get("requestedfriend");
            if (userRequestedFriends.contains(client.getUserId())) {
                userRequestedFriends.remove(client.getUserId());
                this.addFriend(this.user, client);
                this.addFriend(client, this.user);
            } else {
                Users.getInstance().log(this.user, "Packet Edit [AddFriend]", "Forcing add friend.");
                Users.getInstance().kick(this.user, "Forcing add friend.");
            }
        }
    }

    private void addFriend(User userObj1, User userObj2) throws RequestExternalPacketException {
        int userID1 = (Integer) userObj1.properties.get(Properties.ID);
        int userID2 = (Integer) userObj2.properties.get(Properties.ID);
        JSONObject addFriend = new JSONObject();
        addFriend.put("cmd", "addFriend");
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM users_friends WHERE UserID = ? AND FriendID = ?", userID1, userID2);
        if (result.next()) {
            result.close();
            throw new RequestExternalPacketException(userObj2.getName() + " was already added to your friends list.");
        } else {
            result.close();
            Storage.getInstance().getJdbc().run("INSERT INTO users_friends (UserID, FriendID) VALUES (?, ?)", userID1, userID2);
            JSONObject friendInfo = new JSONObject();
            friendInfo.put("iLvl", userObj2.properties.get(Properties.LEVEL));
            friendInfo.put("ID", userObj2.properties.get(Properties.ID));
            friendInfo.put("sName", userObj2.properties.get(Properties.USERNAME));
            friendInfo.put("sServer", Configuration.SERVER_NAME);
            addFriend.put("friend", friendInfo);
            Kaiden_Extension.getInstance().send(addFriend, userObj1);
            Kaiden_Extension.getInstance().send(new String[]{"server", userObj2.getName() + " has been added to your friends list."}, userObj1);
        }
    }
}
