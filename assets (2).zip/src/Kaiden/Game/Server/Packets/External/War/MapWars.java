package Kaiden.Game.Server.Packets.External.War;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

/** AQW loadWarVars accepts an empty argument list and returns all required war keys. */
public class MapWars extends ExternalPacketHandler {
    @Override
    public void handle() throws RequestExternalPacketException {
        // With no ID, return every configured war variable in one response.
        // Explicit IDs still return only the requested war.
        int requestedWarId = 0;
        if (params != null && params.length > 0 && params[0] != null && !params[0].trim().isEmpty()) {
            try { requestedWarId = Integer.parseInt(params[0].trim()); }
            catch (NumberFormatException ignored) { return; }
            if (requestedWarId <= 0) return;
        }
        QueryResult result = requestedWarId == 0
            ? Storage.getInstance().getJdbc().query("SELECT id, Name, Points, MaxPoints FROM wars ORDER BY id")
            : Storage.getInstance().getJdbc().query("SELECT id, Name, Points, MaxPoints FROM wars WHERE id=?", requestedWarId);
        try {
            JSONObject packet = new JSONObject();
            packet.put("cmd", "loadWarVars");
            boolean found = false;
            while (result.next()) {
                found = true;
                int id = result.getInt("id");
                int points = result.getInt("Points");
                int maximum = result.getInt("MaxPoints");
                packet.put("intWar" + id, points);
                packet.put("intWarTotal" + id, maximum);
                // Retain legacy single-war fields for old SWF handlers.
                if (requestedWarId != 0 || !packet.containsKey("id")) {
                    packet.put("id", result.getString("id"));
                    packet.put("Name", result.getString("Name"));
                    packet.put("Points", points);
                    packet.put("TotalPoints", maximum);
                    packet.put("intWarTotal", maximum);
                }
            }
            if (found) Kaiden_Extension.getInstance().send(packet, user);
        } finally { result.close(); }
    }
}
