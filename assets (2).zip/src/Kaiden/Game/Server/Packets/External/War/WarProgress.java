package Kaiden.Game.Server.Packets.External.War;

import Kaiden.Database.Storage;
import Kaiden.Kaiden_Engine;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public final class WarProgress {
    private WarProgress() {}

    /** Resolve all enabled war mappings for this completed quest from the database. */
    public static synchronized void contributeForQuest(int questId, int userId, int completedCount) {
        if (questId <= 0 || completedCount <= 0) return;
        QueryResult mappings = null;
        java.util.List<Integer> warIds = new java.util.ArrayList<Integer>();
        try {
            mappings = Storage.getInstance().getJdbc().query(
                "SELECT DISTINCT w.id AS WarID FROM wars w " +
                "INNER JOIN war_quests q ON q.WarID=w.id " +
                "WHERE q.QuestID=? AND q.Enabled=1 AND q.PointsPerTurnIn>0", questId);
            while (mappings.next()) warIds.add(mappings.getInt("WarID"));
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[WarProgress] Quest mapping: " + e.getMessage());
            return;
        } finally {
            if (mappings != null) mappings.close();
        }
        for (Integer warId : warIds) contribute(warId, questId, userId, completedCount);
    }

    public static synchronized JSONObject contribute(int warId, int questId, int userId, int completedCount) {
        if (warId <= 0 || completedCount <= 0) return null;
        QueryResult config = null;
        try {
            config = Storage.getInstance().getJdbc().query(
                "SELECT PointsPerTurnIn, Enabled FROM war_quests WHERE WarID=? AND QuestID=?", warId, questId);
            if (!config.next() || config.getInt("Enabled") != 1) return null;
            int perTurn = config.getInt("PointsPerTurnIn");
            if (perTurn <= 0) return null;
            config.close(); config = null;
            long contribution = (long) perTurn * completedCount;
            Storage.getInstance().getJdbc().execute(
                "UPDATE wars SET Points=LEAST(MaxPoints, Points+?) WHERE id=? AND Points<MaxPoints",
                contribution, warId);
            QueryResult result = Storage.getInstance().getJdbc().query(
                "SELECT id, Name, Points, MaxPoints FROM wars WHERE id=?", warId);
            try {
                if (!result.next()) return null;
                JSONObject packet = new JSONObject();
                packet.put("cmd", "loadWarVars");
                packet.put("id", result.getString("id"));
                packet.put("Name", result.getString("Name"));
                packet.put("Points", result.getInt("Points"));
                packet.put("TotalPoints", result.getInt("MaxPoints"));
                packet.put("intWar" + warId, result.getInt("Points"));
                packet.put("intWarTotal", result.getInt("MaxPoints"));
                return packet;
            } finally { result.close(); }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[WarProgress] " + e.getMessage());
            return null;
        } finally { if (config != null) config.close(); }
    }
}
