package Kaiden.Game.Server.Packets.External.Wear;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import jdbchelper.JdbcException;
import net.sf.json.JSONObject;

public class UnwearItem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
        String equipment = params[0];

        JSONObject wearEquipment = (JSONObject) user.properties.get("");
        JSONObject unwearObj = new JSONObject();

        unwearObj.put("cmd", "unwearItem");
        unwearObj.put("uid", user.getUserId());

        if(wearEquipment == null || !wearEquipment.has(equipment))
        {
            unwearObj.put("success", false);
            unwearObj.put("msg", "This item is not worn.");
            Kaiden_Extension.getInstance().send(unwearObj, user);
            return;
        }

        JSONObject itemO = wearEquipment.getJSONObject(equipment);
        ItemBean item = StorageCache.getInstance().getItem(itemO.getInt("ItemID"));

        if (item == null)
        {
            unwearObj.put("success", false);
            unwearObj.put("msg", "Item does not exist!");
            Kaiden_Extension.getInstance().send(unwearObj, user);
            return;
        }

        String sEs = item.getEquipment();
        String type = item.getType();
        String file = item.getFile();
        String link = item.getLink();

        JSONObject eqp = (JSONObject) user.properties.get("equipment");

        if (eqp.has(equipment))
        {
            JSONObject oldItem = eqp.getJSONObject(equipment);
            ItemBean itemO2 = StorageCache.getInstance().getItem(oldItem.getInt("ItemID"));
            sEs = itemO2.getEquipment();
            type = itemO2.getType();
            file = itemO2.getFile();
            link = itemO2.getLink();
        }

        unwearObj.put("ItemID", itemO.getInt("ItemID"));
        unwearObj.put("sES", sEs);
        unwearObj.put("sFile", file);
        unwearObj.put("sLink", link);
        unwearObj.put("sType", type);
        unwearObj.put("success", true);

        if (!eqp.has(equipment))
        {
            unwearObj.put("bRemove", false);
        }

        Storage.getInstance().getJdbc().beginTransaction();
        try {
            wearEquipment.remove(equipment);
            Storage.getInstance().getJdbc().run("UPDATE users_items SET Wear = 0 WHERE ItemID = ? AND UserID = ?", item.getId(), user.properties.get(Properties.ID));
           EnhancementBean enh = StorageCache.getInstance().getEnhancement(item.getEnhId());
            JSONObject itemObj = item.getItemJSON(enh);
                    //Item.getItemJSON(item, null);
            itemObj.put("bWear", 0);
            Kaiden_Extension.getInstance().sendToRoom(unwearObj, user, room);

            Storage.getInstance().getJdbc().commitTransaction();
        } catch (JdbcException jdbcException) {
            if (Storage.getInstance().getJdbc().isInTransaction())
                Storage.getInstance().getJdbc().rollbackTransaction();
        }
    }

}
