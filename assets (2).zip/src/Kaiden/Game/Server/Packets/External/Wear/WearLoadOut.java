package Kaiden.Game.Server.Packets.External.Wear;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.External.Player.ChangeArmorColor;
import Kaiden.Game.Server.Packets.External.Player.ChangeColor;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class WearLoadOut extends ExternalPacketHandler {
    public void handle() throws RequestExternalPacketException {
        String name = params[1];
        int keepColor = Integer.parseInt(params[2]);
        JSONObject wearObj = new JSONObject();
        JSONObject costumeObj = new JSONObject();
        wearObj.put("cmd", "wearLoadout");
        wearObj.put("uid", user.getUserId());
        wearObj.put("success", true);
        QueryResult outfit = Storage.getInstance().getJdbc().query("SELECT * FROM users_outfits WHERE Name = ? AND UserID = ?", name, user.properties.get(Properties.ID));
        if (!outfit.next()) {
            wearObj.put("success", false);
            Kaiden_Extension.getInstance().send(wearObj, user);
            return;
        }
        String[] equipments = outfit.getString("Equipments").split(",");
        String colorAccessory = outfit.getString("ColorAccessory");
        String colorBase = outfit.getString("ColorBase");
        String colorTrim = outfit.getString("ColorTrim");
        String colorHair = outfit.getString("ColorHair");
        String colorSkin = outfit.getString("ColorSkin");
        String colorEye = outfit.getString("ColorEye");
        outfit.close();
        for (String eq : equipments) {
            if (eq == null || eq.trim().isEmpty()) continue;
            int itemId = Integer.parseInt(eq.trim());
            ItemBean item = StorageCache.getInstance().getItem(itemId);
            if (item == null) continue;
            JSONObject itemObj = new JSONObject();
            itemObj.put("ItemID", itemId);
            itemObj.put("sFile", item.getFile());
            itemObj.put("sLink", item.getLink());
            itemObj.put("iRty", item.getRarity());
            itemObj.put("sType", item.getType());
            costumeObj.put(item.getEquipment(), itemObj);
        }
        wearObj.put("costume", costumeObj);
        Kaiden_Extension.getInstance().sendToRoom(wearObj, user, room);
        if (keepColor == 1) {
            ChangeColor color = new ChangeColor();
            color.user = user; color.room = room;
            color.params = new String[]{colorSkin,colorHair,colorEye,String.valueOf(user.properties.get("HairID"))};
            color.handle();
            ChangeArmorColor armor = new ChangeArmorColor();
            armor.user = user; armor.room = room;
            armor.params = new String[]{colorBase,colorTrim,colorAccessory};
            armor.handle();
        }
    }
}
