package Kaiden.Game.Server.Packets.External.Wear;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;

public class WearItem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        
         int itemId = Integer.parseInt(params[0]);
        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item.isStaff() && !this.user.isAdmin() && !this.user.isModerator()) {
            Users.getInstance().ban(this.user, "Packet Edit [EquipItem]", "Banned for item id exploit.", 120);
            return;
        }
        EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(item.getEnhId());
        JSONObject eqp = (JSONObject) user.properties.get("equipment");
        JSONObject eqpObj;
         //Storage.getInstance().getJdbc().run("UPDATE users_items SET Equipped = 1 WHERE ItemID = ? AND UserID = ?", itemId, user.properties.get(Properties.ID));
                eqpObj = new JSONObject();
                JSONObject var28 = new JSONObject();
                var28.put("uid", user.getUserId());
                var28.put("cmd", "equipItem");
                var28.put("ItemID", itemId);
                var28.put("strES", item.getEquipment());
                var28.put("sFile", item.getFile());
                var28.put("sLink", item.getLink());
                var28.put("sMeta", item.getMeta());
                eqpObj.put("ItemID", itemId);
                eqpObj.put("sFile", item.getFile());
                eqpObj.put("sLink", item.getLink());
                var28.put("sName", item.getName());
                var28.put("sES", item.getEquipment());
                eqpObj.put("sName", item.getName());
                eqpObj.put("sES", item.getEquipment());
                eqpObj.put("sMeta", item.getMeta());
                if (enhancement != null) {
                    var28.put("EnhID", enhancement.getId());
                    var28.put("EnhLvl", enhancement.getLevel());
                    var28.put("EnhPatternID", enhancement.getClientPatternId());
                    var28.put("EnhRty", enhancement.getRarity());
                    var28.put("ProcID", enhancement.getProcId());
                    var28.put("EnhDPS", enhancement.getDPS());
                    eqpObj.put("EnhID", enhancement.getId());
                    eqpObj.put("EnhLvl", enhancement.getLevel());
                    eqpObj.put("EnhPatternID", enhancement.getClientPatternId());
                    eqpObj.put("EnhRty", enhancement.getRarity());
                    eqpObj.put("ProcID", enhancement.getProcId());
                    eqpObj.put("EnhDPS", enhancement.getDPS());
                }
                var28.put("iDPS", item.getDPS());
                var28.put("iRng", item.getClientRange());
                var28.put("EnhRng", item.getClientRange());
                eqpObj.put("iDPS", item.getDPS());
                eqpObj.put("iRng", item.getClientRange());
                eqpObj.put("EnhRng", item.getClientRange());
                if (item.getEquipment().equals("Weapon")) {
                    var28.put("sType", item.getType());
                    eqpObj.put("sType", item.getType());
                    user.properties.put("weaponitem", item);
                    user.properties.put("weaponitemenhancement", enhancement);
                }
                
                eqp.put(item.getEquipment(), eqpObj);
                Kaiden_Extension.getInstance().sendToRoom(var28, user, room);
                if (item.getEquipment().equals("ar") || item.getEquipment().equals("ba") || item.getEquipment().equals("he") || item.getEquipment().equals("Weapon")) {
                    if (item.getEquipment().equals("ar")) {
                        Users.getInstance().updateClass(user, item, 35000);
                    }

                    Users.getInstance().updateStats(user, enhancement, item.getEquipment());
                    Users.getInstance().sendStats(user);
                }
          }
    }