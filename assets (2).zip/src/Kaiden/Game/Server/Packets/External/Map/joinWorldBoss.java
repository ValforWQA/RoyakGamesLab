package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

public class joinWorldBoss extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        Room bossRoom = Kaiden_Extension.getInstance().getZone().getRoomByName(this.params[0]);
        if (bossRoom != null) {
            Rooms.getInstance().joinRoom(bossRoom, user, "Enter", "Spawn");
        } else {
            throw new RequestExternalPacketException("World Boss invitation has expired.");
        }
    }
}