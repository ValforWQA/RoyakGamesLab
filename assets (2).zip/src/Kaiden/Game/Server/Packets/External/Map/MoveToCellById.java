package Kaiden.Game.Server.Packets.External.Map;


import Kaiden.Database.Beans.CellBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;




public class MoveToCellById extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        State state = (State) user.properties.get("state");
        ZoneBean area = StorageCache.getInstance().getArea(room.getName().split("-")[0]);
        if (area != null) {
            CellBean cell = StorageCache.getInstance().getArea(room.getName().split("-")[0]).cells.get(Integer.parseInt(this.params[0]));
            if (cell != null) {
                if ((!cell.getFrame().equals("Enter0") || (Integer) this.user.properties.get("pvpteam") == 0) && (!cell.getFrame().equals("Enter1") || (Integer) this.user.properties.get("pvpteam") == 1)) {
                    ExternalPacketHandler message = new MoveToCell();
                    message.params = new String[]{cell.getFrame(), cell.getPad()};
                    message.room = this.room;
                    message.user = this.user;
                    message.handle();
                    Kaiden_Extension.getInstance().send(new String[]{"mtcid", params[0]}, user);
                }
            }
        }
    }
}
