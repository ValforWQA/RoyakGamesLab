package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

public class ServerUseItem extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (params == null || params.length < 2 || user == null) {
            return;
        }

        String option = params[0];

        if (option.equals("+")) {
            handleActivateBoost();
            return;
        }

        handleDisableBoost(option);
    }

    private void handleActivateBoost() throws RequestExternalPacketException {
        int itemId;

        try {
            itemId = Integer.parseInt(params[1]);
        } catch (Exception e) {
            throw new RequestExternalPacketException("Invalid item request.", "server");
        }

        ItemBean boost = StorageCache.getInstance().getItem(itemId);

        if (boost == null || boost.getType() == null || !boost.getType().equals("ServerUse")) {
            return;
        }

        if (boost.getLink() == null || !boost.getLink().contains("::")) {
            throw new RequestExternalPacketException("This feature is not yet available.", "server");
        }

        String[] itemParams = boost.getLink().split("::");

        if (itemParams.length < 3) {
            throw new RequestExternalPacketException("Invalid boost item setup.", "server");
        }

        String boostType = itemParams[0];
        int minutes;
        boolean showShop;

        try {
            minutes = Integer.parseInt(itemParams[1]);
            showShop = Boolean.parseBoolean(itemParams[2]);
        } catch (Exception e) {
            throw new RequestExternalPacketException("Invalid boost item duration.", "server");
        }

        if (minutes <= 0) {
            throw new RequestExternalPacketException("Invalid boost item duration.", "server");
        }

        String column = getBoostColumn(boostType);
        String property = getBoostProperty(boostType);

        if (column == null || property == null) {
            throw new RequestExternalPacketException("Invalid boost type.", "server");
        }

        Object userId = user.properties.get(Properties.ID);
        if (userId == null) {
            throw new RequestExternalPacketException("Unable to activate boost: missing user id.", "server");
        }

        if (!Users.getInstance().turnInItem(user, itemId, 1)) {
            Users.getInstance().log(user, "Suspicious Request [ServerUseItem]", "Failed to pass turn-in validation, might be a duplicate request.");
            return;
        }

        int secondsLeft = updateBoostExpireAtomic(column, minutes, userId);

        if (secondsLeft <= 0) {
            user.properties.put(property, Boolean.FALSE);
            throw new RequestExternalPacketException("Boost failed to activate. Please try again.", "server");
        }

        user.properties.put(property, Boolean.TRUE);

        JSONObject packet = new JSONObject();
        packet.put("cmd", boostType);
        packet.put("bShowShop", showShop);
        packet.put("op", "+");
        addBoostPacketFields(packet, boostType, secondsLeft);

        Kaiden_Extension.getInstance().send(packet, user);

        logBoost("green", "Activated " + boostType + " column=" + column + " userId=" + userId + " secondsLeft=" + secondsLeft + " itemId=" + itemId);
    }

    private void handleDisableBoost(String option) {
        if (params.length < 2) {
            return;
        }

        String boostType = params[1];
        String property = getBoostProperty(boostType);

        if (property != null) {
            user.properties.put(property, Boolean.FALSE);
        }

        JSONObject packet = new JSONObject();
        packet.put("cmd", boostType);
        packet.put("op", option);

        Kaiden_Extension.getInstance().send(packet, user);
    }

    /**
     * Atomic boost update.
     *
     * If the boost is still active, add minutes to the existing expire time.
     * If it is expired, start from NOW().
     *
     * This avoids the old SELECT TIMESTAMPDIFF -> UPDATE race and makes the DB update happen in one statement.
     */
    private int updateBoostExpireAtomic(String column, int minutes, Object userId) throws RequestExternalPacketException {
        QueryResult check = null;

        try {
            Storage.getInstance().getJdbc().run(
                    "UPDATE users SET " + column + " = CASE " +
                            "WHEN " + column + " > NOW() THEN DATE_ADD(" + column + ", INTERVAL ? MINUTE) " +
                            "ELSE DATE_ADD(NOW(), INTERVAL ? MINUTE) " +
                            "END WHERE id = ?",
                    minutes,
                    minutes,
                    userId
            );

            int rows = 0;
            try {
                rows = Storage.getInstance().getJdbc().queryForInt("SELECT ROW_COUNT()");
            } catch (Exception ignored) {
                // Some JDBC helper versions do not allow ROW_COUNT here. The follow-up SELECT still confirms the value.
            }

            check = Storage.getInstance().getJdbc().query(
                    "SELECT TIMESTAMPDIFF(SECOND, NOW(), " + column + ") AS SecsLeft, " + column + " AS BoostExpire FROM users WHERE id = ?",
                    userId
            );

            if (!check.next()) {
                logBoost("red", "No user row found while updating " + column + " userId=" + userId + " rowCount=" + rows);
                return 0;
            }

            int secondsLeft = check.getInt("SecsLeft");
            if (secondsLeft < 0) {
                secondsLeft = 0;
            }

            logBoost("yellow", "DB update " + column + " userId=" + userId + " rowCount=" + rows + " secondsLeft=" + secondsLeft + " expire=" + check.getString("BoostExpire"));
            return secondsLeft;
        } catch (Exception e) {
            logBoost("red", "DB update failed for " + column + " userId=" + userId + " error=" + e.getMessage());
            throw new RequestExternalPacketException("Boost failed to save to database.", "server");
        } finally {
            try {
                if (check != null) {
                    check.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private String getBoostColumn(String boostType) {
        switch (boostType) {
            case "xpboost":
                return "ExpBoostExpire";
            case "gboost":
                return "GoldBoostExpire";
            case "cpboost":
                return "CpBoostExpire";
            case "repboost":
                return "RepBoostExpire";
            default:
                return null;
        }
    }

    private String getBoostProperty(String boostType) {
        switch (boostType) {
            case "xpboost":
                return "xpboost";
            case "gboost":
                return "goldboost";
            case "cpboost":
                return "cpboost";
            case "repboost":
                return "repboost";
            default:
                return null;
        }
    }

    private void addBoostPacketFields(JSONObject packet, String boostType, int secondsLeft) {
        if (packet == null) {
            return;
        }

        if (secondsLeft < 0) {
            secondsLeft = 0;
        }

        packet.put("iSecsLeft", secondsLeft);
        packet.put("boostTS", System.currentTimeMillis());

        if ("xpboost".equals(boostType)) {
            packet.put("iBoostXP", secondsLeft);
        } else if ("gboost".equals(boostType)) {
            packet.put("iBoostG", secondsLeft);
        } else if ("cpboost".equals(boostType)) {
            packet.put("iBoostCP", secondsLeft);
        } else if ("repboost".equals(boostType)) {
            packet.put("iBoostRep", secondsLeft);
        }
    }

    private void logBoost(String color, String message) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(color, "[Boost] " + message);
        } catch (Exception ignored) {
        }
    }
}
