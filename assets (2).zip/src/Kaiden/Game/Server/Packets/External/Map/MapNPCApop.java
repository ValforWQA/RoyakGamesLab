package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Database.Beans.*;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.regex.Pattern;

public class MapNPCApop extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        int mapNpcId = -1;
        try {
            mapNpcId = Integer.parseInt(params[0]);
        } catch (Exception ignored) {}

        if (mapNpcId <= 0) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                    mapNpcId + " is not a valid MapNpc id.");
            return;
        }

        // Get apop by MapNpcID
        MapNpcBeanApop mapNpcApop =
                StorageCache.getInstance().getMapNPC(mapNpcId);

        if (mapNpcApop == null) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                    "MapNpcApop not found for MapNpcID: " + mapNpcId);
            return;
        }

        // Get NPC using actual NpcID from apop
        int npcId = mapNpcApop.getNpcID();
        NpcBean npcObj = StorageCache.getInstance().getNpc(npcId);

        if (npcObj == null) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                    "NpcBean not found for NpcID: " + npcId);
            return;
        }

        if ((int) user.properties.get(Properties.ACCESS) >= 40) {
            Kaiden_Extension.getInstance().send(
                    new String[]{"server", "Requested Map NPC APOP ID: " +
                            mapNpcApop.getMapNpcBeanApopID()},
                    user
            );
        }

        JSONObject npcInfo = new JSONObject();
        npcInfo.put("NpcID", String.valueOf(npcObj.getId()));
        npcInfo.put("intHP", 100);
        npcInfo.put("intHPMax", 100);
        npcInfo.put("intLevel", 1);
        npcInfo.put("intMP", 100);
        npcInfo.put("intMPMax", 100);
        npcInfo.put("sRace", "NPC");
        npcInfo.put("strBehave", "walk");
        npcInfo.put("strElement", "None");
        npcInfo.put("iNpcType", npcObj.getType());
        if (npcObj.getType() == NpcBean.TYPE_FILE) {
            npcInfo.put("strLinkage", npcObj.getLinkage());
            npcInfo.put("strFileName", npcObj.getFile());

            // aliases used by DynamicNPC debug
            npcInfo.put("strFile", npcObj.getFile());
            npcInfo.put("strLink", npcObj.getLinkage());
        }

        if (npcObj.getType() == NpcBean.TYPE_HUMAN) {
            npcInfo.put("strGender", npcObj.getGender());

            HairBean hair = StorageCache.getInstance().getHair(npcObj.getHairId());
            if (hair != null) {
                npcInfo.put("HairID", hair.getId());
                npcInfo.put("strHairName", hair.getName());
                npcInfo.put("strHairFilename", hair.getFile());
            }

            npcInfo.put("intColorHair", Integer.valueOf(npcObj.getColorHair(), 16));
            npcInfo.put("intColorSkin", Integer.valueOf(npcObj.getColorSkin(), 16));
            npcInfo.put("intColorEye", Integer.valueOf(npcObj.getColorEye(), 16));
            npcInfo.put("intColorBase", Integer.valueOf(npcObj.getColorBase(), 16));
            npcInfo.put("intColorTrim", Integer.valueOf(npcObj.getColorTrim(), 16));
            npcInfo.put("intColorAccessory", Integer.valueOf(npcObj.getColorAccessory(), 16));
            npcInfo.put("showCloak", Boolean.TRUE);
            npcInfo.put("showHelm", Boolean.TRUE);

            JSONObject equipmentObj = new JSONObject();
            ItemBean armorItem = StorageCache.getInstance().getItemOrDefault(npcObj.getArmorId());
            if (armorItem != null) {
                equipmentObj.put(Properties.ITEM_CLASS, armorItem.getEquipmentJson());
            }
            ItemBean helmItem = StorageCache.getInstance().getItemOrDefault(npcObj.getHelmId());
            if (helmItem != null) {
                equipmentObj.put(Properties.ITEM_HELM, helmItem.getEquipmentJson());
            }

            ItemBean weaponItem = StorageCache.getInstance().getItemOrDefault(npcObj.getWeaponId());
            if (weaponItem != null) {
                equipmentObj.put(Properties.ITEM_WEAPON, weaponItem.getEquipmentJson());
            }
            ItemBean capeItem = StorageCache.getInstance().getItemOrDefault(npcObj.getCapeId());
            if (capeItem != null) {
                equipmentObj.put(Properties.ITEM_CAPE, capeItem.getEquipmentJson());
            }
            npcInfo.put("eqp", equipmentObj);
        }

        npcInfo.put("strName", npcObj.getName());

        JSONArray actions = new JSONArray();
        int actionBtnLimitCounter = 0;

        if (mapNpcApop.actions != null) {
            for (MapNpcBeanApopAction action : mapNpcApop.actions) {
                if (actionBtnLimitCounter == 3) break;

                JSONObject actionInfo = new JSONObject();
                actionInfo.put("Action", action.getAction());
                actionInfo.put("Caption", action.getCaption());
                actionInfo.put("ShopID", action.getShopId());
                if(action.getQuestItem() > 0) {
                actionInfo.put("QuestItem", action.getQuestItem());
                }
                if(action.getQuestID() > 0) {
                    actionInfo.put("QuestID", action.getQuestID());
                }
                actionInfo.put("QuestIDs", action.getQuestIds());
                actionInfo.put("RoomFrame", action.getRoomFrame());
                actionInfo.put("RoomName", action.getRoomName());
                actionInfo.put("RoomPad", action.getRoomPad());
                actionInfo.put("SortOrder", action.getSortOrder());

                if (action.getStartDate() != null &&
                        !action.getStartDate().isEmpty()) {
                    actionInfo.put("StartDate", action.getStartDate());
                }

                if (action.getEndDate() != null &&
                        !action.getEndDate().isEmpty()) {
                    actionInfo.put("EndDate", action.getEndDate());
                }

                actions.add(actionInfo);
                actionBtnLimitCounter++;
            }
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd", "showNpcApop");
        jsonObject.put("id", mapNpcApop.getMapNpcBeanApopID());
        jsonObject.put("title", mapNpcApop.getSubtitle());

        String npcMessage = mapNpcApop.getMessage();
        npcMessage = npcMessage.replaceAll(
                Pattern.quote("{user}"),
                (String) user.properties.getOrDefault(
                        Properties.USERNAME, "Username")
        );

        jsonObject.put("message", npcMessage);
        jsonObject.put("npcData", npcInfo);
        jsonObject.put("actions", actions);

        Kaiden_Extension.getInstance().send(jsonObject, user);
    }

    private int parseHexColor(String hex) {
        try {
            if (hex == null) return 0xFFFFFF;
            hex = hex.trim().replace("#", "");
            if (hex.length() == 0) return 0xFFFFFF;
            return Integer.parseInt(hex, 16);
        } catch (Exception e) {
            return 0xFFFFFF;
        }
    }
}
