package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;

import java.util.HashSet;
import java.util.Set;

public class GetMapItem extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (this.params == null || this.params.length == 0) {
            return;
        }

        final int mapItemId;
        try {
            mapItemId = Integer.parseInt(this.params[0]);
        } catch (Exception e) {
            return;
        }

        ZoneBean area = StorageCache.getInstance().getArea(this.room.getName().split("-")[0]);
        if (area == null) {

            return;
        }



        Integer actualItemId = null;
        int quantity = 1;

        QueryResult result = null;
        try {
            result = Storage.getInstance().getJdbc().query(
                    "SELECT ItemID, Quantity FROM maps_items WHERE MapID=? AND id=? LIMIT 1",
                    area.getId(),
                    mapItemId
            );

            if (result.next()) {
                actualItemId = result.getInt("ItemID");
                quantity = Math.max(1, result.getInt("Quantity"));
            }
        } catch (Exception firstSchemaError) {
            // Some Kaiden databases name the map-side identifier MapItemID.
            try { if (result != null) result.close(); } catch (Exception ignored) {}
            result = null;

            try {
                result = Storage.getInstance().getJdbc().query(
                        "SELECT ItemID, Quantity FROM maps_items WHERE MapID=? AND MapItemID=? LIMIT 1",
                        area.getId(),
                        mapItemId
                );

                if (result.next()) {
                    actualItemId = result.getInt("ItemID");
                    quantity = Math.max(1, result.getInt("Quantity"));
                }
            } catch (Exception ignored) {
                // Fall through to the legacy ItemID mapping below.
            }
        } finally {
            try { if (result != null) result.close(); } catch (Exception ignored) {}
        }

        /*
         * Backwards compatibility: old custom maps sometimes passed the actual
         * ItemID directly. Keep those maps working too.
         */
        if (actualItemId == null && area.items != null && area.items.containsKey(mapItemId)) {
            actualItemId = mapItemId;
            Integer cachedQty = area.items.get(mapItemId);
            quantity = cachedQty == null ? 1 : Math.max(1, cachedQty);
        }

        if(user.isModerator()) {
            Kaiden_Extension.getInstance().sendZoneMessage("server", "attempting mapdrop item id:" + actualItemId, this.user);
            Kaiden_Extension.getInstance().sendZoneMessage("server", "atempting mapid:"+ area.getId(), this.user);
            Kaiden_Extension.getInstance().sendZoneMessage("server", "atempting mapdrop:"+ mapItemId, this.user);
        }

        if (actualItemId == null || actualItemId <= 0) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow",
                    "[GetMapItem] No map item mapping found map=" + area.getName() +
                            " mapItemID=" + mapItemId
            );
            return;
        }

        // Map pickups used as active quest turn-in requirements must be granted
        // as quest/temp items even when the legacy items row has Temporary=0.
        // AQW maps commonly use getMapItem (not questItem), which was the path
        // still leaving the client at 1/1 while the server turn-in state stayed 0.
        boolean activeTurnInItem = false;
        Set<Integer> activeQuests = (Set<Integer>) this.user.properties.get(Properties.QUESTS);
        if (activeQuests != null) {
            for (Integer activeQuestId : activeQuests) {
                if (activeQuestId == null) continue;
                QuestBean activeQuest = StorageCache.getInstance().getQuest(activeQuestId);
                if (activeQuest != null && activeQuest.requirements != null &&
                        activeQuest.requirements.containsKey(actualItemId)) {
                    activeTurnInItem = true;
                    break;
                }
            }
        }

        ItemBean mappedItem = StorageCache.getInstance().getItem(actualItemId);
        if (mappedItem == null) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("yellow",
                    "[GetMapItem] Item not cached: " + actualItemId);
            return;
        }

        // Only Quest Item types are restricted by ReqQuests.
        // All other map item types can drop without an active quest,
        // even when their items row has ReqQuests populated.
        String itemType = mappedItem.getType();
        boolean questItemType = itemType != null &&
                ("Quest Item".equalsIgnoreCase(itemType.trim()) ||
                 "QuestItem".equalsIgnoreCase(itemType.trim()));
        String reqQuests = mappedItem.getReqQuests();
        if (questItemType && !QuestProgressManager.reloadActiveQuests(this.user)) return;
        activeQuests = (Set<Integer>) this.user.properties.get(Properties.QUESTS);
        if (questItemType && reqQuests != null && !reqQuests.trim().isEmpty()) {
            boolean matchingQuestActive = false;
            if (activeQuests != null) {
                for (String token : reqQuests.trim().split("[,;|\\s]+")) {
                    if (token.isEmpty()) continue;
                    try {
                        if (activeQuests.contains(Integer.valueOf(token))) {
                            matchingQuestActive = true;
                            break;
                        }
                    } catch (NumberFormatException ignored) {
                        // Ignore malformed quest identifiers; never grant on them.
                    }
                }
            }
            if (!matchingQuestActive) {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "yellow", "[GetMapItem] blocked: required quest inactive, ItemID="
                                + actualItemId + " type=" + itemType + " ReqQuests=" + reqQuests
                                + " active=" + activeQuests + " user=" + this.user.getName());
                return;
            }
        }

        // Quest Item type also belongs in TEMP_ITEMS, even without an active quest.
        boolean temporaryPickup = mappedItem.isTemporary() || questItemType || activeTurnInItem;
        if (temporaryPickup) {
            Users.getInstance().giveMapQuestItem(this.user, actualItemId, quantity);
        } else {
            Set<UserDrop> drops = new HashSet<UserDrop>();
            drops.add(new UserDrop(actualItemId, quantity, false));
            Users.getInstance().dropItems(this.user, drops);
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "[GetMapItem] map=" + area.getName() +
                        " mapItemID=" + mapItemId +
                        " -> ItemID=" + actualItemId +
                        " qty=" + quantity +
                        " path=" + (temporaryPickup ? "TEMP" : "NORMAL") +
                        " user=" + this.user.getName()
        );
    }
}
