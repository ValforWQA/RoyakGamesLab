package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

public class Move extends ExternalPacketHandler {
    private static final Logger LOGGER = Logger.getLogger(Move.class);

    // Must match client:
    // speed = WALKSPEED;
    // if (rootClass.pDash && !justRan) speed = speed * 3;
    private static final int AQW_WALK_SPEED = 8;
    private static final int AQW_DASH_SPEED = AQW_WALK_SPEED * 3;
    private static final int DASH_COST = 50;

    @Override
    public void handle() {
        try {
            if (this.params == null || this.params.length < 3) {
                return;
            }

            int x = Integer.parseInt(this.params[0]);
            int y = Integer.parseInt(this.params[1]);
            int requestedSpeed = Integer.parseInt(this.params[2]);
            int finalSpeed = requestedSpeed;

            State state = (State) this.user.properties.get("state");
            String frame = String.valueOf(this.user.properties.get("frame"));

            // EXACT AQW-style detection:
            // only consume dash when client sends the boosted dash speed
            boolean isDashMove = requestedSpeed >= AQW_DASH_SPEED;

            if (state != null) {
                if (isDashMove) {
                    // Dash requires 50 SP and consumes exactly 50 SP.
                    // Max dash remains 100 so the meter/regeneration system stays intact.
                    if (state.getDash() >= DASH_COST) {
                        state.decreaseDash(DASH_COST);
                        sendDashUpdate(state.getDash());
                    } else {
                        finalSpeed = AQW_WALK_SPEED;
                        sendDashUpdate(state.getDash());
                    }
                } else {
                  if(state.getDash() <= 50) {
                      Users.getInstance().regenDash(this.user);
                  }
                }

                // keep regen active
                Users.getInstance().regenDash(this.user);
            }

            Kaiden_Extension.getInstance().sendToRoomButOne(
                    new String[]{
                            "uotls",
                            this.user.getName(),
                            "tx:" + x + ",ty:" + y + ",sp:" + finalSpeed + ",strFrame:" + frame
                    },
                    this.user,
                    this.room
            );

            this.user.properties.put("tx", x);
            this.user.properties.put("ty", y);
            this.user.properties.put("sp", finalSpeed);

        } catch (Exception e) {
            LOGGER.error("Move packet failed for user: " + (this.user != null ? this.user.getName() : "null"), e);
        }
    }

    private void sendDashUpdate(int dash) {
        try {
            JSONObject packet = new JSONObject();
            JSONObject o = new JSONObject();

            o.put("intSP", dash);
            packet.put("cmd", "uotls");
            packet.put("o", o);
            packet.put("unm", this.user.getName());

            Kaiden_Extension.getInstance().send(packet, this.user);
        } catch (Exception ignored) {
        }
    }
}