package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

public class NpcMove extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        // Staff-only protection – adjust to your real check if needed. client already protects



        // Expect: [ npcDbId, X, Y, Scale ]
        if (this.params == null || this.params.length < 4) {
            throw new RequestExternalPacketException("Invalid npcMove packet (expected: id, X, Y, Scale).");
        }

        int npcDbId;
        int x;
        int y;
        double scale;

        try {
            npcDbId = Integer.parseInt(this.params[0]); // maps_npcs.id
            x = Integer.parseInt(this.params[1]);
            y = Integer.parseInt(this.params[2]);
            scale = Double.parseDouble(this.params[3]);
        } catch (NumberFormatException e) {
            throw new RequestExternalPacketException("Invalid npcMove numeric parameters.", e.getMessage());
        }

        // Clamp scale to same bounds as client (0.7 - 2.3)
        if (scale < 0.7) scale = 0.7;
        if (scale > 2.3) scale = 2.3;

        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("Cannot resolve room for npcMove.");
        }

        // DB UPDATE: maps_npcs uses PosX / PosY / Scale
        Storage.getInstance().getJdbc().run(
                "UPDATE maps_npcs SET PosX = ?, PosY = ?, Scale = ? WHERE id = ?",
                x, y, scale, npcDbId
        );

        //Kaiden_Engine.LOGGER.info(
               // "[MapEdit] NPC moved by " + this.user.getName() +
                        //" => maps_npcs.id=" + npcDbId +
                        //" PosX=" + x + " PosY=" + y + " Scale=" + scale
        //);

        // Live broadcast to everyone in this room
        Kaiden_Extension.getInstance().sendToRoom(
                new String[]{
                        "npcMove",
                        String.valueOf(npcDbId),
                        String.valueOf(x),
                        String.valueOf(y),
                        String.valueOf(scale)
                },
                this.user,
                room
        );

        StorageCache.getInstance().RetrieveStorageBeans("royakgames");
        StorageCache.getInstance().RetrieveStorageBeans("maps");
    }
}
