package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;

public class MonsterMove extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        // Staff-only protection – adjust to your real check if needed.

        // Expect: [ MonMapID, MonsterID, X, Y, Scale ]
        if (this.params == null || this.params.length < 5) {
            throw new RequestExternalPacketException(
                    "Invalid monsterMove packet (expected: MonMapID, MonsterID, X, Y, Scale)."
            );
        }

        int monMapId;
        int monsterId;
        int x;
        int y;
        double scale;

        try {
            monMapId  = Integer.parseInt(this.params[0]);
            monsterId = Integer.parseInt(this.params[1]);
            x         = Integer.parseInt(this.params[2]);
            y         = Integer.parseInt(this.params[3]);
            scale     = Double.parseDouble(this.params[4]);
        }
        catch (NumberFormatException e) {
            throw new RequestExternalPacketException("Invalid monsterMove numeric parameters.", e.getMessage());
        }

        // Clamp scale
        if (scale < 0.7) scale = 0.7;
        if (scale > 2.3) scale = 2.3;

        Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
        if (room == null) {
            throw new RequestExternalPacketException("Cannot resolve room for monsterMove.");
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "npcX:"+x+ "  npcY:"+y);
        // DB UPDATE: only Scale is persisted in maps_monsters
        Storage.getInstance().getJdbc().run(
                "UPDATE maps_monsters SET Scale = ?, PosX = ?, PosY = ? WHERE MonsterID = ? AND MonMapID = ?",
                scale, x, y, monsterId, monMapId
        );
        //
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "update sent.. to monMapID"+monMapId+ " / MonsterID:"+ monsterId);

        //Kaiden_Engine.LOGGER.info(
                //"[MapEdit] Monster moved by " + this.user.getName() +
                        //" => MonsterID=" + monsterId +
                        //" MonMapID=" + monMapId +
                        //" X=" + x + " Y=" + y + " Scale=" + scale
        //);

        // Live broadcast to room (clients just need MonMapID)
        Kaiden_Extension.getInstance().sendToRoom(
                new String[] {
                        "monsterMove",
                        String.valueOf(monMapId),
                        String.valueOf(x),
                        String.valueOf(y),
                        String.valueOf(scale)
                },
                this.user,
                room
        );

        StorageCache.getInstance().RetrieveStorageBeans("royakgames");
        StorageCache.getInstance().RetrieveStorageBeans("maps");
    }
}
