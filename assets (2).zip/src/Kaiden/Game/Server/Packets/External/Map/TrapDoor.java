package Kaiden.Game.Server.Packets.External.Map;

import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;

public class TrapDoor extends ExternalPacketHandler {
    public void handle() {
        Kaiden_Extension.getInstance().sendToRoom(new String[]{"trap door", params[0]}, user, room);
    }
}
