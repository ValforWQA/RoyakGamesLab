package Kaiden.Game.Server.Packets.External.Map;


import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONObject;




public class MoveToCell extends ExternalPacketHandler {

    public void handle() {
        if (this.user.properties != null && this.room != null) {
            String frame = this.params[0];
            String pad = this.params[1];
            this.user.properties.put("frame", frame);
            this.user.properties.put("pad", pad);
            this.user.properties.put("tx", 0);
            this.user.properties.put("ty", 0);
            State state = (State) user.properties.get("state");
            if (state != null) {
                // Cell/pad movement should not clear auras or blindly tear down stats.
                // Only refresh target/combat state so the client gets a clean neutral/combat
                // transition without wiping buffs/passives during normal movement.
                state.refreshCombatState();
                Users.getInstance().regen(this.user);

                JSONObject sb = new JSONObject();
                JSONObject p = new JSONObject();
                p.put(this.user.getName(), state.getData());
                sb.put("cmd", "ct");
                sb.put("p", p);
                Kaiden_Extension.getInstance().sendToRoom(sb, this.user, this.room);
            }
            Kaiden_Extension.getInstance().sendToRoomButOne(new String[]{"uotls", this.user.getName(), "strPad:" + this.user.properties.get("pad") + ",tx:" + this.user.properties.get("tx") + ",strFrame:" + this.user.properties.get("frame") + ",ty:" + this.user.properties.get("tx")}, this.user, this.room);
            Users.getInstance().lastarea(this.user, this.room, frame, pad);
            Users.getInstance().lastlocation(this.user, this.room.getName());

            
        }
    }
}
