package Kaiden.Game.Server.Packets.External.Titles;

import Kaiden.Database.Beans.TitleBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import jdbchelper.JdbcException;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class UpdateTitle extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
       int titleId = Integer.parseInt(params[0]);
       String type = params[1];

       TitleBean title = StorageCache.getInstance().getTitle(titleId);
       if (title == null) throw new RequestExternalPacketException("Invalid Title.");

       int titleCount = Storage.getInstance().getJdbc().queryForInt("SELECT COUNT(*) AS rowcount FROM users_title WHERE TitleID = ? AND UserID = ?", titleId, user.properties.get(Properties.ID));
       if (titleCount < 1) throw new RequestExternalPacketException("Selected title is currently locked.");



       JSONObject utl = new JSONObject();
       utl.put("cmd", "updateTitle");
       utl.put("uid", user.getUserId());
       utl.put("type", type.toLowerCase());
       utl.put("title", new JSONObject()
               .accumulate("id", title.getId())
               .accumulate("Name", title.getName())
               .accumulate("Description", title.getDescription())
               .accumulate("Color", title.getColor())
               .accumulate("Strength", title.getStrength())
               .accumulate("Intellect", title.getIntellect())
               .accumulate("Endurance", title.getEndurance())
               .accumulate("Dexterity", title.getDexterity())
               .accumulate("Wisdom", title.getWisdom())
               .accumulate("Luck", title.getLuck())
       );
       utl.put("success", 1);

       Storage.getInstance().getJdbc().beginTransaction();
       try {
          switch (type.toLowerCase()) {
             case "equip":
                Storage.getInstance().getJdbc().run("UPDATE users SET TitleID = ? WHERE id = ?", titleId, user.properties.get(Properties.ID));
                user.properties.put(Properties.TITLE_ID, titleId);
                break;
             case "unequip":
                Storage.getInstance().getJdbc().run("UPDATE users SET TitleID = 0 WHERE id = ?", user.properties.get(Properties.ID));
                user.properties.put(Properties.TITLE_ID, 0);
                break;
             default:
                Users.getInstance().kick(user, "title abuse");
                break;
          }

          Storage.getInstance().getJdbc().commitTransaction();
       } catch (JdbcException jdbcException) {
          if (Storage.getInstance().getJdbc().isInTransaction())
             Storage.getInstance().getJdbc().rollbackTransaction();

          throw new RequestExternalPacketException("Error updating title!");
       }

       Kaiden_Extension.getInstance().sendToRoom(utl, user, room);

       Users.getInstance().sendUotls(user, true, true, true, true, true, false, false);
       Users.getInstance().sendStats(user);
       Users.getInstance().sendStateStats(user);
    }

}