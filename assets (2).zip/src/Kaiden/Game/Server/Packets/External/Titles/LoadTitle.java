package Kaiden.Game.Server.Packets.External.Titles;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class LoadTitle extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
       JSONObject titleObject = new JSONObject();
       JSONArray lists = new JSONArray();

       QueryResult title = Storage.getInstance().getJdbc().query("SELECT b.id, b.Name, b.Description, b.Color, b.Strength, b.Intellect, b.Endurance, b.Dexterity, b.Wisdom, b.Luck FROM users_title AS a INNER JOIN title AS b ON a.TitleID = b.id WHERE a.UserID = ?" , user.properties.get(Properties.ID));

       while(title.next()) {
          lists.add(new JSONObject()
                  .accumulate("id", title.getInt("id"))
                  .accumulate("Name", title.getString("Name"))
                  .accumulate("Description", title.getString("Description"))
                  .accumulate("Color", title.getString("Color"))
                  .accumulate("Strength", title.getInt("Strength"))
                  .accumulate("Intellect", title.getInt("Intellect"))
                  .accumulate("Endurance", title.getInt("Endurance"))
                  .accumulate("Dexterity", title.getInt("Dexterity"))
                  .accumulate("Wisdom", title.getInt("Wisdom"))
                  .accumulate("Luck", title.getInt("Luck"))
          );
       }

       if(user.properties.get(Properties.USERNAME).equals("Valfor")) {
          Kaiden_Engine.sendEmulatorMessage("blue", "loading title.");
       }

       titleObject.put("cmd", "loadTitles");
       titleObject.put("lists", lists);
       titleObject.put("success", 1);
       title.close();
       Kaiden_Extension.getInstance().send(titleObject, user);
    }
}
