package Kaiden.Game.Server.Packets.External.Combat;


import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import org.apache.log4j.Logger;

import java.util.concurrent.TimeUnit;

@SuppressWarnings("ALL")
public class RestoreTimed extends ExternalPacketHandler {
    private static final Logger LOGGER = Logger.getLogger(RestoreTimed.class);

    public void handle() {
            if (this.user.properties.containsKey("respawntime")) {
                Long respawnTime = (Long) this.user.properties.get("respawntime");
                int elapsed = Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - respawnTime)).intValue();
                if (elapsed >= 8) {

                    Users.getInstance().respawn(this.user);
                    ZoneBean zone = StorageCache.getInstance().getArea(this.room.getName().split("-")[0]);
                    if (zone != null) {
                        if (zone.isPvP()) {
                            Kaiden_Extension.getInstance().send(new String[]{"resTimed", "Enter" + this.user.properties.get("pvpteam"), "Spawn"}, this.user);
                        } else {
                            Kaiden_Extension.getInstance().send(new String[]{"resTimed", "Enter", "Spawn"}, this.user);
                      }
                    }
                }
            }
        }
    }