package Kaiden.Game.Server.Packets.External.Combat;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Threads.Executor;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class AggroMonster extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {
        if (user != null) {
            HashMap monsters = (HashMap) room.properties.get("monsters");
            MonsterAI ai = (MonsterAI) monsters.get(Integer.parseInt(params[0]));
            if (ai != null) {
                ai.getState().addTarget(user.getUserId());
                if (ai.getState().isNeutral()) {
                    ai.setAttacking(Executor.getInstance().scheduleTask(ai, ai.getMonster().getAttack(), TimeUnit.MILLISECONDS, true));
                }

            }
        }
    }
}
