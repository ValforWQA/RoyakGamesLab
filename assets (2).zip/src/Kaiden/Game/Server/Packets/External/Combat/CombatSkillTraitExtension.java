package Kaiden.Game.Server.Packets.External.Combat;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.Set;

/**
 * DB-driven class/skill trait extension for special combat mechanics that do not
 * belong inside normal stat math. Add new aura_effects keys here with a switch case.
 */
public final class CombatSkillTraitExtension {

    private static final String PROP_VAMPIRE_BLOOD = "vampireBloodCharges";
    private static final int VAMPIRE_BLOOD_MAX = 10;

    private CombatSkillTraitExtension() {
    }

    public static void handle(String trait,
                              CombatAction combat,
                              User caster,
                              MonsterAI primaryTarget,
                              HashMap<Integer, MonsterAI> monsters,
                              State casterState,
                              Set<RemoveAura> casterAuras,
                              int damageDealt,
                              JSONArray damageArray,
                              JSONObject monstersJson) {
        if (trait == null || combat == null || caster == null || damageDealt <= 0) return;

        switch (trait.trim().toLowerCase()) {
            case "blood":
                handleBloodCharges(caster, casterAuras, damageDealt);
                break;

            case "bloodnova":
                handleBloodNova(combat, caster, primaryTarget, monsters, casterState, casterAuras, damageDealt, damageArray, monstersJson);
                break;

            default:
                break;
        }
    }

    private static void handleBloodCharges(User caster, Set<RemoveAura> casterAuras, int damageDealt) {
        double bloodGain = getTotalAuraEffectValue(casterAuras, "blood");
        if (bloodGain <= 0.0D) return;

        int gain = Math.max(1, (int) Math.round(bloodGain));
        Object curObj = caster.properties.get(PROP_VAMPIRE_BLOOD);
        int current = (curObj instanceof Integer) ? (Integer) curObj : 0;
        int next = Math.min(VAMPIRE_BLOOD_MAX, current + gain);
        caster.properties.put(PROP_VAMPIRE_BLOOD, next);

        if (next != current) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[Vampire] " + caster.getName() + " Blood Charges " + current + " -> " + next + "/" + VAMPIRE_BLOOD_MAX
            );
        }
    }

    private static void handleBloodNova(CombatAction combat,
                                        User caster,
                                        MonsterAI primaryTarget,
                                        HashMap<Integer, MonsterAI> monsters,
                                        State casterState,
                                        Set<RemoveAura> casterAuras,
                                        int damageDealt,
                                        JSONArray damageArray,
                                        JSONObject monstersJson) {
        if (primaryTarget == null || monsters == null || casterState == null || damageArray == null || monstersJson == null) return;

        double novaPct = getTotalAuraEffectValue(casterAuras, "bloodnova");
        if (novaPct <= 0.0D) return;

        int novaDamage = (int) Math.max(1, Math.round(damageDealt * novaPct));
        int hitCount = 0;

        for (MonsterAI other : monsters.values()) {
            if (other == null || other == primaryTarget || other.getState() == null || other.getMapMonster() == null) continue;
            if (other.getState().isDead()) continue;
            if (!MonsterAI.canDamageMonster(other) || other.isRegenImmune()) continue;

            int finalDamage = combat.applyTraitIncomingMonsterModifiers(other, novaDamage);
            other.getState().decreaseHealth(finalDamage);
            other.getState().applyMonsterOnDamageTaken(finalDamage);
            other.getState().addTarget(caster.getUserId());
            casterState.addMonsterTarget(other.getMapMonster().getMonMapId());

            damageArray.add(Damage.getDamageResult(
                    "p:" + caster.getUserId(),
                    "m:" + other.getMapMonster().getMonMapId(),
                    finalDamage,
                    DamageType.HIT
            ));

            if (other.getState().isDead()) {
                combat.handleTraitMonsterDeath(other, casterState, combat.requireTraitAreaSafe(), new JSONArray());
                casterState.removeMonsterTarget(other.getMapMonster().getMonMapId());
            }

            monstersJson.accumulate(
                    String.valueOf(other.getMapMonster().getMonMapId()),
                    other.getState().getData().accumulate("targets", other.getState().getTargets())
            );

            hitCount++;
            if (hitCount >= 3) break;
        }

        if (hitCount > 0) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[Vampire] Blood Nova hit " + hitCount + " extra monster(s) for " + novaDamage + " base damage."
            );
        }
    }

    private static double getTotalAuraEffectValue(Set<RemoveAura> auraSet, String effectKey) {
        if (auraSet == null || auraSet.isEmpty() || effectKey == null) return 0.0D;

        double total = 0.0D;
        for (RemoveAura removeAura : auraSet) {
            if (removeAura == null || removeAura.getAura() == null) continue;
            AuraBean aura = removeAura.getAura();
            if (aura.effects == null || aura.effects.isEmpty()) continue;

            for (int effectId : aura.effects) {
                try {
                    AuraEffectsBean effect = StorageCache.getInstance().getAuraEffect(effectId);
                    if (effect == null || effect.getStat() == null) continue;
                    if (!effectKey.equalsIgnoreCase(effect.getStat().trim())) continue;

                    double value = normalizeValue(effect.getValue());
                    if ("-".equals(effect.getType())) total -= value;
                    else total += Math.abs(value);
                } catch (Exception ignored) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage(
                            "orange",
                            "[TraitExtension] effect read failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage()
                    );
                }
            }
        }

        return Math.max(0.0D, total);
    }

    private static double normalizeValue(double value) {
        if (Math.abs(value) > 1.0D) return value / 100.0D;
        return value;
    }
}
