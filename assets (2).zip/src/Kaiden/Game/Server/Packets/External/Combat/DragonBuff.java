package Kaiden.Game.Server.Packets.External.Combat;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;




public class DragonBuff extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        Kaiden_Extension.getInstance().send(new String[]{"Dragon Buff"}, user);
    }
}
