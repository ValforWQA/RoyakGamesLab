package Kaiden.Game.Server.Packets.External.Combat;

import Kaiden.Game.Server.Combat.Player.TargetAuraContainer;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.UserState;
import net.sf.json.JSONObject;


public class LazerPar extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        UserState state = (UserState) this.user.properties.get("state");
        if (state == null) {
            return;
        }

         state.decreaseHealth(16);

        try {
            String fromTarget = "p:" + this.user.getUserId();
            JSONObject auraResult = TargetAuraContainer.getInstance().applyAuraToUser(this.user, 101, fromTarget, 16);

            Users.getInstance().sendUotls(this.user, true, false, false, true, false, false, false);

        } catch (Exception e) {
            throw new RequestExternalPacketException(e.getMessage());
        }
    }
}