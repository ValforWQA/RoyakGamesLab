package Kaiden.Game.Server.Packets.External.Combat;

import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;


public class Rest extends ExternalPacketHandler {

    public void handle() {
        State state = (State) this.user.properties.get("state");
        
        if (state.isNeutral() && (state.getHealth() < state.getMaxHealth() || state.getMana() < state.getMaxMana())) {
            state.increaseHealthByPercent(0.19D);
            state.increaseManaByPercent(0.19D);
            state.setState(1);
            Users.getInstance().regen(this.user);
            Users.getInstance().sendUotls(user, true, false, false, true, false, false, false);
        }
    }
}
