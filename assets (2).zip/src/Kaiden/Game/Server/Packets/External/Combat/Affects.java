package Kaiden.Game.Server.Packets.External.Combat;


import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Threads.Executor;
import Kaiden.Kaiden_Engine;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class Affects extends ExternalPacketHandler {

    public void handle() throws RequestExternalPacketException {

        //Kaiden_Engine.getInstance().sendEmulatorMessage("blue", "applying affects from affects/");
    }
}
