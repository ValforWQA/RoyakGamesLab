package Kaiden.Game.Server.Packets.External.Combat;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.SkillBean;
import Kaiden.Database.Beans.SkillIconBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.PotionAffectHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Kaiden_Extension;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public class GetPotionEffect extends ExternalPacketHandler {

    @Override
    public void handle() throws RequestExternalPacketException {
        if (params == null || params.length < 2) {
            throw new RequestExternalPacketException("Invalid potion equip packet.");
        }

        String itemLink = params[0];
        int skillId;
        int itemId = 0;

        try {
            skillId = Integer.parseInt(params[1]);
            if (params.length > 2 && params[2] != null && params[2].trim().length() > 0) {
                itemId = Integer.parseInt(params[2]);
            }
        } catch (Exception e) {
            throw new RequestExternalPacketException("Invalid potion equip values.");
        }

        SkillBean skill = StorageCache.getInstance().getSkill(skillId);
        if (skill == null) {
            throw new RequestExternalPacketException("Potion/scroll skill not found for Meta/SkillID: " + skillId);
        }

        if (itemId > 0) {
            ItemBean item = StorageCache.getInstance().getItem(itemId);
            if (item == null) {
                throw new RequestExternalPacketException("Potion/scroll item not found: " + itemId);
            }
            if (!PotionAffectHandler.isUsableItem(item)) {
                throw new RequestExternalPacketException("Equipped item is not a potion or scroll.");
            }
            if (!String.valueOf(skillId).equals(String.valueOf(item.getMeta()))) {
                throw new RequestExternalPacketException("Potion/scroll Meta does not match requested skill.");
            }
            String link = item.getLink() == null ? "" : item.getLink().trim();
            if (itemLink != null && itemLink.trim().length() > 0 && !link.equalsIgnoreCase(itemLink.trim())) {
                throw new RequestExternalPacketException("Potion/scroll link mismatch.");
            }
        }

        JSONObject seia = new JSONObject();
        JSONObject o = new JSONObject();

        o.put("id", skillId);
        // IMPORTANT: the action bar expects the usable item slot to remain i1.
        // The item's Link remains potion/scroll only for validation; it is not the action ref.
        o.put("ref", "i1");
        o.put("sArg1", String.valueOf(itemId));
        o.put("nam", skill.getName());
        o.put("anim", skill.getAnimation());
        o.put("mp", skill.getMana());
        o.put("desc", skill.getDescription());
        o.put("range", skill.getRange());
        o.put("fx", skill.getEffects());
        o.put("tgt", skill.getTarget());
        o.put("typ", skill.getType());
        o.put("strl", skill.getStrl());
        o.put("cd", skill.getCooldown());

        JSONArray clientAuras = buildClientAuraPreview(skill);
        if (!clientAuras.isEmpty()) {
            o.put("auras", clientAuras);
        }

        seia.put("cmd", "seia");
        seia.put("iRes", 1);
        seia.put("o", o);
        Kaiden_Extension.getInstance().send(seia, user);

        @SuppressWarnings("unchecked")
        ConcurrentHashMap<String, Integer> skills = (ConcurrentHashMap<String, Integer>) user.properties.get("skills");
        if (skills != null) {
            skills.put("i1", skillId);
        }
    }

    private JSONArray buildClientAuraPreview(SkillBean skill) {
        JSONArray skills = new JSONArray();

        try {
            if (skill == null) return skills;

            if (skill.auraLinks != null && !skill.auraLinks.isEmpty()) {
                java.util.HashSet<Integer> seen = new java.util.HashSet<Integer>();
                for (Kaiden.Database.Beans.SkillAuraBean link : skill.auraLinks) {
                    if (link == null || link.getAuraId() <= 0 || !seen.add(link.getAuraId())) continue;
                    JSONObject auraInfo = buildAuraInfo(link.getAuraId());
                    if (auraInfo != null) skills.add(auraInfo);
                }
                return skills;
            }

            if (skill.hasAuraId()) {
                JSONObject auraInfo = buildAuraInfo(skill.getAuraId());
                if (auraInfo != null) skills.add(auraInfo);
            }
        } catch (Exception ignored) {
        }

        return skills;
    }

    private JSONObject buildAuraInfo(int auraId) {
        AuraBean aura = StorageCache.getInstance().getAura(auraId);
        if (aura == null) return null;

        JSONObject auraInfo = new JSONObject();
        JSONArray effects = new JSONArray();

        if (aura.effects != null) {
            for (int effectId : aura.effects) {
                AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                if (ae == null) continue;
                JSONObject effect = new JSONObject();
                effect.put("typ", ae.getType());
                effect.put("sta", ae.getStat());
                effect.put("id", ae.getId());
                effect.put("val", ae.getValue());
                effects.add(effect);
            }
        }

        if (!effects.isEmpty()) {
            auraInfo.put("e", effects);
        }

        if (aura.getDuration() > 0) {
            auraInfo.put("t", "s");
        }

        auraInfo.put("nam", aura.getName());
        try {
            SkillIconBean skillIcon = StorageCache.getInstance().getSkillIcon(Integer.valueOf(aura.getIcon()));
            auraInfo.put("icon", skillIcon == null ? aura.getIcon() : skillIcon.getName());
        } catch (Exception e) {
            auraInfo.put("icon", aura.getIcon());
        }
        return auraInfo;
    }
}
