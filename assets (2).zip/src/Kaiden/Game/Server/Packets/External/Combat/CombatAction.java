package Kaiden.Game.Server.Packets.External.Combat;

import Kaiden.Database.Beans.*;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.BoostContainer;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Combat.Containers.Combat.CombatDsrcContainer;
import Kaiden.Game.Server.Combat.Player.PlayerCombatContainer;
import Kaiden.Game.Server.Combat.Player.TargetAuraContainer;
import Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine;
import Kaiden.Game.Server.Combat.Player.EnhancementProcAuras;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Game.Server.Combat.Player.CombatLockRegistry;
import Kaiden.Game.Server.Combat.Player.PotionAffectHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.ClassRank;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Server.Users.Utils.UserState;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import jdbchelper.NoResultException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class CombatAction extends ExternalPacketHandler {

    private static final double PVE_BASE_DODGE = 0.09D;
    private static final double GLANCE_CHANCE_ON_MISS = 0.18D;
    private static final double GLANCE_DAMAGE_MULT = 0.35D;
    private static final double DMG_VARIANCE_MIN = 0.92D;
    private static final double DMG_VARIANCE_MAX = 1.08D;
    private static final int AURA_APPLY_CHANCE_PERCENT = 100;

    private static final String PROP_VAMPIRE_BLOOD = "vampireBloodCharges";
    private static final int VAMPIRE_BLOOD_MAX = 10;

    /*
     * Class-specific AQW-style mechanics.
     * These IDs match the DB aura/skill rows we seeded for Arachnomancer and Undead Goat.
     */
    private static final int SKILL_ARACH_SPIDER_BITE = 152;
    private static final int AURA_ARACH_VENOM_FANGS = 152;
    private static final double ARACH_SPIDER_BITE_LIFESTEAL = 0.35D;

    private static final int SKILL_GOAT_FORAGE = 162;
    private static final int SKILL_GOAT_SCREAM = 163;
    private static final int SKILL_GOAT_HEADBUTT = 164;
    private static final int SKILL_GOAT_BONES_OF_STEEL = 165;
    private static final int SKILL_GOAT_STAMPEDE = 166;

    private static final int AURA_GOAT_GRASS_GATHERED = 160;
    private static final int AURA_GOAT_DOWNHILL_BATTLE = 162;
    private static final int AURA_GOAT_UPHILL_BATTLE = 163;
    private static final int AURA_GOAT_FENCED_OFF = 165;
    private static final int AURA_GOAT_FREE_RANGE = 167;
    private static final int AURA_GOAT_GOATED = 170;

    private static final double GOAT_STAMPEDE_DAMAGE_PER_GRASS_STACK = 0.10D;
    private static final double GOAT_FREE_RANGE_HEADBUTT_MULTIPLIER = 1.50D;
    private static final double GOAT_BONES_HEAL_PER_GRASS_STACK = 0.05D;
    private static final double GOAT_GOATED_PROC_CHANCE = 0.005D;

    private final Set<String> castAuraKeys = new HashSet<String>();
    private boolean goatGrassConsumedThisCast = false;
    private int goatGrassStacksThisCast = 0;

    protected enum DamageSchool {
        PHYSICAL, MAGICAL
    }

    protected void sendFxUser(User u, String effect, int on) {
        try {
            if (u == null) return;

            JSONObject affects = new JSONObject();
            affects.put("cmd", "fx");
            affects.put("targetType", "player");
            affects.put("target", u.getName());
            affects.put("on", String.valueOf(on));
            affects.put("anim", "none");
            affects.put("effect", String.valueOf(effect));

            Kaiden_Extension.getInstance().send(
                    affects,
                    Kaiden_Extension.getInstance().getZone().getRoom(u.getRoom()).getChannellList()
            );
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    protected void sendFxMonster(MonsterAI mon, String effect, int on) {
        try {
            if (mon == null || mon.getRoom() == null || mon.getMapMonster() == null) return;

            int monMapId = mon.getMapMonster().getMonMapId();

            JSONObject affects = new JSONObject();
            affects.put("cmd", "fx");
            affects.put("targetType", "monster");
            affects.put("target", String.valueOf(monMapId));
            affects.put("on", String.valueOf(on));
            affects.put("effect", String.valueOf(effect));
            affects.put("anim", "none");

            Kaiden_Extension.getInstance().send(affects, mon.getRoom().getChannellList());
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    @Override
    public void handle() throws RequestExternalPacketException {
        ReentrantLock combatLock = getCombatLock(this.user);
        long lockStart = System.nanoTime();
        // Never let a stalled action block every subsequent skill packet forever.
        // A timeout is diagnostic; we do not forcibly unlock another thread or
        // reset legitimate cooldown/stun state.
        boolean acquired;
        try {
            acquired = combatLock.tryLock(2L, TimeUnit.SECONDS);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            CombatTrace.warn("CombatAction.lock", "interrupted actor=" + CombatTrace.who(this.user));
            return;
        }
        if (!acquired) {
            CombatTrace.warn("CombatAction.lock", "timeoutMs=2000 actor=" + CombatTrace.who(this.user)
                    + " ownerLikelyStalled=true; inspect preceding action logs");
            return;
        }
        long lockWaitMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - lockStart);
        long actionStart = System.nanoTime();
        if (lockWaitMs >= 250L) {
            CombatTrace.warn("CombatAction.lock", "waitMs=" + lockWaitMs + " actor=" + CombatTrace.who(this.user));
        }
        try {
            handleSerialized();
        } finally {
            try {
                this.castAuraKeys.clear();
            } finally {
                long actionMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - actionStart);
                if (actionMs >= 250L) {
                    CombatTrace.warn("CombatAction.lock", "heldMs=" + actionMs + " actor=" + CombatTrace.who(this.user));
                }
                combatLock.unlock();
            }
        }
    }

    private void handleSerialized() throws RequestExternalPacketException {
        Integer actId = null;
        String[] targets = new String[0];
        State state = null;

        try {
            CombatTrace.info("CombatAction.handle", "start actor=" + CombatTrace.who(this.user) + ", raw=" + java.util.Arrays.toString(this.params));
            if (params == null || params.length < 2) {
                throw new RequestExternalPacketException("Combat packet missing action or targets");
            }
            actId = parseActionId(params[0]);

            String skillReference = getSkillReference(params[1]);
            String targetInfo = parseTargetInfo(params[1]);
            targets = targetInfo == null || targetInfo.trim().isEmpty()
                    ? new String[0] : targetInfo.split(",");

            state = requireUserState();
            if (state.isDead()) throw new RequestExternalPacketException("User is dead and cannot act.");

            ensureNoDuplicateTargets(targets);

            SkillBean skill = requireSkill(skillReference);

            if (PotionAffectHandler.isPotionSlot(skill)) {
                ItemBean equippedPotionItem = requireEquippedPotionItem(skill);
                if (PotionAffectHandler.handleDirectPotion(this.user, this.room, actId, skill, equippedPotionItem, targets)) {
                    CombatTrace.info("CombatAction.handle", "direct potion handled item=" + equippedPotionItem.getId() + ", skill=" + skill.getId());
                    return;
                }
                if (!PotionAffectHandler.consumeEquippedItem(this.user, equippedPotionItem)) {
                    Users.getInstance().log(this.user, "Packet Edit [Action]", "TurnIn failed when using potion/scroll item " + equippedPotionItem.getId() + ".");
                    throw new RequestExternalPacketException("TurnIn failed when using potion/scroll.");
                }
            }

            ZoneBean area = requireArea();
            CombatTrace.info("CombatAction.handle", "validated actId=" + actId + ", skill=" + skill.getReference() + "#" + skill.getId() + ", targets=" + java.util.Arrays.toString(targets) + ", " + CombatTrace.state(state));

            this.castAuraKeys.clear();
            this.goatGrassConsumedThisCast = false;
            this.goatGrassStacksThisCast = 0;
            processCombatAction(actId, skill, targets, state, area);
            CombatTrace.info("CombatAction.handle", "done actId=" + actId + ", skill=" + skill.getReference() + ", " + CombatTrace.state(state));
        } catch (RequestExternalPacketException e) {
            CombatTrace.error("CombatAction.handle.request", e);
            logCombatException("CombatAction.handle", e);
            if (actId != null) {
                sendSkillBlockedResponse(actId, targets, state);
                return;
            }
            throw e;
        } catch (Exception e) {
            CombatTrace.error("CombatAction.handle.exception", e);
            logCombatException("CombatAction.handle", e);
            if (actId != null) {
                sendSkillBlockedResponse(actId, targets, state);
                return;
            }
            throw new RequestExternalPacketException("Combat action failed: " + e.getMessage(), "" + e);
        }
    }

    private ReentrantLock getCombatLock(User user) {
        return CombatLockRegistry.get(this.room, user);
    }

    private void logCombatException(String context, Exception e) {
        try {
            CombatTrace.error(context, e);
            Log.error(context + " - " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()), e);
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[CombatDebug] exception: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    private int parseActionId(String param) throws RequestExternalPacketException {
        try {
            return Integer.parseInt(param);
        } catch (NumberFormatException e) {
            throw new RequestExternalPacketException("Invalid action ID");
        }
    }

    private State requireUserState() throws RequestExternalPacketException {
        State state = (State) this.user.properties.get("state");
        if (state == null) throw new RequestExternalPacketException("User state missing");
        return state;
    }

    private void ensureNoDuplicateTargets(String[] targets) throws RequestExternalPacketException {
        List<String> list = Arrays.asList(targets);
        Set<String> set = new HashSet<String>(list);
        if (set.size() < list.size()) {
            Users.getInstance().ban(this.user, "Packet Edit [gar]", "Hack detected.", 24);
            throw new RequestExternalPacketException("Duplicate targets detected - possible hack attempt");
        }
    }


    private ItemBean requireEquippedPotionItem(SkillBean skill) throws RequestExternalPacketException {
        if (this.params.length < 3 || this.params[2] == null || this.params[2].trim().isEmpty()) {
            throw new RequestExternalPacketException("Potion item ID missing.");
        }

        int itemId;
        try {
            itemId = Integer.parseInt(this.params[2]);
        } catch (Exception e) {
            throw new RequestExternalPacketException("Invalid potion item ID.");
        }

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item == null) {
            throw new RequestExternalPacketException("Potion item not found: " + itemId);
        }

        try {
            PotionAffectHandler.validateEquippedItem(this.user, skill, item);
        } catch (Exception e) {
            throw new RequestExternalPacketException(e.getMessage());
        }

        return item;
    }

    private SkillBean requireSkill(String skillReference) throws RequestExternalPacketException {
        try {
            @SuppressWarnings("unchecked")
            ConcurrentHashMap<String, Integer> skills =
                    (ConcurrentHashMap<String, Integer>) this.user.properties.get("skills");

            if (skills == null || !skills.containsKey(skillReference)) {
                throw new RequestExternalPacketException("Skill not found in user skills");
            }

            SkillBean skill = StorageCache.getInstance().getSkill(skills.get(skillReference));

            int classRank = ClassRank.getRankFromPoints((Integer) this.user.properties.get("cp"));
            if ((classRank < 2 && skill.getReference().equals("a2")) ||
                    (classRank < 3 && skill.getReference().equals("a3")) ||
                    (classRank < 5 && skill.getReference().equals("a4"))) {

                Users.getInstance().ban(
                        this.user,
                        "Packet Edit [Action]",
                        "Using a skill when designated rank is not yet achieved.",
                        6
                );
                throw new RequestExternalPacketException("Skill rank requirement not met");
            }

            return skill;
        } catch (NoResultException e) {
            throw new RequestExternalPacketException("Unassigned skill ID: " + skillReference);
        }
    }

    private ZoneBean requireArea() throws RequestExternalPacketException {
        String baseName = this.room.getName().split("-")[0];
        String mapName = baseName.equals("house") ? this.room.getName() : baseName;

        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area == null) throw new RequestExternalPacketException("Area not found: " + mapName);

        return area;
    }

    private void validateTargetAuras(SkillBean skill, String[] targets, ZoneBean area) throws RequestExternalPacketException {
        if (skill == null) return;

        Set<Integer> auraIds = new HashSet<Integer>();
        try {
            if (skill.auras != null) auraIds.addAll(skill.auras.keySet());
            if (skill.auraLinks != null) {
                for (SkillAuraBean link : skill.auraLinks) {
                    if (link != null && link.getAuraId() > 0) auraIds.add(link.getAuraId());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        if (skill.hasAuraId()) auraIds.add(skill.getAuraId());
        if (auraIds.isEmpty()) return;

        final int selfId = this.user.getUserId();
        final boolean isPvP = (area != null) && (area.isPvP() || area.isPK());

        boolean hasPlayerTarget = false;
        boolean hasMonsterTarget = false;
        boolean targetsIncludeSelf = false;

        for (String t : targets) {
            if (t == null || t.isEmpty()) continue;

            String[] sp = t.split(":");
            if (sp.length != 2) throw new RequestExternalPacketException("Bad target format: " + t);

            String kind = sp[0];
            int id;
            try {
                id = Integer.parseInt(sp[1]);
            } catch (Exception e) {
                throw new RequestExternalPacketException("Bad target id: " + t);
            }

            if ("p".equals(kind)) {
                hasPlayerTarget = true;
                if (id == selfId) targetsIncludeSelf = true;
            } else if ("m".equals(kind)) {
                hasMonsterTarget = true;
            } else {
                throw new RequestExternalPacketException("Unknown target kind: " + kind);
            }
        }

        for (int auraId : auraIds) {
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null) continue;

            if (aura.isSelfTarget()) continue;

            String cat = (aura.getCategory() == null) ? "" : aura.getCategory().trim().toLowerCase();
            if ("d".equals(cat)) cat = "dot";

            boolean isFriendly =
                    cat.equals("buff") || cat.equals("hot") || cat.equals("clean") || cat.equals("regen") || cat.equals("heal");

            boolean isHostile =
                    cat.equals("debuff") || cat.equals("dot") || cat.equals("stun") || cat.equals("stone") ||
                            cat.equals("freeze") || cat.equals("frozen") || cat.equals("disabled") || cat.equals("disable");

            if (!isFriendly && !isHostile) continue;

            if (isFriendly) {
                boolean fallbackToSelfAllowed = aura.isSelfTarget() || aura.isPlayerTarget() || aura.isOtherTarget();
                if (!hasPlayerTarget && !fallbackToSelfAllowed) {
                    throw new RequestExternalPacketException("Friendly aura requires a player target.");
                }
            }

            if (isHostile) {
                if (hasMonsterTarget) continue;

                if (hasPlayerTarget) {
                    if (!isPvP) throw new RequestExternalPacketException("Hostile aura cannot target players here.");
                    if (targetsIncludeSelf) throw new RequestExternalPacketException("Hostile aura cannot target self.");
                    continue;
                }

                throw new RequestExternalPacketException("Hostile aura requires a hostile target.");
            }
        }
    }

    private boolean canUseSkillOnMonster(SkillBean skill, MonsterAI monster) {
        String race = monster != null && monster.getMonster() != null ? monster.getMonster().getRace() : null;
        return StorageCache.getInstance().isSkillRaceAllowed(skill.getId(), race);
    }

    private void sendSkillBlockedResponse(int actId, String[] targets, State state) {
        try {
            JSONArray sarsa = new JSONArray();
            for (String target : targets) {
                JSONObject sarsaAction = new JSONObject();
                sarsaAction.put("cInf", "p:" + this.user.getUserId());
                sarsaAction.put("tInf", target);
                sarsaAction.put("a", new JSONArray());
                sarsaAction.put("actID", actId);
                sarsaAction.put("iRes", 0);
                sarsa.add(sarsaAction);
            }

            JSONObject ct = new JSONObject();
            ct.put("cmd", "ct");
            ct.put("m", new JSONObject());
            ct.put("a", new JSONArray());

            JSONObject players = new JSONObject();
            if (state != null) {
                players.put(this.user.getName(), state.getData());
            }
            ct.put("p", players);

            ct.put("anims", new JSONArray());
            ct.put("sarsa", sarsa);

            Kaiden_Extension.getInstance().send(ct, this.user);
        } catch (Exception failure) {
            CombatTrace.error("CombatAction.failedResponse", failure);
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[CombatDebug] failed-action response could not be sent: " + failure.getMessage());
        }
    }


    private String[] normalizeCombatTargets(SkillBean skill, String[] rawTargets) {
        if (rawTargets == null || rawTargets.length == 0) {
            return new String[]{"p:" + this.user.getUserId()};
        }

        String[] normalized = new String[rawTargets.length];
        boolean friendlyOrSelfSkill = isFriendlyTargetSkill(skill);

        for (int i = 0; i < rawTargets.length; i++) {
            String target = rawTargets[i] == null ? "" : rawTargets[i].trim();
            String lower = target.toLowerCase();

            if (target.length() == 0
                    || "s".equals(lower)
                    || "self".equals(lower)
                    || "f".equals(lower)
                    || "friend".equals(lower)
                    || "friendly".equals(lower)
                    || "ally".equals(lower)
                    || "allies".equals(lower)) {
                normalized[i] = "p:" + this.user.getUserId();
                continue;
            }

            if (friendlyOrSelfSkill && target.indexOf(':') < 0) {
                normalized[i] = "p:" + this.user.getUserId();
                continue;
            }

            normalized[i] = target;
        }

        return normalized;
    }

    private void processCombatAction(int actId, SkillBean skill, String[] targets, State state, ZoneBean area) throws Exception {
        CombatTrace.info("CombatAction.process", "begin actId=" + actId + ", skill=" + (skill == null ? "null" : skill.getReference()) + ", targetCount=" + (targets == null ? 0 : targets.length));

        targets = normalizeCombatTargets(skill, targets);

        EnhancementTraitEngine.tickUserTraitEffects(this.user);
        Stats stats = (Stats) this.user.properties.get("stats");
        @SuppressWarnings("unchecked")
        Set<RemoveAura> userAuras = (((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set<RemoveAura>) user.properties.get("auras"));
        @SuppressWarnings("unchecked")
        HashMap<Integer, MonsterAI> monsters = (HashMap<Integer, MonsterAI>) this.room.properties.get("monsters");

        JSONArray sarsa = new JSONArray();
        JSONObject ct = new JSONObject();

        JSONArray auraPackets = new JSONArray();
        JSONArray damagePackets = new JSONArray();

        JSONObject players = new JSONObject();
        JSONObject monstersJson = new JSONObject();

        String fromTarget = "p:" + user.getUserId();

        validateTargetAuras(skill, targets, area);
        enforceMonsterSkillRestrictions(skill, targets, state, area, monsters, actId);

        Set<String> failedTargets = new HashSet<String>();

        if(state.getMana() < 24) {
            state.increaseManaByPercent(0.15);
        }

        for (String t : targets) {
            try {
                CombatTrace.info("CombatAction.target", "start target=" + t + ", skill=" + (skill == null ? "null" : skill.getReference()));
                String[] splitTarget = t.split(":");
                if (splitTarget.length != 2) {
                    failedTargets.add(t);
                    continue;
                }

                String tgtType = splitTarget[0];
                int tgtId = Integer.parseInt(splitTarget[1]);

                if ("m".equals(tgtType)) {
                    processMonsterTarget(monsters, tgtId, skill, state, stats, userAuras, damagePackets, auraPackets, monstersJson, fromTarget, area);
                    triggerEnhancementTrait(skill, stats, state, t, damagePackets, auraPackets, players, monstersJson, area, monsters);
                    players.put(this.user.getName(), state.getData());
                } else if ("p".equals(tgtType)) {
                    processPlayerTarget(tgtId, skill, state, stats, userAuras, damagePackets, auraPackets, players, fromTarget, area);
                    triggerEnhancementTrait(skill, stats, state, t, damagePackets, auraPackets, players, monstersJson, area, monsters);
                    players.put(this.user.getName(), state.getData());
                } else {
                    failedTargets.add(t);
                    CombatTrace.warn("CombatAction.target", "unknown target type for " + t);
                    logCombatException("CombatAction.processCombatAction", new Exception("Unknown target type: " + tgtType));
                }
                CombatTrace.info("CombatAction.target", "done target=" + t + ", failed=" + failedTargets.contains(t));
            } catch (RequestExternalPacketException e) {
                failedTargets.add(t);
                CombatTrace.error("CombatAction.target.request target=" + t, e);
                logCombatException("CombatAction.processCombatAction", e);
            } catch (Exception e) {
                failedTargets.add(t);
                CombatTrace.error("CombatAction.target.exception target=" + t, e);
                logCombatException("CombatAction.processCombatAction", e);
            }
        }
        ////Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "under tgt");
        //state.decreaseMana(skill.getMana());

        for (String target : targets) {
            JSONObject sarsaAction = new JSONObject();
            sarsaAction.put("cInf", fromTarget);
            sarsaAction.put("tInf", target);
            sarsaAction.put("a", damagePackets);
            sarsaAction.put("actID", actId);
            sarsaAction.put("iRes", failedTargets.contains(target) ? 0 : 1);
            sarsa.add(sarsaAction);
        }

       // //Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "under tgts");
        //state.decreaseMana(skill.getMana());

        //if (!players.containsKey(this.user.getName())) players.put(this.user.getName(), state.getData());
        if (!players.containsKey(this.user.getName())) {
            players.put(this.user.getName(), state.getData());
        }

        cleanupStateTargets(state, monsters);

        //Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "under players");
        CombatTrace.info("CombatAction.process", "before mana spend " + CombatTrace.state(state) + ", manaCost=" + skill.getMana());
        state.decreaseMana(skill.getMana());
        CombatTrace.info("CombatAction.process", "after mana spend " + CombatTrace.state(state));

        if (state.isNeutral()) {
            state.setState(Properties.STATE_NORMAL);
        }

        // Always refresh caster state last so self/player aura casts keep the spent MP in ct.p
        players.put(this.user.getName(), state.getData());

        Users.getInstance().sendStatsIfDirty(this.user);
        for (String target : targets) {
            try {
                if (target != null && target.startsWith("p:")) {
                    User targetUser = ExtensionHelper.instance().getUserById(Integer.parseInt(target.substring(2)));
                    if (targetUser != null && targetUser != this.user) {
                        Users.getInstance().sendStatsIfDirty(targetUser);
                    }
                }
            } catch (Exception ignored) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] stats flush failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
            }
        }

        ct.put("m", monstersJson);
        ct.put("a", auraPackets);
        ct.put("p", players);
        ct.put("cmd", "ct");
        ct.put("anims", getAnims(skill, parseTargetInfo(this.params[1])));

        CombatTrace.info("CombatAction.process", "sending ct: players=" + players.size() + ", monsters=" + monstersJson.size() + ", auraPackets=" + auraPackets.size() + ", damagePackets=" + damagePackets.size() + ", sarsa=" + sarsa.size());
        if (area.isPvP() || area.isPK()) {
            ct.put("sarsa", sarsa);
            Kaiden_Extension.getInstance().sendToRoom(ct, this.user, this.room);
        } else {
            Kaiden_Extension.getInstance().sendToRoomButOne(ct, this.user, this.room);
            ct.put("sarsa", sarsa);
            Kaiden_Extension.getInstance().send(ct, this.user);
        }
        CombatTrace.info("CombatAction.process", "send complete actId=" + actId + ", failedTargets=" + failedTargets.size());

        //Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "after ct");
        //state.decreaseMana(skill.getMana());
    }

    private void enforceMonsterSkillRestrictions(SkillBean skill,
                                                 String[] targets,
                                                 State state,
                                                 ZoneBean area,
                                                 HashMap<Integer, MonsterAI> monsters,
                                                 int actId) throws RequestExternalPacketException {
        if (monsters == null) return;

        for (String target : targets) {
            String[] splitTarget = target.split(":");
            if (splitTarget.length != 2) continue;

            String tgtType = splitTarget[0];
            if (!"m".equals(tgtType)) continue;

            int tgtId = Integer.parseInt(splitTarget[1]);

            MonsterAI monster = monsters.get(tgtId);
            if (monster == null || monster.getState() == null) {
                // A client can still have a stale target for a monster that was
                // removed, died, or has not finished spawning. Do not abort the
                // entire combat packet here. processMonsterTarget() will mark
                // this individual target as failed and return iRes=0.
                CombatTrace.warn("CombatAction.restrictions",
                        "Skipping restriction check for missing monster target m:" + tgtId +
                        ", roomMonsterKeys=" + monsters.keySet());
                continue;
            }

            if (canUseSkillOnMonster(skill, monster)) continue;

            String required = StorageCache.getInstance().getSkillRequiredRaces(skill.getId());
            if (required.isEmpty()) required = "required race";

            Kaiden_Extension.getInstance().sendToUser(
                    "warning",
                    "Target is not a " + required + " !",
                    this.user
            );

            // Outer request handler sends the single failed-action response.
            throw new RequestExternalPacketException("Skill blocked for monster type.");
        }
    }

    private void processMonsterTarget(HashMap<Integer, MonsterAI> monsters,
                                      int tgtId,
                                      SkillBean skill,
                                      State state,
                                      Stats stats,
                                      Set<RemoveAura> userAuras,
                                      JSONArray damageArray,
                                      JSONArray auras,
                                      JSONObject monstersJson,
                                      String fromTarget,
                                      ZoneBean area) throws RequestExternalPacketException {

        MonsterAI monster = monsters.get(tgtId);
        if (monster == null || monster.getState() == null) {
            throw new RequestExternalPacketException("Monster target not found or invalid state");
        }

        monster.getState().addTarget(this.user.getUserId());
        state.addMonsterTarget(monster.getMapMonster().getMonMapId());

        MonsterDamageRoll roll = rollMonsterDamage(skill, monster, stats);
        roll.damage = applyPveBoosts(roll.damage, monster);
        roll.damage = applyUndeadGoatMonsterDamageModifiers(skill, state, monster, roll.damage);

        state.setState(2);

        if (monster.getState().hasAuras()) {
            roll.damage = Damage.evaluateAuras(
                    Damage.evaluateAuras(roll.damage, monster.getState().getAuras()),
                    userAuras
            );
        }

        boolean linkedDamageBlocked = !MonsterAI.canDamageMonster(monster);
        boolean typedSkillDamageBlocked = monster.blocksPlayerDamageWhileCastingTypedSkill();

        if (linkedDamageBlocked || typedSkillDamageBlocked) {
            roll.damage = 0;

            /*
             * Keep this as HIT instead of NONE so the existing client damage-number
             * renderer still displays a normal floating 0 on protected monsters.
             */
            roll.type = DamageType.HIT;

            if (linkedDamageBlocked) {
                maybeWarnLinkedBoss(monster, monsters);
            }
        } else {
            DamageSchool school = resolveDamageSchool(skill);
            roll.damage = applyUserOutgoingModifiers(stats, roll.damage, school);
            roll.damage = applyMonsterIncomingModifiers(monster, roll.damage, school);

            if (monster.isRegenImmune()) {
                roll.damage = 0;

                /*
                 * DamageType.NONE hides the client number. Use HIT so 0 is shown.
                 */
                roll.type = DamageType.HIT;
            } else if (!monster.getState().isDead()) {
                monster.getState().decreaseHealth(roll.damage);
                monster.getState().applyMonsterOnDamageTaken(roll.damage);
                applyAuraStealsOnHit(userAuras, roll.damage, false, null, area, damageArray);
                applyVampireBloodChargeOnHit(userAuras, roll.damage);
                applyVampireBloodNovaIfNeeded(monster, monsters, state, userAuras, roll.damage, damageArray, monstersJson);
                applyArachnomancerSpiderBiteLeech(skill, monster, state, roll.damage, damageArray);
                applyOnDamageTakenTriggers(monster.getState().getAuras(), roll.damage, monster.getState());
            }

            applyReflectIfNeeded(monster, tgtId, state, roll.damage, damageArray);
        }

        /*
         * Always send damage feedback.
         * If linked monsters are alive, this shows 0 damage on the protected monster.
         */
        damageArray.add(Damage.getDamageResult(fromTarget, "m:" + tgtId, roll.damage, roll.type));

        if (monster.getState().isDead()) {
            handleMonsterDeath(monster, state, area, auras);
            state.removeMonsterTarget(monster.getMapMonster().getMonMapId());
            Users.getInstance().sendUotls(this.user, false, false, false, false, false, false, true);

            monstersJson.accumulate(
                    String.valueOf(monster.getMapMonster().getMonMapId()),
                    monster.getState().getData().accumulate("targets", monster.getState().getTargets())
            );
            return;
        }

        if (monster.getState().isNeutral()) {
            monster.setAttacking(
                    Executor.getInstance().scheduleTask(
                            monster,
                            500,
                            monster.getMonster().getAttack(),
                            TimeUnit.MILLISECONDS,
                            true
                    )
            );
        }

        applySkillAurasForMonsterTarget(skill, monster, this.user, fromTarget, roll.damage, auras);
        applyOnDamageDealtTriggers(userAuras, roll.damage, state);
        consumeForceCritHitCounterIfNeeded(skill, state, userAuras, roll.damage, roll.type);

        monstersJson.accumulate(
                String.valueOf(monster.getMapMonster().getMonMapId()),
                monster.getState().getData().accumulate("targets", monster.getState().getTargets())
        );
    }

    private static final class MonsterDamageRoll {
        int damage;
        DamageType type;

        MonsterDamageRoll(int damage, DamageType type) {
            this.damage = damage;
            this.type = type;
        }
    }

    private MonsterDamageRoll rollMonsterDamage(SkillBean skill, MonsterAI monster, Stats stats) {
        if (Server.getInstance().getDamage() < 1) {
            Users.getInstance().clearAuras(this.user);
            try {
                immuneAura(monster, "p:" + this.user.getUserId());
            } catch (Exception ignored) {
            }
            return new MonsterDamageRoll(0, Damage.evaluateDamageType(0D, 1D, 0D));
        }

        Set<RemoveAura> activeAuras = getUserAuraSnapshot();
        DamageType type = CombatEvaluator.resolvePlayerVsMonster(this.user, monster, stats);
        if (isAutoAttackSkill(skill) && hasForceCritAura(activeAuras)
                && type != DamageType.MISS && type != DamageType.DODGE && type != DamageType.PARRY && type != DamageType.NONE) {
            type = DamageType.CRITICAL;
        }
        int dmg = calculateResolvedSkillAmount(stats, null, skill, type, false);
        return new MonsterDamageRoll(dmg, type);
    }


    private Set<RemoveAura> getUserAuraSnapshot() {
        try {
            State state = this.user != null && this.user.properties != null ? (State) this.user.properties.get("state") : null;
            if (state != null) return state.getAuras();
            @SuppressWarnings("unchecked")
            Set<RemoveAura> fallback = this.user != null && this.user.properties != null ? (Set<RemoveAura>) this.user.properties.get("auras") : null;
            return fallback != null ? new HashSet<RemoveAura>(fallback) : Collections.<RemoveAura>emptySet();
        } catch (Throwable ignored) {
            return Collections.<RemoveAura>emptySet();
        }
    }

    private boolean isAutoAttackSkill(SkillBean skill) {
        if (skill == null) return false;
        String ref = skill.getReference() == null ? "" : skill.getReference().trim().toLowerCase();
        String type = skill.getType() == null ? "" : skill.getType().trim().toLowerCase();
        return "aa".equals(ref) || "aa".equals(type);
    }

    private boolean hasForceCritAura(Set<RemoveAura> auraSet) {
        if (auraSet == null || auraSet.isEmpty()) return false;
        for (RemoveAura ra : auraSet) {
            if (ra != null && ra.isForceCrit()) return true;
        }
        return false;
    }

    private void consumeForceCritHitCounterIfNeeded(SkillBean skill, State state, Set<RemoveAura> auraSet, int damage, DamageType type) {
        if (!isAutoAttackSkill(skill) || state == null || auraSet == null || auraSet.isEmpty()) return;
        if (damage <= 0 || type == DamageType.MISS || type == DamageType.DODGE || type == DamageType.PARRY || type == DamageType.NONE) return;

        for (RemoveAura ra : new HashSet<RemoveAura>(auraSet)) {
            if (ra == null || !ra.isForceCrit() || !ra.hasHitCounter()) continue;

            int remaining = ra.decrementHitCounter();
            CombatTrace.info("CombatAction.forcecrit", "consumed hitcounter remaining=" + remaining + " " + CombatTrace.aura(ra));

            if (remaining <= 0) {
                try {
                    ra.run();
                } catch (Throwable runError) {
                    try { ra.cancel(); } catch (Throwable ignored) {}
                    try { state.removeAura(ra); } catch (Throwable ignored) {}
                }
                try { state.refreshCombatState(); } catch (Throwable ignored) {}
            }
            return;
        }
    }

    private int applyPveBoosts(int damage, MonsterAI monster) {
        try {
            double mult = BoostContainer.getInstance().validateBoost(this.user, monster, false);
            return (int) Math.round((double) damage * mult);
        } catch (Exception ignored) {
            return damage;
        }
    }

    private void maybeWarnLinkedBoss(MonsterAI monster, HashMap<Integer, MonsterAI> monsters) {
        try {
            int bossMonMapId = monster.getMapMonster().getMonMapId();

            @SuppressWarnings("unchecked")
            Set<Integer> warnedBosses = (Set<Integer>) this.user.properties.get("linkWarnedBosses");
            if (warnedBosses == null) {
                warnedBosses = Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());
                this.user.properties.put("linkWarnedBosses", warnedBosses);
            }

            if (warnedBosses.contains(bossMonMapId)) return;

            warnedBosses.add(bossMonMapId);

            String petName = "the linked monsters";
            MapMonsterBean mm = monster.getMapMonster();
            int groupId = mm.getLinkGroupId();

            if (groupId > 0 && monsters != null) {
                for (MonsterAI ai : monsters.values()) {
                    if (ai == null || ai.getMapMonster() == null) continue;
                    MapMonsterBean other = ai.getMapMonster();

                    if (other.getLinkGroupId() == groupId && !other.isLinkBoss()) {
                        if (ai.getMonster() != null) petName = ai.getMonster().getName();
                        break;
                    }
                }
            }

            Server.getInstance().sendServerNotifaction(
                    petName + " must be defeated before you are able to deal damage to " + monster.getMonster().getName(),
                    this.user
            );
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applyReflectIfNeeded(MonsterAI monster, int tgtId, State state, int damage, JSONArray damageArray) {
        try {
            double reflectPercent = monster.getState().getReflectPercent();
            if (reflectPercent <= 0.0D || damage <= 0) return;

            int reflected = (int) Math.max(1, Math.round(damage * reflectPercent));
            state.decreaseHealth(reflected);

            Object totalObj = this.user.properties.get("totalReflectedDamage");
            int totalReflected = (totalObj instanceof Integer) ? (Integer) totalObj : 0;
            totalReflected += reflected;
            this.user.properties.put("totalReflectedDamage", totalReflected);

            JSONObject o = new JSONObject();
            o.put("cmd", "reflectDamage");
            o.put("strText", "Reflected " + reflected + "! (Total: " + totalReflected + ")");
            Kaiden_Extension.getInstance().send(o, user);

            damageArray.add(
                    Damage.getDamageResult(
                            "m:" + tgtId,
                            "p:" + this.user.getUserId(),
                            reflected,
                            DamageType.HIT
                    )
            );
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void handleMonsterDeath(MonsterAI monster, State state, ZoneBean area, JSONArray auras) {
        if (monster == null || monster.getState() == null || monster.getMapMonster() == null) {
            return;
        }

        try {
            monster.getState().clearAuras();
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        try {
            if (area != null && area.isPvP()) {
                Rooms.getInstance().relayPvPEvent(monster, (Integer) this.user.properties.get("pvpteam"));
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        Set<Integer> monsterAurasTargets = new HashSet<Integer>(monster.getState().getTargets());
        int monMapId = monster.getMapMonster().getMonMapId();

        for (int userState : monsterAurasTargets) {
            try {
                User userTarget = ExtensionHelper.instance().getUserById(userState);
                if (userTarget != null) {
                    State targetState = (State) userTarget.properties.get("state");
                    if (targetState != null) {
                        targetState.removeMonsterTarget(monMapId);
                    }
                    Users.getInstance().sendUotls(userTarget, false, false, false, false, false, false, true);
                }
            } catch (Exception ignored) {
            }
        }

        try {
            monster.getState().clearTargets();
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        try {
            if (state != null) {
                state.refreshCombatState();
                state.removeMonsterTarget(monMapId);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        try {
            Users.getInstance().regen(this.user);
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applySkillAurasToMonster(SkillBean skill, MonsterAI monster, String fromTarget, int damage, JSONArray auras)
            throws RequestExternalPacketException {

        if (skill == null || monster == null || skill.auras == null || skill.auras.isEmpty()) return;

        User selfUser = ExtensionHelper.instance().getUserById(user.getUserId());

        java.util.Set<Integer> seenAuraIds = new java.util.HashSet<Integer>();
        for (Map.Entry<Integer, Integer> auraEntry : skill.auras.entrySet()) {
            int auraId = auraEntry.getKey();
            if (!seenAuraIds.add(auraId)) continue;
            AuraBean auraObj = StorageCache.getInstance().getAura(auraId);
            if (auraObj == null) continue;

            if (monster.getState().isAuraImmune(auraObj)) continue;

            JSONObject aj = null;

            if (auraObj.isSelfTarget() || auraObj.isPlayerTarget() || auraObj.isOtherTarget()) {
                aj = applyAura(selfUser, auraId, "p:" + user.getUserId(), Math.max(0, damage));
            } else {
                aj = applyAura(monster, auraId, fromTarget, Math.max(0, damage));
            }

            if (aj != null) auras.add(aj);
        }
    }

    private void processPlayerTarget(int tgtId,
                                     SkillBean skill,
                                     State state,
                                     Stats stats,
                                     Set<RemoveAura> userAuras,
                                     JSONArray damageArray,
                                     JSONArray auras,
                                     JSONObject players,
                                     String fromTarget,
                                     ZoneBean area) throws RequestExternalPacketException {


        User userTarget = ExtensionHelper.instance().getUserById(tgtId);
        if (userTarget == null) throw new RequestExternalPacketException("Player target not found");

        @SuppressWarnings("unchecked")
        Set<RemoveAura> targetAuras = (Set<RemoveAura>) userTarget.properties.get("auras");
        Stats targetStats = (Stats) userTarget.properties.get("stats");
        UserState targetState = (UserState) userTarget.properties.get("state");


        if (targetAuras == null || targetStats == null || targetState == null) {
            throw new RequestExternalPacketException("Target player missing properties");
        }

        DamageType type = CombatEvaluator.resolvePlayerVsPlayer(stats, targetStats);
        if (isAutoAttackSkill(skill) && hasForceCritAura(userAuras)
                && type != DamageType.MISS && type != DamageType.DODGE && type != DamageType.PARRY && type != DamageType.NONE) {
            type = DamageType.CRITICAL;
        }

        double scalar = skill.getDamage();
        boolean isHealScalar = scalar < 0;
        boolean isSelfCast = userTarget.getUserId() == this.user.getUserId();
        boolean isSelfHealthCost = isSelfCast && !isHealScalar && scalar > 0.0D && isFriendlyTargetSkill(skill);
        boolean isSupportOnly = isSupportOnlySkill(skill);

        // Self/friendly support skills are allowed to apply auras, but they should never
        // roll hostile damage into the caster. Real self-health-cost skills still hurt
        // the caster; they are normalized later so high enhancements cannot nuke the player.
        if (isSelfHealthCost) {
            isSupportOnly = false;
        } else if (isSelfCast && !isHealScalar && isSelfOrFriendlyAuraSkill(skill)) {
            isSupportOnly = true;
        }

        int amount = calculateResolvedSkillAmount(stats, targetState, skill, type, isHealScalar);
        amount = applyUndeadGoatSelfHealModifiers(skill, state, amount);
        if (isSupportOnly && !isHealScalar && !isSelfHealthCost) {
            amount = 0;
            type = DamageType.NONE;
        }

        if (area != null && (area.isPvP() || area.isPK())) {
            try {
                double mult = BoostContainer.getInstance().validateBoost(this.user, null, true);
                amount = (int) Math.round((double) amount * mult);
            } catch (Exception ignored) {
            }
        }

        amount = Damage.evaluateAuras(
                Damage.evaluateAuras(amount, userAuras),
                targetAuras
        );

        if (!isHealScalar && amount > 0) {
            DamageSchool school = resolveDamageSchool(skill);
            amount = applyUserOutgoingModifiers(stats, amount, school);
            amount = applyTargetIncomingModifiers(targetStats, targetState, amount, school);
        } else if (isHealScalar && amount > 0) {
            amount = applyHealingModifiers(stats, targetStats, amount);
        }

        if (isSelfHealthCost && amount > 0) {
            amount = normalizeSelfHealthCost(amount, state);
            if (amount <= 0) type = DamageType.NONE;
        }

        if (targetState.onCombat() || targetState.isNeutral()) {
            if (!isHealScalar && !isSupportOnly && userTarget != user) {
                state.addPlayerTarget(userTarget.getName());
            } else {
                state.refreshCombatState();
            }

            if (!targetState.isDead()) {
                if (isHealScalar) {
                    User maybeTarget = userTarget;
                    if (maybeTarget == null || !EnhancementTraitEngine.hasUserEffect(maybeTarget, "decay")) {
                        targetState.increaseHealth(amount);
                    } else {
                        amount = 0;
                    }
                } else if (!isSupportOnly && (!isSelfCast || isSelfHealthCost)) {
                    targetState.decreaseHealth(amount);
                }

                if (!isHealScalar && !isSupportOnly && amount > 0 && !isSelfHealthCost) {
                    applyAuraStealsOnHit(userAuras, amount, true, targetState, area, damageArray);
                    applyVampireBloodChargeOnHit(userAuras, amount);
                    applyOnDamageTakenTriggers(targetAuras, amount, targetState);
                    applyOnDamageDealtTriggers(userAuras, amount, state);
                }
            }

            if (targetState.isDead()) {
                state.removePlayerTarget(userTarget.getName());
                Users.getInstance().sendUotls(this.user, false, false, false,false, false, false, true);

                incrementPlayerKillDeathInMemory(this.user, userTarget);

                if (area != null && (area.isPvP() || area.isPK())) {
                    handlePvPKill(userTarget, area);
                }
            }
        }

        if (isSupportOnly && !isHealScalar && !isSelfHealthCost) {
            amount = 0;
        }

        int reportHp = isHealScalar ? -amount : amount;
        if (reportHp != 0) type = DamageType.HIT;
        else type = DamageType.NONE;

        if (area != null && area.isPvP()) {
        } else if (!isHealScalar && !isSupportOnly && amount > 0 && !this.user.getName().equals(userTarget.getName())) {
            amount = 0;
            reportHp = 0;
            type = DamageType.NONE;
        }

        consumeForceCritHitCounterIfNeeded(skill, state, userAuras, amount, type);
        applySkillAurasForPlayerTarget(skill, userTarget, fromTarget, amount, auras);

        if (userTarget.getUserId() == this.user.getUserId()) {
            players.put(this.user.getName(), state.getData());
        }
        players.put(userTarget.getName(), targetState.getData());
        damageArray.add(Damage.getDamageResult(fromTarget, "p:" + tgtId, reportHp, type));
    }


    private int normalizeSelfHealthCost(int amount, State state) {
        if (amount <= 0 || state == null) return 0;

        int maxHealth = Math.max(1, state.getMaxHealth());
        int currentHealth = Math.max(0, state.getHealth());

        /*
         * Self-cost skills like Stiletto should still hurt the caster, but only as
         * a controlled blood/health payment. Use a small percent of the resolved
         * skill damage instead of letting enhancement/crit/aura scaling take huge
         * chunks of HP.
         *
         * Balance target:
         * - about 10% of the skill's resolved damage
         * - at least 2% max HP when the player has enough HP
         * - never more than 12% max HP per cast
         * - never kills the caster by itself
         */
        int percentOfDamage = Math.max(1, (int) Math.round((double) amount * 0.10D));
        int minHpCost = Math.max(1, (int) Math.round((double) maxHealth * 0.02D));
        int maxHpCap = Math.max(1, (int) Math.round((double) maxHealth * 0.12D));

        int safeAmount = Math.max(minHpCost, percentOfDamage);
        safeAmount = Math.min(safeAmount, maxHpCap);

        if (currentHealth > 1) {
            safeAmount = Math.min(safeAmount, currentHealth - 1);
        } else {
            safeAmount = 0;
        }

        return Math.max(0, safeAmount);
    }

    private void handlePvPKill(User userTarget, ZoneBean area) {
        if (this.room.getName().startsWith("duel") || this.room.getName().startsWith("doomarena")) {
            Rooms.getInstance().addPvPScore(this.room, 1000, (Integer) this.user.properties.get("pvpteam"));
        } else {
            int levelDiff = (Integer) userTarget.properties.get(Properties.LEVEL) -
                    (Integer) this.user.properties.get(Properties.LEVEL);

            if (levelDiff > 30) Rooms.getInstance().addPvPScore(this.room, 600, (Integer) this.user.properties.get("pvpteam"));
            else if (levelDiff > 20) Rooms.getInstance().addPvPScore(this.room, 400, (Integer) this.user.properties.get("pvpteam"));
            else if (levelDiff > 10) Rooms.getInstance().addPvPScore(this.room, 200, (Integer) this.user.properties.get("pvpteam"));
            else Rooms.getInstance().addPvPScore(this.room, 150, (Integer) this.user.properties.get("pvpteam"));
        }
    }

    private JSONArray getAnims(SkillBean skill, String tInf) throws RequestExternalPacketException {
        JSONArray animations = new JSONArray();
        JSONObject anim = new JSONObject();

        anim.put("strFrame", this.user.properties.get("frame"));
        String fx = skill.getEffects() == null ? "" : skill.getEffects();
        String strl = skill.getStrl() == null ? "" : skill.getStrl();

        anim.put("fx", fx);
        anim.put("tInf", tInf);
        anim.put("cInf", "p:" + this.user.getUserId());
        anim.put("animStr", skill.getAnimation() == null ? "" : skill.getAnimation());

        if (strl.length() > 0 && !"none".equalsIgnoreCase(strl)) {
            anim.put("strl", strl);
        }

        animations.add(anim);
        return animations;
    }


    private boolean registerAuraCastKey(String targetInf, int auraId, String fromTarget) {
        String key = (fromTarget == null ? "" : fromTarget.trim().toLowerCase()) + "|"
                + (targetInf == null ? "" : targetInf.trim().toLowerCase()) + "|"
                + auraId;
        return this.castAuraKeys.add(key);
    }

    private JSONObject applyAura(MonsterAI ai, int auraId, String fromTarget, int damage) throws RequestExternalPacketException {
        try {
            String targetInf = ai != null && ai.getMapMonster() != null ? ("m:" + ai.getMapMonster().getMonMapId()) : "";
            if (!registerAuraCastKey(targetInf, auraId, fromTarget)) {
                CombatTrace.warn("CombatAction.applyAuraMonster", "duplicate cast key blocked target=" + targetInf + ", auraId=" + auraId + ", from=" + fromTarget);
                return null;
            }
            CombatTrace.info("CombatAction.applyAuraMonster", "target=" + targetInf + ", auraId=" + auraId + ", from=" + fromTarget + ", damage=" + damage);
            return TargetAuraContainer.getInstance().applyAuraToMonster(ai, auraId, fromTarget, damage);
        } catch (Exception e) {
            logCombatException("CombatAction.applyAuraMonster", e);
            return null;
        }
    }

    private JSONObject immuneAura(MonsterAI ai, String fromTarget) throws RequestExternalPacketException {
        return null;
    }

    private JSONObject applyAura(User userTgt, int auraId, String fromTarget, int damage) throws RequestExternalPacketException {
        try {
            String targetInf = userTgt != null ? ("p:" + userTgt.getUserId()) : "";
            if (!registerAuraCastKey(targetInf, auraId, fromTarget)) {
                CombatTrace.warn("CombatAction.applyAuraUser", "duplicate cast key blocked target=" + targetInf + ", auraId=" + auraId + ", from=" + fromTarget);
                return null;
            }
            AuraBean auraObj = StorageCache.getInstance().getAura(auraId);
            if (EnhancementTraitEngine.blocksAuraOnUser(userTgt, auraObj)) {
                CombatTrace.warn("CombatAction.applyAuraUser", "blocked by enhancement target=" + targetInf + ", auraId=" + auraId);
                return null;
            }
            CombatTrace.info("CombatAction.applyAuraUser", "target=" + targetInf + ", auraId=" + auraId + ", from=" + fromTarget + ", damage=" + damage);
            return TargetAuraContainer.getInstance().applyAuraToUser(userTgt, auraId, fromTarget, damage);

        } catch (Exception e) {
            logCombatException("CombatAction.applyAuraUser", e);
            return null;
        }
    }

    private JSONObject immuneAura(User userTgt, String fromTarget) {
        return null;
    }

    private String getSkillReference(String str) {
        return str.contains(",") ? str.split(",")[0].split(">")[0] : str.split(">")[0];
    }

    private String parseTargetInfo(String str) {
        StringBuilder tb = new StringBuilder();
        if (str.contains(",")) {
            String[] multi = str.split(",");
            for (int i = 0; i < multi.length; ++i) {
                if (i != 0) tb.append(",");
                tb.append(multi[i].split(">")[1]);
            }
        } else {
            tb.append(str.split(">")[1]);
        }
        return tb.toString();
    }

    private static boolean rollAuraChance(AuraBean aura) {
        double chance = 1.0D;

        try {
            if (aura != null) {
                chance = aura.getAuraChance();
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[CombatDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }

        if (chance >= 1.0D) return true;
        if (chance <= 0.0D) return false;

        return Math.random() < chance;
    }

    private void applyAuraStealsOnHit(Set<RemoveAura> attackerAuras,
                                      int damageDealt,
                                      boolean targetIsPlayer,
                                      UserState targetState,
                                      ZoneBean area,
                                      JSONArray damageArray) {
        State state = (State) this.user.properties.get("state");
        if (damageDealt <= 0 || attackerAuras == null || attackerAuras.isEmpty()) return;

        if (targetIsPlayer) {
            if (area == null || !(area.isPvP() || area.isPK())) {
                return;
            }
        }

        double lifePct = getTotalAuraEffectValue(attackerAuras, "lifesteal");
        double manaPct = 0.0D;

        for (RemoveAura ra : attackerAuras) {
            if (ra == null) continue;
            AuraBean a = ra.getAura();
            if (a == null) continue;

            try {
                if (a.getLifeSteal() > 0.0D) lifePct += a.getLifeSteal();
                if (a.getManaSteal() > 0.0D) manaPct += a.getManaSteal();
            } catch (Exception ignored) {
            }
        }

        lifePct = clamp(lifePct, 0.0D, 1.0D);
        manaPct = clamp(manaPct, 0.0D, 1.0D);

        int heal = 0;
        if (lifePct > 0.0D && state != null) {
            // Lifesteal should feel useful, but not scale out of control with high
            // enhancements, crit multipliers, Blood Pact, or Lord of the Night.
            // Use a softened damage basis and hard-cap each hit at 8% max HP.
            int softDamageBasis = (int) Math.max(1, Math.round(damageDealt * 0.35D));
            int rawHeal = (int) Math.round(softDamageBasis * lifePct);
            int perHitCap = (int) Math.max(25, Math.round(state.getMaxHealth() * 0.08D));
            heal = Math.max(0, Math.min(rawHeal, perHitCap));
        }
        int mana = (manaPct > 0.0D) ? (int) Math.round(damageDealt * manaPct) : 0;

        if (heal > 0) {
            /*
             * Lifesteal heals the caster from damage already dealt.
             * Monster targets do not have a UserState, so never touch targetState
             * unless this was a PvP/player target. The old path threw a
             * NullPointerException on monster hits while Vampiric Feast /
             * Lord of the Night was active.
             */
            if (targetIsPlayer && targetState != null) {
                targetState.decreaseHealth(heal);
            }

            state.increaseHealth(heal);

            if (damageArray != null) {
                damageArray.add(
                        Damage.getDamageResult(
                                "p:" + this.user.getUserId(),
                                "p:" + this.user.getUserId(),
                                -heal,
                                DamageType.HIT
                        )
                );
            }
        }

        if (mana > 0) {
            state.increaseMana(mana);

            if (targetIsPlayer && targetState != null) {
                targetState.decreaseMana(mana);
            }
        }
    }


    private double normalizeVampireEffectValue(double value) {
        if (Math.abs(value) > 1.0D) return value / 100.0D;
        return value;
    }

    private double getTotalAuraEffectValue(Set<RemoveAura> auraSet, String effectKey) {
        if (auraSet == null || auraSet.isEmpty() || effectKey == null) return 0.0D;
        double total = 0.0D;
        for (RemoveAura ra : auraSet) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura.effects == null || aura.effects.isEmpty()) continue;
            for (int effectId : aura.effects) {
                try {
                    AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                    if (ae == null || ae.getStat() == null) continue;
                    if (!effectKey.equalsIgnoreCase(ae.getStat().trim())) continue;
                    double v = normalizeVampireEffectValue(ae.getValue());
                    if ("-".equals(ae.getType())) total -= v;
                    else total += Math.abs(v);
                } catch (Exception ignored) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[Vampire] effect read failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
                }
            }
        }
        return Math.max(0.0D, total);
    }

    private void applyVampireBloodChargeOnHit(Set<RemoveAura> attackerAuras, int damageDealt) {
        if (damageDealt <= 0) return;
        double bloodGain = getTotalAuraEffectValue(attackerAuras, "blood");
        if (bloodGain <= 0.0D) return;

        int gain = Math.max(1, (int) Math.round(bloodGain));
        Object curObj = this.user.properties.get(PROP_VAMPIRE_BLOOD);
        int current = (curObj instanceof Integer) ? (Integer) curObj : 0;
        int next = Math.min(VAMPIRE_BLOOD_MAX, current + gain);
        this.user.properties.put(PROP_VAMPIRE_BLOOD, next);

        if (next != current) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[Vampire] " + this.user.getName() + " Blood Charges " + current + " -> " + next + "/" + VAMPIRE_BLOOD_MAX);
        }
    }

    private void applyVampireBloodNovaIfNeeded(MonsterAI primaryTarget,
                                               HashMap<Integer, MonsterAI> monsters,
                                               State casterState,
                                               Set<RemoveAura> attackerAuras,
                                               int damageDealt,
                                               JSONArray damageArray,
                                               JSONObject monstersJson) {
        if (primaryTarget == null || monsters == null || casterState == null || damageDealt <= 0) return;
        double novaPct = getTotalAuraEffectValue(attackerAuras, "bloodnova");
        if (novaPct <= 0.0D) return;

        int novaDamage = (int) Math.max(1, Math.round(damageDealt * novaPct));
        int hitCount = 0;
        for (MonsterAI other : monsters.values()) {
            if (other == null || other == primaryTarget || other.getState() == null || other.getMapMonster() == null) continue;
            if (other.getState().isDead()) continue;
            if (!MonsterAI.canDamageMonster(other) || other.isRegenImmune()) continue;

            int finalDamage = applyIncomingMonsterModifiers(other, novaDamage);
            other.getState().decreaseHealth(finalDamage);
            other.getState().applyMonsterOnDamageTaken(finalDamage);
            other.getState().addTarget(this.user.getUserId());

            damageArray.add(Damage.getDamageResult(
                    "p:" + this.user.getUserId(),
                    "m:" + other.getMapMonster().getMonMapId(),
                    finalDamage,
                    DamageType.HIT
            ));

            if (other.getState().isDead()) {
                handleMonsterDeath(other, casterState, requireAreaSafe(), new JSONArray());
                casterState.removeMonsterTarget(other.getMapMonster().getMonMapId());
            }

            monstersJson.accumulate(
                    String.valueOf(other.getMapMonster().getMonMapId()),
                    other.getState().getData().accumulate("targets", other.getState().getTargets())
            );

            hitCount++;
            if (hitCount >= 3) break;
        }

        if (hitCount > 0) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[Vampire] Blood Nova hit " + hitCount + " extra monster(s) for " + novaDamage + " base damage.");
        }
    }

    private ZoneBean requireAreaSafe() {
        try {
            return requireArea();
        } catch (Exception ignored) {
            return null;
        }
    }

    private int applyUserOutgoingModifiers(Stats stats, int amount, DamageSchool school) {
        if (stats == null || amount <= 0) return amount;
        double out = Math.max(0.05D, stats.get$outdmg());
        double typed = 1.0D;
        if (school == DamageSchool.MAGICAL) typed = Math.max(0.05D, stats.get$cmo());
        else typed = Math.max(0.05D, stats.get$cpo());
        return (int) Math.max(0, Math.round(amount * out * typed));
    }

    private int applyHealingModifiers(Stats casterStats, Stats targetStats, int amount) {
        if (amount <= 0) return amount;
        double out = 1.0D;
        double in = 1.0D;
        if (casterStats != null) out = Math.max(0.05D, casterStats.get$cho());
        if (targetStats != null) in = Math.max(0.05D, targetStats.get$chi());
        return (int) Math.max(0, Math.round(amount * out * in));
    }

    private DamageSchool resolveDamageSchool(SkillBean skill) {
        if (skill == null) return DamageSchool.PHYSICAL;
        String ref = skill.getReference() == null ? "" : skill.getReference().trim().toLowerCase();
        String type = skill.getType() == null ? "" : skill.getType().trim().toLowerCase();
        String fx = skill.getEffects() == null ? "" : skill.getEffects().trim().toLowerCase();
        if (ref.contains("spell") || ref.contains("magic") || ref.contains("cast") || type.contains("magic") || fx.contains("magic")) {
            return DamageSchool.MAGICAL;
        }
        return DamageSchool.PHYSICAL;
    }

    private int applyMonsterIncomingModifiers(MonsterAI monster, int amount, DamageSchool school) {
        if (monster == null || monster.getState() == null || amount <= 0) return amount;
        MonsterState state = monster.getState();
        double incomingMod = state.getMonsterIncDmg();
        double incomingMultiplier = Math.max(0.05D, 1.0D + incomingMod);
        double typedResist = (school == DamageSchool.MAGICAL) ? state.getMonsterMagRes() : state.getMonsterPhysRes();
        double resistTotal = clamp(state.getMonsterAllRes() + typedResist, 0.0D, 0.80D);

        double adjusted = amount * incomingMultiplier;
        if (state.hasAura(EnhancementProcAuras.AWE_BLAST)) {
            adjusted *= 1.15D;
        }
        int arcanaStacks = state.getAuraStackCount(EnhancementProcAuras.ARCANAS_CONCERTO);
        if (arcanaStacks > 0) {
            adjusted *= (1.0D + (Math.min(11, arcanaStacks) * 0.02D));
        }
        adjusted *= (1.0D - resistTotal);
        int finalAmount = (int) Math.max(0, Math.round(adjusted));

        if (state.getCurrentShield() <= 0 && state.getMonsterShieldValue() > 0.0D) {
            state.setCurrentShield((int) Math.max(0, Math.round(state.getMonsterShieldValue())));
        }
        return state.absorbShield(finalAmount);
    }


    public int applyTraitIncomingMonsterModifiers(MonsterAI monster, int amount) {
        return applyIncomingMonsterModifiers(monster, amount);
    }

    public void handleTraitMonsterDeath(MonsterAI monster, State casterState, ZoneBean area, JSONArray auras) {
        handleMonsterDeath(monster, casterState, area, auras == null ? new JSONArray() : auras);
    }

    public ZoneBean requireTraitAreaSafe() {
        return requireAreaSafe();
    }

    private int applyIncomingMonsterModifiers(MonsterAI monster, int amount) {
        if (monster == null || amount <= 0) return amount;
        DamageSchool school = DamageSchool.PHYSICAL;
        try {
            return applyMonsterIncomingModifiers(monster, amount, school);
        } catch (Exception ignored) {
            return Math.max(0, amount);
        }
    }

    private int applyTargetIncomingModifiers(Stats targetStats, State targetState, int amount, DamageSchool school) {
        if (targetStats == null || amount <= 0) return amount;

        double incoming = Math.max(0.05D, targetStats.get$incdmg());
        double typedResist = 0.0D;
        if (school == DamageSchool.MAGICAL) typedResist = targetStats.get$magres();
        else typedResist = targetStats.get$physres();

        double resistTotal = clamp(targetStats.get$allres() + typedResist, 0.0D, 0.80D);
        double adjusted = amount * incoming;
        User targetUser = null;
        try { if (targetState instanceof UserState) targetUser = ((UserState) targetState).getUser(); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        if (targetState != null && targetState.hasAura(EnhancementProcAuras.AWE_BLAST)) {
            adjusted *= 1.15D;
        }
        int arcanaStacks = targetState != null ? targetState.getAuraStackCount(EnhancementProcAuras.ARCANAS_CONCERTO) : 0;
        if (arcanaStacks > 0) {
            adjusted *= (1.0D + (Math.min(11, arcanaStacks) * 0.02D));
        }
        adjusted *= (1.0D - resistTotal);

        int finalAmount = (int) Math.max(0, Math.round(adjusted));
        if (targetState != null) {
            finalAmount = targetState.absorbShield(finalAmount);
        } else {
            double shield = Math.max(0.0D, targetStats.get$shield());
            if (shield > 0.0D) finalAmount = (int) Math.max(0, Math.round(finalAmount - shield));
        }
        return finalAmount;
    }

    private void applyOnDamageTakenTriggers(Set<RemoveAura> targetAuras, int damageDealt, State recipientState) {
        if (damageDealt <= 0 || targetAuras == null || targetAuras.isEmpty()) return;

        State state = recipientState;
        if (state == null) return;

        double manaGain = 0.0D;
        for (RemoveAura ra : targetAuras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            String cat = aura.getCategory() == null ? "" : aura.getCategory().trim().toLowerCase();
            if (!("trigger_ondamagetaken".equals(cat) || "manafeed".equals(cat))) continue;

            if (aura.effects != null) {
                for (int effectId : aura.effects) {
                    try {
                        AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                        if (ae != null && "manaret".equalsIgnoreCase(ae.getStat())) {
                            if ("+".equals(ae.getType())) manaGain += ae.getValue();
                            else if ("-".equals(ae.getType())) manaGain -= ae.getValue();
                            else manaGain += ae.getValue();
                        }
                    } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                }
            }
        }

        if (manaGain > 0.0D) {
            int mana = (int) Math.max(1, Math.round(damageDealt * manaGain));
            state.increaseMana(mana);
        }
    }

    private void applyOnDamageDealtTriggers(Set<RemoveAura> attackerAuras, int damageDealt, State attackerState) {
        if (damageDealt <= 0 || attackerAuras == null || attackerAuras.isEmpty() || attackerState == null) return;
        double manaGain = 0.0D;
        for (RemoveAura ra : attackerAuras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            String cat = aura.getCategory() == null ? "" : aura.getCategory().trim().toLowerCase();
            if (!"trigger_ondamagedealt".equals(cat)) continue;
            if (aura.effects == null) continue;
            for (int effectId : aura.effects) {
                try {
                    AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                    if (ae != null && "manaret".equalsIgnoreCase(ae.getStat())) {
                        manaGain += Math.abs(ae.getValue() > 1.0D ? ae.getValue() / 100.0D : ae.getValue());
                    }
                } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
            }
        }
        if (manaGain > 0.0D) {
            attackerState.increaseMana((int) Math.max(1, Math.round(damageDealt * manaGain)));
        }
    }

    private boolean isSkill(SkillBean skill, int skillId) {
        return skill != null && skill.getId() == skillId;
    }

    private int getAuraStackCountSafe(State state, int auraId) {
        if (state == null) return 0;
        try {
            return Math.max(0, state.getAuraStackCount(auraId));
        } catch (Throwable t) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[ClassSpecial] stack read failed aura=" + auraId + ": " + t.getMessage());
            return state.hasAura(auraId) ? 1 : 0;
        }
    }

    private void removeAuraByIdSafe(State state, int auraId) {
        if (state == null || auraId <= 0) return;
        try {
            for (RemoveAura ra : state.getAuras()) {
                if (ra == null || ra.getAura() == null || ra.getAura().getId() != auraId) continue;
                try {
                    ra.run();
                } catch (Throwable runError) {
                    try { ra.cancel(); } catch (Throwable ignored) {}
                    try { state.removeAura(ra); } catch (Throwable ignored) {}
                }
            }
            state.refreshCombatState();
        } catch (Throwable t) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[ClassSpecial] aura remove failed aura=" + auraId + ": " + t.getMessage());
        }
    }

    private int consumeAuraStacksSafe(State state, int auraId) {
        int stacks = getAuraStackCountSafe(state, auraId);
        if (stacks > 0) {
            removeAuraByIdSafe(state, auraId);
        }
        return stacks;
    }

    private void applyArachnomancerSpiderBiteLeech(SkillBean skill,
                                                   MonsterAI monster,
                                                   State casterState,
                                                   int damageDealt,
                                                   JSONArray damageArray) {
        if (!isSkill(skill, SKILL_ARACH_SPIDER_BITE)) return;
        if (monster == null || monster.getState() == null) return;
        if (casterState == null || damageDealt <= 0) return;
        if (!monster.getState().hasAura(AURA_ARACH_VENOM_FANGS)) return;

        int heal = (int) Math.max(1, Math.round(damageDealt * ARACH_SPIDER_BITE_LIFESTEAL));
        casterState.increaseHealth(heal);

        if (damageArray != null) {
            damageArray.add(Damage.getDamageResult(
                    "p:" + this.user.getUserId(),
                    "p:" + this.user.getUserId(),
                    -heal,
                    DamageType.HIT
            ));
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "[Arachnomancer] Spider Bite siphoned " + heal + " HP from Venom Fangs."
        );
    }

    private int applyUndeadGoatMonsterDamageModifiers(SkillBean skill, State casterState, MonsterAI monster, int damage) {
        if (skill == null || casterState == null || damage <= 0) return damage;

        if (isSkill(skill, SKILL_GOAT_STAMPEDE)) {
            if (!this.goatGrassConsumedThisCast) {
                this.goatGrassStacksThisCast = consumeAuraStacksSafe(casterState, AURA_GOAT_GRASS_GATHERED);
                this.goatGrassConsumedThisCast = true;
            }
            if (this.goatGrassStacksThisCast > 0) {
                double mult = 1.0D + (Math.min(8, this.goatGrassStacksThisCast) * GOAT_STAMPEDE_DAMAGE_PER_GRASS_STACK);
                int adjusted = (int) Math.max(1, Math.round(damage * mult));
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "green",
                        "[UndeadGoat] Goat Stampede consumed Grass=" + this.goatGrassStacksThisCast + ", damage " + damage + " -> " + adjusted
                );
                return adjusted;
            }
        }

        if (isSkill(skill, SKILL_GOAT_HEADBUTT) && casterState.hasAura(AURA_GOAT_FREE_RANGE)) {
            int adjusted = (int) Math.max(1, Math.round(damage * GOAT_FREE_RANGE_HEADBUTT_MULTIPLIER));
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[UndeadGoat] Free Range empowered Headbutt " + damage + " -> " + adjusted
            );
            return adjusted;
        }

        return damage;
    }

    private int applyUndeadGoatSelfHealModifiers(SkillBean skill, State casterState, int currentHeal) {
        if (!isSkill(skill, SKILL_GOAT_BONES_OF_STEEL)) return currentHeal;
        if (casterState == null) return currentHeal;

        int grassStacks = consumeAuraStacksSafe(casterState, AURA_GOAT_GRASS_GATHERED);
        removeAuraByIdSafe(casterState, AURA_GOAT_FREE_RANGE);

        int grassHeal = 0;
        if (grassStacks > 0) {
            grassHeal = (int) Math.max(1, Math.round(casterState.getMaxHealth() * GOAT_BONES_HEAL_PER_GRASS_STACK * Math.min(8, grassStacks)));
        }

        int finalHeal = Math.max(currentHeal, grassHeal);
        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "[UndeadGoat] Bones of Steel consumed Grass=" + grassStacks + ", heal=" + finalHeal + ", Free Range removed."
        );
        return finalHeal;
    }

    private boolean shouldApplyClassSpecialAuraLink(SkillBean skill, AuraBean aura, State selfState) {
        if (skill == null || aura == null) return true;
        int skillId = skill.getId();
        int auraId = aura.getId();
        boolean freeRange = selfState != null && selfState.hasAura(AURA_GOAT_FREE_RANGE);

        if (skillId == SKILL_GOAT_SCREAM) {
            if (auraId == AURA_GOAT_DOWNHILL_BATTLE) return !freeRange;
            if (auraId == AURA_GOAT_UPHILL_BATTLE) return freeRange;
        }

        if (skillId == SKILL_GOAT_HEADBUTT) {
            if (auraId == AURA_GOAT_FENCED_OFF) return !freeRange;
        }

        return true;
    }

    private void applyUndeadGoatGoatedProcIfNeeded(SkillBean skill,
                                                   User selfUser,
                                                   String fromTarget,
                                                   int damage,
                                                   JSONArray auras) throws RequestExternalPacketException {
        if (!isSkill(skill, SKILL_GOAT_FORAGE)) return;
        if (selfUser == null) return;

        State selfState = (State) selfUser.properties.get("state");
        if (selfState == null || selfState.isDead()) return;
        if (selfState.hasAura(AURA_GOAT_GOATED)) return;
        if (Math.random() > GOAT_GOATED_PROC_CHANCE) return;

        JSONObject aj = applyAura(selfUser, AURA_GOAT_GOATED, fromTarget, Math.max(0, damage));
        if (aj != null && auras != null) auras.add(aj);

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "gold",
                "[UndeadGoat] Invinciberry found! Goated applied."
        );
    }

    private void applySkillAurasForMonsterTarget(SkillBean skill, MonsterAI monster, User selfUser, String fromTarget, int damage, JSONArray auras) throws RequestExternalPacketException {
        if (skill == null || monster == null || monster.getState() == null || monster.getState().isDead()) return;

        if (skill.auraLinks != null && !skill.auraLinks.isEmpty()) {
            java.util.Set<Integer> seenAuraIds = new java.util.HashSet<Integer>();
            for (SkillAuraBean link : skill.auraLinks) {
                if (link == null || link.getAuraId() <= 0) continue;
                if (!seenAuraIds.add(link.getAuraId())) continue;

                AuraBean aura = StorageCache.getInstance().getAura(link.getAuraId());
                if (aura == null) continue;

                State selfState = selfUser != null ? (State) selfUser.properties.get("state") : null;
                if (!shouldApplyClassSpecialAuraLink(skill, aura, selfState)) continue;

                JSONObject aj = null;
                String targetType = aura.getTarget() == null ? "target" : aura.getTarget().trim().toLowerCase();

                if (targetType.equals("self")) {
                    if (selfState != null && !selfState.isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(selfUser, link.getAuraId(), fromTarget, damage);
                    }
                } else if (targetType.equals("player") || targetType.equals("players") || targetType.equals("other")) {
                    if (selfState != null && !selfState.isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(selfUser, link.getAuraId(), fromTarget, damage);
                    }
                } else if (targetType.equals("monster") || targetType.equals("monsters") || targetType.equals("target")) {
                    if (monster.getState() != null && !monster.getState().isDead() && !monster.getState().isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(monster, link.getAuraId(), fromTarget, damage);
                    }
                }

                if (aj != null) auras.add(aj);
            }
            applyUndeadGoatGoatedProcIfNeeded(skill, selfUser, fromTarget, damage, auras);
            return;
        }

        if (monster.getState() != null && !monster.getState().isDead()) {
            applySkillAurasToMonster(skill, monster, fromTarget, damage, auras);
        }
    }

    private void applySkillAurasForPlayerTarget(SkillBean skill, User userTarget, String fromTarget, int damage, JSONArray auras) throws RequestExternalPacketException {
        if (skill == null || userTarget == null) return;
        if (skill.auraLinks != null && !skill.auraLinks.isEmpty()) {
            User selfUser = ExtensionHelper.instance().getUserById(user.getUserId());
            java.util.Set<Integer> seenAuraIds = new java.util.HashSet<Integer>();
            for (SkillAuraBean link : skill.auraLinks) {
                if (link == null || link.getAuraId() <= 0) continue;
                if (!seenAuraIds.add(link.getAuraId())) continue;
                AuraBean aura = StorageCache.getInstance().getAura(link.getAuraId());
                if (aura == null) continue;

                JSONObject aj = null;
                if (aura.isSelfTarget()) {
                    State selfState = selfUser != null ? (State) selfUser.properties.get("state") : null;
                    if (selfState != null && !selfState.isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(selfUser, link.getAuraId(), "p:" + user.getUserId(), damage);
                    }
                } else if (aura.isPlayerTarget() || aura.isOtherTarget()) {
                    User auraTarget = userTarget;
                    if (auraTarget == null || auraTarget.getUserId() == user.getUserId()) {
                        auraTarget = selfUser;
                    }
                    State targetState = auraTarget != null ? (State) auraTarget.properties.get("state") : null;
                    if (targetState != null && !targetState.isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(auraTarget, link.getAuraId(), fromTarget, damage);
                    }
                } else if (aura.isMonsterTarget()) {
                    aj = null;
                } else {
                    State targetState = (State) userTarget.properties.get("state");
                    if (targetState != null && !targetState.isAuraStackFull(aura.getId(), aura.getStack())) {
                        aj = applyAura(userTarget, link.getAuraId(), fromTarget, damage);
                    }
                }
                if (aj != null) auras.add(aj);
            }
            return;
        }

        for (Map.Entry<Integer, Integer> auraEntry : skill.auras.entrySet()) {
            int auraId = auraEntry.getKey();
            AuraBean auraObj = StorageCache.getInstance().getAura(auraId);
            if (auraObj == null) continue;

            JSONObject aj = null;
            User selfUser = ExtensionHelper.instance().getUserById(user.getUserId());

            if (auraObj.isSelfTarget()) {
                aj = applyAura(selfUser, auraId, "p:" + user.getUserId(), damage);
            } else if (auraObj.isPlayerTarget() || auraObj.isOtherTarget()) {
                User auraTarget = userTarget;
                if (auraTarget == null || auraTarget.getUserId() == user.getUserId()) {
                    auraTarget = selfUser;
                }
                aj = applyAura(auraTarget, auraId, fromTarget, damage);
            } else if (auraObj.isMonsterTarget()) {
                aj = null;
            } else {
                aj = applyAura(userTarget, auraId, fromTarget, damage);
            }

            if (aj != null) auras.add(aj);
        }
    }

    private boolean isFriendlyTargetSkill(SkillBean skill) {
        if (skill == null) return false;
        String target = skill.getTarget() == null ? "" : skill.getTarget().trim().toLowerCase();
        return "f".equals(target)
                || "s".equals(target)
                || "self".equals(target)
                || "friend".equals(target)
                || "friendly".equals(target)
                || "ally".equals(target)
                || "allies".equals(target);
    }

    private boolean isSelfOrFriendlyAuraSkill(SkillBean skill) {
        if (skill == null) return false;

        if (isFriendlyTargetSkill(skill)) return true;

        Set<Integer> auraIds = new HashSet<Integer>();
        try {
            if (skill.auras != null) auraIds.addAll(skill.auras.keySet());
            if (skill.auraLinks != null) {
                for (SkillAuraBean link : skill.auraLinks) {
                    if (link != null && link.getAuraId() > 0) auraIds.add(link.getAuraId());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] self/friendly aura scan failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        if (skill.hasAuraId()) auraIds.add(skill.getAuraId());

        for (int auraId : auraIds) {
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null) continue;
            if (aura.isSelfTarget() || aura.isPlayerTarget() || aura.isOtherTarget()) return true;
        }
        return false;
    }

    private boolean isSupportOnlySkill(SkillBean skill) {
        if (skill == null) return false;
        if (!isFriendlyTargetSkill(skill)) return false;

        Set<Integer> auraIds = new HashSet<Integer>();
        try {
            if (skill.auras != null) auraIds.addAll(skill.auras.keySet());
            if (skill.auraLinks != null) {
                for (SkillAuraBean link : skill.auraLinks) {
                    if (link != null && link.getAuraId() > 0) auraIds.add(link.getAuraId());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        if (skill.hasAuraId()) auraIds.add(skill.getAuraId());

        if (auraIds.isEmpty()) {
            String desc = skill.getDescription() == null ? "" : skill.getDescription().toLowerCase();
            return desc.contains("friendly") || desc.contains("heal") || desc.contains("protection") || desc.contains("resistance") || desc.contains("hot");
        }

        for (int auraId : auraIds) {
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null) continue;
            String cat = aura.getCategory() == null ? "" : aura.getCategory().trim().toLowerCase();
            if ("d".equals(cat)) cat = "dot";
            boolean hostile = cat.equals("debuff") || cat.equals("dot") || cat.equals("stun") || cat.equals("stone") || cat.equals("freeze") || cat.equals("frozen") || cat.equals("disabled") || cat.equals("disable") || cat.equals("poison") || cat.equals("burn") || cat.equals("bleed");
            if (hostile) return false;
        }
        return true;
    }


    private void triggerEnhancementTrait(SkillBean skill,
                                         Stats stats,
                                         State state,
                                         String targetInf,
                                         JSONArray damageArray,
                                         JSONArray auraPackets,
                                         JSONObject players,
                                         JSONObject monstersJson,
                                         ZoneBean area,
                                         HashMap<Integer, MonsterAI> monsters) {
        try {
            if (skill == null || stats == null || state == null || targetInf == null || targetInf.isEmpty()) return;

            EnhancementBean enhancement = (EnhancementBean) this.user.properties.get("weaponitemenhancement");
            if (enhancement == null) return;

            int procId = EnhancementTraitEngine.getProcId(enhancement);
            if (procId <= 0) return;

            String procName = EnhancementTraitEngine.getProcDisplayName(procId);
            String enhName = enhancement.getName() == null ? "Unknown Enhancement" : enhancement.getName();
            String skillRef = skill.getReference() == null ? "" : skill.getReference().trim().toLowerCase();
            double procChance = EnhancementTraitEngine.getProcChance(procId);
            double roll = Math.random();
            if (!EnhancementTraitEngine.skillMatchesProcTrigger(skillRef, procId)) { return; }

            if (roll > procChance) {
                return;
            }

            /*
            Kaiden_Engine.getInstance().sendEmulatorMessage(

                    "red",
                    "[PROC FOUND] " + enhName + " proc=" + procName + " skillRef=" + skillRef
            );





            //Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[PROC CHECK] " + enhName + " proc=" + procName + " chance=" + procChance + " roll=" + roll
            );

            if (roll > procChance) {
                //Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "yellow",
                        "[PROC FAIL] " + procName + " chance=" + procChance + " roll=" + roll
                );
                return;
            }

            //Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[PROC PASS] " + procName + " chance=" + procChance + " roll=" + roll
            );

             */

            switch (procId) {
                case EnhancementTraitEngine.PROC_SPIRAL_CARVE: {
                    int damage = computeTraitDamage(stats, 2.0D, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.SPIRAL_CARVE, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_AWE_BLAST: {
                    int damage = computeTraitDamage(stats, 1.0D, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.AWE_BLAST, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_HEALTH_VAMP: {
                    int damage = computeTraitDamage(stats, 0.10D, "hybrid", false, false, false, state, null);
                    int baseHeal = computeTraitBaseDamage(stats, 0.10D, "hybrid");
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, true);
                    state.increaseHealth((int) Math.max(1, Math.round(baseHeal * 1.25D)));
                    players.put(this.user.getName(), state.getData());
                    return;
                }
                case EnhancementTraitEngine.PROC_MANA_VAMP: {
                    int damage = computeTraitDamage(stats, 0.2D, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, true);
                    state.increaseMana(10);
                    players.put(this.user.getName(), state.getData());
                    return;
                }
                case EnhancementTraitEngine.PROC_POWERWORD_DIE: {
                    applyTraitDamageToTarget(targetInf, 999999, "hybrid", damageArray, players, monstersJson, area, monsters, true);
                    return;
                }
                case EnhancementTraitEngine.PROC_LACERATE: {
                    if (!EnhancementTraitEngine.tryConsumeCooldown(this.user, "lacerate", 2000L)) return;
                    int damage = computeTraitDamage(stats, 0.80D, "physical", true, true, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "physical", damageArray, players, monstersJson, area, monsters, false);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.LACERATE, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_SMITE: {
                    if (!EnhancementTraitEngine.tryConsumeCooldown(this.user, "smite", 15000L)) return;
                    int damage = computeTraitDamage(stats, 5.0D, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    return;
                }
                case EnhancementTraitEngine.PROC_VALIANCE: {
                    if (!EnhancementTraitEngine.tryConsumeCooldown(this.user, "valiance", 15000L)) return;
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.VALIANCE, 0, auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_ARCANAS_CONCERTO: {
                    int damage = computeTraitDamage(stats, 0.50D, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.ARCANAS_CONCERTO, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_ACHERON: {
                    int achDamage = computeTraitDamage(stats, 0.80D, "magic", true, true, false, state, null);
                    int achTargets = applyTraitDamageToTarget(targetInf, achDamage, "magic", damageArray, players, monstersJson, area, monsters, false) > 0 ? 1 : 0;
                    achTargets += applySecondaryTraitTarget(targetInf, "magic", damageArray, players, monstersJson, area, monsters, achDamage);
                    EnhancementTraitEngine.applyStygian(this.user, Math.max(1, achTargets));
                    players.put(this.user.getName(), state.getData());
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.ACHERON, 0, auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_ELYSIUM: {
                    double manaPct = state.getMaxMana() <= 0 ? 1.0D : (double) state.getMana() / (double) state.getMaxMana();
                    double scalar = 11.25D - (8.75D * manaPct);
                    int damage = computeTraitDamage(stats, scalar, "magic", true, false, true, state, null);
                    int elyTargets = applyTraitDamageToTarget(targetInf, damage, "magic", damageArray, players, monstersJson, area, monsters, false) > 0 ? 1 : 0;
                    elyTargets += applySecondaryTraitTarget(targetInf, "magic", damageArray, players, monstersJson, area, monsters, damage);
                    EnhancementTraitEngine.applyElysian(this.user, Math.max(1, elyTargets));
                    players.put(this.user.getName(), state.getData());
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.ELYSIUM, 0, auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_PRAXIS: {
                    if (!EnhancementTraitEngine.tryConsumeCooldown(this.user, "praxis", 4000L)) return;
                    int chain = updatePraxisChain(targetInf);
                    double scalar = 0.70D * (1.0D + (0.10D * Math.max(0, chain - 1)));
                    int damage = computeTraitDamage(stats, scalar, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    if (!targetHasAura(targetInf, EnhancementProcAuras.PRAXIS, monsters)) {
                        applyTraitDebuff(targetInf, "spinningdragon", 1, 2000L, monsters, players, monstersJson);
                    }
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.PRAXIS, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_DAUNTLESS: {
                    if (!EnhancementTraitEngine.tryConsumeCooldown(this.user, "dauntless", 3000L)) return;
                    double hpPct = state.getMaxHealth() <= 0 ? 1.0D : (double) state.getHealth() / (double) state.getMaxHealth();
                    double scalar = 5.70D - (3.80D * hpPct);
                    int damage = computeTraitDamage(stats, scalar, "physical", true, true, false, state, null);
                    int dealt = applyTraitDamageToTarget(targetInf, damage, "physical", damageArray, players, monstersJson, area, monsters, false);
                    state.increaseHealth(Math.max(1, dealt));
                    players.put(this.user.getName(), state.getData());
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.DAUNTLESS, 0, auraPackets, monsters, players, monstersJson);
                    return;
                }
                case EnhancementTraitEngine.PROC_RAVENOUS: {
                    double targetPct = resolveTargetHealthPct(targetInf, monsters);
                    double scalar = 3.38D - (2.63D * targetPct);
                    int damage = computeTraitDamage(stats, scalar, "hybrid", false, false, false, state, null);
                    applyTraitDamageToTarget(targetInf, damage, "hybrid", damageArray, players, monstersJson, area, monsters, false);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.RAVENOUS, 0, auraPackets, monsters, players, monstersJson);
                    applyProcAuraByDefinition(targetInf, EnhancementProcAuras.CONSUMED, Math.max(0, damage), auraPackets, monsters, players, monstersJson);
                    return;
                }
                default:
                    return;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applyProcAuraToSelf(int auraId, int damage, JSONArray auraPackets) {
        try {
            JSONObject aj = applyAura(this.user, auraId, "p:" + this.user.getUserId(), Math.max(0, damage));
            if (aj != null && auraPackets != null) {
                auraPackets.add(aj);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applyProcAuraToTarget(String targetInf,
                                       int auraId,
                                       int damage,
                                       JSONArray auraPackets,
                                       HashMap<Integer, MonsterAI> monsters,
                                       JSONObject players,
                                       JSONObject monstersJson) {
        try {
            JSONObject aj = null;
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                if (ai != null) {
                    aj = applyAura(ai, auraId, "p:" + this.user.getUserId(), Math.max(0, damage));
                    if (ai.getState() != null) {
                        monstersJson.accumulate(String.valueOf(ai.getMapMonster().getMonMapId()), ai.getState().getData().accumulate("targets", ai.getState().getTargets()));
                    }
                }
            } else if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                if (userTarget != null) {
                    aj = applyAura(userTarget, auraId, "p:" + this.user.getUserId(), Math.max(0, damage));
                    State targetState = (State) userTarget.properties.get("state");
                    if (targetState != null) {
                        players.put(userTarget.getName(), targetState.getData());
                    }
                }
            }
            if (aj != null && auraPackets != null) {
                auraPackets.add(aj);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applyProcAuraByDefinition(String targetInf,
                                           int auraId,
                                           int damage,
                                           JSONArray auraPackets,
                                           HashMap<Integer, MonsterAI> monsters,
                                           JSONObject players,
                                           JSONObject monstersJson) {
        try {
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null) return;

            String normalized = aura.normalizedTarget();
            if (aura.isSelfTarget()) {
                applyProcAuraToSelf(auraId, damage, auraPackets);
                return;
            }

            if (targetInf == null || targetInf.trim().isEmpty()) {
                if (aura.isPlayerTarget() || aura.isOtherTarget()) {
                    applyProcAuraToSelf(auraId, damage, auraPackets);
                }
                return;
            }

            boolean targetIsPlayer = targetInf.startsWith("p:");
            boolean targetIsMonster = targetInf.startsWith("m:");

            if ("target".equals(normalized)) {
                applyProcAuraToTarget(targetInf, auraId, damage, auraPackets, monsters, players, monstersJson);
                return;
            }

            if (aura.isPlayerTarget() || aura.isOtherTarget()) {
                if (targetIsPlayer) {
                    applyProcAuraToTarget(targetInf, auraId, damage, auraPackets, monsters, players, monstersJson);
                } else {
                    applyProcAuraToSelf(auraId, damage, auraPackets);
                }
                return;
            }

            if (aura.isMonsterTarget()) {
                if (targetIsMonster) {
                    applyProcAuraToTarget(targetInf, auraId, damage, auraPackets, monsters, players, monstersJson);
                }
                return;
            }

            applyProcAuraToTarget(targetInf, auraId, damage, auraPackets, monsters, players, monstersJson);
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void appendProcAura(JSONArray auraPackets, String targetInf, String fromTarget, String auraName, String category, long durationSeconds) {
        try {
            if (auraPackets == null || targetInf == null || auraName == null || auraName.trim().isEmpty()) return;
            JSONObject packet = new JSONObject();
            JSONArray auras = new JSONArray();
            JSONObject auraInfo = new JSONObject();
            auraInfo.put("nam", auraName);
            auraInfo.put("icon", "");
            auraInfo.put("t", "s");
            auraInfo.put("dur", String.valueOf(Math.max(1L, durationSeconds)));
            auraInfo.put("isNew", true);
            if (category != null && !category.trim().isEmpty()) {
                auraInfo.put("cat", category.trim().toLowerCase());
            }
            auras.add(auraInfo);
            packet.put("cInf", fromTarget == null ? "p:" + this.user.getUserId() : fromTarget);
            packet.put("cmd", "aura+");
            packet.put("tInf", targetInf);
            packet.put("auras", auras);
            auraPackets.add(packet);
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private int updatePraxisChain(String targetInf) {
        String last = (String) this.user.properties.get("praxisLastTarget");
        Integer count = (Integer) this.user.properties.get("praxisChainCount");
        if (last != null && last.equals(targetInf)) {
            count = count == null ? 1 : count + 1;
        } else {
            count = 1;
        }
        this.user.properties.put("praxisLastTarget", targetInf);
        this.user.properties.put("praxisChainCount", count);
        return count;
    }

    private double resolveTargetHealthPct(String targetInf, HashMap<Integer, MonsterAI> monsters) {
        try {
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                if (ai != null && ai.getState() != null && ai.getState().getMaxHealth() > 0) {
                    return Math.max(0.0D, Math.min(1.0D, (double) ai.getState().getHealth() / (double) ai.getState().getMaxHealth()));
                }
            } else if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                State targetState = userTarget != null ? (State) userTarget.properties.get("state") : null;
                if (targetState != null && targetState.getMaxHealth() > 0) {
                    return Math.max(0.0D, Math.min(1.0D, (double) targetState.getHealth() / (double) targetState.getMaxHealth()));
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return 1.0D;
    }

    private int computeTraitBaseDamage(Stats stats, double scalar, String school) {
        if (stats == null) return 0;
        return resolveAqwBaseAmount(stats, new SkillBeanProxy(scalar, school), false, true);
    }

    private int computeTraitDamage(Stats stats, double scalar, String school, boolean alwaysHit, boolean alwaysCrit, boolean cannotCrit, State state, State targetState) {
        DamageType type = DamageType.HIT;
        if (alwaysCrit && !cannotCrit) type = DamageType.CRITICAL;
        int amount = calculateResolvedSkillAmount(stats, targetState, new SkillBeanProxy(scalar, school), type, false);
        if (cannotCrit && amount > 0) {
            amount = resolveAqwBaseAmount(stats, new SkillBeanProxy(scalar, school), false, true);
        }
        return Math.max(0, amount);
    }

    private int applyTraitDamageToTarget(String targetInf,
                                         int amount,
                                         String school,
                                         JSONArray damageArray,
                                         JSONObject players,
                                         JSONObject monstersJson,
                                         ZoneBean area,
                                         HashMap<Integer, MonsterAI> monsters,
                                         boolean trueDamage) {
        try {
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                if (ai == null || ai.getState() == null || ai.getState().isDead()) return 0;
                int finalAmount = amount;
                DamageSchool dmgSchool = resolveTraitDamageSchool(school);
                if (!trueDamage) {
                    finalAmount = applyUserOutgoingModifiers((Stats) this.user.properties.get("stats"), finalAmount, dmgSchool);
                    finalAmount = applyMonsterIncomingModifiers(ai, finalAmount, dmgSchool);
                }
                finalAmount = Math.max(0, finalAmount);
                ai.getState().decreaseHealth(finalAmount);
                if (ai.getState().isDead()) {
                    State selfState = (State) this.user.properties.get("state");
                    handleMonsterDeath(ai, selfState, area, new JSONArray());
                    if (selfState != null) {
                        selfState.removeMonsterTarget(ai.getMapMonster().getMonMapId());
                    }
                    Users.getInstance().sendUotls(this.user, false, false, false, false, false, false, true);
                }
                monstersJson.accumulate(String.valueOf(ai.getMapMonster().getMonMapId()), ai.getState().getData().accumulate("targets", ai.getState().getTargets()));
                damageArray.add(Damage.getDamageResult("p:" + this.user.getUserId(), targetInf, finalAmount, DamageType.HIT));
                return finalAmount;
            }
            if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                if (userTarget == null) return 0;
                Stats targetStats = (Stats) userTarget.properties.get("stats");
                UserState targetState = (UserState) userTarget.properties.get("state");
                if (targetState == null || targetState.isDead()) return 0;
                int finalAmount = amount;
                DamageSchool dmgSchool = resolveTraitDamageSchool(school);
                if (!trueDamage) {
                    finalAmount = applyUserOutgoingModifiers((Stats) this.user.properties.get("stats"), finalAmount, dmgSchool);
                    finalAmount = applyTargetIncomingModifiers(targetStats, targetState, finalAmount, dmgSchool);
                }
                finalAmount = Math.max(0, finalAmount);
                if (userTarget.getUserId() == this.user.getUserId()) {
                    finalAmount = Math.min(finalAmount, Math.max(0, targetState.getHealth() - 1));
                }
                if (finalAmount <= 0) {
                    players.put(userTarget.getName(), targetState.getData());
                    damageArray.add(Damage.getDamageResult("p:" + this.user.getUserId(), targetInf, 0, DamageType.NONE));
                    return 0;
                }
                targetState.decreaseHealth(finalAmount);
                if (targetState.isDead()) {
                    handlePlayerDeathFromTrait(userTarget, targetState, area);
                }
                players.put(userTarget.getName(), targetState.getData());
                damageArray.add(Damage.getDamageResult("p:" + this.user.getUserId(), targetInf, finalAmount, DamageType.HIT));
                return finalAmount;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return 0;
    }

    private void handlePlayerDeathFromTrait(User userTarget, UserState targetState, ZoneBean area) {
        try {
            State selfState = (State) this.user.properties.get("state");
            if (selfState != null && userTarget != null && userTarget.getUserId() != this.user.getUserId()) {
                selfState.removePlayerTarget(userTarget.getName());
            }
            Users.getInstance().sendUotls(this.user, false, false, false, false, false, false, true);

                incrementPlayerKillDeathInMemory(this.user, userTarget);

            if (area != null && (area.isPvP() || area.isPK())) {
                handlePvPKill(userTarget, area);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void incrementPlayerKillDeathInMemory(User killer, User victim) {
        try {
            if (killer != null && killer.properties != null) {
                Object oldKill = killer.properties.get(Properties.KILL_COUNT);
                int killCount = oldKill instanceof Number ? ((Number) oldKill).intValue() : 0;
                killer.properties.put(Properties.KILL_COUNT, killCount + 1);
            }
            if (victim != null && victim.properties != null) {
                Object oldDeath = victim.properties.get(Properties.DEATH_COUNT);
                int deathCount = oldDeath instanceof Number ? ((Number) oldDeath).intValue() : 0;
                victim.properties.put(Properties.DEATH_COUNT, deathCount + 1);
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[CombatCounter] memory increment failed: " + e.getMessage());
        }
    }

    private int applySecondaryTraitTarget(String primaryTarget,
                                          String school,
                                          JSONArray damageArray,
                                          JSONObject players,
                                          JSONObject monstersJson,
                                          ZoneBean area,
                                          HashMap<Integer, MonsterAI> monsters,
                                          int damage) {
        try {
            if (primaryTarget != null && primaryTarget.startsWith("m:") && monsters != null) {
                for (MonsterAI ai : monsters.values()) {
                    if (ai == null || ai.getState() == null || ai.getState().isDead()) continue;
                    String inf = "m:" + ai.getMapMonster().getMonMapId();
                    if (inf.equals(primaryTarget)) continue;
                    return applyTraitDamageToTarget(inf, damage, school, damageArray, players, monstersJson, area, monsters, false) > 0 ? 1 : 0;
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return 0;
    }

    private DamageSchool resolveTraitDamageSchool(String school) {
        String key = school == null ? "" : school.trim().toLowerCase();
        if ("magic".equals(key) || "magical".equals(key)) return DamageSchool.MAGICAL;
        return DamageSchool.PHYSICAL;
    }

    private boolean targetHasAura(String targetInf, int auraId, HashMap<Integer, MonsterAI> monsters) {
        try {
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                return ai != null && ai.getState() != null && ai.getState().hasAura(auraId);
            }
            if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                State targetState = userTarget != null ? (State) userTarget.properties.get("state") : null;
                return targetState != null && targetState.hasAura(auraId);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return false;
    }

    private void applyTraitDebuff(String targetInf, String key, int stacks, long durationMs, HashMap<Integer, MonsterAI> monsters, JSONObject players, JSONObject monstersJson) {
        try {
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                EnhancementTraitEngine.applyTargetDebuff(ai, key, stacks, durationMs);
                if (ai != null && ai.getState() != null) {
                    monstersJson.accumulate(String.valueOf(ai.getMapMonster().getMonMapId()), ai.getState().getData().accumulate("targets", ai.getState().getTargets()));
                }
            } else if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                if (userTarget != null) {
                    EnhancementTraitEngine.applyTargetDebuff(userTarget, key, stacks, durationMs);
                    Users.getInstance().sendStatsIfDirty(userTarget);
                    State targetState = (State) userTarget.properties.get("state");
                    if (targetState != null) players.put(userTarget.getName(), targetState.getData());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void addTraitDebuffStack(String targetInf, String key, int add, int maxStacks, long durationMs, HashMap<Integer, MonsterAI> monsters, JSONObject players, JSONObject monstersJson) {
        try {
            if (targetInf.startsWith("m:")) {
                MonsterAI ai = monsters.get(Integer.parseInt(targetInf.substring(2)));
                EnhancementTraitEngine.addTargetDebuffStacks(ai, key, add, maxStacks, durationMs);
                if (ai != null && ai.getState() != null) {
                    monstersJson.accumulate(String.valueOf(ai.getMapMonster().getMonMapId()), ai.getState().getData().accumulate("targets", ai.getState().getTargets()));
                }
            } else if (targetInf.startsWith("p:")) {
                User userTarget = ExtensionHelper.instance().getUserById(Integer.parseInt(targetInf.substring(2)));
                if (userTarget != null) {
                    EnhancementTraitEngine.addTargetDebuffStacks(userTarget, key, add, maxStacks, durationMs);
                    Users.getInstance().sendStatsIfDirty(userTarget);
                    State targetState = (State) userTarget.properties.get("state");
                    if (targetState != null) players.put(userTarget.getName(), targetState.getData());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private static final class SkillBeanProxy extends SkillBean {
        private final double damage;
        private final String type;
        private SkillBeanProxy(double damage, String type) { this.damage = damage; this.type = type; }
        @Override public double getDamage() { return this.damage; }
        @Override public String getReference() { return this.type; }
        @Override public String getType() { return this.type; }
        @Override public String getEffects() { return this.type; }
    }

    private void cleanupStateTargets(State state, HashMap<Integer, MonsterAI> monsters) {
        if (state == null) return;
        state.cleanupInvalidTargets();
        if (monsters != null && !state.getMonsterTargets().isEmpty()) {
            Set<Integer> invalid = new HashSet<Integer>();
            for (Integer monId : state.getMonsterTargets()) {
                MonsterAI ai = monsters.get(monId);
                if (ai == null || ai.getState() == null || ai.getState().isDead()) {
                    invalid.add(monId);
                }
            }
            for (Integer monId : invalid) {
                state.removeMonsterTarget(monId);
            }
        }
        state.refreshCombatState();
    }

    private int calculateResolvedSkillAmount(Stats stats, State targetState, SkillBean skill, DamageType type, boolean heal) {
        if (stats == null || skill == null) return 0;
        if (type == DamageType.DODGE || type == DamageType.PARRY || type == DamageType.MISS || type == DamageType.NONE) {
            return 0;
        }

        int amount = resolveAqwBaseAmount(stats, skill, heal, false);
        if (heal) {
            amount = (int) Math.max(1, Math.round(amount * 0.72D));
            if (targetState != null) {
                double healCap = Math.max(50.0D, targetState.getMaxHealth() * 0.18D);
                amount = (int) Math.min(amount, Math.round(healCap));
            }
        } else if (type == DamageType.CRITICAL) {
            double critMult = (stats != null) ? Math.max(1.05D, stats.get$scm()) : 1.5D;
            amount = (int) Math.max(0, Math.round(amount * critMult));
        }

        return Math.max(0, amount);
    }

    private int resolveAqwBaseAmount(Stats stats, SkillBean skill, boolean heal, boolean forceNoCrit) {
        if (stats == null || skill == null) return 0;

        // dsrc is now authoritative when present. CombatDsrcContainer keeps the
        // old weapon DPS / weapon damage text detection as a compatibility
        // fallback for blank, unknown, and unfinished special dsrc values.
        int amount = CombatDsrcContainer.resolve(stats, skill, heal);

        if (forceNoCrit) {
            return Math.max(0, amount);
        }
        return Math.max(0, amount);
    }

    private double normalizeSkillScalar(double raw) {
        double v = Math.abs(raw);
        if (v <= 0.0D) return 1.0D;
        if (v > 10.0D) v = v / 100.0D;
        return Math.max(0.05D, Math.min(5.0D, v));
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private static int safeInt(Object v, int fallback) {
        if (v instanceof Integer) return (Integer) v;
        if (v instanceof Number) return ((Number) v).intValue();
        return fallback;
    }

    private static int applyVariance(int dmg) {
        if (dmg <= 0) return dmg;
        double mult = DMG_VARIANCE_MIN + (Math.random() * (DMG_VARIANCE_MAX - DMG_VARIANCE_MIN));
        return (int) Math.round(dmg * mult);
    }
}