package Kaiden.Game.Server.Packets.Internal;


import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public class UserExitEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        Room room = (Room) ieo.getObject("room");
        User user = (User) ieo.getObject("user");
         Rooms.getInstance().exit(room, user);
         //SmartFoxServer.getInstance().removeUser(user);
        if (room.getUserCount() <= 0) {
           Kaiden_Extension.getInstance().getHelper().destroyRoom(Kaiden_Extension.getInstance().getZone(), room.getId());
        }
    }
}