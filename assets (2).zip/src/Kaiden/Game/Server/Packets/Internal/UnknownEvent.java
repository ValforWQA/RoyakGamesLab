package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.UnknownPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public class UnknownEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        throw new UnknownPacketException("An illegal internal event has occured within the server: " + ieo.getEventName());
    }
}