package Kaiden.Game.Server.Packets.Internal;


import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public class NewRoomEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        Room room = (Room) ieo.getObject("room");
        room.getUserList();
    }
}
