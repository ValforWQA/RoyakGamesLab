package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;
import net.sf.json.JSONObject;

public class UserJoinEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        SmartFoxServer.log.info("UserJoin:");
        Room room = (Room) ieo.getObject("room");
        User user = (User) ieo.getObject("user");
        JSONObject userObj = Users.getInstance().getProperties(user, room);
        JSONObject join = new JSONObject();
        join.put("cmd", "uotls");
        join.put("o", userObj);
        join.put("unm", user.getName());
        Kaiden_Extension.getInstance().sendToRoomButOne(join, user, room);
    }
}
