package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;



public class ServerReadyEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        // The SFS instance that hosts ServerManagerUI is not a playable world.
        // Only a GUI-started child (or a legacy no-interface standalone world) may mark a row online.
        if (!Boolean.getBoolean("kaiden.manager.child") && Configuration.ALLOW_INTERFACE) {
            return;
        }
        Storage.getInstance().getJdbc().run("UPDATE servers SET Online = 1 WHERE Name = ?", Configuration.SERVER_NAME);
        Storage.getInstance().getJdbc().run("UPDATE users SET CurrentServer = 'Offline' WHERE CurrentServer = ?", Configuration.SERVER_NAME);
    }
}
