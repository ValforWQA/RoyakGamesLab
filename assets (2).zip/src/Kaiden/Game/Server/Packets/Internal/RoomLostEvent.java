package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public class RoomLostEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        int fromRoom = Integer.parseInt(ieo.getParam("roomId"));
    }
}
