package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestInternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Settings;
import Kaiden.Game.Server.Users.Utils.ServerCountManager;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Game.Server.Users.Utils.AccountRewardSync;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;
import it.gotoandplay.smartfoxserver.exceptions.LoginException;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import jdbchelper.JdbcException;
import jdbchelper.NoResultException;
import jdbchelper.QueryResult;

import java.nio.channels.SocketChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

public class LoginRequestEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) throws RequestInternalPacketException {
        String nick = ieo.getParam("nick").split("~")[1];
        String pass = ieo.getParam("pass");
        SocketChannel chan = (SocketChannel) ieo.getObject("chan");

        try {
            Zone zone = Kaiden_Extension.getInstance().getZone();
            User existingUser = zone.getUserByName(nick);

            // AQW-style multi-login handling: kick old session, continue with new
            if (existingUser != null && !existingUser.isBeingKicked) {
                Users.getInstance().multiLogin(existingUser, chan);
                // Wait a tiny bit for the kick to process cleanly
                Thread.sleep(300);
            }

            // Proceed with normal login
            User user = ExtensionHelper.instance().canLogin(nick, pass, chan, zone.getName(), true);

            user.properties = loadUserPropertiesWithRetry(nick, pass);

            if (user.properties != null) {
                int accessLevel = (Integer) user.properties.get("access");

                if(!(accessLevel >= 10) && Configuration.TESTING_ONLY) {
                    Kaiden_Extension.getInstance().send(
                            new String[]{
                                    "loginResponse", "false", "-1", nick,
                                    "A game update/maintenance is currently on-going. Only selected testing players can log in."
                            },
                            user
                    );
                } else

                if (!(accessLevel >= 60 || accessLevel >= 40) && Configuration.STAFF_ONLY) {
                    Kaiden_Extension.getInstance().send(
                            new String[]{
                                    "loginResponse", "false", "-1", nick,
                                    "A game update/maintenance is currently on-going. Only the RoyakGames staff can enter the server at the moment."
                            },
                            user
                    );

                } else {



                    String[] response = new String[]{
                            "loginResponse", "true", String.valueOf(user.getUserId()), nick,
                            StorageCache.getInstance().getMessageOfTheDay(),
                            (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")).format(new Date()),
                            StorageCache.getInstance().getServerStrings()
                    };



                    Users.getInstance().processLogin(user);
                    Properties.updateLastLogin(user);
                    Server.getInstance().setDamage(1);
                    Users.getInstance().sendPreferences(user, Settings.PARTY);
                    Users.getInstance().sendPreferences(user, Settings.GOTO);
                    Users.getInstance().sendPreferences(user, Settings.FRIEND);
                    Users.getInstance().sendPreferences(user, Settings.WHISPER);
                    Users.getInstance().sendPreferences(user, Settings.TOOLTIPS);
                    Users.getInstance().sendPreferences(user, Settings.DUEL);
                    Users.getInstance().sendPreferences(user, Settings.GUILD);
                    Users.getInstance().sendPreferences(user, Settings.TRADE);

                    ServerCountManager.login(user);
                    QuestProgressManager.restore(user);
                    Kaiden_Extension.getInstance().send(response, user);
                    Users.getInstance().loadUserBoosts(user);
                    Users.getInstance().sendStateStats(user);
                    //Users.getInstance().sendUotls(user, true, false, true, false, false, false);

                    // Load optional login extras safely. If the pool is under pressure,
                    // do not fail the whole login because achievements/redeems can be refreshed later.
                    loadLoginExtrasSafely(user);

                    // Backfill any automatic account reward tied to achievements
                    // the player earned before the reward was configured.
                    AccountRewardSync.syncAutomaticRewards(user);
            }
        } else {
            Kaiden_Extension.getInstance().send(
                    new String[]{
                            "loginResponse", "false", "-1", nick,
                            "User Data for '" + nick + "' could not be retrieved. Please contact the staff to resolve the issue."
                    },
                    chan

            );
            SmartFoxServer.log.info("[Login Failed] For User '" + nick + "pass:"+ pass+ "' + logged in successfully.");
        }

    } catch (NoResultException error) {
        throw new RequestInternalPacketException("NoResultException during login: " + error.getMessage());
    } catch (JdbcException error) {
        throw new RequestInternalPacketException("JdbcException during login: " + error.getMessage());
    } catch (LoginException error) {
        throw new RequestInternalPacketException("Login error: " + error.getMessage());
    } catch (InterruptedException e) {
        throw new RequestInternalPacketException("Interrupted during login: " + e.getMessage());
    }
}
    private java.util.Map loadUserPropertiesWithRetry(String nick, String pass) {
        try {
            return Storage.getInstance().getJdbc().queryForObject(
                    "SELECT users.*, users_guilds.GuildID, users_guilds.Rank FROM users LEFT JOIN users_guilds ON UserID = id WHERE Name = ?",
                    Properties.userData, nick
            );
        } catch (Throwable t) {
            String msg = String.valueOf(t.getMessage());
            if (msg.contains("free database connection") || msg.contains("Timeout")) {
                Storage.getInstance().recoverPool("login-timeout");
                return Storage.getInstance().getJdbc().queryForObject(
                        "SELECT users.*, users_guilds.GuildID, users_guilds.Rank FROM users LEFT JOIN users_guilds ON UserID = id WHERE Name = ?",
                        Properties.userData, nick
                );
            }
            throw t;
        }
    }

    private void loadLoginExtrasSafely(User user) {
        QueryResult resultAchievements = null;
        QueryResult resultRedeems = null;
        try {
            Set achievements = (Set) user.properties.get(Properties.ACHIEVEMENTS);
            resultAchievements = Storage.getInstance().getJdbc()
                    .query("SELECT AchID FROM users_achievements WHERE UserID = ?", user.properties.get(Properties.ID));
            while (resultAchievements.next()) {
                achievements.add(resultAchievements.getInt("AchID"));
            }
        } catch (Throwable t) {
            SmartFoxServer.log.warning("[Login Extras] achievements skipped for " + user.getName() + ": " + t.getMessage());
        } finally {
            try { if (resultAchievements != null) resultAchievements.close(); } catch (Throwable ignored) {}
        }

        try {
            Set codedRedeems = (Set) user.properties.get(Properties.CODED_REDEEMS);
            resultRedeems = Storage.getInstance().getJdbc()
                    .query("SELECT CodeID FROM users_codes WHERE UserID = ?", user.properties.get(Properties.ID));
            while (resultRedeems.next()) {
                codedRedeems.add(resultRedeems.getInt("CodeID"));
            }
        } catch (Throwable t) {
            SmartFoxServer.log.warning("[Login Extras] code redeems skipped for " + user.getName() + ": " + t.getMessage());
        } finally {
            try { if (resultRedeems != null) resultRedeems.close(); } catch (Throwable ignored) {}
        }
    }

}