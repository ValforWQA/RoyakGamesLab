package Kaiden.Game.Server.Packets.Internal;

import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

public class UserLostEvent extends InternalPacketHandler {

    public void handle(InternalEventObject ieo) {
        User user = (User) ieo.getObject("user");
        Room room = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
        if (room != null) {
            Rooms.getInstance().exit(room, user);
            if (room.getUserCount() <= 0) {
                Rooms.getInstance().deleteRoom(room);
            }
        }
        Users.getInstance().lost(user);
        //ExtensionHelper.instance().logoutUser(user, true, false);
        SmartFoxServer.getInstance().removeUser(user);
        //if (FloodController.getInstance().contains(user)) {
           // FloodController.getInstance().remove(user);
        //}
    }
}