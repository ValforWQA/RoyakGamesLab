package Kaiden.Game.Server.Users;

import jdbchelper.QueryResult;

import java.sql.Date;
import java.util.Calendar;

public class UserItem {

    private final int charItemId;
    private int quantity;
    private final int itemId;
    private final int enhId;
    private final Date datePurchased;

    public UserItem(QueryResult result) {
        this.charItemId = result.getInt("id");
        this.quantity = result.getInt("Quantity");
        this.itemId = result.getInt("ItemID");
        this.enhId = result.getInt("EnhID");
        this.datePurchased = result.getDate("DatePurchased");
    }

    public UserItem(int charItemId, int quantity, int itemId, int enhId) {
        this.charItemId = charItemId;
        this.quantity = quantity;
        this.itemId = itemId;
        this.enhId = enhId;
        this.datePurchased = new Date(Calendar.getInstance().getTimeInMillis());
    }

    public int getCharItemId() {
        return this.charItemId;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public int getItemId() {
        return this.itemId;
    }

    public int getEnhId() {
        return this.enhId;
    }

    public Date getDatePurchased() {
        return this.datePurchased;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
