package Kaiden.Game.Server.Users.Parties;

import Kaiden.Game.Server.Users.Properties;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;

import java.util.LinkedList;

public class PartyInfo {
    private final int id;
    private final LinkedList members = new LinkedList();
    private User owner;

    public PartyInfo(User owner, int id) {
        this.owner = owner;
        this.id = id;
        owner.properties.put("partyId", this.id);
    }

    public JSONArray getUsers() {
        JSONArray partyMembers = new JSONArray();
        for (Object member : this.members) {
            User user = (User) member;
            partyMembers.add(user.properties.get(Properties.USERNAME));
        }
        partyMembers.add(this.owner.properties.get(Properties.USERNAME));
        return partyMembers;
    }

    public int getMemberCount() {
        return this.members.size();
    }

    public User getNextOwner() {
        return (User) this.members.get(0);
    }

    public boolean isMember(User user) {
        return this.members.contains(user);
    }

    public void addMember(User user) {
        if (!this.members.contains(user)) {
            this.members.add(user);
            user.properties.put("partyId", this.id);
        } else {
            throw new UnsupportedOperationException("unable to add member already in the party");
        }
    }

    public void removeMember(User user) {
        if (this.members.contains(user)) {
            this.members.remove(user);
            user.properties.put("partyId", -1);
        } else {
            throw new UnsupportedOperationException("unable to remove member not in the party");
        }
    }

    public LinkedList getChannelListButOne(User user) {
        LinkedList partyMembers = new LinkedList();
        for (Object member : this.members) {
            User u = (User) member;
            if (user != u) {
                partyMembers.add(u.getChannel());
            }
        }
        partyMembers.add(this.owner.getChannel());
        return partyMembers;
    }

    public LinkedList getChannelList() {
        LinkedList partyMembers = new LinkedList();
        for (Object member : this.members) {
            User u = (User) member;
            partyMembers.add(u.getChannel());
        }
        partyMembers.add(this.owner.getChannel());
        return partyMembers;
    }

    public String getOwner() {
        return (String) this.owner.properties.get(Properties.USERNAME);
    }

    public void setOwner(User user) {
        this.addMember(this.owner);
        this.removeMember(user);
        this.owner = user;
        this.owner.properties.put("partyId", this.id);
    }

    public User getOwnerObject() {
        return this.owner;
    }

    public int getId() {
        return this.id;
    }
}