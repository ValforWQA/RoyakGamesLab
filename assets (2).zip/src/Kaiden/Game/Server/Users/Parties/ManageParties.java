package Kaiden.Game.Server.Users.Parties;

import it.gotoandplay.smartfoxserver.data.User;
import org.apache.log4j.Logger;

import java.util.concurrent.ConcurrentHashMap;

public class ManageParties {
    private static ManageParties instance;
    private static final Logger LOGGER = Logger.getLogger(ManageParties.class);
    public static ManageParties getInstance() {
        if (instance == null) {
            instance = new ManageParties();
        }
        return instance;
    }

    private int lastPartie = 1;
    private final ConcurrentHashMap<Integer, PartyInfo> parties = new ConcurrentHashMap();


    public PartyInfo getPartyInfo(int partyId) {
        return this.parties.get(partyId);
    }

    public boolean contains(int partyId) {
        return this.parties.containsKey(partyId);
    }

    public int size() {
        return this.parties.size();
    }

    public void removeParty(int partyId) {
        //LOGGER.info("A group was undone [" + partyId + "]");
        this.parties.remove(partyId);
        this.lastPartie--;
    }

    public int create(User owner) {
        PartyInfo party = new PartyInfo(owner, this.lastPartie++);
        //LOGGER.info("A new group has been created [" + party.getId() + "]");
        this.parties.put(party.getId(), new PartyInfo(owner, party.getId()));
        return party.getId();
    }
}