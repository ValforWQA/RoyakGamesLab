package Kaiden.Game.Server.Users;

import Kaiden.Database.Beans.*;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Combat.Player.PassiveContainer;
import Kaiden.Game.Server.Combat.Player.PlayerCombatContainer;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Query.UsersQuery;
import Kaiden.Game.Server.Users.Utils.*;
import Kaiden.Game.Threads.*;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("ALL")
public class Users extends UsersQuery {

    private static final Logger LOGGER = Logger.getLogger(Users.class);
    private static Users instance;
    public static String CURRENCY1 = "Rubie's";

    public static Users getInstance() {
        if (instance == null) {
            instance = new Users();
        }
        return instance;
    }

    public void LogoutUser(User user) {
        Executor.getInstance().scheduleTask(new LogoutUser(user), 1L, TimeUnit.SECONDS);
    }

    public void kick(User user, String reason) {
        Kaiden_Extension.getInstance().send(new String[]{"logoutWarning", reason, "65"}, user);
        Executor.getInstance().scheduleTask(new KickUser(user), 3L, TimeUnit.SECONDS);
        user.isBeingKicked = true;
    }

    public void MultiLogin(User user) {

    }

    public void multiLogin(final User oldUser, SocketChannel newChan) {
        if (oldUser == null) return;

        // Prevent the old session from continuing to process packets.
        oldUser.isBeingKicked = true;

        // ✅ Send warning FIRST (must flush before disconnect)
        try {
            Kaiden_Extension.getInstance().send(
                    new String[]{"multiLoginWarning", "Your account was logged in from another location."},
                    oldUser
            );
        } catch (Exception ignored) {}

        // ✅ Delay cleanup/disconnect so the client actually receives the packet
        Executor.getInstance().scheduleTask(new Runnable() {
            @Override
            public void run() {

                // Best-effort cleanup of server-side runtime state
                try {
                    Users.getInstance().lost(oldUser);
                } catch (Exception ignored) {}

                // Force room exit so the avatar disappears for everyone immediately (prevents "ghost" users)
                try {
                    Room room = Kaiden_Extension.getInstance().getZone().getRoom(oldUser.getRoom());
                    if (room != null) {
                        Rooms.getInstance().exit(room, oldUser);
                        if (room.getUserCount() <= 0) {
                            Rooms.getInstance().deleteRoom(room);
                        }
                    }
                } catch (Exception ignored) {}

                // Trigger standard SFS logout flow
                try {
                    ExtensionHelper.instance().logoutUser(oldUser, true, false);
                } catch (Exception ignored) {}

                // Force disconnect + close channel
                try {
                    ExtensionHelper.instance().disconnectUser(oldUser);
                } catch (Exception ignored) {}

                try {
                    safeCloseChan(oldUser.getChannel());
                } catch (Exception ignored) {}

                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "green",
                        "[MultiLogin] Old session of '" + oldUser.getName() + "' was kicked. New connection accepted."
                );
            }
        }, 1L, TimeUnit.SECONDS);
    }

    private boolean isUserLoggedIn(User user) {
        return user != null;
    }

    public void RestorePlayer(User user, String message) {
        State state = (State) user.properties.get("state");
        state.reset();
        state.clearAuras();
        this.sendUotls(user, false, false,false, false, false, false, true);
        //AdminControlPanel.logMessage("[INFO]", "Player " + user.getName() + " has been restored after " + message + ". CurrentState[" + state.getStateByID(state.getState()) + "]", "[External Packet]", user.getName());
    }

    public void respawn(User user) {
        State state = (State) user.properties.get("state");
        state.restore();
        this.sendUotls(user, true, true, false, true, false, false, true);
        //Kaiden_Engine.Kaiden_Engine.getInstance().sendEmulatorMessage("green","[Respawn] New session of '" + user.getName() + "' was restarted.");
    }


    private void safeCloseChan(SocketChannel chan) {
        try {
            Thread.sleep(1000L);
            chan.close();
        } catch (IOException ignored) {
        } catch (InterruptedException ignored) {
        }
    }

    public void processLogin(User user) {
        if (((Integer) user.properties.get(Properties.ACCESS)) == 80) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("pinkd", user.getName()+ " has developer privileges");
            user.setAsAdmin();
            user.isAdmin();
        }
        else if (((Integer) user.properties.get(Properties.ACCESS)) == 60) {
            user.setAsAdmin();
            user.isAdmin();
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", user.getName()+ " has administrator privileges");
        } else if (((Integer) user.properties.get(Properties.ACCESS)) == 50) {
            user.setAsModerator();
            user.isModerator();
            Kaiden_Engine.getInstance().sendEmulatorMessage("gold", user.getName()+ " has moderator privileges");
        }

        user.properties.put("stats", new Stats(user));
        user.properties.put("equipment", new JSONObject());
        user.properties.put("regenaration", new Regeneration(user));
        user.properties.put("dashRegeneration", new DashRegeneration(user));
        user.properties.put("guildobj", this.getGuildObject((Integer) user.properties.get("guildid")));
        user.properties.put("partyId", -1);
        user.properties.put("upgdays", this.getUpgradeDays(user));

        user.properties.put(Properties.WEAR_EQUIPMENT, new JSONObject());
        user.properties.put("skills", new ConcurrentHashMap());
        user.properties.put(Properties.SKILLS_CD, new HashMap());
        user.properties.put("auras", Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put("quests", new HashSet());
        user.properties.put(Properties.ACHIEVEMENTS, Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put(Properties.CODED_REDEEMS, Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put(Properties.INVENTORY_ITEMS, new ConcurrentHashMap());
        user.properties.put(Properties.BANK_ITEMS, new ConcurrentHashMap());
        user.properties.put(Properties.TEMP_ITEMS, new ConcurrentHashMap());
        //import trade
        user.properties.put(Properties.REQUESTED_TRADE, new HashSet());
        user.properties.put(Properties.TRADE_OFFERS, new JSONObject());
        user.properties.put(Properties.TRADE_TARGET, -1);
        user.properties.put(Properties.TRADE_DEAL, 0);
        user.properties.put(Properties.TRADE_LOCK, 0);
        user.properties.put(Properties.TRADE_COINS, 0);
        user.properties.put(Properties.TRADE_GOLD, 0);
        //trade import
        user.properties.put("currentserver", Configuration.SERVER_NAME);
        user.properties.put("drops", new ConcurrentHashMap());
        user.properties.put("xpboost", false);
        user.properties.put("goldboost", false);
        user.properties.put("cpboost", false);
        user.properties.put("repboost", false);
        user.properties.put("coinboost", false);
        user.properties.put("requestedparty", Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put("requestedfriend", Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put("requestedduel", Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put("requestedguild", Collections.newSetFromMap(new ConcurrentHashMap()));
        user.properties.put("state", new UserState(user, 100, 100, 100));
        this.regenDash(user);
        user.properties.put("afk", false);
        user.properties.put("lastPlayerActivity", System.currentTimeMillis());
        user.properties.put("pvpteam", 0);
        user.properties.put("entertime", System.currentTimeMillis());
        user.properties.put("loginKillCount", user.properties.get(Properties.KILL_COUNT));
        user.properties.put("loginDeathCount", user.properties.get(Properties.DEATH_COUNT));
    }

    public void loadUserBoosts(User user) {
        if (user == null || user.properties == null) {
            return;
        }

        QueryResult boosts = null;

        try {
            Object userId = user.properties.get(Properties.ID);
            if (userId == null) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[BoostLoad] Skipped boost restore because user id is missing for " + user.getName());
                return;
            }

            /*
             * Do NOT restore boosts with QueryResult.getDate() + Java date math.
             * Some JDBC helpers return only the DATE portion for DATETIME fields.
             * Example: 2026-05-01 08:54:04 may become 2026-05-01 00:00:00,
             * which makes a still-active 60-minute boost look expired at login.
             *
             * MariaDB wrote these values with NOW(), so MariaDB should also calculate
             * the remaining seconds using TIMESTAMPDIFF(SECOND, NOW(), column).
             */
            boosts = Storage.getInstance().getJdbc().query(
                    "SELECT " +
                            "TIMESTAMPDIFF(SECOND, NOW(), ExpBoostExpire) AS ExpSecsLeft, ExpBoostExpire, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), CpBoostExpire) AS CpSecsLeft, CpBoostExpire, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), GoldBoostExpire) AS GoldSecsLeft, GoldBoostExpire, " +
                            "TIMESTAMPDIFF(SECOND, NOW(), RepBoostExpire) AS RepSecsLeft, RepBoostExpire " +
                            "FROM users WHERE id = ?",
                    userId
            );

            if (!boosts.next()) {
                setBoostInactive(user, "xpboost");
                setBoostInactive(user, "cpboost");
                setBoostInactive(user, "goldboost");
                setBoostInactive(user, "repboost");
                return;
            }

            loadBoostFromSeconds(user, "xpboost", "xpboost", boosts.getInt("ExpSecsLeft"), boosts.getString("ExpBoostExpire"));
            loadBoostFromSeconds(user, "cpboost", "cpboost", boosts.getInt("CpSecsLeft"), boosts.getString("CpBoostExpire"));
            loadBoostFromSeconds(user, "gboost", "goldboost", boosts.getInt("GoldSecsLeft"), boosts.getString("GoldBoostExpire"));
            loadBoostFromSeconds(user, "repboost", "repboost", boosts.getInt("RepSecsLeft"), boosts.getString("RepBoostExpire"));

        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[BoostLoad] Failed for " + (user == null ? "unknown" : user.getName()) + ": " + e.getMessage());
        } finally {
            try {
                if (boosts != null) {
                    boosts.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private void loadBoostFromSeconds(User user, String clientCmd, String propertyKey, int secondsLeft, String expireText) {
        try {
            if (secondsLeft <= 0) {
                setBoostInactive(user, propertyKey);
                Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[BoostLoad] " + clientCmd + " inactive for " + user.getName() + " expire=" + expireText + " secondsLeft=" + secondsLeft);
                return;
            }

            user.properties.put(propertyKey, Boolean.TRUE);

            JSONObject boost = new JSONObject();
            boost.put("cmd", clientCmd);
            boost.put("bShowShop", false);
            boost.put("op", "+");
            addBoostPacketFields(boost, clientCmd, secondsLeft);

            Kaiden_Extension.getInstance().send(boost, user);
            Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[BoostLoad] Restored " + clientCmd + " for " + user.getName() + " with " + secondsLeft + "s left. expire=" + expireText);
        } catch (Exception e) {
            setBoostInactive(user, propertyKey);
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[BoostLoad] Failed loading " + clientCmd + " for " + user.getName() + ": " + e.getMessage());
        }
    }

    private void addBoostPacketFields(JSONObject boost, String clientCmd, int secondsLeft) {
        if (boost == null) {
            return;
        }

        if (secondsLeft < 0) {
            secondsLeft = 0;
        }

        boost.put("iSecsLeft", secondsLeft);
        boost.put("boostTS", System.currentTimeMillis());

        if ("xpboost".equals(clientCmd)) {
            boost.put("iBoostXP", secondsLeft);
        } else if ("gboost".equals(clientCmd)) {
            boost.put("iBoostG", secondsLeft);
        } else if ("cpboost".equals(clientCmd)) {
            boost.put("iBoostCP", secondsLeft);
        } else if ("repboost".equals(clientCmd)) {
            boost.put("iBoostRep", secondsLeft);
        }
    }

    private void setBoostInactive(User user, String propertyKey) {
        if (user != null && user.properties != null && propertyKey != null) {
            user.properties.put(propertyKey, Boolean.FALSE);
        }
    }

    public JSONObject getProperties(User user, Room room) {
        JSONObject userprop = new JSONObject();
        State state = (State) user.properties.get("state");
        userprop.put("afk", user.properties.get("afk"));
        userprop.put("currentserver", user.properties.get("currentserver"));
        userprop.put("entID", user.getUserId());
        userprop.put("entType", "p");
        userprop.put("intGold", user.properties.get(Properties.GOLD));
        userprop.put("intCoins", user.properties.get(Properties.COINS));
        userprop.put("intHP", state.getHealth());
        userprop.put("intHPMax", state.getMaxHealth());
        userprop.put("intSouls", user.properties.get(Properties.SOULS));
        userprop.put("intLevel", user.properties.get(Properties.LEVEL));
        userprop.put("intMP", state.getMana());
        userprop.put("intSP", state.getDash());
        userprop.put("intMPMax", state.getMaxMana());
        userprop.put("intState", state.getState());
        userprop.put("showCloak", Boolean.TRUE);
        userprop.put("showHelm", Boolean.TRUE);
        userprop.put("strFrame", user.properties.get("frame"));
        userprop.put("strPad", user.properties.get("pad"));
        userprop.put("CharID", user.properties.get(Properties.ID));
        userprop.put("FactionID", user.properties.get(Properties.FACTION));
        userprop.put("FactionPerk", user.properties.get(Properties.FACTION_PERK));
        userprop.put("strUsername", user.properties.get(Properties.USERNAME));
        userprop.put("rolename", user.properties.get(Properties.ROLE_NAME));
        userprop.put("rolecolor", user.properties.get(Properties.ROLE_COLOR));
        userprop.put("namecolor", user.properties.get(Properties.NAME_COLOR));
        userprop.put("titleid", user.properties.get(Properties.TITLE_ID));
        userprop.put("tx", user.properties.get("tx"));
        userprop.put("ty", user.properties.get("ty"));
        userprop.put("sp", user.properties.get("speed"));
        userprop.put("uoName", user.getName());
        if (!room.getName().contains("house") && StorageCache.getInstance().getArea(room.getName().split("-")[0]).isPvP()) {
            userprop.put("pvpTeam", user.properties.get("pvpteam"));
        }
        return userprop;
    }

    public void sendStateStats(User user) {
        State state = (State) user.properties.get("state");
        FactionPerks perk = StorageCache.getInstance().getPerks(Integer.valueOf((String)user.properties.get(Properties.FACTION_PERK)));
        int hp = state.getHealth();
        int hpMax = state.getMaxHealth();
        int mp = state.getMana();
        int mpMax = state.getMaxMana();

        if (perk != null) {
            hpMax = hpMax + perk.getHPBoost();
            mpMax = mpMax + perk.getMPBoost();
            hp = hp + perk.getHPBoost();
            mp = mp + perk.getMPBoost();
        }

        StateBean levelinfo = StorageCache.getInstance().getState((Integer) user.properties.get(Properties.LEVEL));
        state.setMaxHealth(hpMax);
        state.setMaxMana(mpMax);
        state.setHealth(hp);
        state.setMana(mp);
    }

    public void sendUotls(User user, boolean showHp, boolean showSp, boolean showHpMax, boolean showMp, boolean showMpMax, boolean showLevel, boolean showState) {
        try {
            if (user == null || user.properties == null) return;
            State state = (State) user.properties.get("state");
            if (state == null) return;

            Room sendRoom = null;
            try {
                if (user.getRoom() > 0) {
                    sendRoom = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
                }
            } catch (Throwable ignored) {
                sendRoom = null;
            }
            if (sendRoom == null) return;

            JSONObject uotls = new JSONObject();
            JSONObject o = new JSONObject();
            uotls.put("cmd", "uotls");

            if (showHp) o.put("intHP", state.getHealth());
            if (showSp) o.put("intSp", state.getDash());
            if (showHpMax) o.put("intHPMax", state.getMaxHealth());
            if (showMp) o.put("intMP", state.getMana());
            if (showMpMax) o.put("intMPMax", state.getMaxMana());
            if (showLevel) o.put("intLevel", user.properties.get("level"));
            if (showState) o.put("intState", state.getState());

            uotls.put("o", o);
            uotls.put("unm", user.getName());
            Kaiden_Extension.getInstance().send(uotls, sendRoom.getChannellList());
        } catch (Throwable t) {
            try {
                LOGGER.warn("sendUotls skipped for disconnected/changing-room user: " + t.getClass().getSimpleName() + " - " + t.getMessage());
            } catch (Throwable ignored) {}
        }
    }
/*
  public void getPerkAffects(User user) {
        FactionPerks perk = StorageCache.getInstance().getPerks((int)user.properties.get(Properties.FACTION_PERK));
        if (perk != null) { return; }

    }
*/
    public void regen(User user) {
        Regeneration regen = (Regeneration) user.properties.get("regenaration");
        if (!regen.isRegenerating()) {
            regen.setRunning(Executor.getInstance().scheduleTask(regen, 1L, TimeUnit.SECONDS, true));
        }
    }

    public void RegenerateOverTime(User user) {
        Regeneration regen = (Regeneration) user.properties.get("regenaration");
        if (!regen.isRegenerating()) {
            regen.setRunning(Executor.getInstance().scheduleTask(regen, 2L, TimeUnit.SECONDS, true));
        }
    }

    public void regenDash(User user) {
        // Kaiden_Engine.getInstance().sendEmulatorMessage("blue", "user dash is regenerating from regen function");
        DashRegeneration regen = (DashRegeneration) user.properties.get("dashRegeneration");
        if (regen != null) {
            regen.ensureRunning();
        }
    }

    public void createClass(User user, String ClassName) {
        JSONObject updateClass = new JSONObject();
        updateClass.put("cmd", "updateClass");
        updateClass.put("iCP", 500000);
        updateClass.put("uid", user.getUserId());
        updateClass.put("sClassName", ClassName);
        Kaiden_Extension.getInstance().send(updateClass, user);
        updateClass.clear();
        updateClass.put("cmd", "updateClass");
        updateClass.put("iCP", 500000);
        updateClass.put("sClassName", ClassName);
        updateClass.put("uid", user.getUserId());
        user.properties.put("cp", 50000);
        user.properties.put("classname", ClassName);
        Zone zone = Kaiden_Extension.getInstance().getZone();
        Kaiden_Extension.getInstance().sendToRoomButOne(updateClass, user, zone.getRoom(user.getRoom()));
    }

    public void updateClass(User user, ItemBean item, int classPoints) {
        String rawCategory = item.getItemClass() != null ? item.getItemClass().getCategory() : null;
        String normalizedCategoryCode = ClassCategory.normalizeCode(rawCategory);
        String categoryDisplayName = ClassCategory.codeToName(normalizedCategoryCode);

        JSONObject updateClass = new JSONObject();
        updateClass.put("cmd", "updateClass");
        updateClass.put("iCP", classPoints);
        updateClass.put("sClassCat", normalizedCategoryCode);
        updateClass.put("sClassCatName", categoryDisplayName);
        updateClass.put("sClassCatCode", normalizedCategoryCode);
        updateClass.put("sDesc", item.getItemClass().getDescription());
        updateClass.put("sStats", item.getItemClass().getStatsDescription());
        updateClass.put("uid", user.getUserId());

        if (item.getItemClass().getManaRegenerationMethods().contains(":")) {
            JSONArray aMRM = new JSONArray();
            String[] params = item.getItemClass().getManaRegenerationMethods().split(",");
            for (String method : params) {
                aMRM.add(method + "\r");
            }
            updateClass.put("aMRM", aMRM);
        } else {
            updateClass.put("aMRM", item.getItemClass().getManaRegenerationMethods());
        }

        updateClass.put("sClassName", item.getName());
        Kaiden_Extension.getInstance().send(updateClass, user);

        updateClass.clear();
        updateClass.put("cmd", "updateClass");
        updateClass.put("iCP", classPoints);
        updateClass.put("sClassCat", normalizedCategoryCode);
        updateClass.put("sClassCatName", categoryDisplayName);
        updateClass.put("sClassCatCode", normalizedCategoryCode);
        updateClass.put("sClassName", item.getName());
        updateClass.put("uid", user.getUserId());

        user.properties.put("cp", classPoints);
        user.properties.put("classname", item.getName());
        user.properties.put("classcat", normalizedCategoryCode);
        user.properties.put("classcatname", categoryDisplayName);
        user.properties.put("equippedClassItem", item);

        Zone zone = Kaiden_Extension.getInstance().getZone();
        Kaiden_Extension.getInstance().sendToRoomButOne(updateClass, user, zone.getRoom(user.getRoom()));
        this.loadClassSkills(user, item, classPoints);
    }

    public void dropItems(User user, Set<UserDrop> items) {
        dropItems(user, items, false);
    }

    /**
     * Quest completion rewards are a trusted grant source. Monster/map/live drops are not:
     * quest-bound items may only drop while one of their matching quests is active.
     */
    public void dropQuestRewards(User user, Set<UserDrop> items) {
        dropItems(user, items, true);
    }

    private void dropItems(User user, Set<UserDrop> items, boolean questRewardSource) {
        // Expire stale active quests and pending drops before evaluating any new drop.
        // This keeps Properties.QUESTS from outliving users_quests_active.

        // This prevents players from receiving time-trial quest drops after the clock ends.
        QuestProgressManager.checkTimedQuests(user);

        Set<UserDrop> dropItems = new HashSet();
        Set<UserDrop> addItems = new HashSet();
        Set<Integer> userQuests = (Set) user.properties.get(Properties.QUESTS);
        ConcurrentHashMap<Integer, UserItem> userItems = (ConcurrentHashMap) user.properties.get(Properties.INVENTORY_ITEMS);
        ConcurrentHashMap<Integer, UserItem> bankItems = (ConcurrentHashMap) user.properties.get(Properties.BANK_ITEMS);
        ConcurrentHashMap<Integer, Integer> tempItems = (ConcurrentHashMap) user.properties.get(Properties.TEMP_ITEMS);
        for (UserDrop item : items) {
            ItemBean itemObj = StorageCache.getInstance().getItem(item.getItemId());
            if (itemObj != null) {
                boolean questRequirement = this.isActiveQuestRequirement(userQuests, item.getItemId());
                boolean questMetadataMatch = this.checkDropItemForQuest(userQuests, itemObj);
                boolean questTyped = this.isQuestItemType(itemObj) || itemObj.isTemporary();
                boolean hasReqQuests = itemObj.getReqQuests() != null && !itemObj.getReqQuests().trim().isEmpty();

                // Critical distinction:
                // - quest completion rewards are allowed because the server is explicitly granting them;
                // - monster/map/live drops carrying quest metadata are blocked unless a matching quest is active.
                // This prevents Quest Item / ReqQuests drops from leaking when the quest is not in progress.
                // Yokai War medals are collected from monsters for the map's war meter.
                // Their ReqQuests metadata (482/483) is a legacy SWF war-meter reference,
                // not a requirement to accept a regular database quest first.
                // Restrict this exemption to these two item IDs only.
                boolean warItem = isConfiguredWarDropItem(itemObj);
                if (warItem) {
                    LOGGER.info("[WarDrop] Eligible war item " + item.getItemId()
                            + " for player " + user.getUserId());
                }
                // ReqQuests is an explicit restriction for monster/map drops.
                // Temporary items without ReqQuests remain freely droppable.
                // Quest rewards and configured war drops retain their own exemptions.
                // ReqQuests restricts only items explicitly typed Quest Item.
                // Regular weapons, armor, classes, and other items must drop normally.
                boolean explicitlyQuestItem = isQuestItemType(itemObj);
                boolean eligible = questRewardSource || warItem
                        || !explicitlyQuestItem
                        || !hasReqQuests
                        || questMetadataMatch;
                // War drops must enter temporary quest inventory even when the
                // SWF war-meter quest is not accepted as a database quest.
                // Use the same database-backed war lookup as drop eligibility.
                boolean questInventoryItem = warItem || (explicitlyQuestItem && (itemObj.isTemporary() || questRequirement || questRewardSource));

                if (eligible) {
                    // AQW-style rule: an item that is a turn-in requirement for ANY
                    // currently active quest is quest inventory, regardless of stale
                    // items.Temporary / ReqQuests metadata. Quest definitions are the
                    // authoritative source for quest-item ownership.
                    int stackLimit = Math.max(1, itemObj.getStack());
                    int requestedQuantity = Math.max(1, item.getQuantity());

                    if (!questInventoryItem) {
                        if (userItems.containsKey(item.getItemId())) {
                            int currentQuantity = Math.max(0, userItems.get(item.getItemId()).getQuantity());
                            int allowedQuantity = Math.min(requestedQuantity, Math.max(0, stackLimit - currentQuantity));
                            if (allowedQuantity > 0) {
                                dropItems.add(new UserDrop(item.getItemId(), allowedQuantity, false));
                            }
                        } else if (bankItems.containsKey(item.getItemId())) {
                            if (bankItems.size() >= (Integer) user.properties.get(Properties.BANK_SLOTS)) {
                                int allowedQuantity = Math.min(requestedQuantity, stackLimit);
                                if (allowedQuantity > 0) {
                                    dropItems.add(new UserDrop(item.getItemId(), allowedQuantity, true));
                                }
                            }
                        } else {
                            int allowedQuantity = Math.min(requestedQuantity, stackLimit);
                            if (allowedQuantity > 0) {
                                dropItems.add(new UserDrop(item.getItemId(), allowedQuantity, false));
                            }
                        }
                    } else {
                        int currentQuantity = tempItems.containsKey(item.getItemId())
                                ? Math.max(0, tempItems.get(item.getItemId())) : 0;
                        int allowedQuantity = Math.min(requestedQuantity, Math.max(0, stackLimit - currentQuantity));
                        if (allowedQuantity > 0) {
                            if (tempItems.containsKey(item.getItemId())) {
                                tempItems.replace(item.getItemId(), currentQuantity + allowedQuantity);
                            } else {
                                tempItems.put(item.getItemId(), allowedQuantity);
                            }
                            addItems.add(new UserDrop(item.getItemId(), allowedQuantity, false));
                        }
                    }
                }
            }
        }
        if (dropItems.size() > 0) {
            this.sendDropItem(user, dropItems);
        }
        if (addItems.size() > 0) {
            this.sendAddItems(user, addItems);
            for (UserDrop item : addItems) {
                QuestProgressManager.saveTempItem(user, item.getItemId());
            }
        }
    }

    /**
     * A monster drop is a war item when its ReqQuests contains a quest mapped to
     * an existing war in war_quests. This does not require the player to have
     * accepted the regular quest. Other quest-item restrictions stay intact.
     *
     * The short-lived cache avoids one SQL query per monster kill per item,
     * while still picking up newly configured wars without a server restart.
     */
    private static final ConcurrentHashMap<Integer, Boolean> WAR_DROP_CACHE = new ConcurrentHashMap<Integer, Boolean>();
    private static volatile long warDropCacheExpiresAt = 0L;

    private boolean isConfiguredWarDropItem(ItemBean item) {
        if (item == null) return false;
        String req = item.getReqQuests();
        if (req == null || req.trim().isEmpty()) return false;
        long now = System.currentTimeMillis();
        if (now >= warDropCacheExpiresAt) {
            synchronized (WAR_DROP_CACHE) {
                if (now >= warDropCacheExpiresAt) {
                    WAR_DROP_CACHE.clear();
                    warDropCacheExpiresAt = now + 30000L;
                }
            }
        }
        Boolean cached = WAR_DROP_CACHE.get(item.getId());
        if (cached != null) return cached.booleanValue();
        boolean isWar = false;
        // ReqQuests can contain multiple comma-separated quest IDs.
        for (String token : req.split("[,;| ]+")) {
            if (token.isEmpty()) continue;
            int questId;
            try { questId = Integer.parseInt(token); }
            catch (NumberFormatException ignored) { continue; }
            QueryResult result = null;
            try {
                result = Storage.getInstance().getJdbc().query(
                    "SELECT 1 FROM war_quests wq INNER JOIN wars w ON w.id=wq.WarID " +
                    "WHERE wq.QuestID=? AND wq.Enabled=1 LIMIT 1", questId);
                if (result.next()) { isWar = true; break; }
            } catch (Exception e) {
                LOGGER.warn("[WarDrop] Failed to check war quest " + questId + ": " + e.getMessage());
            } finally {
                if (result != null) result.close();
            }
        }
        WAR_DROP_CACHE.put(item.getId(), isWar);
        return isWar;
    }

    private boolean isActiveQuestRequirement(Set<Integer> activeQuestIds, int itemId) {
        if (activeQuestIds == null || activeQuestIds.isEmpty() || itemId <= 0) return false;
        for (Integer questId : activeQuestIds) {
            if (questId == null) continue;
            QuestBean quest = StorageCache.getInstance().getQuest(questId);
            if (quest != null && quest.requirements != null && quest.requirements.containsKey(itemId)) {
                return true;
            }
        }
        return false;
    }

    private boolean isQuestItemType(ItemBean itemObj) {
        if (itemObj == null) return false;
        String type = itemObj.getType();
        return type != null && ("Quest Item".equalsIgnoreCase(type.trim()) || "QuestItem".equalsIgnoreCase(type.trim()));
    }

    /** AQW quest inventory classification. Quest Item type is authoritative for quest rewards. */
    private boolean isQuestInventoryItem(ItemBean itemObj, boolean activeRequirement) {
        if (itemObj == null) return false;
        if (activeRequirement || itemObj.isTemporary()) return true;
        String type = itemObj.getType();
        return type != null && ("Quest Item".equalsIgnoreCase(type.trim()) || "QuestItem".equalsIgnoreCase(type.trim()));
    }

    private boolean checkDropItemForQuest(Set userQuests, ItemBean itemObj) {
        if (itemObj == null) {
            return false;
        }

        String reqQuests = itemObj.getReqQuests();
        if (reqQuests == null || reqQuests.trim().isEmpty()) {
            return true;
        }

        // Quest-required monster drops must only drop while the matching quest is active.
        // Null/empty active quest sets were causing required quest drops to fail silently.
        if (userQuests == null || userQuests.isEmpty()) {
            return false;
        }

        try {
            if (reqQuests.contains(",")) {
                for (String questId : reqQuests.split(",")) {
                    if (questId == null || questId.trim().isEmpty()) {
                        continue;
                    }
                    if (userQuests.contains(Integer.valueOf(questId.trim()))) {
                        return true;
                    }
                }
            } else {
                return userQuests.contains(Integer.valueOf(reqQuests.trim()));
            }
        } catch (Exception ignored) {
        }

        return false;
    }


    /**
     * Gives an item originating from the map/NPC QuestItem packet as a true
     * temporary quest item. Some legacy item rows are incorrectly marked
     * Temporary=0; routing those through dropItems() puts them in the pending
     * drop queue even though the AQW client immediately displays them as a
     * quest item. That leaves the client at 1/1 while server turn-in sees 0.
     */
    public void giveMapQuestItem(User user, int itemId, int quantity) {
        if (user == null || user.properties == null || itemId <= 0 || quantity <= 0) return;

        ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
        if (itemObj == null) return;

        ConcurrentHashMap<Integer, Integer> tempItems =
                (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);
        if (tempItems == null) {
            tempItems = new ConcurrentHashMap<Integer, Integer>();
            user.properties.put(Properties.TEMP_ITEMS, tempItems);
        }

        int oldQty = tempItems.containsKey(itemId) ? tempItems.get(itemId) : 0;
        int stack = itemObj.getStack() > 0 ? itemObj.getStack() : Integer.MAX_VALUE;
        int newQty = Math.min(stack, oldQty + quantity);
        int addedQty = newQty - oldQty;
        if (addedQty <= 0) return;

        tempItems.put(itemId, newQty);
        QuestProgressManager.saveTempItem(user, itemId);

        // A previous buggy QuestItem grant may have created a pending normal drop.
        ConcurrentHashMap<Integer, UserDrop> drops =
                (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");
        if (drops != null) drops.remove(itemId);
        QuestProgressManager.markDropAccepted(user, itemId);

        JSONObject packet = new JSONObject();
        JSONObject items = new JSONObject();
        JSONObject itemJSON = itemObj.getItemJSON(StorageCache.getInstance().getEnhancement(itemObj.getEnhId()));
        // getQuestItem/map quest-item grants are temporary by protocol semantics.
        // Do not leak a stale items.Temporary=0 value back to the client after we
        // have deliberately placed the item in TEMP_ITEMS. AQW keeps the client
        // quest inventory and the authoritative server temp inventory in sync.
        itemJSON.put("bTemp", 1);
        itemJSON.put("iQty", addedQty);
        items.accumulate(String.valueOf(itemObj.getId()), itemJSON);
        packet.put("items", items);
        packet.put("cmd", "addItems");
        Kaiden_Extension.getInstance().send(packet, user);

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green", "[QuestItem] temp grant user=" + user.getName() +
                        " ItemID=" + itemId + " qty=" + newQty +
                        " dbTemporary=" + itemObj.isTemporary());
    }

    private void sendAddItems(User user, Set<UserDrop> droppedItems) {
        JSONObject drop = new JSONObject();
        JSONObject items = new JSONObject();
        boolean replayingRestore = QuestProgressManager.isRestoreReplayingDrops(user);

        for (UserDrop item : droppedItems) {
            ItemBean itemObj = StorageCache.getInstance().getItem(item.getItemId());
            if (itemObj == null) {
                continue;
            }

            JSONObject itemJSON = itemObj.getItemJSON(StorageCache.getInstance().getEnhancement(itemObj.getEnhId()));
            itemJSON.put("iQty", item.getQuantity());

            Set<Integer> activeQuestIds = (Set<Integer>) user.properties.get(Properties.QUESTS);
            boolean questRequirement = this.isActiveQuestRequirement(activeQuestIds, item.getItemId());
            boolean questInventoryItem = this.isQuestInventoryItem(itemObj, questRequirement) || this.isConfiguredWarDropItem(itemObj);
            if (questInventoryItem) {
                // The quest definition wins over stale item metadata. The client must
                // receive the same temp classification used by server-side storage.
                itemJSON.put("bTemp", 1);
            }
            items.accumulate(String.valueOf(itemObj.getId()), itemJSON);

            // Only true normal drops belong in users_quests_drops. Active quest
            // requirements are already authoritative in TEMP_ITEMS/users_quests_items.
            if (!replayingRestore && !questInventoryItem) {
                QuestProgressManager.savePendingDrop(user, item);
            }
        }

        if (items.isEmpty()) {
            return;
        }

        drop.put("items", items);
        drop.put("cmd", "addItems");
        Kaiden_Extension.getInstance().send(drop, user);
    }


    public void sendRestoredTempItems(User user, Set<Integer> acceptedQuestIds) {
        if (user == null || user.properties == null) return;
        Map<Integer, Integer> restored = (Map<Integer, Integer>) user.properties.get(QuestProgressManager.RESTORED_TEMP_ITEMS);
        if (restored == null || restored.isEmpty()) return;

        ConcurrentHashMap<Integer, Integer> tempItems =
                (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);
        if (tempItems == null) {
            tempItems = new ConcurrentHashMap<Integer, Integer>();
            user.properties.put(Properties.TEMP_ITEMS, tempItems);
        }

        JSONObject items = new JSONObject();
        int restoredCount = 0;
        for (Map.Entry<Integer, Integer> entry : restored.entrySet()) {
            Integer itemId = entry.getKey();
            Integer quantity = entry.getValue();
            if (itemId == null || quantity == null || quantity <= 0) continue;
            ItemBean item = StorageCache.getInstance().getItem(itemId);
            if (item == null || !isActiveQuestRequirement(acceptedQuestIds, itemId)) continue;

            // The saved quantity is a snapshot, NOT an additional drop. Never add it
            // to a live quantity or a repeated room join could duplicate the item.
            int existing = tempItems.containsKey(itemId) ? tempItems.get(itemId) : 0;
            int finalQty = Math.max(existing, quantity);
            int stack = item.getStack();
            if (stack > 0) finalQty = Math.min(finalQty, stack);
            if (finalQty <= 0) continue;
            tempItems.put(itemId, finalQty);

            JSONObject itemJson = item.getItemJSON(StorageCache.getInstance().getEnhancement(item.getEnhId()));
            itemJson.put("bTemp", 1);
            itemJson.put("iQty", finalQty);
            items.accumulate(String.valueOf(itemId), itemJson);
            QuestProgressManager.saveTempItem(user, itemId);
            restoredCount++;
        }
        if (!items.isEmpty()) {
            JSONObject packet = new JSONObject();
            packet.put("cmd", "addItems");
            packet.put("items", items);
            Kaiden_Extension.getInstance().send(packet, user);
            Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                    "[QuestProgress] synchronized restored temp inventory user=" + user.getName()
                    + " items=" + restoredCount);
        }
    }

    public void sendRestoredPendingDrops(User user) {
        Map<Integer, UserDrop> restored = (Map<Integer, UserDrop>) user.properties.get(QuestProgressManager.RESTORED_PENDING_DROPS);
        if (restored == null || restored.isEmpty()) {
            return;
        }

        Set<UserDrop> dropItems = new HashSet<UserDrop>();
        for (UserDrop drop : restored.values()) {
            if (drop != null && drop.getItemId() > 0 && drop.getQuantity() > 0
                    && QuestProgressManager.isPendingDropValid(user, drop.getItemId())) {
                dropItems.add(drop);
            }
        }

        if (!dropItems.isEmpty()) {
            // Replaying pending drops must NOT re-save/update users_quests_drops.
            // The DB row stays pending until the player accepts or declines it.
            QuestProgressManager.beginRestoreDropReplay(user);
            try {
                this.sendDropItem(user, dropItems);
            } finally {
                QuestProgressManager.endRestoreDropReplay(user);
            }
            Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[QuestProgress] restored pending drop packet user=" + user.getName() + " drops=" + dropItems.size());
        }
    }

    public int getUpgradeDays(User user) {
        long expire = ((Date) user.properties.get("upgradeexpire")).getTime() - (new Date()).getTime();
        if (SpanUtils.millisToSeconds(expire) > 0) {
            return SpanUtils.millisToDays(expire);
        }
        return -1;
    }

    public int getBanTime(User user) {
        return SpanUtils.millisToSeconds(((Date) user.properties.get("bantime")).getTime() - (new Date()).getTime());
    }

    private void sendDropItem(User user, Set<UserDrop> droppedItems) {
        ConcurrentHashMap<Integer, UserDrop> drops = (ConcurrentHashMap) user.properties.get("drops");
        JSONObject drop = new JSONObject();
        JSONObject items = new JSONObject();
        boolean replayingRestore = QuestProgressManager.isRestoreReplayingDrops(user);

        for (UserDrop item : droppedItems) {
            ItemBean itemObj = StorageCache.getInstance().getItem(item.getItemId());
            if (itemObj == null) {
                continue;
            }

            // Enforce the stack cap against inventory AND already queued drops.
            int stackLimit = Math.max(1, itemObj.getStack());
            ConcurrentHashMap<Integer, UserItem> inventory =
                    (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.INVENTORY_ITEMS);
            ConcurrentHashMap<Integer, UserItem> bank =
                    (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.BANK_ITEMS);
            // Both locations count toward the same item.getStack() cap.
            int owned = 0;
            if (inventory != null && inventory.containsKey(item.getItemId()))
                owned += Math.max(0, inventory.get(item.getItemId()).getQuantity());
            if (bank != null && bank.containsKey(item.getItemId()))
                owned += Math.max(0, bank.get(item.getItemId()).getQuantity());

            UserDrop pending = drops.get(item.getItemId());
            int allowed;
            if (replayingRestore) {
                allowed = Math.min(Math.max(0, item.getQuantity()),
                        Math.max(0, stackLimit - owned));
                if (pending == null && allowed > 0)
                    drops.put(item.getItemId(), new UserDrop(item.getItemId(), allowed, item.isBank()));
            } else {
                int pendingQty = pending == null ? 0 : Math.max(0, pending.getQuantity());
                allowed = Math.min(Math.max(0, item.getQuantity()),
                        Math.max(0, stackLimit - owned - pendingQty));
                if (allowed > 0) {
                    if (pending == null)
                        drops.put(item.getItemId(), new UserDrop(item.getItemId(), allowed, item.isBank()));
                    else
                        pending.addQuantity(allowed);
                }
            }
            if (allowed <= 0) continue;
            UserDrop totalPending = drops.get(item.getItemId());

            JSONObject itemJSON = itemObj.getItemJSON(StorageCache.getInstance().getEnhancement(itemObj.getEnhId()));
            itemJSON.put("iQty", replayingRestore ? allowed : totalPending.getQuantity());
            items.accumulate(String.valueOf(itemObj.getId()), itemJSON);

            // LIVE monster drops save as pending. Restore replays already exist as pending
            // and must not rewrite/update the DB row. Accepted/declined handlers clear them.
            if (!replayingRestore && !isQuestItemType(itemObj) && !isConfiguredWarDropItem(itemObj)) {
                QuestProgressManager.savePendingDrop(user, totalPending);
            }
        }

        if (items.isEmpty()) {
            return;
        }

        drop.put("items", items);
        drop.put("cmd", "dropItem");
        Kaiden_Extension.getInstance().send(drop, user);
    }

    public int getAchievement(String field, int index, User user) {
        if ("ia0".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("ia0"), index);

        if ("iq0".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("iq0"), index);

        if ("ip0".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("ip0"), index);

        if ("ip1".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("ip1"), index);

        if ("ip2".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("ip2"), index);

        if ("id0".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("dailyquests0"), index);

        if ("id1".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("dailyquests1"), index);

        if ("id2".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("dailyquests2"), index);

        if ("im0".equals(field))
            return Kaiden.Game.Server.Users.Utils.Achievement.get((Integer) user.properties.get("monthlyquests0"), index);

        //Kaiden_Engine.getInstance().sendEmulatorMessage("red", "return -1");
        return -1;
    }

    public String getGuildRank(int rank) {
        String rankName = "";
        switch (rank) {
            case 0:
                rankName = "duffer";
                break;
            case 1:
                rankName = "member";
                break;
            case 2:
                rankName = "officer";
                break;
            case 3:
                rankName = "leader";
        }
        return rankName;
    }

    public boolean turnInItem(User user, int itemId, int quantity) {
        ConcurrentHashMap items = new ConcurrentHashMap();
        items.put(itemId, quantity);
        return this.turnInItems(user, items);
    }

    public void sendPreferences(User user, String pref) {
        int ia1 = (Integer) user.properties.get("settings");
        boolean value = Settings.getPreferences(pref, ia1);
        if (pref.equals(Settings.PARTY) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.PARTY_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.PARTY) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.PARTY_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.GOTO) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.GOTO_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.GOTO) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.GOTO_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.FRIEND) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.FRIEND_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.FRIEND) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.FRIEND_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.WHISPER) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.WHISPER_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.WHISPER) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.WHISPER_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.TOOLTIPS) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.TOOLTIPS_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.TOOLTIPS) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.TOOLTIPS_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.DUEL) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.DUEL_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.DUEL) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.DUEL_MESSAGE_OFF}, user);
        }

        if (pref.equals(Settings.GUILD) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.GUILD_MESSAGE_ON}, user);
        } else if (pref.equals(Settings.GUILD) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.GUILD_MESSAGE_OFF}, user);
        }
        if(pref.equals(Settings.TRADE) && value) {
            Kaiden_Extension.getInstance().send(new String[]{"server", Settings.TRADE_NESSAGE_ON}, user);
        } else if (pref.equals(Settings.TRADE) && !value) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", Settings.TRADE_MESSAGE_OFF}, user);
        }
    }

    public void updateStats(User user, EnhancementBean enhancement, String equipment) {
        Map<String, Double> itemStats = Server.getInstance().getItemStats(enhancement, equipment);
        Stats stats = (Stats) user.properties.get("stats");
        switch (equipment) {
            case "ar": {
                for (Entry<String, Double> ar : itemStats.entrySet()) {
                    stats.armor.put(ar.getKey(), ar.getValue());
                }
                break;
            }
            case "Weapon": {
                for (Entry<String, Double> weapon : itemStats.entrySet()) {
                    stats.weapon.put(weapon.getKey(), weapon.getValue());
                }
                // keep cached enhancement in sync so Stats.applyCoreStatRatings uses the new DPS immediately
                user.properties.put("weaponitemenhancement", enhancement);
                break;
            }
            case "ba": {
                for (Entry<String, Double> ba : itemStats.entrySet()) {
                    stats.cape.put(ba.getKey(), ba.getValue());
                }
                break;
            }
            /*
            case "mi": {
                for (Entry<String, Double> mi : stats.misc.entrySet()) {
                    stats.misc.put(mi.getKey(), 0.0D);
                }
                break;
            }

             */
            default: {
                if (equipment.equals("he")) {
                    for (Entry<String, Double> he : itemStats.entrySet()) {
                        stats.helm.put(he.getKey(), he.getValue());
                    }
                    break;
                }
                // co is visual armor and should not receive enhancement stats.
                if (equipment.equals("co")) {
                    return;
                }
                throw new IllegalArgumentException("equipment " + equipment + " cannot have stat values!");
            }
        }
    }

    public void removeAura(User user, RemoveAura ra) {
        if (user == null || ra == null) return;

        Set auras = (Set) user.properties.get("auras");
        State state = (State) user.properties.get("state");
        Object lock = state != null ? (Object) state : (auras != null ? (Object) auras : this);
        synchronized (lock) {
            if (auras != null) {
                auras.remove(ra);
            }
            if (state != null) {
                state.removeAura(ra);
            }
        }
    }

    public boolean hasAura(User user, int auraId) {
        if (user == null) return false;
        State state = (State) user.properties.get("state");
        if (state != null) {
            return state.hasAura(auraId);
        }

        Set auras = (Set) user.properties.get("auras");
        if (auras == null || auras.isEmpty()) return false;

        long now = System.currentTimeMillis();
        for (Object o : auras) {
            if (!(o instanceof RemoveAura)) continue;
            RemoveAura ra = (RemoveAura) o;
            if (ra == null || ra.getAura() == null) continue;
            long end = ra.getEndTime();
            if (end > 0L && end <= now) continue;
            if (ra.getAura().getId() == auraId) {
                return true;
            }
        }
        return false;
    }

    public RemoveAura applyAura(User user, AuraBean aura) {
        return this.applyAura(user, aura, "");
    }

    public RemoveAura applyAura(User user, AuraBean aura, String sourceInf) {
        if (user == null || aura == null) return null;

        Set<RemoveAura> auras = (Set) user.properties.get("auras");
        if (auras == null) {
            auras = Collections.newSetFromMap(new ConcurrentHashMap<RemoveAura, Boolean>());
            user.properties.put("auras", auras);
        }

        State state = (State) user.properties.get("state");
        final String normalizedSource = sourceInf == null ? "" : sourceInf.trim().toLowerCase();
        final Object lock = state != null ? (Object) state : auras;

        synchronized (lock) {
            RemoveAura ra = state != null ? state.applyAura(aura, normalizedSource) : null;
            if (ra == null && state == null) {
                long newEndTime = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(aura.getDuration());
                ra = new RemoveAura(aura, user, Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom()));
                ra.setStackCount(1);
                ra.setRefreshedOnly(false);
                ra.scheduleToEndTime(newEndTime);
                ra.setSourceInf(normalizedSource);
            }
            if (ra != null) {
                auras.add(ra);
                try {
                    Stats stats = (Stats) user.properties.get("stats");
                    if (stats != null && state != null && stats.get$shield() > 0.0D && state.getCurrentShield() <= 0) {
                        state.setCurrentShield((int) Math.max(0, Math.round(stats.get$shield())));
                    }
                } catch (Exception ignored) {}
            }
            return ra;
        }
    }



    public void clearAuras(User user) {
        Set<RemoveAura> auras = (Set) user.properties.get("auras");
        if (auras != null && !auras.isEmpty()) {
            java.util.Set<RemoveAura> copy = new java.util.HashSet<RemoveAura>(auras);
            for (RemoveAura ca : copy) {
                if (ca == null) continue;
                try {
                    ca.run();
                } catch (Throwable ignored) {}
                try {
                    ca.cancel();
                } catch (Throwable ignored) {}
                try {
                    if (ca.getAura() != null) {
                        //this.RestorePlayer(user, "the aura: " + ca.getAura().getName() + " has been cleared!");
                    }
                } catch (Throwable ignored) {}
            }
            auras.clear();
        }
        Stats stats = (Stats) user.properties.get("stats");
        State state = (State) user.properties.get("state");
        if (stats != null) {
            // Active aura removals above already remove their own applied stat effects via RemoveAura.run().
            // Do NOT clear every stat effect here, or passive effects get wiped and rebuilt repeatedly on
            // movement / pad changes / neutral-state aura clears.
            PassiveContainer.getInstance().restoreCachedPassiveEffects(user, false);
            stats.updateIfDirty();
        } else {
            PassiveContainer.getInstance().restoreCachedPassiveEffects(user, false);
        }
        if (state != null) {
            state.setCurrentShield(0);
            state.refreshCombatState();
        }
        this.sendStats(user);
        Kaiden_Extension.getInstance().send(new JSONObject().accumulate("cmd", "clearAuras"), user);
    }

    public void applyPassiveAuras(User user, int rank, ClassBean classObj) {
        PassiveContainer.getInstance().applyPassiveAuras(user, rank, classObj);
    }

    public void sendStats(User user) {
        this.sendStats(user, false);
    }

    public void sendStatsIfDirty(User user) {
        Stats stats = (Stats) user.properties.get("stats");
        if (stats == null || !stats.isDirty()) return;
        this.sendStats(user, false, true);
    }

    public void sendStats(User user, boolean levelUp) {
        this.sendStats(user, levelUp, false);
    }

    private void sendStats(User user, boolean levelUp, boolean onlyIfDirty) {
        JSONObject stu = new JSONObject();
        JSONObject tempStat = new JSONObject();
        int userLevel = (int) user.properties.get(Properties.LEVEL);
        Stats stats = (Stats) user.properties.get("stats");
        StateBean statemodule = StorageCache.getInstance().getState(userLevel);
        FactionPerks perk = StorageCache.getInstance().getPerks(Integer.valueOf((String)user.properties.get(Properties.FACTION_PERK)));

        int userHp = statemodule.getHealth();
        int userMp = statemodule.getMana();
        int userHpMax = statemodule.getHealth();
        int userMpMax = statemodule.getMana();
        int dash = 100;

        if (perk != null) {
            userHp = statemodule.getHealth() + perk.getHPBoost();
            userHpMax = statemodule.getMana() + perk.getMPBoost();
            userMp = statemodule.getMana() + perk.getMPBoost();
            userMpMax = statemodule.getMana() + perk.getHPBoost();
        }

        stats.updateIfDirty();

        State state = (State) user.properties.get("state");
        state.setMaxHealth(userHp);
        state.setMaxMana(userMp);
        state.setMaxDash(100);
        if (state.getState() == 1 || levelUp) {
            state.setHealth(userHp);
        }
        if (state.getState() == 1 || levelUp) {
            state.setMana(userMp);
        }
        this.sendUotls(user, true, false, true, true, true, levelUp, false);
        JsonConfig config = new JsonConfig();
        JSONObject stat = JSONObject.fromObject(stats, config);
        stat.put("$tcr", CombatEvaluator.getDisplayedCritChance(stats));
        stat.put("$tdo", CombatEvaluator.getDisplayedEvadeChance(stats));
        stat.put("$thi", CombatEvaluator.getDisplayedHitChance(stats));
        stat.put("$tha", CombatEvaluator.getDisplayedHaste(stats));
        stat.put("intHP", state.getHealth());
        stat.put("intHPMax", state.getMaxHealth());
        stat.put("intMP", state.getMana());
        stat.put("intMPMax", state.getMaxMana());
        JSONObject innate = new JSONObject();
        innate.put("INT", stats.innate.get("INT") +  stats.title.get("INT"));
        innate.put("STR", stats.innate.get("STR") +  stats.title.get("STR"));
        innate.put("DEX", stats.innate.get("DEX") +  stats.title.get("DEX"));
        innate.put("END", stats.innate.get("END") +  stats.title.get("END"));
        innate.put("LCK", stats.innate.get("LCK") +  stats.title.get("LCK"));
        innate.put("WIS", stats.innate.get("WIS") +   stats.title.get("WIS"));
        tempStat.put("ba", this.itemStats(stats.cape.entrySet().iterator()));
        tempStat.put("ar", this.itemStats(stats.armor.entrySet().iterator()));
        tempStat.put("Weapon", this.itemStats(stats.weapon.entrySet().iterator()));
        tempStat.put("he", this.itemStats(stats.helm.entrySet().iterator()));
        tempStat.put("aura", this.itemStats(stats.auraCore.entrySet().iterator()));
        tempStat.put("innate", innate);
        stu.put("tempSta", tempStat);
        stu.put("cmd", "stu");
        stu.put("sta", stat);
        stu.put("wDPS", stats.wDPS);
        Kaiden_Extension.getInstance().send(stu, user);
    }

    private JSONObject itemStats(Iterator iterator) {
        JSONObject object = new JSONObject();
        while (iterator.hasNext()) {
            Entry entry = (Entry) iterator.next();
            if (((Double) entry.getValue()) != 0.0D) {
                object.put(entry.getKey(), ((Double) entry.getValue()).intValue());
            }
        }
        return object;
    }

    public JSONObject getItemObject(int itemId, int enhId) {
        JSONObject item = new JSONObject();
        ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
        if (itemObj != null) {
            item.put("ItemID", itemId);
            item.put("bCoins", itemObj.isCoins() ? 1 : 0);
            item.put("bHouse", itemObj.isHouse() ? 1 : 0);
            item.put("bPTR", 0);
            item.put("bStaff", itemObj.isStaff() ? 1 : 0);
            item.put("bTemp", itemObj.isTemporary() ? 1 : 0);
            item.put("bUpg", itemObj.isUpgrade() ? 1 : 0);
            item.put("bTrade", itemObj.isTradeable() ? 1 : 0);
            item.put("iCost", itemObj.getCost());
            item.put("iDPS", itemObj.getDPS());
            item.put("iLvl", itemObj.getLevel());
            item.put("iQSindex", itemObj.getQuestStringIndex());
            item.put("iQSvalue", itemObj.getQuestStringValue());
            //item.put("sQuest", itemObj.getQ());
            item.put("iRng", itemObj.getClientRange());
            item.put("iRty", itemObj.getRarity());
            item.put("iStk", itemObj.getStack());
            item.put("sDesc", itemObj.getDescription());
            item.put("sES", itemObj.getEquipment());
            item.put("sElmt", itemObj.getElement());
            item.put("sFile", itemObj.getFile());
            item.put("sIcon", itemObj.getIcon());
            item.put("sLink", itemObj.getLink());
            item.put("sMeta", itemObj.getMeta());
            item.put("sName", itemObj.getName());
            //item.put("sDateCreated", itemObj.getDateCreated());
            item.put("sReqQuests", itemObj.getReqQuests());
            item.put("sType", itemObj.getType());

            if (enhId > 0 || itemObj.getType().equals("Enhancement")) {
                EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(enhId);
                if (itemObj.getType().equals("Enhancement")) {
                    item.put("PatternID", enhancement.getClientPatternId());
                    item.put("EnhPatternID", enhancement.getClientPatternId());
                    item.put("ProcID", enhancement.getProcId());
                    item.put("iDPS", enhancement.getDPS());
                    item.put("iLvl", enhancement.getLevel());
                    item.put("EnhLvl", enhancement.getLevel());
                    item.put("iRng", itemObj.getClientRange());
                    item.put("iRty", enhancement.getRarity());
                    item.put("EnhID", enhancement.getId());
                    item.remove("sFile");
                } else {
                    item.put("EnhID", enhId);
                    item.put("EnhLvl", enhancement.getLevel());
                    item.put("EnhPatternID", enhancement.getClientPatternId());
                    item.put("EnhRty", enhancement.getRarity());
                    item.put("ProcID", enhancement.getProcId());
                    item.put("EnhLvl", enhancement.getLevel());
                    item.put("iRty", enhancement.getRarity());
                    item.put("iRng", itemObj.getClientRange());
                    item.put("EnhRng", itemObj.getClientRange());
                    item.put("InvEnhPatternID", enhancement.getClientPatternId());
                    item.put("EnhDPS", enhancement.getDPS());
                }
            }
        }
        return item;
    }

    public void addOfferItem(User user, int itemId, int quantity, int enhId) {
        Map offers = (Map) user.properties.get(Properties.TRADE_OFFERS);
        Map enhances = (Map) user.properties.get(Properties.TRADE_OFFERS_ENHID);
        if (offers.containsKey(Integer.valueOf(itemId))) {
            int deltaQuantity = ((Integer) offers.get(Integer.valueOf(itemId))).intValue() + quantity;
            offers.put(Integer.valueOf(itemId), Integer.valueOf(deltaQuantity));
        } else {
            offers.put(Integer.valueOf(itemId), Integer.valueOf(quantity));
        }

        enhances.put(Integer.valueOf(itemId), Integer.valueOf(enhId));
    }

    public void removeOfferItem(User user, int itemId, int quantity) {
        Map tempInventory = (Map) user.properties.get(Properties.TRADE_OFFERS);
        Map enhances = (Map) user.properties.get(Properties.TRADE_OFFERS_ENHID);
        if (tempInventory.containsKey(Integer.valueOf(itemId))) {
            int deltaQuantity = ((Integer) tempInventory.get(Integer.valueOf(itemId))).intValue() - quantity;
            if (deltaQuantity < 1) {
                tempInventory.remove(Integer.valueOf(itemId));
                enhances.remove(Integer.valueOf(itemId));
            } else {
                tempInventory.put(Integer.valueOf(itemId), Integer.valueOf(deltaQuantity));
            }
        }
    }
    public void lastarea(User user, Room room, String frame, String pad) {
        user.properties.put("lastarea", room.getName() + "|" + frame + "|" + pad);
        Storage.getInstance().getJdbc().run("UPDATE users SET lastarea = ? WHERE id = ?", user.properties.get("lastarea"), user.properties.get(Properties.ID));
    }

    public void lastlocation(User user, String location) {
        user.properties.put("lastlocation", location);
        Storage.getInstance().getJdbc().run("UPDATE users SET LastLocation = ? WHERE id = ?", location, user.properties.get(Properties.ID));
    }
}
