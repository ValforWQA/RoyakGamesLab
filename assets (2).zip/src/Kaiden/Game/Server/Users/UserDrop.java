package Kaiden.Game.Server.Users;

public class UserDrop {

    private final int itemId;
    private int quantity;
    private final boolean bank;

    public UserDrop(int itemId, int quantity, boolean bank) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.bank = bank;
    }

    public int getItemId() {
        return this.itemId;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public boolean isBank() {
        return this.bank;
    }

    public void addQuantity(int quantity) {
        this.quantity += quantity;
    }
}
