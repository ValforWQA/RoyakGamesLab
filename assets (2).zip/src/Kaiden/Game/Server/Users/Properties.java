package Kaiden.Game.Server.Users;

import Kaiden.Database.Storage;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.BeanCreator;
import net.sf.json.JSONObject;

import java.util.HashMap;

@SuppressWarnings("ALL")
public class Properties extends Users {
    public static final String ID = "id";
    public static final String USERNAME = "username";
    public static final String GOLD = "gold";
    public static final String COINS = "coins";
    public static final String LOGIN_GOLD = "loginGold";
    public static final String LOGIN_COINS = "loginCoins";
    public static final String SOULS = "souls";
    public static final String PRESTIGE_LEVEL = "prestige_level";
    public static final String PRESTIGE_EXP = "prestige_exp";
    public static final String EXPERIENCE = "experience";
    public static final String LEVEL = "level";
    public static final String FRAME = "frame";
    public static final String PAD = "pad";
    public static final String TITLE_ID = "title_id";
    public static final String ACHIEVEMENTS = "achievements";
    public static final String CODED_REDEEMS = "codedredeems";
    public static final String FACTIONS = "factions";
    public static final String ACCESS = "access";
    public static final String ROLE_NAME = "rolename";
    public static final String ROLE_COLOR = "rolecolor";
    public static final String NAME_COLOR = "namecolor";
    public static final String UPG_LEVEL = "upglevel";
    public static final String FACTION_PERK = "factionperk";
    public static final String FACTION = "factionid";


    public static final String HASH = "hash";
    public static final String EMAIL = "email";
    public static final String AVATAR = "avatar";

    public static final String ACTIVATION_FLAG = "activationflag";
    public static final String PERMAMUTE_FLAG = "permamute";
    public static final String COUNTRY = "country";
    public static final String AGE = "age";
    public static final String GENDER = "gender";

    public static final String CURRENT_SERVER = "currentserver";
    public static final String HOUSE_INFO = "houseinfo";

    public static final String KILL_COUNT = "killcount";
    public static final String DEATH_COUNT = "deathcount";

    public static final String IP = "ip";
    public static final String LOGIN_TOKEN = "logintoken";

    public static final String DATE_CREATED = "datecreated";
    public static final String LAST_LOGIN = "lastlogin";

    public static final String UPGRADE_EXPIRE = "upgradeexpire";
    public static final String UPGRADE_DAYS = "upgradedays";
    public static final String UPGRADED = "upgraded";

    public static final String QUESTS_1 = "quests1";
    public static final String QUESTS_2 = "quests2";
    public static final String DAILY_QUESTS0 = "dailyquests0";
    public static final String DAILY_QUESTS1 = "dailyquests1";
    public static final String DAILY_QUESTS2 = "dailyquests2";
    public static final String MONTHLY_QUESTS0 = "monthlyquests0";

    public static final String SETTINGS = "settings";
    public static final String IA0 = "ia0";


    public static final String IQ0 = "iq0";
    public static final String IP0 = "ip0";
    public static final String IP1 = "ip1";
    public static final String IP2 = "ip2";

    public static final String QUESTS = "quests";
    public static final String BANK_SLOTS = "bankslots";
    public static final String INVENTORY_ITEMS = "inventoryitems";
    public static final String BANK_ITEMS = "iventoryitems";
    public static final String TEMP_ITEMS = "tempinventory";
    public static final String LOADOUT_SLOTS = "loadoutslots";
    public static final String WEAR_EQUIPMENT = "wearequipment";
    public static final String SKILLS = "skills";
    public static final String SKILLS_CD = "skills_cd";

    public static final int STATE_DEAD = 0;
    public static final int STATE_NORMAL = 1;
    public static final int STATE_COMBAT = 2;

    public static final String TRADE_TARGET = "tradetgt";
    public static final String TRADE_OFFERS = "offer";
    public static final String TRADE_OFFERS_ENHID = "offerenh";
    public static final String TRADE_GOLD = "tradegold";
    public static final String TRADE_COINS = "tradecoins";
    public static final String TRADE_LOCK = "tradelock";
    public static final String TRADE_DEAL = "tradedeal";
    public static final String TRADE_ITEM = "trade_item";
    public static final String TRADE_INVITE = "trade_invite";
    public static final String TRADE_INVITE_TIME = "trade_invite_time";
    public static final String REQUESTED_TRADE = "requestedtrade";

    public static final String SLOTS_BAG = "bagslots";
    public static final String SLOTS_BANK = "bankslots";
    public static final String SLOTS_HOUSE = "houseslots";

    // bean properties

    public static final String ITEM_CLASS = "ar";
    public static final String ITEM_ARMOR = "co";
    public static final String ITEM_WEAPON = "Weapon";
    public static final String ITEM_HELM = "he";
    public static final String ITEM_CAPE = "ba";
    public static final String ITEM_PET = "pe";
    public static final String ITEM_GROUND = "mi";
    public static final String ITEM_AMULET = "am";
    public static final String ITEM_HOUSE = "ho";
    public static final String ITEM_HOUSE_ITEM = "hi";
    public static final String RESPAWN_TIME = "respawntime";

    public static final BeanCreator<HashMap> userData = rs -> {
        HashMap properties = new HashMap();
        properties.put(Properties.ID, rs.getInt("id"));
        properties.put(Properties.USERNAME, rs.getString("Name"));
        properties.put(Properties.GOLD, rs.getInt("Gold"));
        properties.put(Properties.COINS, rs.getInt("Coins"));

        // Currency baseline captured at login for safe logout delta-saving.
        properties.put(Properties.LOGIN_GOLD, rs.getInt("Gold"));
        properties.put(Properties.LOGIN_COINS, rs.getInt("Coins"));
        properties.put(Properties.SOULS, rs.getInt("Souls"));
        properties.put(Properties.LEVEL, rs.getInt("Level"));
        properties.put(Properties.EXPERIENCE, rs.getInt("Exp"));
        properties.put(Properties.ACCESS, rs.getInt("Access"));
        properties.put(Properties.ROLE_NAME, rs.getString("Role"));
        properties.put(Properties.ROLE_COLOR, rs.getString("RoleColor"));
        properties.put(Properties.NAME_COLOR, rs.getString("NameColor"));
        properties.put(Properties.FACTION_PERK, rs.getString("PerkID"));
        properties.put(Properties.FACTION, rs.getString("FactionID"));
        properties.put(Properties.TRADE_COINS, 0);
        properties.put(Properties.TRADE_GOLD, 0);
        properties.put("permamute", rs.getInt("PermamuteFlag"));
        properties.put("gender", rs.getString("Gender"));
        properties.put("colorhair", Integer.valueOf(rs.getString("ColorHair"), 16));
        properties.put("colorskin", Integer.valueOf(rs.getString("ColorSkin"), 16));
        properties.put("coloreye", Integer.valueOf(rs.getString("ColorEye"), 16));
        properties.put("colorbase", Integer.valueOf(rs.getString("ColorBase"), 16));
        properties.put("colortrim", Integer.valueOf(rs.getString("ColorTrim"), 16));
        properties.put("coloraccessory", Integer.valueOf(rs.getString("ColorAccessory"), 16));
        properties.put("hairId", rs.getInt("HairID"));
        properties.put(Properties.LOADOUT_SLOTS, rs.getInt("SlotsLoadOut"));
        properties.put(Properties.TITLE_ID, rs.getInt("TitleID"));
        properties.put("bagslots", rs.getInt("SlotsBag"));
        properties.put("bankslots", rs.getInt("SlotsBank"));
        properties.put("houseslots", rs.getInt("SlotsHouse"));
        properties.put("lastarea", rs.getString("LastArea"));
        properties.put("lastlocation", rs.getString("LastLocation"));
        properties.put("quests1", rs.getString("Quests1"));
        properties.put("quests2", rs.getString("Quests2"));
        properties.put("dailyquests0", rs.getInt("DailyQuests0"));
        properties.put("dailyquests1", rs.getInt("DailyQuests1"));
        properties.put("dailyquests2", rs.getInt("DailyQuests2"));
        properties.put("monthlyquests0", rs.getInt("MonthlyQuests0"));
        properties.put("settings", rs.getInt("Settings"));
        properties.put("ia0", rs.getInt("Achievement"));
        properties.put("guildid", rs.getInt("GuildID"));
        properties.put("guildrank", rs.getInt("Rank"));
        properties.put("upgradeexpire", rs.getDate("UpgradeExpire"));
        properties.put("timeplay", rs.getInt("TimePlay"));


        properties.put("iq0", rs.getInt("Iq0"));
        properties.put("ip0", rs.getInt("ip0"));
        properties.put("ip1", rs.getInt("ip1"));
        properties.put("ip2", rs.getInt("ip2"));


        properties.put(Properties.HASH, rs.getString("Hash"));
        properties.put(Properties.EMAIL, rs.getString("Email"));
        properties.put(Properties.AVATAR, rs.getString("Avatar"));

        properties.put(Properties.ACTIVATION_FLAG, rs.getInt("ActivationFlag"));
        properties.put(Properties.PERMAMUTE_FLAG, rs.getInt("PermamuteFlag"));
        properties.put(Properties.COUNTRY, rs.getString("Country"));
        properties.put(Properties.AGE, rs.getInt("Age"));
        properties.put(Properties.GENDER, rs.getString("Gender"));

        properties.put(Properties.CURRENT_SERVER, rs.getString("CurrentServer"));
        properties.put(Properties.HOUSE_INFO, rs.getString("HouseInfo"));

        properties.put(Properties.KILL_COUNT, rs.getInt("KillCount"));
        properties.put(Properties.DEATH_COUNT, rs.getInt("DeathCount"));

        properties.put(Properties.IP, rs.getString("IP"));
        properties.put(Properties.LOGIN_TOKEN, rs.getString("LoginToken"));

        properties.put(Properties.DATE_CREATED, rs.getDate("DateCreated"));
        properties.put(Properties.LAST_LOGIN, rs.getDate("LastLogin"));

        properties.put(Properties.UPGRADE_EXPIRE, rs.getDate("UpgradeExpire"));
        properties.put(Properties.UPGRADE_DAYS, rs.getLong("UpgradeDays"));
        properties.put(Properties.UPGRADED, rs.getInt("Upgraded"));

        // prestige columns are varchar in your schema (safe to store raw)
        properties.put(Properties.PRESTIGE_LEVEL, rs.getString("PrestigeLevel"));
        properties.put(Properties.PRESTIGE_EXP, rs.getString("PrestigeExp"));

        return properties;
    };

    public static void updateCoins(User user, int amount, int quantity) {
        JSONObject sellItem = new JSONObject();
        sellItem.put("cmd", "sellItem");
        sellItem.put("intAmount", quantity);
        sellItem.put("CharItemID", user.hashCode());
        sellItem.put("bCoins", "1");
        Kaiden_Extension.getInstance().send(sellItem, user);
        user.properties.replace(Properties.COINS, amount);
    }

    public static void updateLastLogin(User user) {
        Storage.getInstance().getJdbc().run(
                "UPDATE users SET `LastLogin` = NOW() WHERE `id` = ?",
                user.properties.get(Properties.ID)
        );
    }

    public static void updateGoldCoins(User user, int gold, int coins) {
        JSONObject tr = new JSONObject();
        tr.element("cmd", "updateGoldCoins");
        tr.element("intGold", gold);
        tr.element("intCoins", coins);
        Kaiden_Extension.getInstance().send(tr, user);

        user.properties.replace(Properties.COINS, coins);
        user.properties.replace(Properties.GOLD, gold);

        Storage.getInstance().getJdbc().run(
                "UPDATE users SET Coins = ?, Gold = ? WHERE id = ?",
                new Object[]{Integer.valueOf(coins), Integer.valueOf(gold), user.properties.get(Properties.ID)}
        );

        // This method writes absolute Gold/Coins to the DB. Reset the logout
        // baseline so the logout delta-save will not apply this update twice.
        user.properties.put(Properties.LOGIN_GOLD, gold);
        user.properties.put(Properties.LOGIN_COINS, coins);
    }
}
