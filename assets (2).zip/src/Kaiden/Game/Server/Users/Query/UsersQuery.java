package Kaiden.Game.Server.Users.Query;

import Kaiden.Database.Beans.*;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Database.AsyncDbExecutor;
import Kaiden.Game.Server.Packets.Commands.Moderator.Item;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Rooms.WarzoneQueue;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Parties.ManageParties;
import Kaiden.Game.Server.Users.Parties.PartyInfo;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserItem;
import Kaiden.Game.Server.Combat.Player.PassiveContainer;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.*;
import Kaiden.Game.Threads.Regeneration;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import jdbchelper.JdbcException;
import jdbchelper.NoResultException;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/* holds all KaidenEngine user queries */

public class UsersQuery {

    private static final Logger LOGGER = Logger.getLogger(UsersQuery.class);
    private static UsersQuery instance;
    //public static String CURRENCY1 = "Rubie's";

    public static UsersQuery getInstance() {
        if (instance == null) {
            instance = new UsersQuery();
        }
        return instance;
    }

    public JSONObject getUserData(User user, boolean self) {
        HairBean hair = StorageCache.getInstance().getHair((Integer) user.properties.get("hairId"));
        if (hair != null) {
            JSONObject userData = new JSONObject();
            String lastArea = (String) user.properties.get("lastarea");
            lastArea = lastArea.split("\\|")[0];
            userData.put("eqp", user.properties.get("equipment"));
            userData.put("iCP", user.properties.get("cp"));
            userData.put("iUpgDays", user.properties.get("upgdays"));
            userData.put("intAccessLevel", user.properties.get("access"));
            userData.put("intColorAccessory", user.properties.get("coloraccessory"));
            userData.put("intColorBase", user.properties.get("colorbase"));
            userData.put("intColorEye", user.properties.get("coloreye"));
            userData.put("intColorHair", user.properties.get("colorhair"));
            userData.put("intColorSkin", user.properties.get("colorskin"));
            userData.put("intColorTrim", user.properties.get("colortrim"));
            userData.put("intLevel", user.properties.get(Properties.LEVEL));
            userData.put("strClassName", user.properties.get("classname"));
            userData.put("strGender", user.properties.get("gender"));
            userData.put("strHairFilename", hair.getFile());
            userData.put("strHairName", hair.getName());
            userData.put("FactionID", user.properties.get(Properties.FACTION));
            userData.put("PerkID", user.properties.get(Properties.FACTION_PERK));
            userData.put("strUsername", user.properties.get(Properties.USERNAME));
            userData.put("CharID", user.properties.get(Properties.ID));
            userData.put("rolecolor", user.properties.get(Properties.ROLE_COLOR));
            userData.put("namecolor", user.properties.get(Properties.NAME_COLOR));
            userData.put("rolename", user.properties.get(Properties.ROLE_NAME));
            userData.put("intGold", user.properties.get(Properties.GOLD));
            userData.put("intCoins", user.properties.get(Properties.COINS));
            userData.put("intSouls", user.properties.get(Properties.SOULS));


            if ((Integer) user.properties.get("guildid") > 0) {
                JSONObject state = (JSONObject) user.properties.get("guildobj");
                JSONObject result = new JSONObject();
                result.put("id", user.properties.get("guildid"));
                result.put("Name", state.get("Name"));
                result.put("MOTD", state.get("MOTD"));
                result.put("guildcolor", state.get("guildcolor"));
                userData.put("guild", result);
                userData.put("guildRank", user.properties.get("guildrank"));
            }

            if ((Integer) user.properties.get(Properties.TITLE_ID) > 0) {
                JSONObject title = new JSONObject();
                TitleBean titleObject = StorageCache.getInstance().getTitle((Integer) user.properties.get(Properties.TITLE_ID));
                title.put("id", user.properties.get(Properties.TITLE_ID));
                title.put("Name", titleObject != null ? titleObject.getName() : "");
                title.put("Color", titleObject != null ? titleObject.getColor() : "");
                userData.put("title", title);
            }

            if (self) {
                State state1 = (State) user.properties.get("state");
                QueryResult result1 = Storage.getInstance().getJdbc().query(
                        "SELECT HouseInfo, ActivationFlag, Gold, Coins, Exp, Country, Email, DateCreated, UpgradeExpire, Age, Souls, PrestigeLevel, PrestigeExp, Upgraded FROM users WHERE id = ?",
                        user.properties.get(Properties.ID)
                );

                if (result1.next()) {
                    userData.put("CharID", user.properties.get(Properties.ID));
                    userData.put("HairID", hair.getId());
                    userData.put("UserID", user.properties.get(Properties.ID));
                    userData.put("bPermaMute", user.properties.get("permamute"));
                    userData.put("bitSuccess", "1");
                    userData.put("dCreated", (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")).format(result1.getDate("DateCreated")));
                    userData.put("dUpgExp", (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")).format(result1.getDate("UpgradeExpire")));
                    userData.put("iAge", result1.getString("Age"));
                    userData.put("iBagSlots", user.properties.get("bagslots"));
                    userData.put("iBankSlots", user.properties.get("bankslots"));
                    userData.put("iBoostCP", 0);
                    userData.put("iBoostG", 0);
                    userData.put("iBoostRep", 0);
                    userData.put("iBoostXP", 0);
                    userData.put("iDEX", 0);
                    userData.put("iDailyAdCap", 6);
                    userData.put("iDailyAds", 0);
                    userData.put("iEND", 0);
                    userData.put("iFounder", 1);
                    userData.put("iHouseSlots", user.properties.get("houseslots"));
                    userData.put("iLoadoutSlots", user.properties.get(Properties.LOADOUT_SLOTS));
                    userData.put("iSlots", user.properties.get(Properties.LOADOUT_SLOTS));
                    userData.put("sOutfits", "r2");
                    userData.put("outfitSets", getUserLoadouts(user));
                    userData.put("iINT", 0);
                    userData.put("iLCK", 0);
                    userData.put("iSTR", 0);
                    userData.put("iUpg", result1.getInt("Upgraded"));
                    userData.put("iWIS", 0);
                    userData.put("ia0", user.properties.get("ia0"));
                    userData.put("ia1", user.properties.get("settings"));
                    userData.put("id0", user.properties.get("dailyquests0"));
                    userData.put("id1", user.properties.get("dailyquests1"));
                    userData.put("id2", user.properties.get("dailyquests2"));
                    userData.put("im0", user.properties.get("monthlyquests0"));
                    userData.put("ip0", user.properties.get("ip0"));
                    userData.put("ip1", user.properties.get("ip1"));
                    userData.put("ip2", user.properties.get("ip2"));
                    userData.put("iq0", user.properties.get("iq0"));
                    userData.put("intActivationFlag", result1.getInt("ActivationFlag"));
                    userData.put("intCoins", result1.getInt("Coins"));
                    userData.put("intSouls", result1.getInt("Souls"));
                    userData.put("intPrestigeLevel", result1.getInt("PrestigeLevel"));
                    userData.put("intPrestigeExp", result1.getInt("PrestigeExp"));
                    userData.put("intExp", result1.getInt("Exp"));
                    userData.put("intExpToLevel", Server.getInstance().getExpToLevel((Integer) user.properties.get(Properties.LEVEL)));
                    userData.put("intGold", result1.getInt("Gold"));
                    userData.put("intHP", state1.getHealth());
                    userData.put("intHPMax", state1.getMaxHealth());
                    userData.put("intHits", 1267);
                    userData.put("intMP", state1.getMana());
                    userData.put("intSP", state1.getDash());
                    userData.put("intMPMax", state1.getMaxMana());
                    userData.put("lastArea", user.properties.get("lastarea"));
                    userData.put("lastlocation", user.properties.get("lastlocation"));
                    userData.put("sCountry", result1.getString("Country"));
                    userData.put("sHouseInfo", result1.getString("HouseInfo"));
                    userData.put("strEmail", result1.getString("Email"));
                    userData.put("strMapName", Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom()).getName().split("-")[0]);
                    userData.put("strQuests", user.properties.get("quests1"));
                    userData.put("strQuests2", user.properties.get("quests2"));
                }
                result1.close();
            }

            return userData;
        }
        return null;
    }

    public void giveRewards(User user, int exp, int gold, int cp, int rep, int coin, int Souls, int monboost, int factionId, int fromId, String npcType) {

        boolean levelup = false;
        boolean xpBoost = (Boolean) user.properties.get("xpboost");
        boolean goldBoost = (Boolean) user.properties.get("goldboost");
        boolean repBoost = (Boolean) user.properties.get("repboost");
        boolean coinBoost = (Boolean) user.properties.get("coinboost");
        boolean cpBoost = (Boolean) user.properties.get("cpboost");

        double itemExpMult = Kaiden.Game.Server.Combat.Player.BoostContainer.getInstance().validateExpBoost(user);
        double itemGoldMult = Kaiden.Game.Server.Combat.Player.BoostContainer.getInstance().validateGoldBoost(user);
        double itemRepMult = Kaiden.Game.Server.Combat.Player.BoostContainer.getInstance().validateRepBoost(user);
        double itemCpMult = Kaiden.Game.Server.Combat.Player.BoostContainer.getInstance().validateClassBoost(user);

        int calcExp = xpBoost ? exp * (1 + Configuration.EXP_RATE) : exp * Configuration.EXP_RATE;
        int calcGold = goldBoost ? gold * (1 + Configuration.GOLD_RATE) : gold * Configuration.GOLD_RATE;
        int calcRep = repBoost ? rep * (1 + Configuration.REP_RATE) : rep * Configuration.REP_RATE;
        int calcCoin = coinBoost ? coin * (1 + Configuration.COIN_RATE) : coin * Configuration.COIN_RATE;
        int calcCp = cpBoost ? cp * (1 + Configuration.CP_RATE) : cp * Configuration.CP_RATE;

        calcExp = (int) Math.round(calcExp * itemExpMult);
        calcGold = (int) Math.round(calcGold * itemGoldMult);
        calcRep = (int) Math.round(calcRep * itemRepMult);
        calcCp = (int) Math.round(calcCp * itemCpMult);

        int userLevel = (int) user.properties.get(Properties.LEVEL);
        int maxLevel = StorageCache.getInstance().getCoreValue("intLevelMax").intValue();
        int expReward = (Integer) user.properties.get(Properties.LEVEL) < maxLevel ? calcExp : 0;

        int classPoints = (Integer) user.properties.get("cp");
        int curRank = ClassRank.getRankFromPoints((Integer) user.properties.get("cp"));

        int userGold = (int) user.properties.get(Properties.GOLD) + calcGold;
        int userCoins = (int) user.properties.get(Properties.COINS) + calcCoin;
        int userExp = (int) user.properties.get(Properties.EXPERIENCE) + expReward;

        if (expReward > 0) {
            if (userLevel < StorageCache.getInstance().getCoreValue("intLevelMax")) {
                int nextLevel = userLevel;
                while (userExp >= Server.getInstance().getExpToLevel(userLevel)) {
                    userExp -= Server.getInstance().getExpToLevel(userLevel);
                    nextLevel++;
                }
                if (nextLevel > userLevel) {
                    Users.getInstance().levelUp(user, nextLevel);
                    levelup = true;
                }
                user.properties.replace(Properties.EXPERIENCE, userExp);
            }
        }

        if (calcGold > 0) {
            user.properties.replace(Properties.GOLD, userGold);
        }

        if (calcCoin > 0) {
            Properties.updateCoins(user, userCoins, calcCoin);
        }

        if (curRank != 10 && (calcCp > 0 || monboost > 0)) {
            JSONObject equipment = (JSONObject) user.properties.get("equipment");
            int cpBaseReward = calcCp;
            int cpBonusReward = monboost > 0 ? monboost : 0;
            int cpTotalReward = cpBaseReward + cpBonusReward;
            int finalUserCp = classPoints + cpTotalReward >= 302500 ? 302500 : classPoints + cpTotalReward;

            if (equipment.has("ar")) {
                JSONObject oldItem = equipment.getJSONObject("ar");
                int itemId = oldItem.getInt("ItemID");

                Storage.getInstance().getJdbc().beginTransaction();
                try {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?",
                            finalUserCp,
                            itemId,
                            user.properties.get(Properties.ID)
                    );

                    if (ClassRank.getRankFromPoints(finalUserCp) > curRank) {
                        this.loadClassSkills(user, StorageCache.getInstance().getItem(itemId), finalUserCp);
                    }
                } catch (JdbcException e) {
                    if (Storage.getInstance().getJdbc().isInTransaction()) {
                        Storage.getInstance().getJdbc().rollbackTransaction();
                    }
                } finally {
                    if (Storage.getInstance().getJdbc().isInTransaction()) {
                        Storage.getInstance().getJdbc().commitTransaction();
                    }
                }
            }
        }

        if (factionId > 1) {
            int expRep = calcRep >= 302500 ? 302500 : calcRep;
            if (Storage.getInstance().getJdbc().queryForBoolean(
                    "SELECT COUNT(*) AS rowcount FROM users_factions WHERE UserID = ? AND FactionID = ?",
                    user.properties.get(Properties.ID), factionId)) {
                Storage.getInstance().getJdbc().run(
                        "UPDATE users_factions SET Reputation = (Reputation + ?) WHERE UserID = ? AND FactionID = ?",
                        expRep, user.properties.get(Properties.ID), factionId);
            } else {
                Storage.getInstance().getJdbc().holdConnection();
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_factions (UserID, FactionID, Reputation) VALUES (?, ?, ?)",
                        user.properties.get(Properties.ID), factionId, expRep);
                long charFactionId = Storage.getInstance().getJdbc().getLastInsertId();
                Storage.getInstance().getJdbc().releaseConnection();

                JSONObject faction = new JSONObject();
                faction.put("FactionID", factionId);
                faction.put("bitSuccess", 1);
                faction.put("CharFactionID", charFactionId);
                faction.put("sName", StorageCache.getInstance().getFaction(factionId));
                faction.put("iRep", calcRep);

                JSONObject addFaction = new JSONObject();
                addFaction.put("cmd", "addFaction");
                addFaction.put("faction", faction);
                Kaiden_Extension.getInstance().send(addFaction, user);
            }
        }

        JSONObject addGoldExp = new JSONObject();
        addGoldExp.put("cmd", "addGoldExp");
        addGoldExp.put("id", fromId);
        addGoldExp.put("intGold", calcGold);

        if (Souls > 0) {
            addGoldExp.put("souls", Souls);
            updateSouls(user, Souls);
        }

        addGoldExp.put("intCoin", calcCoin);
        addGoldExp.put("typ", npcType);

        if (coinBoost) {
            addGoldExp.put("bonusCoin", calcCoin / 2);
        }

        if (userLevel < maxLevel) {
            if (levelup) {
                addGoldExp.put("intExp", userExp);
            } else {
                addGoldExp.put("intExp", expReward);
            }

            int baseServerExp = xpBoost ? exp * Configuration.EXP_RATE : exp * Configuration.EXP_RATE;
            int itemExpBonus = expReward - baseServerExp;
            if (itemExpBonus > 0) {
                addGoldExp.put("bonusExp", itemExpBonus);
            } else if (xpBoost) {
                addGoldExp.put("bonusExp", expReward / 2);
            }
        }

        if (curRank != 10 && monboost > 0) {
            int cpBaseReward = calcCp;
            int cpBonusReward = monboost;
            int cpTotalReward = cpBaseReward + cpBonusReward;
            int finalUserCp = classPoints + cpTotalReward >= 302500 ? 302500 : classPoints + cpTotalReward;

            addGoldExp.put("iCP", cpTotalReward);
            addGoldExp.put("bonusCP", cpBonusReward);
            user.properties.put("cp", finalUserCp);

        } else if (curRank != 10 && calcCp > 0) {
            int cpBonusReward = 0;
            int cpTotalReward = calcCp;
            int finalUserCp = calcCp + classPoints >= 302500 ? 302500 : calcCp + classPoints;

            int baseServerCp = cpBoost ? cp * (1 + Configuration.CP_RATE) : cp * Configuration.CP_RATE;
            int itemCpBonus = calcCp - baseServerCp;

            if (itemCpBonus > 0) {
                cpBonusReward = itemCpBonus;
                cpTotalReward = calcCp;
                finalUserCp = cpTotalReward + classPoints >= 302500 ? 302500 : cpTotalReward + classPoints;
            } else if (cpBoost) {
                cpBonusReward = calcCp / 2;
                cpTotalReward = calcCp + cpBonusReward;
                finalUserCp = cpTotalReward + classPoints >= 302500 ? 302500 : cpTotalReward + classPoints;
            }

            addGoldExp.put("iCP", cpTotalReward);
            if (cpBonusReward > 0) {
                addGoldExp.put("bonusCP", cpBonusReward);
            }
            user.properties.put("cp", finalUserCp);
        }

        if (factionId > 0) {
            addGoldExp.put("FactionID", factionId);
            addGoldExp.put("iRep", calcRep);

            int baseServerRep = repBoost ? rep * (1 + Configuration.REP_RATE) : rep * Configuration.REP_RATE;
            int itemRepBonus = calcRep - baseServerRep;

            if (itemRepBonus > 0) {
                addGoldExp.put("bonusRep", itemRepBonus);
            } else if (repBoost) {
                addGoldExp.put("bonusRep", calcRep / 2);
            }
        }

        int baseServerGold = goldBoost ? gold * (1 + Configuration.GOLD_RATE) : gold * Configuration.GOLD_RATE;
        int itemGoldBonus = calcGold - baseServerGold;
        if (itemGoldBonus > 0) {
            addGoldExp.put("bonusGold", itemGoldBonus);
        }

        Kaiden_Extension.getInstance().send(addGoldExp, user);
    }
/*
        if (curRank != 10 && calcCp > 0 && rankedClassItem != null) {
            try {
                if (rankedUp) {
                    this.loadClassSkills(user, rankedClassItem, userCp);
                } else {
                    Users.getInstance().updateClass(user, rankedClassItem, userCp);
                }
            } catch (Exception ignored) {
            }
        }
    }
*/
public boolean turnInItems(User user, ConcurrentHashMap<Integer, Integer> items) {
    if (user == null || items == null || items.isEmpty()) {
        return false;
    }

    ConcurrentHashMap<Integer, UserItem> inventory =
            (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.INVENTORY_ITEMS);
    ConcurrentHashMap<Integer, Integer> temporaryInventory =
            (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);

    StringBuilder sItems = new StringBuilder();
    ConcurrentHashMap<Integer, Boolean> consumeFromTemp = new ConcurrentHashMap<Integer, Boolean>();

    // Validate every requirement first.  Legacy AQW quest data is inconsistent
    // about the Temporary flag, so locate the item in the container that really
    // owns enough quantity instead of rejecting a valid client-visible quest item.
    for (Entry<Integer, Integer> entry : items.entrySet()) {
        int itemId = entry.getKey();
        int quantityRequirement = entry.getValue();
        if (quantityRequirement <= 0) continue;

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item == null) {
            this.log(user, "Suspicous TurnIn", "Turning in an unknown item: " + itemId);
            return false;
        }

        int tempQty = 0;
        if (temporaryInventory != null) {
            Integer q = temporaryInventory.get(itemId);
            tempQty = q == null ? 0 : q;
        }

        int normalQty = 0;
        if (inventory != null) {
            UserItem ui = inventory.get(itemId);
            normalQty = ui == null ? 0 : ui.getQuantity();
        }

        // Recover authoritative persisted state if an older packet handler wrote
        // the DB but failed to update the live maps. Hydrate the temp container
        // so consumption and users_quests_items cleanup stay on the normal path.
        if (tempQty < quantityRequirement && normalQty < quantityRequirement) {
            try {
                int persistedTemp = Storage.getInstance().getJdbc().queryForInt(
                        "SELECT COALESCE(MAX(Quantity),0) FROM users_quests_items WHERE UserID=? AND ItemID=?",
                        user.properties.get(Properties.ID), itemId);
                if (persistedTemp >= quantityRequirement) {
                    if (temporaryInventory == null) {
                        temporaryInventory = new ConcurrentHashMap<Integer, Integer>();
                        user.properties.put(Properties.TEMP_ITEMS, temporaryInventory);
                    }
                    temporaryInventory.put(itemId, persistedTemp);
                    tempQty = persistedTemp;
                }
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red",
                        "[QuestTurnIn] temp item recovery failed item=" + itemId + ": " + e.getMessage());
                return false; // Do not consume other items after an uncertain inventory read.
            }
        }

        // Some older quest-item handlers persist the normal item without
        // hydrating INVENTORY_ITEMS. Restore only real persisted ownership.
        if (tempQty < quantityRequirement && normalQty < quantityRequirement) {
            try {
                int persistedNormal = Storage.getInstance().getJdbc().queryForInt(
                        "SELECT COALESCE(SUM(Quantity),0) FROM users_items WHERE UserID=? AND ItemID=?",
                        user.properties.get(Properties.ID), itemId);
                if (persistedNormal >= quantityRequirement) {
                    // Do not fabricate an in-memory UserItem; reject with an
                    // actionable diagnostic instead of silently losing items.
                    Kaiden_Engine.getInstance().sendEmulatorMessage("yellow",
                            "[QuestTurnIn] item=" + itemId +
                            " persistedNormal=" + persistedNormal +
                            " but live normal inventory is stale; relog/reload required");
                }
            } catch (Exception ignored) {}
        }

        boolean useTemp;
        if (item.isTemporary() && tempQty >= quantityRequirement) {
            useTemp = true;
        } else if (!item.isTemporary() && normalQty >= quantityRequirement) {
            useTemp = false;
        } else if (tempQty >= quantityRequirement) {
            useTemp = true;
        } else if (normalQty >= quantityRequirement) {
            useTemp = false;
        } else {
            this.log(user, "Suspicous TurnIn", "Quantity requirement is lacking for item " + itemId +
                    " (temp=" + tempQty + ", inventory=" + normalQty + ", need=" + quantityRequirement + ").");
            return false;
        }
        consumeFromTemp.put(itemId, useTemp);
    }

    // Consume from the same container selected during validation.
    for (Entry<Integer, Integer> entry : items.entrySet()) {
        int itemId = entry.getKey();
        int quantityRequirement = entry.getValue();
        if (quantityRequirement <= 0) continue;

        boolean useTemp = Boolean.TRUE.equals(consumeFromTemp.get(itemId));
        if (useTemp) {
            int ownedQty = temporaryInventory.get(itemId);
            int quantityLeft = ownedQty - quantityRequirement;
            if (quantityLeft > 0) temporaryInventory.put(itemId, quantityLeft);
            else temporaryInventory.remove(itemId);

            // Keep persistent quest-item restore state in sync with the turn-in.
            QuestProgressManager.saveTempItem(user, itemId);
        } else {
            UserItem userItem = inventory.get(itemId);
            int quantityLeft = userItem.getQuantity() - quantityRequirement;
            if (quantityLeft > 0) {
                userItem.setQuantity(quantityLeft);
                inventory.put(itemId, userItem);
                Storage.getInstance().getJdbc().execute(
                        "UPDATE users_items SET Quantity = ? WHERE ItemID = ? AND UserID = ?",
                        quantityLeft, itemId, user.properties.get(Properties.ID));
            } else {
                inventory.remove(itemId);
                Storage.getInstance().getJdbc().execute(
                        "DELETE FROM users_items WHERE ItemID = ? AND UserID = ?",
                        itemId, user.properties.get(Properties.ID));
            }
        }

        if (sItems.length() > 0) sItems.append(",");
        sItems.append(itemId).append(":").append(quantityRequirement);
    }

    if (sItems.length() > 0) {
        JSONObject ti1 = new JSONObject();
        ti1.put("cmd", "turnIn");
        ti1.put("sItems", sItems.toString());
        Kaiden_Extension.getInstance().send(ti1, user);
    }
    return true;
}



    public void removeActiveQuestAfterCompletion(User user, int questid) {
        Storage.getInstance().getJdbc().execute(
                "DELETE FROM users_quests_active WHERE UserID = ? AND QuestID = ?",
                user.properties.get(Properties.ID),
                questid
        );
    }

    public int getItemQuantity(User user, int itemId) {
        if (user == null || itemId <= 0) {
            return 0;
        }

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item == null) {
            return 0;
        }

        if (item.isTemporary()) {
            ConcurrentHashMap<Integer, Integer> temporaryInventory =
                    (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);

            if (temporaryInventory == null) {
                return 0;
            }

            Integer qty = temporaryInventory.get(itemId);
            return qty == null ? 0 : qty;
        }

        ConcurrentHashMap<Integer, UserItem> inventory =
                (ConcurrentHashMap<Integer, UserItem>) user.properties.get(Properties.INVENTORY_ITEMS);

        if (inventory == null) {
            return 0;
        }

        UserItem userItem = inventory.get(itemId);
        if (userItem == null) {
            return 0;
        }

        return Math.max(userItem.getQuantity(), 0);
    }




    public int getCharItemId(int itemId, @org.jetbrains.annotations.NotNull User user) {
        try {
            return Storage.getInstance().getJdbc().queryForInt("SELECT id FROM users_items WHERE ItemID=? AND UserID=?", itemId, user.properties.get(Properties.ID));
        } catch (NoResultException ex) {
            return -1;
        }
    }

    public void logTrade(User user, int tradepartner, int itemtraded) {
       // Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Trade Session Logged [" + user.getName().toLowerCase() + "][" + tradepartner + "] " + itemtraded);
        int userId = (Integer) user.properties.get(Properties.ID);
        Storage.getInstance().getJdbc().run("INSERT INTO logs_users_trades (UserID, TraderID, ItemID) VALUES (?, ?, ?)", userId, tradepartner, itemtraded);
    }
    public void UsersQuestLog(User user, int questid) {
        int userId = (Integer) user.properties.get(Properties.ID);

        //Kaiden_Engine.getInstance().sendEmulatorMessage(
              //  "green",
               // "Quest Completed [" + user.getName().toLowerCase() +
                //        "][QuestID:" + questid + "], UserID:" + userId
       // );

        Storage.getInstance().getJdbc().run(
                "INSERT INTO users_quests_completed (UserID, QuestID, Count, DateCompleted) " +
                        "VALUES (?, ?, 1, NOW()) " +
                        "ON DUPLICATE KEY UPDATE " +
                        "Count = Count + 1, " +
                        "DateCompleted = NOW()",
                userId,
                questid
        );
    }

    public void log(User user, String violation, String details) {
        //Kaiden_Engine.getInstance().sendEmulatorMessage("green","Logged [" + user.getName().toLowerCase() + "][" + violation + "] " + details);
        int userId = (Integer) user.properties.get(Properties.ID);
        Storage.getInstance().getJdbc().run("INSERT INTO logs_users (UserID, Violation, Details) VALUES (?, ?, ?)", userId, violation, details);
    }

    public void giveAchievement(User user, int achievementId) {
        if (user == null || achievementId <= 0) {
            return;
        }

        Set<Integer> achievements = (Set<Integer>) user.properties.get(Properties.ACHIEVEMENTS);
        if (achievements == null) {
            return;
        }

        AchievementBean achievement = StorageCache.getInstance().getAchievement(achievementId);
        if (achievement == null) {
            return;
        }

        // Prevent duplicate achievement grants
        if (achievements.contains(achievementId) || this.checkAchievements(user, achievementId)) {
            achievements.add(achievementId);
            // Keep account-management rewards synchronized even when the badge
            // already existed before a new automatic reward was configured.
            AccountRewardSync.onAchievementGranted(user, achievementId);
            return;
        }

        if (achievement.getField() != null && !achievement.getField().isEmpty()) {
            this.setAchievement(achievement.getField(), achievement.getIndex(), achievement.getValue(), user);
            Kaiden_Engine.getInstance().sendEmulatorMessage("pinkb", "setting achievement " + achievement.getField());
        }

        if (achievement.getIndex() > -1) {
            this.setQuestValue(user, achievement.getIndex(), achievement.getValue());
            Kaiden_Engine.getInstance().sendEmulatorMessage("green", "setting quest value" + achievement.getValue() + " settings index" + achievement.getIndex());
        }

        Storage.getInstance().getJdbc().run(
                "INSERT INTO users_achievements (`UserID`, `AchID`, DateAchieved) VALUES (?, ?, NOW())",
                user.properties.get(Properties.ID),
                achievementId
        );

        achievements.add(achievementId);

        JSONObject showbadgewin = new JSONObject();
        showbadgewin.put("cmd", "givebadge");
        showbadgewin.put("achievementName", achievement.getName());
        showbadgewin.put("achievementId", achievement.getId());
        Kaiden_Extension.getInstance().send(showbadgewin, user);

        // Bridge achievement unlocks into account-management rewards.
        AccountRewardSync.onAchievementGranted(user, achievementId);
    }

    public void setQuestValue(User user, int index, int value) {
        if (index < 0 || index > Quests.MAX_SLOT || value < 0 || value >= 36) {
            LOGGER.warn("Rejected quest progress slot=" + index + " value=" + value);
            return;
        }
        if (value > this.getQuestValue(user, index)) {
            if (index > 99) {
                user.properties.put("quests2", Quests.updateValue((String) user.properties.get("quests2"), index - 100, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET Quests2 = ? WHERE id =  ?", user.properties.get("quests2"), user.properties.get(Properties.ID));
            } else {
                user.properties.put("quests1", Quests.updateValue((String) user.properties.get("quests1"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET Quests1 = ? WHERE id = ?", user.properties.get("quests1"), user.properties.get(Properties.ID));
            }

            JSONObject updateQuest = new JSONObject();
            updateQuest.put("cmd", "updateQuest");
            updateQuest.put("iIndex", index);
            updateQuest.put("iValue", value);
            Kaiden_Extension.getInstance().send(updateQuest, user);
        }
    }



    public int getQuestValue(User user, int index) {
        if (index < 0 || index > Quests.MAX_SLOT) return 0;
        return index > 99 ? Quests.lookAtValue((String) user.properties.get("quests2"), index - 100) : Quests.lookAtValue((String) user.properties.get("quests1"), index);
    }

    public void setAchievement(String field, int index, int value, User user) {

        // ✅ LOG: request received
//         Kaiden_Engine.getInstance().sendEmulatorMessage(
//                 "green",
//                 "[setAchievement] user=" + user.properties.get(Properties.USERNAME) +
//                         " id=" + user.properties.get(Properties.ID) +
//                         " field=" + field + " index=" + index + " value=" + value
//         );

        switch (field) {
            case "ia0":
                user.properties.put("ia0", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("ia0"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET Achievement = ? WHERE id = ?", user.properties.get("ia0"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK ia0 -> " + user.properties.get("ia0"));
                break;

            case "iq0":
                user.properties.put("iq0", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("iq0"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET Iq0 = ? WHERE id = ?", user.properties.get("iq0"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK iq0 -> " + user.properties.get("iq0"));
                break;

            case "ip0":
                user.properties.put("ip0", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("ip0"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET ip0 = ? WHERE id = ?", user.properties.get("ip0"), user.properties.get(Properties.ID));

                //Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                  //       "[setAchievement] OK ip0 -> " + user.properties.get("ip0"));
                break;

            case "ip1":
                user.properties.put("ip1", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("ip1"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET ip1 = ? WHERE id = ?", user.properties.get("ip1"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK ip1 -> " + user.properties.get("ip1"));
                break;

            case "ip2":
                user.properties.put("ip2", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("ip2"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET ip2 = ? WHERE id = ?", user.properties.get("ip2"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK ip2 -> " + user.properties.get("ip2"));
                break;

            case "id0":
                user.properties.put("dailyquests0", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("dailyquests0"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET DailyQuests0 = ? WHERE id = ?", user.properties.get("dailyquests0"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK id0(dailyquests0) -> " + user.properties.get("dailyquests0"));
                break;

            case "id1":
                user.properties.put("dailyquests1", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("dailyquests1"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET DailyQuests1 = ? WHERE id = ?", user.properties.get("dailyquests1"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK id1(dailyquests1) -> " + user.properties.get("dailyquests1"));
                break;

            case "id2":
                user.properties.put("dailyquests2", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("dailyquests2"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET DailyQuests2 = ? WHERE id = ?", user.properties.get("dailyquests2"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK id2(dailyquests2) -> " + user.properties.get("dailyquests2"));
                break;

            case "im0":
                user.properties.put("monthlyquests0", Kaiden.Game.Server.Users.Utils.Achievement.update((Integer) user.properties.get("monthlyquests0"), index, value));
                Storage.getInstance().getJdbc().run("UPDATE users SET MonthlyQuests0 = ? WHERE id = ?", user.properties.get("monthlyquests0"), user.properties.get(Properties.ID));

//                 Kaiden_Engine.getInstance().sendEmulatorMessage("green",
//                         "[setAchievement] OK im0(monthlyquests0) -> " + user.properties.get("monthlyquests0"));
                break;

            default:
                Kaiden_Extension.getInstance().sendToUser("warning",
                        "Failed to update achievement please report this to staff ASAP [" + field + "]", user);

                // ✅ LOG: failure
//                 Kaiden_Engine.getInstance().sendEmulatorMessage(
//                         "green",
//                         "[setAchievement] FAIL unknown field=" + field +
//                                 " user=" + user.properties.get(Properties.USERNAME) +
//                                 " id=" + user.properties.get(Properties.ID)
//                 );
                break;
        }

        JSONObject sa = new JSONObject();
        sa.put("cmd", "setAchievement");
        sa.put("field", field);
        sa.put("index", index);
        sa.put("value", value);
        Kaiden_Extension.getInstance().send(sa, user);
    }

    public boolean checkAchievements(User user, int achievementId) {
        QueryResult result = Storage.getInstance().getJdbc().query(
                "SELECT AchID FROM users_achievements WHERE UserID = ? AND AchID = ?",
                user.properties.get(Properties.ID), achievementId
        );
        if (result.next()) {
            return true;
        }

        return false;
    }

    public void giveUpgradeDays(User user, int days) {
        if ((Integer) user.properties.get("upgdays") >= 0) {
            user.properties.replace("upgdays", (int) user.properties.get("upgdays") + days);
            Storage.getInstance().getJdbc().run("UPDATE users SET `UpgradeExpire` = DATE_ADD(`UpgradeExpire` , INTERVAL ? DAY) WHERE `id` = ?", days, user.properties.get(Properties.ID));
        } else {
            user.properties.replace("upgdays", days);
            Storage.getInstance().getJdbc().run("UPDATE users SET `UpgradeExpire` = DATE_ADD(NOW() , INTERVAL ? DAY), `Upgraded` = 1 WHERE `id` = ?", days, user.properties.get(Properties.ID));
        }
    }

    public void levelUp(User user, int level) {
        int newLevel = level >= StorageCache.getInstance().getCoreValue("intLevelMax") ? StorageCache.getInstance().getCoreValue("intLevelMax").intValue() : level;
        user.properties.replace(Properties.LEVEL, newLevel);
        user.properties.replace(Properties.EXPERIENCE, 0);
        Users.getInstance().sendStats(user, true);
        JSONObject levelUp = new JSONObject();
        JSONObject balance = new JSONObject();
        levelUp.put("cmd", "levelUp");
        levelUp.put("intLevel", newLevel);
        levelUp.put("intExpToLevel", Server.getInstance().getExpToLevel(newLevel));
        Kaiden_Extension.getInstance().send(levelUp, user);
        balance.put("cmd", "balance");
        balance.put("intExp", user.properties.get(Properties.EXPERIENCE));
        Kaiden_Extension.getInstance().send(balance, user);
        Storage.getInstance().getJdbc().run("UPDATE users SET Level = ? WHERE id = ?", newLevel, user.properties.get(Properties.ID));
    }
    public void updateSouls(User user, int nsouls) {
      JSONObject souls = new JSONObject(); // gotta put the baby to sleep sorry guys brb
        int currentSouls = (int)user.properties.get(Properties.SOULS);
        int newSouls = (int)user.properties.get(Properties.SOULS) + nsouls;
      souls.put("cmd", "updateSouls");
      souls.put("souls", (int)user.properties.get(Properties.SOULS) + nsouls);
      user.properties.replace(Properties.SOULS, newSouls);
      //Storage.getInstance().getJdbc().run("UPDATE users SET Souls = ? WHERE id = ?", newSouls, user.properties.get(Properties.ID));
      //Kaiden_Extension.getInstance().sendToUser("server", "x"+nsouls+ " souls collected", user);
      //Kaiden_Extension.getInstance().send(souls, user);
    }

    public void subtraceSouls(User user, int nsouls) {
        JSONObject souls = new JSONObject(); // gotta put the baby to sleep sorry guys brb
        int currentSouls = (int)user.properties.get(Properties.SOULS);
        int newSouls = (int)user.properties.get(Properties.SOULS) - nsouls;
        souls.put("cmd", "updateSouls");
        souls.put("souls", (int)user.properties.get(Properties.SOULS) - nsouls);
        user.properties.replace(Properties.SOULS, newSouls);
        //Storage.getInstance().getJdbc().run("UPDATE users SET Souls = ? WHERE id = ?", newSouls, user.properties.get(Properties.ID));
        //Kaiden_Extension.getInstance().sendToUser("server", "x"+nsouls+ " souls collected", user);
        Kaiden_Extension.getInstance().send(souls, user);
    }

    public void changePreferences(User user, String pref, boolean value) {
        int ia1 = (Integer) user.properties.get("settings");
        ia1 = Settings.setPreferences(pref, ia1, value);
        Zone zone = Kaiden_Extension.getInstance().getZone();
        user.properties.put("settings", ia1);
        JSONObject uotls = new JSONObject();
        uotls.put("cmd", "uotls");
        uotls.put("unm", user.getName());
        if (pref.equals(Settings.HELM)) {
            uotls.put("o", (new JSONObject()).put("showHelm", Settings.getPreferences(Settings.HELM, ia1)));
            Kaiden_Extension.getInstance().sendToRoomButOne(uotls, user, zone.getRoom(user.getRoom()));
        }
        if (pref.equals(Settings.CLOAK)) {
            uotls.put("o", (new JSONObject()).put("showCloak", Settings.getPreferences(Settings.CLOAK, "ia1")));
            Kaiden_Extension.getInstance().sendToRoomButOne(uotls, user, zone.getRoom(user.getRoom()));
        }
        Users.getInstance().sendPreferences(user, pref);
        Storage.getInstance().getJdbc().run("UPDATE users SET Settings = ? WHERE id = ?", ia1, user.properties.get(Properties.ID));
    }

    public boolean scanInventoryItem(User user, ItemBean drop, int quantity) {
        QueryResult result = Storage.getInstance().getJdbc().query(
                "SELECT * FROM users_items WHERE UserID = ? AND ItemID = ?",
                user.properties.get(Properties.ID), drop.getId());

        if (result.next()) {
            return result.getInt("Quantity") >= quantity; //fuck this was way better
        }

        return false;
    }




    public JSONArray getGuildHallData(int guildId) {
        JSONArray guildData = new JSONArray();
        QueryResult halls = Storage.getInstance().getJdbc().query("SELECT * FROM guilds_halls WHERE GuildID = ?", guildId);
        while (halls.next()) {
            JSONObject hall = new JSONObject();
            hall.put("intY", halls.getInt("Y"));
            hall.put("intX", halls.getInt("X"));
            hall.put("strLinkage", halls.getString("Linkage"));
            hall.put("ID", halls.getInt("id"));
            hall.put("strCell", halls.getString("Cell"));
            hall.put("strBuildings", this.getBuildingString(halls.getInt("id")));
            hall.put("strConnections", this.getConnectionsString(halls.getInt("id")));
            hall.put("strInterior", halls.getString("Interior"));
            guildData.add(hall);
        }
        halls.close();
        return guildData;
    }

    public String getConnectionsString(int hallId) {
        StringBuilder sb = new StringBuilder();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM guilds_halls_connections WHERE HallID = ?", hallId);
        while (result.next()) {
            sb.append(result.getString("Pad")).append(",");
            sb.append(result.getString("Cell")).append(",");
            sb.append(result.getString("PadPosition")).append("|");
        }
        result.close();
        if (sb.length() <= 0) {
            return sb.toString();
        } else {
            int index = sb.length() - 1;
            return sb.deleteCharAt(index).toString();
        }
    }

    public String getBuildingString(int hallId) {
        StringBuilder sb = new StringBuilder();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM guilds_halls_buildings WHERE HallID = ?", hallId);
        while (result.next()) {
            ItemBean index = StorageCache.getInstance().getItem(result.getInt("ItemID"));
            sb.append("slot:").append(result.getInt("Slot")).append(",");
            sb.append("size:").append(result.getInt("Size")).append(",");
            sb.append("itemID:").append(result.getInt("ItemID")).append(",");
            sb.append("linkage:").append(index.getLink()).append(",");
            sb.append("file:").append(index.getFile()).append("|");
        }
        result.close();
        if (sb.length() <= 0) {
            return sb.toString();
        } else {
            int index1 = sb.length() - 1;
            return sb.deleteCharAt(index1).toString();
        }
    }

    public JSONObject getGuildObject(int guildId) {
        JSONObject guild = new JSONObject();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM guilds WHERE id = ?", guildId);
        if (result.next()) {
            JSONArray members = new JSONArray();
            guild.put("Name", result.getString("Name"));
            guild.put("MOTD", result.getString("MessageOfTheDay").length() > 0 ? result.getString("MessageOfTheDay") : "undefined");
            guild.put("pending", new JSONObject());
            guild.put("MaxMembers", result.getInt("MaxMembers"));
            guild.put("dateUpdated", (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")).format(result.getDate("LastUpdated")));
            guild.put("guildcolor", result.getString("Color"));
            guild.put("Level", 1);
            guild.put("HallSize", result.getInt("HallSize"));
            guild.put("guildHall", new JSONArray());
            result.close();
            QueryResult memberResult = Storage.getInstance().getJdbc().query("SELECT id, Name, Level, CurrentServer, Rank FROM users_guilds JOIN users WHERE id = UserID AND users_guilds.GuildID = ?", guildId);
            while (memberResult.next()) {
                JSONObject member = new JSONObject();
                member.put("ID", memberResult.getInt("id"));
                member.put("userName", memberResult.getString("Name"));
                member.put("Level", memberResult.getString("Level"));
                member.put("Rank", memberResult.getInt("Rank"));
                member.put("Server", memberResult.getString("CurrentServer"));
                members.add(member);
            }
            memberResult.close();
            guild.put("ul", members);
        }
        result.close();
        return guild;
    }

    public JSONArray getHouseItems(int userDbId) throws JdbcException {
        JSONArray sData = new JSONArray();
        QueryResult qr = Storage.getInstance().getJdbc()
                .query("SELECT users_items.id, ItemID, Equipped, users_items.Quantity, DatePurchased FROM users_items LEFT JOIN items ON items.id = ItemID WHERE Equipment IN ('ho','hi') AND UserID = ?", userDbId);

        while (qr.next()) {
            JSONObject itemJson = new JSONObject();
            ItemBean itemObj = StorageCache.getInstance().getItem(qr.getInt("ItemID"));

            itemJson.put("ItemID", itemObj.getId());
            itemJson.put("file", itemObj.getFile());
            itemJson.put("CharItemID", qr.getInt("id"));
            itemJson.put("Equipped", qr.getString("Equipped"));
            itemJson.put("Quantity", qr.getInt("Quantity"));

            if (itemObj.isCoins()) {
                Date purchased = qr.getDate("DatePurchased");
                long hours = (new Date().getTime() - purchased.getTime()) / (3600 * 1000);
                itemJson.put("HoursOwned", hours);
                itemJson.put("DatePurchased", purchased.toString().replace(" ", "T"));
            }

            sData.add(itemJson);
        }

        qr.close();
        return sData;
    }

    public String getHouseData(int userId, int houseItemId) {
        StringBuilder houseInfo = new StringBuilder();

        QueryResult houseDataResult = Storage.getInstance().getJdbc().query(
                "SELECT id, Frame, ItemID, X, Y " +
                        "FROM users_houses " +
                        "WHERE UserID = ? AND HouseID = ? " +
                        "ORDER BY id ASC",
                userId,
                houseItemId
        );
        houseDataResult.setAutoClose(true);

        while (houseDataResult.next()) {
            if (houseInfo.length() > 0) {
                houseInfo.append("|");
            }

            houseInfo.append("ID:")
                    .append(houseDataResult.getInt("ItemID"))
                    .append(",X:")
                    .append(houseDataResult.getInt("X"))
                    .append(",Y:")
                    .append(houseDataResult.getInt("Y"))
                    .append(",Frame:")
                    .append(houseDataResult.getString("Frame"))
                    .append(",dbID:")
                    .append(houseDataResult.getInt("id"));
        }

        houseDataResult.close();
        return houseInfo.toString();
    }


    public JSONObject loadHouseInventory(int userId, int houseid) throws SQLException {
        JSONObject result = new JSONObject();
        JSONArray itemsArray = new JSONArray();

        QueryResult rs = Storage.getInstance().getJdbc().query(
                "SELECT ui.id, ui.ItemID, ui.Equipped, ui.Quantity, ui.Bank, ui.DatePurchased " +
                        "FROM users_items ui " +
                        "LEFT JOIN items i ON i.id = ui.ItemID " +
                        "WHERE ui.UserID = ? " +
                        "AND ui.Bank = 0 " +
                        "AND i.Equipment IN ('ho', 'hi')",
                userId
        );

        rs.setAutoClose(true);

        while (rs.next()) {
            int itemId = rs.getInt("ItemID");
            ItemBean itemObj = StorageCache.getInstance().getItem(itemId);

            if (itemObj == null) {
                continue;
            }

            JSONObject item = itemObj.getItemJSON();
            item.put("ItemID", itemId);
            item.put("CharItemID", rs.getInt("id"));
            item.put("bEquip", rs.getString("Equipped"));
            item.put("iQty", rs.getString("Quantity"));
            item.put("bBank", rs.getInt("Bank"));

            if (itemObj.isCoins()) {
                Date purchased = rs.getDate("DatePurchased");

                if (purchased != null) {
                    long hours = (new Date().getTime() - purchased.getTime()) / (60L * 60L * 1000L);
                    item.put("iHrs", hours);
                    item.put("dPurchase", rs.getString("DatePurchased").replace(" ", "T"));
                }
            }

            itemsArray.add(item);
        }

        rs.close();

        result.put("cmd", "loadHouseInventory");
        result.put("items", itemsArray);
        result.put("sHouseInfo", getHouseData(userId, houseid));

        return result;
    }

    public int getBankCount(User user) {
        int bankCount = 0;
        QueryResult bankResult = Storage.getInstance().getJdbc().query("SELECT ItemID FROM users_items WHERE Bank = 1 AND UserID = ?", user.properties.get(Properties.ID));

        while (bankResult.next()) {
            int itemid = bankResult.getInt("ItemID");
            if (!StorageCache.getInstance().getItem(itemid).isCoins()) {
                ++bankCount;
            }
        }

        bankResult.close();
        return bankCount;
    }

    public void lost(User user) {
        if (user == null || user.properties == null || !user.properties.containsKey(Properties.LEVEL)) {
            return;
        }

        try {
            WarzoneQueue.getInstance().remove(user);

            int partyId = getIntProperty(user, "partyId", -1);
            if (partyId > 0) {
                PartyInfo pi = ManageParties.getInstance().getPartyInfo(partyId);
                if (pi != null) {
                    if (pi.getOwner() != null && pi.getOwner().equals(user.properties.get(Properties.USERNAME))) {
                        pi.setOwner(pi.getNextOwner());
                    }

                    pi.removeMember(user);

                    JSONObject pr = new JSONObject();
                    pr.put("cmd", "pr");
                    pr.put("owner", pi.getOwner());
                    pr.put("typ", "l");
                    pr.put("unm", user.properties.get(Properties.USERNAME));

                    Kaiden_Extension.getInstance().send(pr, pi.getChannelListButOne(user));
                    Kaiden_Extension.getInstance().send(pr, user);

                    if (pi.getMemberCount() <= 0) {
                        JSONObject pc = new JSONObject();
                        pc.put("cmd", "pc");

                        User ownerObject = pi.getOwnerObject();
                        if (ownerObject != null) {
                            Kaiden_Extension.getInstance().send(pc, ownerObject);
                            ownerObject.properties.put("partyId", -1);
                        }

                        ManageParties.getInstance().removeParty(partyId);
                    }
                }
            }

            int guildId = getIntProperty(user, "guildid", 0);
            if (guildId > 0) {
                Kaiden_Extension.getInstance().sendGuildUpdate(this.getGuildObject(guildId));
            }

            JSONObject updateFriend = new JSONObject();
            JSONObject friendInfo = new JSONObject();
            updateFriend.put("cmd", "updateFriend");
            friendInfo.put("iLvl", user.properties.get(Properties.LEVEL));
            friendInfo.put("ID", user.properties.get(Properties.ID));
            friendInfo.put("sName", user.properties.get(Properties.USERNAME));
            friendInfo.put("sServer", "Offline");
            updateFriend.put("friend", friendInfo);

            QueryResult result = null;
            try {
                if (Storage.getInstance().shouldSkipNonCriticalDb()) {
                    throw new RuntimeException("DB pool busy; friend offline notify delayed/skipped");
                }

                result = Storage.getInstance().getJdbc().query(
                        "SELECT Name FROM users LEFT JOIN users_friends ON FriendID = id WHERE CurrentServer != \"Offline\" AND UserID = ?",
                        user.properties.get(Properties.ID)
                );

                while (result.next()) {
                    User client = Kaiden_Extension.getInstance().getZone().getUserByName(result.getString("Name").toLowerCase());
                    if (client != null) {
                        Kaiden_Extension.getInstance().send(updateFriend, client);
                        Kaiden_Extension.getInstance().send(new String[]{"server", user.getName() + " has logged out."}, client);
                    }
                }
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[Users.lost] friend offline notify skipped for " + user.getName() + ": " + e.getMessage());
            } finally {
                try {
                    if (result != null) {
                        result.close();
                    }
                } catch (Exception ignored) {
                }
            }

            int playerId = getIntProperty(user, Properties.ID, 0);
            long enterTime = 0L;
            Object enterTimeObj = user.properties.get("entertime");
            if (enterTimeObj instanceof Long) {
                enterTime = (Long) enterTimeObj;
            } else if (enterTimeObj instanceof Number) {
                enterTime = ((Number) enterTimeObj).longValue();
            }

            int onlineSeconds = enterTime > 0L ? (int) ((System.currentTimeMillis() - enterTime) / 1000L) : 0;
            int timeplayed = onlineSeconds + getIntProperty(user, "timeplay", 0);
            int experience = getIntProperty(user, Properties.EXPERIENCE, 0);

            int loginGold = getIntProperty(user, Properties.LOGIN_GOLD, getIntProperty(user, Properties.GOLD, 0));
            int loginCoins = getIntProperty(user, Properties.LOGIN_COINS, getIntProperty(user, Properties.COINS, 0));
            int currentGold = getIntProperty(user, Properties.GOLD, loginGold);
            int currentCoins = getIntProperty(user, Properties.COINS, loginCoins);

            int goldDelta = currentGold - loginGold;
            int coinsDelta = currentCoins - loginCoins;
            int loginKillCount = getIntProperty(user, "loginKillCount", getIntProperty(user, Properties.KILL_COUNT, 0));
            int loginDeathCount = getIntProperty(user, "loginDeathCount", getIntProperty(user, Properties.DEATH_COUNT, 0));
            int currentKillCount = getIntProperty(user, Properties.KILL_COUNT, loginKillCount);
            int currentDeathCount = getIntProperty(user, Properties.DEATH_COUNT, loginDeathCount);
            int killDelta = Math.max(0, currentKillCount - loginKillCount);
            int deathDelta = Math.max(0, currentDeathCount - loginDeathCount);

            ServerCountManager.logout(user);

            final int finalTimeplayed = timeplayed;
            final int finalExperience = experience;
            final int finalGoldDelta = goldDelta;
            final int finalCoinsDelta = coinsDelta;
            final int finalKillDelta = killDelta;
            final int finalDeathDelta = deathDelta;
            final int finalPlayerId = playerId;
            final User finalUser = user;

            AsyncDbExecutor.submit("user-lost-save", new Runnable() {
                @Override
                public void run() {
                    QuestProgressManager.saveAll(finalUser);

                    // Currency/stat-safe logout save: apply only emulator session deltas so
                    // PHP/panel rewards granted while online are preserved instead of overwritten.
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users SET CurrentServer = 'Offline', TimePlay = ?, Exp = ?, " +
                                    "Gold = GREATEST(0, Gold + ?), Coins = GREATEST(0, Coins + ?), " +
                                    "KillCount = KillCount + ?, DeathCount = DeathCount + ? WHERE id = ?",
                            finalTimeplayed,
                            finalExperience,
                            finalGoldDelta,
                            finalCoinsDelta,
                            finalKillDelta,
                            finalDeathDelta,
                            finalPlayerId
                    );
                }
            });

            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow",
                    "[Users.lost] Currency save user=" + user.getName() +
                            " loginGold=" + loginGold + " currentGold=" + currentGold + " deltaGold=" + goldDelta +
                            " loginCoins=" + loginCoins + " currentCoins=" + currentCoins + " deltaCoins=" + coinsDelta
            );

            UserState state = (UserState) user.properties.get("state");
            if (state != null) {
                state.clearAuras();
            }

            Regeneration regen = (Regeneration) user.properties.get("regenaration");
            if (regen != null) {
                regen.cancel();
            }

        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[Users.lost] Failed for " + (user == null ? "unknown" : user.getName()) + ": " + e.getMessage()
            );
            e.printStackTrace();
        }
    }

    private int getIntProperty(User user, String key, int fallback) {
        if (user == null || user.properties == null || key == null || !user.properties.containsKey(key)) {
            return fallback;
        }

        Object value = user.properties.get(key);
        if (value instanceof Integer) {
            return (Integer) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        if (value instanceof String) {
            try {
                return Integer.parseInt((String) value);
            } catch (Exception ignored) {
            }
        }
        return fallback;
    }

    public void ban(User user, String violation, String details, int banTime) {
        //Kaiden_Engine.getInstance().sendEmulatorMessage("green","A player has been banned: [" + user.properties.get(Properties.USERNAME) + "]");
        int userId = (Integer) user.properties.get(Properties.ID);
        Storage.getInstance().getJdbc().run("UPDATE users SET BanTime = ? WHERE id = ?", SpanUtils.getDateByHours(banTime), userId);
        Kaiden_Extension.getInstance().send(new String[]{"loginResponse", "false", "-1", user.getName(), details}, user);
        this.log(user, violation, details);
        Storage.getInstance().getJdbc().run("INSERT INTO users_logs_bans (UserID, Violation, Details, Time) VALUES (?, ?, ?, ?)", userId, violation, details, banTime);
        Users.getInstance().kick(user, violation);
    }
    public void loadClassSkills(User user, ItemBean item, int classPoints) {
        int rank = ClassRank.getRankFromPoints(classPoints);
        ItemBean weaponItem = (ItemBean) user.properties.get("weaponitem");
        ConcurrentHashMap skills = (ConcurrentHashMap) user.properties.get(Properties.SKILLS);
        Map SKILLS_CD = (Map) user.properties.get(Properties.SKILLS_CD);
        JSONArray active = new JSONArray();
        JSONArray passive = new JSONArray();
        JSONObject sAct = new JSONObject();

        for (int actions : item.getItemClass().getSkills()) {
            SkillBean skill = StorageCache.getInstance().getSkill(actions);
            SKILLS_CD.put(skill.getId(), 0);
            if (skill.getType().equals("passive")) {
                JSONObject actObj = new JSONObject();
                actObj.put("desc", skill.getDescription());
                actObj.put("fx", skill.getEffects());
                actObj.put("icon", skill.getIcon());
                actObj.put("id", actions);
                actObj.put("nam", skill.getName());
                actObj.put("range", skill.getRange());
                actObj.put("ref", skill.getReference());
                actObj.put("tgt", skill.getTarget());
                actObj.put("typ", skill.getType());
                JSONArray arrAuras = new JSONArray();
                arrAuras.add(new JSONObject());
                actObj.put("auras", arrAuras);
                actObj.put("isOK", PassiveContainer.getInstance().isPassiveUnlocked(skill, rank));
                passive.add(actObj);
                skills.put(skill.getReference(), actions);
            } else {
                JSONObject actObj = new JSONObject();
                actObj.put("anim", skill.getAnimation());
                actObj.put("cd", String.valueOf(skill.getCooldown()));
                actObj.put("damage", skill.getDamage());
                actObj.put("desc", skill.getDescription());
                if (!skill.getDsrc().isEmpty()) {
                    actObj.put("dsrc", skill.getDsrc());
                }
                actObj.put("fx", skill.getEffects());
                actObj.put("icon", skill.getIcon());
                actObj.put("id", actions);
                actObj.put("isOK", Boolean.TRUE);
                actObj.put("mp", String.valueOf(skill.getMana()));
                actObj.put("nam", skill.getName());
                actObj.put("range", String.valueOf(skill.getRange()));
                actObj.put("ref", skill.getReference());
                if (!skill.getStrl().isEmpty()) {
                    actObj.put("strl", skill.getStrl());
                }
                actObj.put("tgt", skill.getTarget());
                actObj.put("typ", skill.getType());

                if (rank < 2 && skill.getReference().equals("a2")) {
                    actObj.put("isOK", Boolean.FALSE);
                }
                if (rank < 3 && skill.getReference().equals("a3")) {
                    actObj.put("isOK", Boolean.FALSE);
                }
                if (rank < 5 && skill.getReference().equals("a4")) {
                    actObj.put("isOK", Boolean.FALSE);
                }
                if (rank < 9 && skill.getReference().equals("a5")) {
                    actObj.put("isOK", Boolean.FALSE);
                }
                if (skill.getHitTargets() > 0) {
                    actObj.put("tgtMax", String.valueOf(skill.getHitTargets()));
                    actObj.put("tgtMin", "1");
                }

                switch (skill.getReference()) {
                    case "aa":
                        actObj.put("auto", Boolean.TRUE);
                        actObj.put("typ", "aa");
                        active.element(0, actObj);
                        break;
                    case "a1":
                        active.element(1, actObj);
                        break;
                    case "a2":
                        if (rank < 2) {
                            actObj.put("isOK", Boolean.FALSE);
                        }
                        active.element(2, actObj);
                        break;
                    case "a3":
                        if (rank < 3) {
                            actObj.put("isOK", Boolean.FALSE);
                        }
                        active.element(3, actObj);
                        break;
                    case "a4":
                        if (rank < 5) {
                            actObj.put("isOK", Boolean.FALSE);
                        }
                        active.element(4, actObj);
                        break;
                    case "a5":
                        if (rank < 9) {
                            actObj.put("isOK", Boolean.FALSE);
                        }
                        active.element(5, actObj);
                        break;
                }

                if (skill.getPet() > 0) {
                    actObj.put("pet", skill.getPet());
                }
                skills.put(skill.getReference(), actions);
            }
        }

        QueryResult settings = Storage.getInstance().getJdbc().query("SELECT * FROM a_settings");
        if (settings.next()) {
            int totalSlots = settings.getInt("SlotsMax");
            for (int i = 0; i < totalSlots; i++) {
                if (i >= active.size() || active.get(i) == null) {
                    JSONObject blankSkill = new JSONObject();
                    blankSkill.put("anim", "");
                    blankSkill.put("cd", "0");
                    blankSkill.put("desc", "This skill doesnt exsist. this is a false programmed skill! Valfor you are awesome.");
                    blankSkill.put("fx", "");
                    blankSkill.put("icon", "iLock");
                    blankSkill.put("isOK", false);
                    blankSkill.put("mp", "0");
                    blankSkill.put("nam", "");
                    blankSkill.put("range", "0");
                    blankSkill.put("ref", "a" + i);
                    blankSkill.put("tgt", "");
                    blankSkill.put("typ", "none");
                    active.element(i, blankSkill);
                    //Kaiden_Engine.Kaiden_Engine.getInstance().sendEmulatorMessage("green","Skills Filled at " + i);
                }
            }
        }

        JSONObject potionObj1 = new JSONObject();
        potionObj1.put("anim", "Cheer");
        potionObj1.put("cd", "60000");
        potionObj1.put("desc", "Equip a potion or scroll from your inventory to use it here.");
        potionObj1.put("fx", "");
        potionObj1.put("icon", "icu1");
        potionObj1.put("isOK", true);
        potionObj1.put("mp", "0");
        potionObj1.put("nam", "Potions");
        potionObj1.put("range", 808);
        potionObj1.put("ref", "i1");
        potionObj1.put("str1", "");
        potionObj1.put("tgt", "f");
        potionObj1.put("typ", "i");
        active.element(6, potionObj1);

        int passiveSlotsMax = 2;

        if (settings != null && settings.next()) {
            try {
                passiveSlotsMax = settings.getInt("PassiveSlotsMax");
            } catch (Exception e) {
                //Kaiden_Engine.LOGGER.warn("PassiveSlotsMax not found in settings, using default value of 2.");
            }
        }
        settings.close();

        int startIndex = 1;
        if (!passive.isEmpty()) {
            startIndex = passive.size() + 1;
        }

        for (int i = startIndex; i <= passiveSlotsMax; i++) {
            int passiveIndex = i - 1;
            if (passiveIndex >= passive.size() || passive.get(passiveIndex) == null) {
                JSONObject blankPassive = new JSONObject();
                blankPassive.put("desc", "");
                blankPassive.put("fx", "");
                blankPassive.put("icon", "icu1");
                blankPassive.put("id", 0);
                blankPassive.put("nam", "Passive");
                blankPassive.put("range", 0);
                blankPassive.put("ref", "p" + i);
                blankPassive.put("tgt", "");
                blankPassive.put("typ", "passive");
                blankPassive.put("isOK", false);
                JSONArray arrAuras = new JSONArray();
                arrAuras.add(new JSONObject());
                blankPassive.put("auras", arrAuras);
                passive.element(passiveIndex, blankPassive);
                //Kaiden_Engine.Kaiden_Engine.getInstance().sendEmulatorMessage("green","Passive Filled at slot p" + i + "| passive size " + passive.size());
            }
        }

        JSONObject actions1 = new JSONObject();
        actions1.put("active", active);
        actions1.put("passive", passive);
        sAct.put("cmd", "sAct");
        sAct.put("actions", actions1);

        // Do not clear all auras when action data is requested. Rebuilding passives here
        // causes periodic stat churn and can stall aura-heavy combat classes. Passives are
        // reapplied only if the current class/rank cache changed.
        PassiveContainer.getInstance().ensurePassiveAurasCurrent(user, rank, item.getItemClass());
        Kaiden_Extension.getInstance().send(sAct, user);
    }
    public JSONArray getFriends(User user) {
        JSONArray friends = new JSONArray();
        QueryResult result = Storage.getInstance().getJdbc().query("SELECT id, Level, Name, CurrentServer FROM users LEFT JOIN users_friends ON FriendID = id WHERE UserID = ?", user.properties.get(Properties.ID));
        while (result.next()) {
            JSONObject temp = new JSONObject();
            temp.put("iLvl", result.getInt("Level"));
            temp.put("ID", result.getInt("id"));
            temp.put("sName", result.getString("Name"));
            temp.put("sServer", result.getString("CurrentServer"));
            friends.add(temp);
        }
        result.close();
        return friends;
    }


    private JSONArray getUserLoadouts(User user) {
        JSONArray arr = new JSONArray();
        try {
            QueryResult qr = Storage.getInstance().getJdbc().query("SELECT Name, Equipments, ColorAccessory, ColorBase, ColorTrim, ColorHair, ColorSkin, ColorEye FROM users_outfits WHERE UserID = ?", user.properties.get(Properties.ID));
            while (qr.next()) {
                JSONObject o = new JSONObject();
                o.put("name", qr.getString("Name"));
                String[] eq = qr.getString("Equipments").split(",");
                String[] slots = {"ar","co","he","ba","Weapon","mi"};
                for (int i=0;i<eq.length && i<slots.length;i++) {
                    if (eq[i] != null && !eq[i].trim().isEmpty()) {
                        o.put(slots[i], Integer.parseInt(eq[i].trim()));
                    }
                }
                JSONObject colors = new JSONObject();
                colors.put("accessory", qr.getString("ColorAccessory"));
                colors.put("base", qr.getString("ColorBase"));
                colors.put("trim", qr.getString("ColorTrim"));
                colors.put("hair", qr.getString("ColorHair"));
                colors.put("skin", qr.getString("ColorSkin"));
                colors.put("eye", qr.getString("ColorEye"));
                o.put("colors", colors);
                arr.add(o);
            }
            qr.close();
        } catch (Exception ignored) {}
        return arr;
    }

}