package Kaiden.Game.Server.Users.Utils;

/** Legacy AQW quest progress: one base-36 character per slot. */
public class Quests {
    // Bound growth to protect the database and the Flash client from malformed slots.
    public static final int MAX_SLOT = 4095;

    public static int lookAtValue(String questString, int index) {
        checkIndex(index);
        if (questString == null || index >= questString.length()) return 0;
        int value = Character.digit(questString.charAt(index), 36);
        return value < 0 ? 0 : value;
    }

    public static String updateValue(String questString, int index, int value) {
        checkIndex(index);
        if (value < 0 || value >= 36)
            throw new IllegalArgumentException("Quest value must be 0..35: " + value);
        StringBuilder builder = new StringBuilder(questString == null ? "" : questString);
        while (builder.length() <= index) builder.append('0');
        builder.setCharAt(index, Character.toUpperCase(Character.forDigit(value, 36)));
        return builder.toString();
    }

    private static void checkIndex(int index) {
        if (index < 0 || index > MAX_SLOT)
            throw new IllegalArgumentException("Quest slot out of range: " + index);
    }

    public static String fromCharCode(int... codePoints) {
        return new String(codePoints, 0, codePoints.length);
    }
}
