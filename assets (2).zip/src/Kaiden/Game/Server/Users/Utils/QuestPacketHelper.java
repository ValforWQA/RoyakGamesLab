package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.QuestRewardBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("ALL")
public final class QuestPacketHelper {

    private QuestPacketHelper() {}

    public static JSONObject buildQuestJson(User user, int questId, boolean forceActive) {
        QuestBean questObj = StorageCache.getInstance().getQuest(questId);
        if (questObj == null) {
            return null;
        }

        JSONObject questJson = new JSONObject();

        JSONObject oRewards = new JSONObject();
        JSONArray rewC = new JSONArray();
        JSONArray rewS = new JSONArray();
        JSONArray rewR = new JSONArray();
        JSONArray rewRand = new JSONArray();
        JSONArray rewardsFlat = new JSONArray();

        if (questObj.rewards != null && !questObj.rewards.isEmpty()) {
            for (QuestRewardBean reward : questObj.rewards) {
                if (reward == null) continue;
                ItemBean item = StorageCache.getInstance().getItem(reward.itemId);
                if (item == null) continue;

                int ratePercent = (int) Math.round(reward.rate * 100);

                JSONObject itemJSON = item.getItemJSON();
                itemJSON.put("ItemID", reward.itemId);
                itemJSON.put("iQty", reward.quantity);
                itemJSON.put("iRate", ratePercent);

                if ("C".equalsIgnoreCase(reward.type)) {
                    rewC.add(itemJSON);
                } else if ("S".equalsIgnoreCase(reward.type)) {
                    rewS.add(itemJSON);
                } else if ("R".equalsIgnoreCase(reward.type)) {
                    rewR.add(itemJSON);
                } else if ("rand".equalsIgnoreCase(reward.type)) {
                    rewRand.add(itemJSON);
                }

                JSONObject r = new JSONObject();
                r.put("ItemID", reward.itemId);
                r.put("QuestID", questId);
                r.put("iRate", ratePercent);
                r.put("iQty", reward.quantity);
                rewardsFlat.add(r);
            }

            if (!rewS.isEmpty()) oRewards.put("itemsS", rewS);
            if (!rewC.isEmpty()) oRewards.put("itemsC", rewC);
            if (!rewR.isEmpty()) oRewards.put("itemsR", rewR);
            if (!rewRand.isEmpty()) oRewards.put("itemsrand", rewRand);
        }

        JSONObject reqdArray = new JSONObject();
        JSONArray reqd = new JSONArray();

        for (Object o : questObj.required.entrySet()) {
            Map.Entry entry = (Map.Entry) o;
            int itemId = (Integer) entry.getKey();
            int quantity = (Integer) entry.getValue();

            ItemBean item = StorageCache.getInstance().getItem(itemId);
            if (item == null) continue;

            JSONObject itemJSON = item.getItemJSON();
            itemJSON.put("ItemID", itemId);
            reqdArray.put(String.valueOf(itemId), itemJSON);

            JSONObject itemJSONObject = new JSONObject();
            itemJSONObject.put("ItemID", itemId);
            itemJSONObject.put("QuestID", questId);
            itemJSONObject.put("iQty", quantity);
            reqd.add(itemJSONObject);
        }

        JSONArray turnin = new JSONArray();
        JSONObject oItems = new JSONObject();

        for (Object o : questObj.requirements.entrySet()) {
            Map.Entry entry = (Map.Entry) o;
            int reqItemId = (Integer) entry.getKey();
            int reqQty = (Integer) entry.getValue();

            ItemBean reqItem = StorageCache.getInstance().getItem(reqItemId);
            if (reqItem == null) continue;

            JSONObject item = reqItem.getItemJSON();
            item.put("ItemID", reqItemId);
            oItems.put(reqItemId, item);

            JSONObject turnInObj = new JSONObject();
            turnInObj.put("ItemID", String.valueOf(reqItemId));
            turnInObj.put("QuestID", questId);
            turnInObj.put("iQty", reqQty);
            turnin.add(turnInObj);
        }

        questJson.put("FactionID", questObj.getFactionId());
        questJson.put("sFaction", StorageCache.getInstance().getFaction(questObj.getFactionId()));
        questJson.put("QuestID", questId);
        questJson.put("bOnce", questObj.isOnce() ? 1 : 0);
        questJson.put("bStaff", 0);
        questJson.put("bUpg", questObj.isUpgrade() ? 1 : 0);

        if (questObj.getReqClassId() > 0) {
            ItemBean cls = StorageCache.getInstance().getItem(questObj.getReqClassId());
            if (cls != null) questJson.put("sClass", cls.getName());
        }

        questJson.put("iClass", questObj.getReqClassId());
        questJson.put("iExp", questObj.getExperience());
        questJson.put("iGold", questObj.getGold());
        questJson.put("iLvl", questObj.getLevel());
        questJson.put("iCoins", questObj.getCoin());
        questJson.put("intAmount", questObj.getCoin());
        questJson.put("iRep", questObj.getReputation());
        questJson.put("iReqCP", questObj.getReqClassPoints());
        questJson.put("iReqRep", questObj.getReqReputation());
        questJson.put("iSlot", questObj.getSlot());
        questJson.put("iValue", questObj.getValue());
        questJson.put("iWar", questObj.getWar());

        questJson.put("oItems", oItems);
        questJson.put("oRewards", oRewards);
        questJson.put("reward", rewardsFlat);
        questJson.put("sDesc", questObj.getDescription());
        questJson.put("sEndText", questObj.getEndText());
        questJson.put("sName", questObj.getName());
        questJson.put("turnin", turnin);

        if (!questObj.required.isEmpty()) {
            questJson.put("reqd", reqd);
            questJson.put("oReqd", reqdArray);
        }

        if (!questObj.getField().isEmpty()) {
            questJson.put("sField", questObj.getField());
            questJson.put("iIndex", questObj.getIndex());
        }

        int mapId = QuestProgressManager.getQuestMapId(questObj);
        if (mapId > 0) {
            questJson.put("MapID", mapId);
            questJson.put("iMapID", mapId);
        }

        if (forceActive || isActive(user, questId)) {
            questJson.put("status", "p");
            questJson.put("bAccepted", 1);
        }

        return questJson;
    }

    public static boolean isActive(User user, int questId) {
        if (user == null || user.properties == null) return false;
        Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
        return quests != null && quests.contains(questId);
    }

    public static void sendQuestDefinitions(User user, Set<Integer> questIds, boolean forceActive) {
        if (user == null || questIds == null || questIds.isEmpty()) return;

        JSONObject arrQuests = new JSONObject();
        for (Integer questId : questIds) {
            if (questId == null || questId <= 0) continue;
            JSONObject q = buildQuestJson(user, questId, forceActive);
            if (q != null) {
                arrQuests.put(String.valueOf(questId), q);
            }
        }

        if (arrQuests.isEmpty()) return;

        JSONObject packet = new JSONObject();
        packet.put("cmd", "getQuests");
        packet.put("quests", arrQuests);
        Kaiden_Extension.getInstance().send(packet, user);
    }

    public static void sendTempItems(User user, Map<Integer, Integer> tempItems) {
        if (user == null || tempItems == null || tempItems.isEmpty()) return;

        JSONObject items = new JSONObject();
        int count = 0;

        for (Map.Entry<Integer, Integer> entry : tempItems.entrySet()) {
            int itemId = entry.getKey() == null ? 0 : entry.getKey();
            int qty = entry.getValue() == null ? 0 : entry.getValue();
            if (itemId <= 0 || qty <= 0) continue;

            ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
            if (itemObj == null || !itemObj.isTemporary()) continue;

            JSONObject itemJSON = itemObj.getItemJSON(StorageCache.getInstance().getEnhancement(itemObj.getEnhId()));
            itemJSON.put("ItemID", itemObj.getId());
            itemJSON.put("iQty", qty);
            items.put(String.valueOf(itemObj.getId()), itemJSON);
            count++;
        }

        if (count <= 0) return;

        JSONObject packet = new JSONObject();
        packet.put("cmd", "addItems");
        packet.put("items", items);
        packet.put("restore", 1);
        Kaiden_Extension.getInstance().send(packet, user);
    }
}
