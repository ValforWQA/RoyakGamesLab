package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Beans.*;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.EnhancementProcAuras;
import Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class Stats {

    public static final HashMap<String, List<Double>> classCatMap;
    public static final HashMap ratioByEquipment;

    static {
        List<Double> M1 = Arrays.asList(0.27D, 0.3D, 0.22D, 0.05D, 0.1D, 0.06D);
        List<Double> M2 = Arrays.asList(0.2D, 0.22D, 0.33D, 0.05D, 0.1D, 0.1D);
        List<Double> M3 = Arrays.asList(0.24D, 0.2D, 0.2D, 0.24D, 0.07D, 0.05D);
        List<Double> M4 = Arrays.asList(0.3D, 0.18D, 0.3D, 0.02D, 0.06D, 0.14D);
        List<Double> C1 = Arrays.asList(0.06D, 0.2D, 0.11D, 0.33D, 0.15D, 0.15D);
        List<Double> C2 = Arrays.asList(0.08D, 0.27D, 0.1D, 0.3D, 0.1D, 0.15D);
        List<Double> C3 = Arrays.asList(0.06D, 0.23D, 0.05D, 0.28D, 0.28D, 0.1D);
        List<Double> S1 = Arrays.asList(0.22D, 0.18D, 0.21D, 0.08D, 0.08D, 0.23D);

        HashMap<String, List<Double>> catMap = new HashMap<String, List<Double>>(8);
        catMap.put("M1", M1);
        catMap.put("M2", M2);
        catMap.put("M3", M3);
        catMap.put("M4", M4);
        catMap.put("C1", C1);
        catMap.put("C2", C2);
        catMap.put("C3", C3);
        catMap.put("S1", S1);
        classCatMap = catMap;

        HashMap<String, Double> ratioEquip = new HashMap<String, Double>(4);
        ratioEquip.put("he", 0.42D);
        ratioEquip.put("ar", 0.72D);
        ratioEquip.put("ba", 0.42D);
        ratioEquip.put("Weapon", 0.64D);
        ratioByEquipment = ratioEquip;
    }

    public int wDPS = 0;
    public Map<String, Double> innate = new HashMap<String, Double>(6);
    public Map<String, Double> weapon = new HashMap<String, Double>(6);
    public Map<String, Double> helm = new HashMap<String, Double>(6);
    public Map<String, Double> armor = new HashMap<String, Double>(6);
    public Map<String, Double> title = new LinkedHashMap<>(6);
    //public Map<String, Double> misc = new HashMap<String, Double>(6);
    public Map<String, Double> cape = new HashMap<String, Double>(6);
    public Map<String, Double> auraCore = new HashMap<String, Double>(6);
    public List<AuraEffectsBean> effects = Collections.synchronizedList(new ArrayList<AuraEffectsBean>());

    private int rangeBonus = 0;

    private double $cai = 1.0D;
    private double $cao = 1.0D;
    private double $cdi = 1.0D;
    private double $cdo = 1.0D;
    private double $chi = 1.0D;
    private double $cho = 1.0D;
    private double $cmc = 1.0D;
    private double $cmi = 1.0D;
    private double $cmo = 1.0D;
    private double $cpi = 1.0D;
    private double $cpo = 1.0D;
    private double $sbm = 0.7D;
    private double $scm = 1.5D;
    private double $sem = 0.05D;
    private double $shb = 0.0D;
    private double $smb = 0.0D;
    private double $srm = 0.7D;
    private double attackPower = 0.0D;
    private double magicPower = 0.0D;
    private double block = 0.0D;
    private double criticalHit = 0.05D;
    private double evasion = 0.04D;
    private double haste = 0.0D;
    private double hit = 0.0D;
    private double parry = 0.03D;
    private double resist = 0.7D;
    private double physicalResist = 0.0D;
    private double magicalResist = 0.0D;
    private double allResist = 0.0D;
    private double outgoingDamageMod = 1.0D;
    private double incomingDamageMod = 1.0D;
    private double manaReturn = 0.0D;
    private double lifeSteal = 0.0D;
    private double shieldValue = 0.0D;
    private double physicalBoost = 1.0D;
    private double magicalBoost = 1.0D;
    private double healingIntake = 1.0D;
    private double healingBoost = 1.0D;
    private double dotResistance = 1.0D;
    private double dotBoost = 1.0D;

    private double _ap = 0.0D;
    private double _cai = 1.0D;
    private double _cao = 1.0D;
    private double _cdi = 1.0D;
    private double _cdo = 1.0D;
    private double _chi = 1.0D;
    private double _cho = 1.0D;
    private double _cmc = 1.0D;
    private double _cmi = 1.0D;
    private double _cmo = 1.0D;
    private double _cpi = 1.0D;
    private double _cpo = 1.0D;
    private double _sbm = 0.7D;
    private double _scm = 1.5D;
    private double _sem = 0.05D;
    private double _shb = 0.0D;
    private double _smb = 0.0D;
    private double _sp = 0.0D;
    private double _srm = 0.7D;
    private double _tbl = 0.0D;
    private double _tcr = 0.0D;
    private double _tdo = 0.0D;
    private double _tha = 0.0D;
    private double _thi = 0.0D;
    private double _tpa = 0.0D;
    private double _tre = 0.0D;

    private int minDmg = 0;
    private int maxDmg = 0;

    private final User user;
    private volatile boolean dirty = true;
    private volatile long lastUpdateMs = 0L;

    public Stats(User user) {
        this.user = user;

        this.innate.put("STR", 0.0D);
        this.innate.put("END", 0.0D);
        this.innate.put("DEX", 0.0D);
        this.innate.put("INT", 0.0D);
        this.innate.put("WIS", 0.0D);
        this.innate.put("LCK", 0.0D);

        this.weapon.put("STR", 0.0D);
        this.weapon.put("END", 0.0D);
        this.weapon.put("DEX", 0.0D);
        this.weapon.put("INT", 0.0D);
        this.weapon.put("WIS", 0.0D);
        this.weapon.put("LCK", 0.0D);

        this.helm.put("STR", 0.0D);
        this.helm.put("END", 0.0D);
        this.helm.put("DEX", 0.0D);
        this.helm.put("INT", 0.0D);
        this.helm.put("WIS", 0.0D);
        this.helm.put("LCK", 0.0D);

        this.armor.put("STR", 0.0D);
        this.armor.put("END", 0.0D);
        this.armor.put("DEX", 0.0D);
        this.armor.put("INT", 0.0D);
        this.armor.put("WIS", 0.0D);
        this.armor.put("LCK", 0.0D);

        this.cape.put("STR", 0.0D);
        this.cape.put("END", 0.0D);
        this.cape.put("DEX", 0.0D);
        this.cape.put("INT", 0.0D);
        this.cape.put("WIS", 0.0D);
        this.cape.put("LCK", 0.0D);

        title.put("STR", 0.0);
        title.put("END", 0.0);
        title.put("DEX", 0.0);
        title.put("INT", 0.0);
        title.put("WIS", 0.0);
        title.put("LCK", 0.0);

        //this.misc.put("STR", 0.0D);
        //this.misc.put("END", 0.0D);
        //this.misc.put("DEX", 0.0D);
        //this.misc.put("INT", 0.0D);
        //this.misc.put("WIS", 0.0D);
        //this.misc.put("LCK", 0.0D);

        this.auraCore.put("STR", 0.0D);
        this.auraCore.put("END", 0.0D);
        this.auraCore.put("DEX", 0.0D);
        this.auraCore.put("INT", 0.0D);
        this.auraCore.put("WIS", 0.0D);
        this.auraCore.put("LCK", 0.0D);
    }


    public void markDirty() {
        this.dirty = true;
    }

    public boolean isDirty() {
        return this.dirty;
    }

    public long getLastUpdateMs() {
        return this.lastUpdateMs;
    }

    public void updateIfDirty() {
        if (this.dirty) {
            this.update();
        }
    }


    public void addEffect(AuraEffectsBean effect) {
        if (effect == null) return;
        synchronized (this.effects) {
            if (!this.effects.contains(effect)) {
                this.effects.add(effect);
                this.markDirty();
                CombatTrace.info("Stats.addEffect", CombatTrace.who(this.user) + ", effect=" + effect.getStat() + ":" + effect.getType() + effect.getValue() + ", totalEffects=" + this.effects.size());
            }
        }
    }

    public boolean removeEffect(AuraEffectsBean effect) {
        if (effect == null) return false;
        synchronized (this.effects) {
            boolean removed = this.effects.remove(effect);
            if (removed) {
                this.markDirty();
                CombatTrace.info("Stats.removeEffect", CombatTrace.who(this.user) + ", effect=" + effect.getStat() + ":" + effect.getType() + effect.getValue() + ", totalEffects=" + this.effects.size());
            }
            return removed;
        }
    }

    public void clearEffects() {
        synchronized (this.effects) {
            this.effects.clear();
            this.markDirty();
        }
    }

    public boolean hasEffect(AuraEffectsBean effect) {
        if (effect == null) return false;
        synchronized (this.effects) {
            return this.effects.contains(effect);
        }
    }

    public List<AuraEffectsBean> getEffectsSnapshot() {
        synchronized (this.effects) {
            return new ArrayList<AuraEffectsBean>(this.effects);
        }
    }

    public void sendStatChanges(Set<AuraEffectsBean> effects) {
        JSONObject stu = new JSONObject();
        JSONObject sta = new JSONObject();

        for (AuraEffectsBean ae : effects) {
            String statKey = AuraEffectRegistry.canonicalize(ae.getStat());
            switch (statKey) {
                case "tha":
                    sta.put("$tha", CombatEvaluator.getDisplayedHaste(this));
                    break;
                case "tdo":
                    sta.put("$tdo", CombatEvaluator.getDisplayedEvadeChance(this));
                    break;
                case "thi":
                    sta.put("$thi", CombatEvaluator.getDisplayedHitChance(this));
                    break;
                case "tcr":
                    sta.put("$tcr", CombatEvaluator.getDisplayedCritChance(this));
                    break;
                case "tcm":
                    sta.put("$scm", this.$scm);
                    break;
                case "tpa":
                    sta.put("$tpa", this.parry);
                    break;
                case "tbl":
                    sta.put("$tbl", this.block);
                    break;
                case "tre":
                    sta.put("$tre", this.resist);
                    break;
                case "physres":
                    sta.put("$cpi", this.$cpi);
                    break;
                case "magres":
                    sta.put("$cmi", this.$cmi);
                    break;
                case "allres":
                case "incdmg":
                    sta.put("$cai", this.$cai);
                    break;
                case "outdmg":
                    sta.put("$cao", this.$cao);
                    break;
                case "physboost":
                    sta.put("$cpo", this.$cpo);
                    break;
                case "magboost":
                    sta.put("$cmo", this.$cmo);
                    break;
                case "healin":
                case "healintake":
                    sta.put("$chi", this.$chi);
                    break;
                case "healboost":
                    sta.put("$cho", this.$cho);
                    break;
                case "dotres":
                    sta.put("$cdi", this.$cdi);
                    break;
                case "dotboost":
                    sta.put("$cdo", this.$cdo);
                    break;
                case "manacost":
                case "manaconsume":
                case "manaconsumption":
                    sta.put("$cmc", this.$cmc);
                    break;
                case "manaret":
                    sta.put("$manaret", this.manaReturn);
                    break;
                case "lifesteal":
                case "life steal":
                    sta.put("$lifesteal", this.lifeSteal);
                    break;
                case "shield":
                    sta.put("$shield", this.shieldValue);
                    break;
                case "str":
                    sta.put("$STR", this.get$STR());
                    break;
                case "int":
                    sta.put("$INT", this.get$INT());
                    break;
                case "dex":
                    sta.put("$DEX", this.get$DEX());
                    break;
                case "end":
                    sta.put("$END", this.get$END());
                    break;
                case "wis":
                    sta.put("$WIS", this.get$WIS());
                    break;
                case "lck":
                    sta.put("$LCK", this.get$LCK());
                    break;
                case "range":
                case "rng":
                    sta.put("$rng", this.getEffectiveWeaponRange());
                    break;
            }
        }

        stu.put("cmd", "stu");
        stu.put("sta", sta);
        Kaiden_Extension.getInstance().send(stu, this.user);
    }

    public void update() {
        CombatTrace.info("Stats.update", "start " + CombatTrace.who(this.user) + ", effectCount=" + this.getEffectsSnapshot().size());
        this.initInnateStats();
        this.resetValues();
        this.applyAuraEffects();
        this.applyPassiveCapeHelmTraitMods();
        this.applyTimedUserTraitMods();
        this.applyCoreStatRatings();
        this.syncClientFacingCombatStats();
        this.initDamage();
        this.lastUpdateMs = System.currentTimeMillis();
        this.dirty = false;
        CombatTrace.info("Stats.update", "end " + CombatTrace.who(this.user) + ", ap=" + this.attackPower + ", sp=" + this.magicPower + ", haste=" + this.haste + ", resist=" + this.resist + ", shield=" + this.shieldValue);
    }

    private void applyPassiveCapeHelmTraitMods() {
        EnhancementBean capeEnh = (EnhancementBean) this.user.properties.get("capeitemenhancement");
        EnhancementBean helmEnh = (EnhancementBean) this.user.properties.get("helmitemenhancement");

        String capeName = Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine.normalizeEnhancementName(capeEnh);
        if (capeName.startsWith("absolution")) {
            this.healingBoost *= 1.50D;
            this.physicalBoost *= 0.80D;
        } else if (capeName.startsWith("vainglory")) {
            this.outgoingDamageMod *= 1.15D;
            this.healingIntake *= 0.50D;
        } else if (capeName.startsWith("avarice")) {
            this.haste += 0.10D;
            this.allResist -= 0.35D;
        } else if (capeName.startsWith("penitence")) {
            this.allResist += 0.25D;
            this.dotResistance *= 0.75D;
        } else if (capeName.startsWith("lament")) {
            this.criticalHit += 0.20D;
            this.haste -= 0.05D;
        }

        String helmName = EnhancementTraitEngine.normalizeEnhancementName(helmEnh);
        if (helmName.startsWith("ether")) {
            this.$cmc *= 0.67D;
        } else if (helmName.startsWith("clairvoyance")) {
            this.hit += 0.10D;
        }
    }

    private void applyTimedUserTraitMods() {
        EnhancementTraitEngine.clearExpiredUserEffects(this.user);
        State state = (State) this.user.properties.get("state");
        if (state == null && this.user != null) {
            Object st = this.user.properties.get("state");
            if (st instanceof State) state = (State) st;
        }
        if (state == null) return;

        if (state.hasAura(EnhancementProcAuras.ACHERON)) {
            this.outgoingDamageMod *= 1.30D;
            this.hit += 0.30D;
        }

        int elysianStacks = state.getAuraStackCount(EnhancementProcAuras.ELYSIUM);
        if (elysianStacks > 0) {
            this.outgoingDamageMod *= (1.0D + (0.10D * elysianStacks));
        }
    }

    private void applyAuraEffects() {
        for (Object effect : this.getEffectsSnapshot()) {
            AuraEffectsBean ae = (AuraEffectsBean) effect;
            String statKey = AuraEffectRegistry.canonicalize(ae.getStat());
            double effectValue = AuraEffectRegistry.normalizeValue(statKey, ae.getValue());
            int effectStacks = getAuraEffectStackMultiplier(ae.getId());
            if (effectStacks > 1) {
                if ("+".equals(ae.getType()) || "-".equals(ae.getType())) effectValue *= effectStacks;
                else effectValue = Math.pow(effectValue, effectStacks);
            }
            switch (statKey) {
                case "tha":
                    switch (ae.getType()) {
                        case "+":
                            this.haste += effectValue;
                            break;
                        case "-":
                            this.haste -= effectValue;
                            break;
                        default:
                            this.haste *= effectValue;
                            break;
                    }
                    break;

                case "tdo":
                    switch (ae.getType()) {
                        case "+":
                            this.evasion += effectValue;
                            break;
                        case "-":
                            this.evasion -= effectValue;
                            break;
                        default:
                            this.evasion *= effectValue;
                            break;
                    }
                    break;

                case "thi":
                    switch (ae.getType()) {
                        case "+":
                            this.hit += effectValue;
                            break;
                        case "-":
                            this.hit -= effectValue;
                            break;
                        default:
                            this.hit *= effectValue;
                            break;
                    }
                    break;

                case "tcr":
                    switch (ae.getType()) {
                        case "+":
                            this.criticalHit += effectValue;
                            break;
                        case "-":
                            this.criticalHit -= effectValue;
                            break;
                        default:
                            this.criticalHit *= effectValue;
                            break;
                    }
                    break;

                case "tcm":
                    switch (ae.getType()) {
                        case "+":
                            this.$scm += effectValue;
                            break;
                        case "-":
                            this.$scm -= effectValue;
                            break;
                        default:
                            this.$scm *= effectValue;
                            break;
                    }
                    break;

                case "tpa":
                    switch (ae.getType()) {
                        case "+":
                            this.parry += effectValue;
                            break;
                        case "-":
                            this.parry -= effectValue;
                            break;
                        default:
                            this.parry *= effectValue;
                            break;
                    }
                    break;

                case "tbl":
                    switch (ae.getType()) {
                        case "+":
                            this.block += effectValue;
                            break;
                        case "-":
                            this.block -= effectValue;
                            break;
                        default:
                            this.block *= effectValue;
                            break;
                    }
                    break;

                case "tre":
                    switch (ae.getType()) {
                        case "+":
                            this.resist += effectValue;
                            break;
                        case "-":
                            this.resist -= effectValue;
                            break;
                        default:
                            this.resist *= effectValue;
                            break;
                    }
                    break;

                case "physres":
                    switch (ae.getType()) {
                        case "+":
                            this.physicalResist += effectValue;
                            break;
                        case "-":
                            this.physicalResist -= effectValue;
                            break;
                        default:
                            this.physicalResist *= effectValue;
                            break;
                    }
                    break;

                case "magres":
                    switch (ae.getType()) {
                        case "+":
                            this.magicalResist += effectValue;
                            break;
                        case "-":
                            this.magicalResist -= effectValue;
                            break;
                        default:
                            this.magicalResist *= effectValue;
                            break;
                    }
                    break;

                case "allres":
                    switch (ae.getType()) {
                        case "+":
                            this.allResist += effectValue;
                            break;
                        case "-":
                            this.allResist -= effectValue;
                            break;
                        default:
                            this.allResist *= effectValue;
                            break;
                    }
                    break;

                case "outdmg":
                    switch (ae.getType()) {
                        case "+":
                            this.outgoingDamageMod += effectValue;
                            break;
                        case "-":
                            this.outgoingDamageMod -= effectValue;
                            break;
                        default:
                            this.outgoingDamageMod *= effectValue;
                            break;
                    }
                    break;

                case "incdmg":
                    switch (ae.getType()) {
                        case "+":
                            this.incomingDamageMod += effectValue;
                            break;
                        case "-":
                            this.incomingDamageMod -= effectValue;
                            break;
                        default:
                            this.incomingDamageMod *= effectValue;
                            break;
                    }
                    break;

                case "manaret":
                    switch (ae.getType()) {
                        case "+":
                            this.manaReturn += effectValue;
                            break;
                        case "-":
                            this.manaReturn -= effectValue;
                            break;
                        default:
                            this.manaReturn *= effectValue;
                            break;
                    }
                    break;

                case "lifesteal":
                case "life steal":
                    switch (ae.getType()) {
                        case "+":
                            this.lifeSteal += effectValue;
                            break;
                        case "-":
                            this.lifeSteal -= effectValue;
                            break;
                        default:
                            this.lifeSteal *= effectValue;
                            break;
                    }
                    break;

                case "physboost":
                    switch (ae.getType()) {
                        case "+":
                            this.physicalBoost += effectValue;
                            break;
                        case "-":
                            this.physicalBoost -= effectValue;
                            break;
                        default:
                            this.physicalBoost *= effectValue;
                            break;
                    }
                    break;

                case "magboost":
                    switch (ae.getType()) {
                        case "+":
                            this.magicalBoost += effectValue;
                            break;
                        case "-":
                            this.magicalBoost -= effectValue;
                            break;
                        default:
                            this.magicalBoost *= effectValue;
                            break;
                    }
                    break;

                case "healin":
                case "healintake":
                    switch (ae.getType()) {
                        case "+":
                            this.healingIntake += effectValue;
                            break;
                        case "-":
                            this.healingIntake -= effectValue;
                            break;
                        default:
                            this.healingIntake *= effectValue;
                            break;
                    }
                    break;

                case "healboost":
                    switch (ae.getType()) {
                        case "+":
                            this.healingBoost += effectValue;
                            break;
                        case "-":
                            this.healingBoost -= effectValue;
                            break;
                        default:
                            this.healingBoost *= effectValue;
                            break;
                    }
                    break;

                case "dotres":
                    switch (ae.getType()) {
                        case "+":
                            this.dotResistance -= effectValue;
                            break;
                        case "-":
                            this.dotResistance += effectValue;
                            break;
                        default:
                            this.dotResistance *= effectValue;
                            break;
                    }
                    break;

                case "dotboost":
                    switch (ae.getType()) {
                        case "+":
                            this.dotBoost += effectValue;
                            break;
                        case "-":
                            this.dotBoost -= effectValue;
                            break;
                        default:
                            this.dotBoost *= effectValue;
                            break;
                    }
                    break;

                case "manacost":
                case "manaconsume":
                case "manaconsumption":
                    switch (ae.getType()) {
                        case "+":
                            this.$cmc += effectValue;
                            break;
                        case "-":
                            this.$cmc -= effectValue;
                            break;
                        default:
                            this.$cmc *= effectValue;
                            break;
                    }
                    break;

                case "shield":
                    switch (ae.getType()) {
                        case "+":
                            this.shieldValue += effectValue;
                            break;
                        case "-":
                            this.shieldValue -= effectValue;
                            break;
                        default:
                            this.shieldValue *= effectValue;
                            break;
                    }
                    break;

                case "str":
                    applyAuraCoreStat("STR", ae.getType(), effectValue);
                    break;
                case "int":
                    applyAuraCoreStat("INT", ae.getType(), effectValue);
                    break;
                case "dex":
                    applyAuraCoreStat("DEX", ae.getType(), effectValue);
                    break;
                case "end":
                    applyAuraCoreStat("END", ae.getType(), effectValue);
                    break;
                case "wis":
                    applyAuraCoreStat("WIS", ae.getType(), effectValue);
                    break;
                case "lck":
                    applyAuraCoreStat("LCK", ae.getType(), effectValue);
                    break;
                case "range":
                case "rng":
                    switch (ae.getType()) {
                        case "+":
                            this.rangeBonus += (int) Math.round(effectValue);
                            break;
                        case "-":
                            this.rangeBonus -= (int) Math.round(effectValue);
                            break;
                        default:
                            this.rangeBonus = (int) Math.round(this.rangeBonus * effectValue);
                            break;
                    }
                    break;
            }
        }
    }

    private void applyAuraCoreStat(String stat, String type, double value) {
        Double curObj = this.auraCore.get(stat);
        double cur = curObj != null ? curObj.doubleValue() : 0.0D;
        if ("+".equals(type)) {
            cur += value;
        } else if ("-".equals(type)) {
            cur -= value;
        } else {
            cur *= value;
        }
        this.auraCore.put(stat, cur);
    }

    private void syncClientFacingCombatStats() {
        this._tbl = clamp01(Math.max(0.0D, this.block));
        this._tpa = clamp01(Math.max(0.0D, this.parry));
        this._tdo = clamp01(Math.max(0.0D, this.evasion));
        this._tcr = clamp01(Math.max(0.0D, this.criticalHit));
        this._thi = clamp01(Math.max(0.0D, this.hit));
        this._tha = Math.max(-0.50D, Math.min(0.50D, this.haste));
        this._tre = clamp01(Math.max(0.0D, this.resist));

        this.$cpi = clamp01(1.0D - Math.max(0.0D, this.physicalResist));
        this.$cmi = clamp01(1.0D - Math.max(0.0D, this.magicalResist));
        this.$cao = Math.max(0.0D, this.outgoingDamageMod);
        this.$cai = clamp01(Math.max(0.0D, this.incomingDamageMod) * (1.0D - clamp01(Math.max(0.0D, this.allResist))));
        this.$cpo = Math.max(0.0D, this.physicalBoost);
        this.$cmo = Math.max(0.0D, this.magicalBoost);
        this.$chi = Math.max(0.0D, this.healingIntake);
        this.$cho = Math.max(0.0D, this.healingBoost);
        this.$cdi = clamp01(Math.max(0.0D, this.dotResistance));
        this.$cdo = Math.max(0.0D, this.dotBoost);
        if (this.$cmc < 0.05D) this.$cmc = 0.05D;

        this._cpi = this.$cpi;
        this._cmi = this.$cmi;
        this._cao = this.$cao;
        this._cai = this.$cai;
        this._cpo = this.$cpo;
        this._cmo = this.$cmo;
        this._chi = this.$chi;
        this._cho = this.$cho;
        this._cdi = this.$cdi;
        this._cdo = this.$cdo;
        this._cmc = this.$cmc;
    }

    private double clamp01(double value) {
        if (value < 0.0D) return 0.0D;
        if (value > 1.0D) return 1.0D;
        return value;
    }

    private void initInnateStats() {
        int level = (Integer) this.user.properties.get(Properties.LEVEL);
        String cat = ClassCategory.normalizeCode((String) this.user.properties.get("classcat"));

        this.user.properties.put("classcat", cat);
        this.user.properties.put("classcatname", ClassCategory.codeToName(cat));

        int innateStat = Server.getInstance().getInnateStats(level);
        List<Double> ratios = classCatMap.get(cat);
        if (ratios == null) {
            ratios = classCatMap.get(ClassCategory.M1);
        }

        Set<String> keyEntry = this.innate.keySet();
        int i = 0;
        for (Iterator<String> iterator = keyEntry.iterator(); iterator.hasNext(); ++i) {
            String key = iterator.next();
            double stat = (double) Math.round(ratios.get(i) * (double) innateStat);
            this.innate.put(key, stat);
        }
    }

    private void resetValues() {
        this._ap = 0.0D;
        this.attackPower = 0.0D;
        this._sp = 0.0D;
        this.magicPower = 0.0D;
        this._tbl = 0.0D;
        this._tpa = 0.0D;
        this._tdo = 0.0D;
        this._tcr = 0.0D;
        this._thi = 0.0D;
        this._tha = 0.0D;
        this._tre = 0.0D;

        this.block = StorageCache.getInstance().getCoreValue("baseBlock");
        this.parry = StorageCache.getInstance().getCoreValue("baseParry");
        this.evasion = StorageCache.getInstance().getCoreValue("baseDodge");
        this.criticalHit = StorageCache.getInstance().getCoreValue("baseCrit");
        this.hit = StorageCache.getInstance().getCoreValue("baseHit");
        this.haste = StorageCache.getInstance().getCoreValue("baseHaste");
        this.resist = 0.0D;
        this.physicalResist = 0.0D;
        this.magicalResist = 0.0D;
        this.allResist = 0.0D;
        this.outgoingDamageMod = 1.0D;
        this.incomingDamageMod = 1.0D;
        this.manaReturn = 0.0D;
        this.lifeSteal = 0.0D;
        this.shieldValue = 0.0D;
        this.physicalBoost = 1.0D;
        this.magicalBoost = 1.0D;
        this.healingIntake = 1.0D;
        this.healingBoost = 1.0D;
        this.dotResistance = 1.0D;
        this.dotBoost = 1.0D;

        this._cpo = 1.0D;
        this._cpi = 1.0D;
        this._cao = 1.0D;
        this._cai = 1.0D;
        this._cmo = 1.0D;
        this._cmi = 1.0D;
        this._cdo = 1.0D;
        this._cdi = 1.0D;
        this._cho = 1.0D;
        this._chi = 1.0D;
        this._cmc = 1.0D;

        this.$cpo = 1.0D;
        this.$cpi = 1.0D;
        this.$cao = 1.0D;
        this.$cai = 1.0D;
        this.$cmo = 1.0D;
        this.$cmi = 1.0D;
        this.$cdo = 1.0D;
        this.$cdi = 1.0D;
        this.$cho = 1.0D;
        this.$chi = 1.0D;
        this.$cmc = 1.0D;

        this._scm = StorageCache.getInstance().getCoreValue("baseCritValue");
        this._sbm = StorageCache.getInstance().getCoreValue("baseBlockValue");
        this._srm = StorageCache.getInstance().getCoreValue("baseResistValue");
        this._sem = StorageCache.getInstance().getCoreValue("baseEventValue");

        this.$scm = StorageCache.getInstance().getCoreValue("baseCritValue");
        this.$sbm = StorageCache.getInstance().getCoreValue("baseBlockValue");
        this.$srm = StorageCache.getInstance().getCoreValue("baseResistValue");
        this.$sem = StorageCache.getInstance().getCoreValue("baseEventValue");

        this._shb = 0.0D;
        this._smb = 0.0D;
        this.$shb = 0.0D;
        this.$smb = 0.0D;

        this.rangeBonus = 0;
        this.auraCore.put("STR", 0.0D);
        this.auraCore.put("END", 0.0D);
        this.auraCore.put("DEX", 0.0D);
        this.auraCore.put("INT", 0.0D);
        this.auraCore.put("WIS", 0.0D);
        this.auraCore.put("LCK", 0.0D);
    }

    private double getOffensivePower(String cat) {
        cat = ClassCategory.normalizeCode(cat);

        switch (cat) {
            case "M1":
                return this.attackPower;
            case "M2":
                return (this.attackPower * 0.85D) + (this.magicPower * 0.15D);
            case "M3":
                return (this.attackPower * 0.50D) + (this.magicPower * 0.50D);
            case "M4":
                return (this.attackPower * 1.10D);
            case "C1":
                return this.magicPower;
            case "C2":
                return (this.magicPower * 0.90D) + (this.attackPower * 0.10D);
            case "C3":
                return (this.magicPower * 0.70D) + (this.attackPower * 0.30D);
            case "S1":
                return Math.max(this.attackPower, this.magicPower);
            default:
                return this.attackPower;
        }
    }

    private void applyCoreStatRatings() {
        String cat = (String) this.user.properties.get("classcat");
        cat = ClassCategory.normalizeCode(cat);

        this.user.properties.put("classcat", cat);
        this.user.properties.put("classcatname", ClassCategory.codeToName(cat));

        EnhancementBean enhancement = (EnhancementBean) this.user.properties.get("weaponitemenhancement");
        ItemBean weaponItem = (ItemBean) this.user.properties.get("weaponitem");

        TitleBean Titles = StorageCache.getInstance().getTitle((int)user.properties.get(Properties.TITLE_ID));

        if (Titles != null) {
            title.put("STR", (double) Titles.getStrength());
            title.put("END", (double) Titles.getEndurance());
            title.put("DEX", (double) Titles.getDexterity());
            title.put("INT", (double) Titles.getIntellect());
            title.put("WIS", (double) Titles.getWisdom());
            title.put("LCK", (double) Titles.getLuck());
        } else {
            title.put("STR", 0.0);
            title.put("END", 0.0);
            title.put("DEX", 0.0);
            title.put("INT", 0.0);
            title.put("WIS", 0.0);
            title.put("LCK", 0.0);
        }

        double totalSTR = this.innate.get("STR") + this.title.get("STR") + this.armor.get("STR") + this.weapon.get("STR") + this.helm.get("STR") + this.cape.get("STR") + this.auraCore.get("STR");
        double totalEND = this.innate.get("END") + this.title.get("END") + this.armor.get("END") + this.weapon.get("END") + this.helm.get("END") + this.cape.get("END") + this.auraCore.get("END");
        double totalDEX = this.innate.get("DEX") + this.title.get("DEX") + this.armor.get("DEX") + this.weapon.get("DEX") + this.helm.get("DEX") + this.cape.get("DEX") + this.auraCore.get("DEX");
        double totalINT = this.innate.get("INT") + this.title.get("INT") + this.armor.get("INT") + this.weapon.get("INT") + this.helm.get("INT") + this.cape.get("INT") + this.auraCore.get("INT");
        double totalWIS = this.innate.get("WIS") + this.title.get("WIS") + this.armor.get("WIS") + this.weapon.get("WIS") + this.helm.get("WIS") + this.cape.get("WIS") + this.auraCore.get("WIS");
        double totalLCK = this.innate.get("LCK") + this.title.get("LCK") + this.armor.get("LCK") + this.weapon.get("LCK") + this.helm.get("LCK") + this.cape.get("LCK") + this.auraCore.get("LCK");

        boolean melee = cat.startsWith("M");
        boolean caster = cat.startsWith("C");
        boolean hybrid = "M3".equals(cat) || "S1".equals(cat);

        // AQW-style stat conversion:
        // Physical classes lean on STR/AP, caster classes lean on INT/SP,
        // DEX/WIS support accuracy/haste/evasion and slightly support the matching power,
        // LCK supports both damage sides plus crit chance/crit power.
        double apFromSTR = melee ? 3.00D : (hybrid ? 2.10D : 0.80D);
        double spFromINT = caster ? 3.00D : (hybrid ? 2.10D : 0.80D);
        double dexToAP = (melee || hybrid) ? 0.85D : 0.35D;
        double wisToSP = (caster || hybrid) ? 0.85D : 0.35D;
        double lukToPower = "S1".equals(cat) ? 1.35D : 0.75D;

        this.attackPower += (totalSTR * apFromSTR) + (totalDEX * dexToAP) + (totalLCK * lukToPower);
        this.magicPower += (totalINT * spFromINT) + (totalWIS * wisToSP) + (totalLCK * lukToPower);

        this.physicalBoost += totalSTR * 0.00016D;
        this.magicalBoost += totalINT * 0.00016D;

        this.criticalHit += totalLCK * ("S1".equals(cat) ? 0.00060D : 0.00042D);
        this.$scm += totalLCK * ("S1".equals(cat) ? 0.00105D : 0.00095D);

        this.hit += totalDEX * 0.00085D;
        this.hit += totalWIS * (caster || hybrid ? 0.00080D : 0.00035D);
        this.haste += totalDEX * (("M2".equals(cat) || "M4".equals(cat)) ? 0.00078D : 0.00055D);
        this.haste += totalWIS * (caster || hybrid ? 0.00045D : 0.00018D);
        this.evasion += totalDEX * (("M2".equals(cat) || "S1".equals(cat)) ? 0.00090D : 0.00055D);
        this.evasion += totalWIS * 0.00038D;

        if ("M1".equals(cat) && this._tbl > 0.01D) {
            this.block += totalDEX * 0.00040D;
        }

        this.magicalResist += totalINT * 0.00022D;
        this.physicalResist += totalEND * 0.00022D;
        this.allResist += totalEND * 0.00022D;
        this.healingBoost += totalWIS * 0.00025D;
        this.healingIntake += totalEND * 0.00020D;

        int level = (Integer) this.user.properties.get(Properties.LEVEL);
        double weaponBaseDPS = weaponItem != null ? Math.max(0.0D, (double) weaponItem.getDPS()) : 0.0D;
        double enhancementDPS = enhancement != null ? Math.max(0.0D, (double) enhancement.getDPS()) : 0.0D;
        double iDPS = weaponBaseDPS + enhancementDPS;
        if (iDPS <= 0.0D) {
            iDPS = 100.0D;
        }

        double intAPtoDPS = StorageCache.getInstance().getCoreValue("intAPtoDPS");
        double PCDPSMod = StorageCache.getInstance().getCoreValue("PCDPSMod");
        double offensivePower = getOffensivePower(cat);

        double levelBonus = Math.max(0.0D, level - 1) * 0.25D;
        double apToDps = Math.max(1.0D, intAPtoDPS);

        // Keep weapon DPS as the average base, like AQW. Enhancement stats already
        // feed into AP/SP above, so do not double-count every enhancement stat as raw DPS.
        this.wDPS = (int) Math.max(1L, Math.round((iDPS + levelBonus) * PCDPSMod) + Math.round(offensivePower / apToDps));
    }

    private void initDamage() {
        ConcurrentHashMap userSkills = (ConcurrentHashMap) this.user.properties.get("skills");
        ItemBean weaponItem = (ItemBean) this.user.properties.get("weaponitem");

        if (userSkills != null && weaponItem != null) {
            SkillBean autoAttack = StorageCache.getInstance().getSkill((int) userSkills.get("aa"));
            double autoScalar = autoAttack != null ? normalizeDamageScalar(autoAttack.getDamage()) : 1.0D;
            this.minDmg = getWeaponDamageMin(autoScalar);
            this.maxDmg = getWeaponDamageMax(autoScalar);
        }
    }

    private double normalizeAuraEffectValue(String statKey, double value) {
        return AuraEffectRegistry.normalizeValue(statKey, value);
    }

    /**
     * A single auras_effects row belongs to an aura, while RemoveAura tracks the
     * live stack count. Multiply additive effects by the active stack count so
     * e.g. +3% at 10 stacks becomes +30%. Runtime phase effects use negative
     * IDs and are intentionally treated as one stack.
     */
    private int getAuraEffectStackMultiplier(int effectId) {
        if (effectId <= 0 || this.user == null || this.user.properties == null) return 1;
        Object obj = this.user.properties.get("state");
        if (!(obj instanceof State)) return 1;
        State state = (State) obj;
        int total = 0;
        try {
            for (Kaiden.Game.Threads.RemoveAura ra : state.getAuras()) {
                if (ra == null || ra.getAura() == null || ra.isFinished() || ra.isExpired()) continue;
                AuraBean aura = ra.getAura();
                if (aura.effects == null || !aura.effects.contains(effectId)) continue;
                // Once a later runtime phase is active, its virtual effects replace base effects.
                if (ra.hasActiveRuntimePhase()) continue;
                total += Math.max(1, ra.getStackCount());
            }
        } catch (Throwable ignored) {}
        return Math.max(1, total);
    }

    public int get$DEX() {
        return (int) Math.round(this.innate.get("DEX") + this.title.get("DEX") + this.weapon.get("DEX") + this.armor.get("DEX") + this.helm.get("DEX") + this.cape.get("DEX") + this.auraCore.get("DEX"));
    }

    public int get$END() {
        return (int) Math.round(this.innate.get("END") + this.title.get("END") + this.weapon.get("END") + this.armor.get("END") + this.helm.get("END") + this.cape.get("END") + this.auraCore.get("END"));
    }

    public int get$INT() {
        return (int) Math.round(this.innate.get("INT") + this.title.get("INT") + this.weapon.get("INT") + this.armor.get("INT") + this.helm.get("INT") + this.cape.get("INT") + this.auraCore.get("INT"));
    }

    public int get$LCK() {
        return (int) Math.round(this.innate.get("LCK") + this.title.get("LCK") + this.weapon.get("LCK") + this.armor.get("LCK") + this.helm.get("LCK") + this.cape.get("LCK") + this.auraCore.get("LCK"));
    }

    public int get$STR() {
        return (int) Math.round(this.innate.get("STR") + this.title.get("STR") + this.weapon.get("STR") + this.armor.get("STR") + this.helm.get("STR") + this.cape.get("STR") + this.auraCore.get("STR"));
    }

    public int get$WIS() {
        return (int) Math.round(this.innate.get("WIS") + this.title.get("WIS") + this.weapon.get("WIS") + this.armor.get("WIS") + this.helm.get("WIS") + this.cape.get("WIS") + this.auraCore.get("WIS"));
    }

    public int get$ap() {
        return (int) Math.round(this.attackPower);
    }

    public double get$cai() {
        return this.$cai;
    }

    public double get$cao() {
        return this.$cao;
    }

    public double get$cdi() {
        return this.$cdi;
    }

    public double get$cdo() {
        return this.$cdo;
    }

    public double get$chi() {
        return this.$chi;
    }

    public double get$cho() {
        return this.$cho;
    }

    public double get$cmc() {
        return this.$cmc;
    }

    public double get$cmi() {
        return this.$cmi;
    }

    public double get$cmo() {
        return this.$cmo;
    }

    public double get$cpi() {
        return this.$cpi;
    }

    public double get$cpo() {
        return this.$cpo;
    }

    public double get$sbm() {
        return this.$sbm;
    }

    public double get$scm() {
        return this.$scm;
    }

    public double get$sem() {
        return this.$sem;
    }

    public double get$shb() {
        return this.$shb;
    }

    public double get$smb() {
        return this.$smb;
    }

    public int get$sp() {
        return (int) Math.round(this.magicPower);
    }

    public double get$srm() {
        return this.$srm;
    }

    public double get$tbl() {
        return this.block;
    }

    public double get$tcr() {
        return this._tcr;
    }

    public double get$tdo() {
        return this._tdo;
    }

    public double get$tha() {
        return this._tha;
    }

    public double get$thi() {
        return this._thi;
    }

    public double get$tpa() {
        return this.parry;
    }

    public double get$tre() {
        return this.resist;
    }

    public double get_DEX() {
        return this.innate.get("DEX");
    }

    public double get_END() {
        return this.innate.get("END");
    }

    public double get_INT() {
        return this.innate.get("INT");
    }

    public double get_LCK() {
        return this.innate.get("LCK");
    }

    public double get_STR() {
        return this.innate.get("STR");
    }

    public double get_WIS() {
        return this.innate.get("WIS");
    }

    public double get_ap() {
        return this._ap;
    }

    public double get_cai() {
        return this._cai;
    }

    public double get_cao() {
        return this._cao;
    }

    public double get_cdi() {
        return this._cdi;
    }

    public double get_cdo() {
        return this._cdo;
    }

    public double get_chi() {
        return this._chi;
    }

    public double get_cho() {
        return this._cho;
    }

    public double get_cmc() {
        return this._cmc;
    }

    public double get_cmi() {
        return this._cmi;
    }

    public double get_cmo() {
        return this._cmo;
    }

    public double get_cpi() {
        return this._cpi;
    }

    public double get_cpo() {
        return this._cpo;
    }

    public double get_sbm() {
        return this._sbm;
    }

    public double get_scm() {
        return this._scm;
    }

    public double get_sem() {
        return this._sem;
    }

    public double get_shb() {
        return this._shb;
    }

    public double get_smb() {
        return this._smb;
    }

    public double get_sp() {
        return this._sp;
    }

    public double get_srm() {
        return this._srm;
    }

    public double get_tbl() {
        return this._tbl;
    }

    public double get_tcr() {
        return this._tcr;
    }

    public double get_tdo() {
        return this._tdo;
    }

    public double get_tha() {
        return this._tha;
    }

    public double get_thi() {
        return this._thi;
    }

    public double get_tpa() {
        return this._tpa;
    }

    public double get_tre() {
        return this._tre;
    }

    public double get$physres() {
        return this.physicalResist;
    }

    public double get$magres() {
        return this.magicalResist;
    }

    public double get$allres() {
        return this.allResist;
    }

    public double get$outdmg() {
        return this.outgoingDamageMod;
    }

    public double get$incdmg() {
        return this.incomingDamageMod;
    }

    public double get$manaret() {
        return this.manaReturn;
    }

    public double get$lifesteal() {
        return this.lifeSteal;
    }

    public double get$shield() {
        return this.shieldValue;
    }

    public double get$physboost() {
        return this.physicalBoost;
    }

    public double get$magboost() {
        return this.magicalBoost;
    }

    public double get$dotres() {
        return this.dotResistance;
    }

    public double get$dotboost() {
        return this.dotBoost;
    }

    private int normalizeWeaponRange(int rawRange) {
        if (rawRange > 50) {
            rawRange = (int) Math.round(rawRange / 10.0D);
        }
        if (rawRange < 0) rawRange = 0;
        if (rawRange > 100) rawRange = 100;
        return rawRange;
    }

    public int getEffectiveWeaponRange() {
        ItemBean weaponItem = (ItemBean) this.user.properties.get("weaponitem");
        int baseRange = weaponItem != null ? normalizeWeaponRange(weaponItem.getRange()) : 0;
        int effective = baseRange + this.rangeBonus;
        if (effective < 0) effective = 0;
        if (effective > 100) effective = 100;
        return effective;
    }

    /**
     * Enhancement level used by AQW's level-scaled WDPS curve.
     * Falls back to the equipped weapon level and then player level for
     * legacy records that do not have a weapon enhancement object.
     */
    public int getWeaponEnhancementLevel() {
        EnhancementBean enhancement = (EnhancementBean) this.user.properties.get("weaponitemenhancement");
        if (enhancement != null && enhancement.getLevel() > 0) {
            return enhancement.getLevel();
        }

        ItemBean weaponItem = (ItemBean) this.user.properties.get("weaponitem");
        if (weaponItem != null && weaponItem.getLevel() > 0) {
            return weaponItem.getLevel();
        }

        Object level = this.user.properties.get(Properties.LEVEL);
        return level instanceof Integer ? Math.max(1, (Integer) level) : 1;
    }

    public double getWeaponDamageRangePct() {
        return Math.max(0.05D, Math.min(this.getEffectiveWeaponRange() / 100.0D, 0.95D));
    }

    public double getWeaponDpsBase() {
        return Math.max(1.0D, (double) this.wDPS);
    }

    public double getWeaponDamageBase() {
        return Math.max(1.0D, getWeaponDpsBase() * 2.0D);
    }

    public int getWeaponDamageMin(double scalar) {
        double s = normalizeDamageScalar(scalar);
        double base = getWeaponDamageBase() * s;
        double radius = getWeaponDamageRangePct();
        return (int) Math.max(1, Math.floor(base - (base * radius)));
    }

    public int getWeaponDamageMax(double scalar) {
        double s = normalizeDamageScalar(scalar);
        double base = getWeaponDamageBase() * s;
        double radius = getWeaponDamageRangePct();
        int min = getWeaponDamageMin(s);
        return Math.max(min, (int) Math.ceil(base + (base * radius)));
    }

    public int rollWeaponDamage(double scalar) {
        int min = getWeaponDamageMin(scalar);
        int max = getWeaponDamageMax(scalar);
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    private double normalizeDamageScalar(double raw) {
        double v = Math.abs(raw);
        if (v <= 0.0D) return 1.0D;
        if (v > 10.0D) v = v / 100.0D;
        return Math.max(0.05D, Math.min(12.0D, v));
    }

    public int getMinDmg() {
        return this.minDmg;
    }

    public int getMaxDmg() {
        return this.maxDmg;
    }
}
