package Kaiden.Game.Server.Users.Utils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class ClassCategory {

    public static final String M1 = "M1";
    public static final String M2 = "M2";
    public static final String M3 = "M3";
    public static final String M4 = "M4";
    public static final String C1 = "C1";
    public static final String C2 = "C2";
    public static final String C3 = "C3";
    public static final String S1 = "S1";

    private static final Set<String> VALID_CODES = new HashSet<String>(Arrays.asList(
            M1, M2, M3, M4, C1, C2, C3, S1
    ));

    private ClassCategory() {
    }

    public static String normalizeCode(String value) {
        if (value == null) {
            return M1;
        }

        String v = value.trim();
        if (v.length() == 0) {
            return M1;
        }

        String upper = v.toUpperCase();

        if (VALID_CODES.contains(upper)) {
            return upper;
        }

        if ("FIGHTER".equals(upper)) {
            return M1;
        }
        if ("THIEF".equals(upper)) {
            return M2;
        }
        if ("HYBRID".equals(upper)) {
            return M3;
        }
        if ("ARMSMAN".equals(upper)) {
            return M4;
        }
        if ("WIZARD".equals(upper)) {
            return C1;
        }
        if ("HEALER".equals(upper)) {
            return C2;
        }
        if ("SPELLBREAKER".equals(upper)) {
            return C3;
        }
        if ("LUCKY".equals(upper)) {
            return S1;
        }

        return M1;
    }

    public static String codeToName(String value) {
        String code = normalizeCode(value);

        if (M1.equals(code)) {
            return "Fighter";
        }
        if (M2.equals(code)) {
            return "Thief";
        }
        if (M3.equals(code)) {
            return "Hybrid";
        }
        if (M4.equals(code)) {
            return "Armsman";
        }
        if (C1.equals(code)) {
            return "Wizard";
        }
        if (C2.equals(code)) {
            return "Healer";
        }
        if (C3.equals(code)) {
            return "Spellbreaker";
        }
        if (S1.equals(code)) {
            return "Lucky";
        }

        return "Fighter";
    }

    public static boolean isMelee(String value) {
        String code = normalizeCode(value);
        return M1.equals(code) || M2.equals(code) || M3.equals(code) || M4.equals(code) || S1.equals(code);
    }

    public static boolean isCaster(String value) {
        String code = normalizeCode(value);
        return C1.equals(code) || C2.equals(code) || C3.equals(code) || M3.equals(code) || S1.equals(code);
    }

    public static boolean isLucky(String value) {
        return S1.equals(normalizeCode(value));
    }

    public static boolean isPureCaster(String value) {
        String code = normalizeCode(value);
        return C1.equals(code) || C2.equals(code) || C3.equals(code);
    }

    public static boolean isHybrid(String value) {
        return M3.equals(normalizeCode(value));
    }
}