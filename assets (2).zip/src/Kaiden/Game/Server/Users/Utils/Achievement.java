package Kaiden.Game.Server.Users.Utils;

public class Achievement {

   public static int get(int value, int index) {
      if (index < 0 || index > 31) return -1;
      return (value >>> index) & 1;
   }

   public static int update(int valueToSet, int index, int value) {
      if (index < 0 || index > 31) return valueToSet;

      int mask = (1 << index); // index 31 becomes negative mask, still correct bit pattern

      if (value == 0) {
         return valueToSet & ~mask;
      }
      if (value == 1) {
         return valueToSet | mask;
      }
      return valueToSet;
   }
}
