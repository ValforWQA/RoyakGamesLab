package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledFuture;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.log4j.Logger;

public class UserState extends State {

    private static final Logger COMBAT_WATCHDOG_LOG = Logger.getLogger(UserState.class);
    private static final long WATCHDOG_PERIOD_SECONDS = 5L;
    private final User user;

    public UserState(User user, int maxHealth, int maxMana, int dash) {
        super(maxHealth, maxMana, dash);
        this.user = user;
        startCombatWatchdog(user, this);
    }

    /**
     * Periodically reconcile server combat state against valid targets.
     * This does not invent attacks, reset cooldowns or interrupt live casts.
     * Weak references plus self-cancellation prevent a task retaining logged-out users.
     */
    private static void startCombatWatchdog(User user, UserState state) {
        if (user == null || state == null) return;
        final WeakReference<User> userRef = new WeakReference<User>(user);
        final WeakReference<UserState> stateRef = new WeakReference<UserState>(state);
        final AtomicReference<ScheduledFuture<?>> futureRef = new AtomicReference<ScheduledFuture<?>>();
        Runnable check = new Runnable() {
            @Override public void run() {
                User currentUser = userRef.get();
                UserState currentState = stateRef.get();
                if (currentUser == null || currentState == null
                        || currentUser.properties.get("state") != currentState) {
                    ScheduledFuture<?> future = futureRef.get();
                    if (future != null) future.cancel(false);
                    return;
                }
                try {
                    int before = currentState.getState();
                    if (before == 0) return; // Never resurrect a dead character.
                    currentState.refreshCombatState();
                    int after = currentState.getState();
                    if (before != after) {
                        COMBAT_WATCHDOG_LOG.warn("[CombatWatchdog] repaired user="
                                + currentUser.getName() + " state=" + before + "->" + after
                                + " monsters=" + currentState.getMonsterTargets().size()
                                + " players=" + currentState.getPlayerTargets().size());
                    }
                } catch (Throwable error) {
                    COMBAT_WATCHDOG_LOG.error("[CombatWatchdog] state check failed", error);
                }
            }
        };
        try {
            futureRef.set(Executor.getInstance().scheduleTask(
                    check, WATCHDOG_PERIOD_SECONDS, TimeUnit.SECONDS, true));
        } catch (RuntimeException error) {
            COMBAT_WATCHDOG_LOG.error("[CombatWatchdog] could not start", error);
        }
    }

    public User getUser() {
        return this.user;
    }

    @Override
    public void restore() {
        super.restore();
        if (this.user != null) {
            this.user.properties.remove("monsterdeathcounted");
        }
    }

    @Override
    public void die() {
        // Generic death logic (HP=0, MP=0, state=Dead)
        super.die();
        // Clear all active auras on this user
        super.clearAuras();
        // Mark respawn time for this user
        this.user.properties.put("respawntime", System.currentTimeMillis());
    }

    @Override
    public synchronized RemoveAura applyAura(AuraBean aura) {
        return this.applyAura(aura, "");
    }

    public synchronized RemoveAura applyAura(AuraBean aura, String sourceInf) {
        if (aura == null) return null;

        final int auraId = aura.getId();
        final int maxStacks = Math.max(1, aura.getStack());
        final String normalizedSource = sourceInf == null ? "" : sourceInf.trim().toLowerCase();

        RemoveAura categoryAura = Kaiden.Game.Server.Combat.Player.PlayerCombatContainer.getInstance().findCategoryAura(this.getAuras(), aura);
        if (categoryAura != null && categoryAura.getAura() != null) {
            if (categoryAura.getAura().getId() == auraId) {
                categoryAura.refreshDuration(aura.getRuntimeDuration());
                categoryAura.resetRuntimePhases();
                categoryAura.setSourceInf(normalizedSource);
                categoryAura.setRefreshedOnly(true);
                CombatTrace.info("UserState.applyAura", "refresh exclusive existing " + CombatTrace.aura(categoryAura) + ", target=" + CombatTrace.who(this.user));
                return categoryAura;
            }
            categoryAura.cancel();
            this.removeAura(categoryAura);
        }

        final RemoveAura managed = normalizedSource.isEmpty() ? this.getLatestExpiringAura(auraId) : this.getLatestExpiringAuraBySource(auraId, normalizedSource);
        final int currentStacks = this.getAuraStackCount(auraId);
        final int currentStacksForSource = normalizedSource.isEmpty() ? currentStacks : this.getAuraStackCountBySource(auraId, normalizedSource);

        if (managed != null) {
            managed.refreshDuration(aura.getRuntimeDuration());
            managed.resetRuntimePhases();
            managed.setSourceInf(normalizedSource);

            if (maxStacks <= 1) {
                managed.setRefreshedOnly(true);
                CombatTrace.info("UserState.applyAura", "refresh non-stack aura " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.user));
                return managed;
            }

            if (currentStacks >= maxStacks || currentStacksForSource >= maxStacks) {
                managed.setRefreshedOnly(true);
                CombatTrace.info("UserState.applyAura", "refresh max-stack aura " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.user) + ", stacks=" + currentStacks + "/" + maxStacks);
                return managed;
            }

            managed.incrementStackCount(1, maxStacks);
            managed.setRefreshedOnly(false);
            try {
                Stats stats = (Stats) this.user.properties.get("stats");
                if (stats != null) stats.markDirty();
            } catch (Throwable ignored) {}
            CombatTrace.info("UserState.applyAura", "increase managed stack " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.user) + ", stacks=" + this.getAuraStackCount(auraId) + "/" + maxStacks);
            return managed;
        }

        long newEndTime = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(aura.getRuntimeDuration());
        RemoveAura ra = new RemoveAura(
                aura,
                this.user,
                Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom())
        );
        ra.setStackCount(1);
        ra.setRefreshedOnly(false);
        ra.scheduleToEndTime(newEndTime);
        ra.scheduleRuntimePhases();
        ra.setSourceInf(normalizedSource);
        this.addAura(ra);
        CombatTrace.info("UserState.applyAura", "add new aura " + CombatTrace.aura(ra) + ", target=" + CombatTrace.who(this.user) + ", stacks=" + this.getAuraStackCount(auraId) + "/" + maxStacks);
        return ra;
    }

}
