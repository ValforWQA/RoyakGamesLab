package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.QuestBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.QuestTimedExpire;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("ALL")
public final class QuestProgressManager {

    public static final String RESTORE_PENDING_PUSH = "questRestorePendingPush";
    public static final String RESTORED_QUESTS = "questRestoreQuestIds";
    public static final String RESTORED_TEMP_ITEMS = "questRestoreTempItems";
    public static final String RESTORED_PENDING_DROPS = "questRestorePendingDrops";
    public static final String RESTORED_PENDING_DROPS_PUSHED = "questRestorePendingDropsPushed";
    public static final String RESTORE_REPLAYING_DROPS = "questRestoreReplayingDrops";
    private static final String TIMED_QUEST_TASK_PREFIX = "timedQuestExpireTask_";

    private QuestProgressManager() {}

    public static boolean isRestoreReplayingDrops(User user) {
        if (user == null || user.properties == null) {
            return false;
        }
        Object replaying = user.properties.get(RESTORE_REPLAYING_DROPS);
        return replaying instanceof Boolean && ((Boolean) replaying);
    }

    public static void beginRestoreDropReplay(User user) {
        if (user != null && user.properties != null) {
            user.properties.put(RESTORE_REPLAYING_DROPS, true);
        }
    }

    public static void endRestoreDropReplay(User user) {
        if (user != null && user.properties != null) {
            user.properties.remove(RESTORE_REPLAYING_DROPS);
        }
    }

    public static void ensureSchema() {
        try {
            Storage.getInstance().getJdbc().run(
                    "CREATE TABLE IF NOT EXISTS users_quests_active (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY," +
                            "UserID INT NOT NULL," +
                            "QuestID INT NOT NULL," +
                            "AcceptedAt DATETIME NULL," +
                            "UpdatedAt DATETIME NULL," +
                            "ExpiresAt DATETIME NULL," +
                            "UNIQUE KEY uq_user_quest (UserID, QuestID)" +
                            ")"
            );
        } catch (Exception ignored) {}
        try {
            Storage.getInstance().getJdbc().run(
                    "CREATE TABLE IF NOT EXISTS users_quests_items (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY," +
                            "UserID INT NOT NULL," +
                            "ItemID INT NOT NULL," +
                            "Quantity INT NOT NULL DEFAULT 0," +
                            "UpdatedAt DATETIME NULL," +
                            "ExpiresAt DATETIME NULL," +
                            "UNIQUE KEY uq_user_item (UserID, ItemID)" +
                            ")"
            );
        } catch (Exception ignored) {}
        try {
            Storage.getInstance().getJdbc().run(
                    "CREATE TABLE IF NOT EXISTS users_quests_drops (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY," +
                            "UserID INT NOT NULL," +
                            "ItemID INT NOT NULL," +
                            "QuestID INT NOT NULL DEFAULT 0," +
                            "Quantity INT NOT NULL DEFAULT 1," +
                            "IsTemp TINYINT(1) NOT NULL DEFAULT 0," +
                            "Bank TINYINT(1) NOT NULL DEFAULT 0," +
                            "Status VARCHAR(20) NOT NULL DEFAULT 'pending'," +
                            "CreatedAt DATETIME NULL," +
                            "UpdatedAt DATETIME NULL," +
                            "ExpiresAt DATETIME NULL," +
                            "UNIQUE KEY uq_user_drop (UserID, ItemID)" +
                            ")"
            );
        } catch (Exception ignored) {}

        // Safe migrations for older tables. Duplicate-column errors are ignored.
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN QuestID INT NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN Status VARCHAR(20) NOT NULL DEFAULT 'pending'"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN IsTemp TINYINT(1) NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN Bank TINYINT(1) NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN CreatedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN UpdatedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_drops ADD COLUMN ExpiresAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN AcceptedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN UpdatedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN ExpiresAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE quests ADD COLUMN TimeLimitMinutes INT NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE quests ADD COLUMN TimeLimitSeconds INT NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN TimerStartedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN TimerEndsAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_active ADD COLUMN TimeLimitSeconds INT NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_items ADD COLUMN UpdatedAt DATETIME NULL"); } catch (Exception ignored) {}
        try { Storage.getInstance().getJdbc().run("ALTER TABLE users_quests_items ADD COLUMN ExpiresAt DATETIME NULL"); } catch (Exception ignored) {}
    }

    public static void cleanupExpired() {
        ensureSchema();
        try {
            Storage.getInstance().getJdbc().run("DELETE FROM users_quests_active WHERE ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()");
            Storage.getInstance().getJdbc().run("DELETE FROM users_quests_items WHERE ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()");
            Storage.getInstance().getJdbc().run("DELETE FROM users_quests_drops WHERE ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()");
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] cleanup failed: " + e.getMessage());
        }
    }

    /**
     * Load restore data from DB only. IMPORTANT: do not pre-insert restored temp items into
     * Properties.TEMP_ITEMS here. The client only updates quest progress correctly when the
     * quest is active first and the items are replayed through Users.dropItems() afterward.
     */
    public static void restore(User user) {
        if (user == null || user.properties == null) {
            return;
        }

        cleanupExpired();

        Object userId = user.properties.get(Properties.ID);
        if (userId == null) {
            return;
        }

        Set<Integer> activeQuests = (Set<Integer>) user.properties.get(Properties.QUESTS);
        ConcurrentHashMap<Integer, UserDrop> drops = (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");

        if (activeQuests == null) {
            return;
        }
        if (drops == null) {
            drops = new ConcurrentHashMap<Integer, UserDrop>();
            user.properties.put("drops", drops);
        }

        // Drop stale in-memory active quests before rebuilding from the DB.
        activeQuests.clear();
        Set<Integer> restoredQuestIds = new HashSet<Integer>();
        Map<Integer, Integer> restoredTempItems = new HashMap<Integer, Integer>();
        Map<Integer, UserDrop> restoredPendingDrops = new HashMap<Integer, UserDrop>();

        QueryResult active = null;
        QueryResult items = null;
        QueryResult pendingDrops = null;
        int activeCount = 0;
        int tempCount = 0;
        int dropCount = 0;

        try {
            active = Storage.getInstance().getJdbc().query(
                    "SELECT QuestID FROM users_quests_active WHERE UserID=? AND (ExpiresAt IS NULL OR ExpiresAt >= NOW()) AND (TimerEndsAt IS NULL OR TimerEndsAt > NOW())",
                    userId
            );
            while (active.next()) {
                int questId = active.getInt("QuestID");
                QuestBean questObj = StorageCache.getInstance().getQuest(questId);
                if (questObj == null) {
                    continue;
                }
                activeQuests.add(questId);
                restoredQuestIds.add(questId);
                activeCount++;
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] active restore failed for " + user.getName() + ": " + e.getMessage());
        } finally {
            try { if (active != null) active.close(); } catch (Exception ignored) {}
        }

        if (!restoredQuestIds.isEmpty()) {
            try {
                items = Storage.getInstance().getJdbc().query(
                        "SELECT ItemID, Quantity FROM users_quests_items WHERE UserID=? AND (ExpiresAt IS NULL OR ExpiresAt >= NOW())",
                        userId
                );
                while (items.next()) {
                    int itemId = items.getInt("ItemID");
                    int quantity = Math.max(0, items.getInt("Quantity"));
                    ItemBean item = StorageCache.getInstance().getItem(itemId);
                    if (item == null || quantity <= 0) {
                        continue;
                    }
                    String itemType = item.getType();
                    boolean questInventoryItem = item.isTemporary()
                            || (itemType != null && ("Quest Item".equalsIgnoreCase(itemType.trim())
                            || "QuestItem".equalsIgnoreCase(itemType.trim())));
                    if (!questInventoryItem && !isQuestItemActive(restoredQuestIds, item)) {
                        continue;
                    }
                    if (!isQuestItemActive(restoredQuestIds, item)) {
                        continue;
                    }
                    restoredTempItems.put(itemId, quantity);
                    tempCount++;
                }
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] temp item restore failed for " + user.getName() + ": " + e.getMessage());
            } finally {
                try { if (items != null) items.close(); } catch (Exception ignored) {}
            }
        }

        try {
            pendingDrops = Storage.getInstance().getJdbc().query(
                    "SELECT ItemID, Quantity, Bank, IsTemp FROM users_quests_drops WHERE UserID=? AND Status='pending' AND (ExpiresAt IS NULL OR ExpiresAt >= NOW())",
                    userId
            );
            while (pendingDrops.next()) {
                int itemId = pendingDrops.getInt("ItemID");
                int quantity = Math.max(1, pendingDrops.getInt("Quantity"));
                boolean bank = pendingDrops.getInt("Bank") == 1;
                ItemBean item = StorageCache.getInstance().getItem(itemId);
                if (item == null) {
                    continue;
                }

                // Non-temp monster drops must be re-dropped as pending drops. Temp quest drops
                // are restored through users_quests_items after the quest is active.
                if (item.isTemporary()) {
                    if (isQuestItemActive(restoredQuestIds, item)) {
                        Integer oldQty = restoredTempItems.get(itemId);
                        restoredTempItems.put(itemId, Math.max(oldQty == null ? 0 : oldQty, quantity));
                    }
                    continue;
                }

                // Do NOT insert restored pending drops into the live drops map here.
                // sendRestoredPendingDrops() replays the normal drop packet later, and
                // sendDropItem() will add it to user.properties("drops") exactly once.
                // Pre-inserting here caused restored drops to double/multiply on relog/map join.
                UserDrop drop = new UserDrop(itemId, quantity, bank);
                restoredPendingDrops.put(itemId, drop);
                dropCount++;
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] pending drop restore failed for " + user.getName() + ": " + e.getMessage());
        } finally {
            try { if (pendingDrops != null) pendingDrops.close(); } catch (Exception ignored) {}
        }

        if (activeCount > 0 || tempCount > 0 || dropCount > 0) {
            user.properties.put(RESTORED_QUESTS, restoredQuestIds);
            user.properties.put(RESTORED_TEMP_ITEMS, restoredTempItems);
            user.properties.put(RESTORED_PENDING_DROPS, restoredPendingDrops);
            user.properties.put(RESTORE_PENDING_PUSH, true);
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[QuestProgress] loaded restore user=" + user.getName() + " activeFromDB=" + activeCount + " tempItems=" + tempCount + " pendingDrops=" + dropCount
            );
        }
    }

    /**
     * Pushes restored quest state after room join. Correct AQW-like order:
     * 1) real acceptQuest flow so the client marks the quest active/current
     * 2) getQuests active payload
     * 3) replay temp quest items through Users.dropItems() so Properties.TEMP_ITEMS and client temp inventory update together
     * 4) getQuests again so the tracker recalculates from restored temp inventory
     * 5) re-drop pending normal monster drops
     */
    public static void pushRestoredState(User user) {
        if (user == null || user.properties == null) {
            return;
        }

        checkTimedQuests(user);

        Object pending = user.properties.get(RESTORE_PENDING_PUSH);
        if (!(pending instanceof Boolean) || !((Boolean) pending)) {
            return;
        }

        Set<Integer> restoredQuestIds = (Set<Integer>) user.properties.get(RESTORED_QUESTS);
        if (restoredQuestIds == null) {
            restoredQuestIds = new HashSet<Integer>();
        }

        /*
         * IMPORTANT:
         * Restored quests are already active server-side. restore() loaded them from
         * users_quests_active and inserted them into Properties.QUESTS.
         *
         * Do NOT replay the acceptQuest command here. Sending acceptQuest again causes
         * the AQW client to treat every restored quest as a fresh acceptance. On map
         * joins this can repeatedly open/close the quest UI, trigger abandonQuest on
         * location failures, and block normal quest viewing.
         *
         * getQuests is enough to rebuild the client's questTree with status="p" and
         * bAccepted=1 without firing the acceptQuest UI flow.
         */
        Set<Integer> restoredNow = new HashSet<Integer>();
        for (Integer questId : restoredQuestIds) {
            if (questId == null || questId <= 0) {
                continue;
            }
            QuestBean questObj = StorageCache.getInstance().getQuest(questId);
            if (questObj == null) {
                continue;
            }
            restoredNow.add(questId);
        }

        try {
            if (!restoredNow.isEmpty()) {
                // Restore active/current quest state silently. No acceptQuest packet.
                Kaiden_Extension.getInstance().send(buildGetQuestsPayload(user, restoredNow), user);

                // Replay persisted temporary quest items after questTree is active.
                Users.getInstance().sendRestoredTempItems(user, restoredNow);

                // Re-send state so tracker counts refresh after temp items are restored.
                Kaiden_Extension.getInstance().send(buildGetQuestsPayload(user, restoredNow), user);

                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "green",
                        "[QuestProgress] restored active quest state silently user=" + user.getName() + " quests=" + restoredNow.size()
                );
            }

            Object dropsPushed = user.properties.get(RESTORED_PENDING_DROPS_PUSHED);
            if (!(dropsPushed instanceof Boolean) || !((Boolean) dropsPushed)) {
                Users.getInstance().sendRestoredPendingDrops(user);
                user.properties.put(RESTORED_PENDING_DROPS_PUSHED, true);
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[QuestProgress] restored quest/temp push failed for " + user.getName() + ": " + e.getMessage()
            );
            return;
        }

        // The restore snapshot is a one-time login sync, not something to retry on
        // every map join. Active quests remain in Properties.QUESTS and in the DB.
        user.properties.put(RESTORE_PENDING_PUSH, false);
        user.properties.remove(RESTORED_QUESTS);
        user.properties.remove(RESTORED_TEMP_ITEMS);
        user.properties.remove(RESTORED_PENDING_DROPS);
        user.properties.remove(RESTORED_PENDING_DROPS_PUSHED);
    }

    private static boolean runAcceptQuestHandler(User user, Room room, int questId) {
        JSONObject qObj = new JSONObject();
        qObj.put("cmd", "acceptQuest");
        qObj.put("QuestID", questId);

        try {
            if (user == null || user.properties == null) {
                return false;
            }

            Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
            QuestBean quest = StorageCache.getInstance().getQuest(questId);

            if (quest == null) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Quest not found.");
                Kaiden_Extension.getInstance().send(qObj, user);
                return false;
            }

            if (quests == null) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Quest system unavailable.");
                Kaiden_Extension.getInstance().send(qObj, user);
                return false;
            }

            // Restore/replay must use the same first-map registration as normal accept.
            if ((quest.locations == null || quest.locations.isEmpty())
                    && room != null && room.getName() != null) {
                ZoneBean firstArea = StorageCache.getInstance().getArea(room.getName().split("-")[0]);
                if (firstArea != null) {
                    StorageCache.getInstance().ensureQuestLocation(questId, firstArea.getId());
                }
            }
            if (quest.locations == null || quest.locations.isEmpty()) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Wrong location to accept for this quest!");
                Kaiden_Extension.getInstance().send(qObj, user);
                return false;
            }

            int questMapId = getQuestMapId(quest);
            qObj.put("status", "p");
            qObj.put("strStatus", "p");
            qObj.put("bAccepted", 1);
            qObj.put("MapID", questMapId);
            qObj.put("iMap", questMapId);
            putQuestTimerFields(user, questId, quest, qObj);

            if (room == null || room.getName() == null) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Wrong location to accept for this quest!");
                Kaiden_Extension.getInstance().send(qObj, user);
                return false;
            }

            ZoneBean area = StorageCache.getInstance().getArea(room.getName().split("-")[0]);

            if (area == null || !quest.locations.contains(area.getId())) {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Wrong location to accept for this quest!");
                try {
                    Users.getInstance().log(
                            user,
                            "Invalid Quest Restore Accept",
                            "Quest restore accept delayed because user is not in a valid quest location. QuestID=" + questId
                    );
                } catch (Exception ignored) {}
                Kaiden_Extension.getInstance().send(qObj, user);
                return false;
            }

            if (quests.contains(questId)) {
                acceptQuest(user, questId);
                qObj.put("bSuccess", 1);
                qObj.put("msg", "Quest Accepted!");
                Kaiden_Extension.getInstance().send(qObj, user);
                Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[QuestProgress] restored accept packet user=" + user.getName() + " QuestID=" + questId + " MapID=" + questMapId);
                return true;
            }

            quests.add(questId);
            acceptQuest(user, questId);

            qObj.put("bSuccess", 1);
            qObj.put("msg", "Quest Accepted!");
            Kaiden_Extension.getInstance().send(qObj, user);
            Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[QuestProgress] restored accept packet user=" + user.getName() + " QuestID=" + questId + " MapID=" + questMapId);
            return true;
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] restore accept packet error user=" + (user == null ? "null" : user.getName()) + " QuestID=" + questId + " msg=" + e.getMessage());
            try {
                qObj.put("bSuccess", 0);
                qObj.put("msg", "Quest restore accept failed.");
                if (user != null) {
                    Kaiden_Extension.getInstance().send(qObj, user);
                }
            } catch (Exception ignored) {}
        }

        return false;
    }


    public static void putQuestTimerFields(User user, int questId, QuestBean quest, JSONObject qObj) {
        if (quest == null || qObj == null || !quest.isTimed()) {
            return;
        }

        int totalSeconds = quest.getTimeLimitTotalSeconds();
        int leftSeconds = totalSeconds;
        if (user != null) {
            leftSeconds = getTimedQuestSecondsLeft(user, questId, totalSeconds);
        }

        int minutes = leftSeconds / 60;
        int seconds = leftSeconds % 60;

        qObj.put("timeLimitMinutes", quest.getTimeLimitMinutes());
        qObj.put("timeLimitSeconds", quest.getTimeLimitSeconds());
        qObj.put("timeLimitTotalSeconds", totalSeconds);
        qObj.put("timeLeftMinutes", minutes);
        qObj.put("timeLeftSeconds", seconds);
        qObj.put("timeLeftTotalSeconds", leftSeconds);
        qObj.put("sTimeLeft", minutes + ":" + (seconds < 10 ? "0" + seconds : String.valueOf(seconds)));
        qObj.put("bTimed", 1);
    }

    public static int getTimedQuestSecondsLeft(User user, int questId, int fallbackSeconds) {
        if (user == null || user.properties == null || questId <= 0) {
            return Math.max(0, fallbackSeconds);
        }
        ensureSchema();
        QueryResult rs = null;
        try {
            rs = Storage.getInstance().getJdbc().query(
                    "SELECT GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), TimerEndsAt)) AS SecondsLeft FROM users_quests_active WHERE UserID=? AND QuestID=? AND TimerEndsAt IS NOT NULL LIMIT 1",
                    user.properties.get(Properties.ID),
                    questId
            );
            if (rs.next()) {
                return Math.max(0, rs.getInt("SecondsLeft"));
            }
        } catch (Exception ignored) {
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
        }
        return Math.max(0, fallbackSeconds);
    }

    public static boolean isTimedQuestExpired(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return false;
        }
        ensureSchema();
        try {
            int expired = Storage.getInstance().getJdbc().queryForInt(
                    "SELECT COUNT(*) FROM users_quests_active WHERE UserID=? AND QuestID=? AND TimerEndsAt IS NOT NULL AND TimerEndsAt <= NOW()",
                    user.properties.get(Properties.ID),
                    questId
            );
            return expired > 0;
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[TimedQuest] expire check failed QuestID=" + questId + ": " + e.getMessage());
            return false;
        }
    }

    public static void checkTimedQuests(User user) {
        if (user == null || user.properties == null) {
            return;
        }
        ensureSchema();

        // Expire the general active-quest TTL too, not only timed-quest TimerEndsAt.
        // Properties.QUESTS is used by drop filtering, so leaving an expired DB quest
        // in memory makes its quest drops continue indefinitely.
        QueryResult stale = null;
        Set<Integer> staleQuestIds = new HashSet<Integer>();
        try {
            stale = Storage.getInstance().getJdbc().query(
                    "SELECT QuestID FROM users_quests_active WHERE UserID=? AND ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()",
                    user.properties.get(Properties.ID)
            );
            while (stale.next()) staleQuestIds.add(stale.getInt("QuestID"));
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] active TTL check failed for " + user.getName() + ": " + e.getMessage());
        } finally {
            try { if (stale != null) stale.close(); } catch (Exception ignored) {}
        }
        for (Integer staleQuestId : staleQuestIds) {
            if (staleQuestId == null) continue;
            try {
                Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
                if (quests != null && quests.contains(staleQuestId)) {
                    removeQuest(user, staleQuestId);
                } else {
                    Storage.getInstance().getJdbc().run(
                            "DELETE FROM users_quests_active WHERE UserID=? AND QuestID=?",
                            user.properties.get(Properties.ID), staleQuestId);
                    cleanupQuestTempItems(user, staleQuestId);
                    cleanupQuestPendingDrops(user, staleQuestId);
                }
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "yellow", "[QuestProgress] expired stale active quest user=" + user.getName() + " QuestID=" + staleQuestId);
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] active TTL cleanup failed QuestID=" + staleQuestId + ": " + e.getMessage());
            }
        }

        // Expired pending drops must disappear from both DB and the live in-memory drop map.
        QueryResult expiredDrops = null;
        try {
            expiredDrops = Storage.getInstance().getJdbc().query(
                    "SELECT ItemID FROM users_quests_drops WHERE UserID=? AND Status='pending' AND ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()",
                    user.properties.get(Properties.ID)
            );
            ConcurrentHashMap<Integer, UserDrop> liveDrops =
                    (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");
            while (expiredDrops.next()) {
                int expiredItemId = expiredDrops.getInt("ItemID");
                if (liveDrops != null) liveDrops.remove(expiredItemId);
            }
            Storage.getInstance().getJdbc().run(
                    "DELETE FROM users_quests_drops WHERE UserID=? AND ExpiresAt IS NOT NULL AND ExpiresAt <= NOW()",
                    user.properties.get(Properties.ID));
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] pending drop TTL cleanup failed for " + user.getName() + ": " + e.getMessage());
        } finally {
            try { if (expiredDrops != null) expiredDrops.close(); } catch (Exception ignored) {}
        }

        QueryResult rs = null;
        try {
            rs = Storage.getInstance().getJdbc().query(
                    "SELECT QuestID FROM users_quests_active WHERE UserID=? AND TimerEndsAt IS NOT NULL AND TimerEndsAt <= NOW()",
                    user.properties.get(Properties.ID)
            );
            while (rs.next()) {
                expireTimedQuest(user, rs.getInt("QuestID"));
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[TimedQuest] check failed for " + user.getName() + ": " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
        }
    }

    public static void expireTimedQuest(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return;
        }
        removeQuest(user, questId);
        try {
            JSONObject qObj = new JSONObject();
            qObj.put("cmd", "questExpired");
            qObj.put("QuestID", questId);
            qObj.put("bSuccess", 1);
            qObj.put("msg", "Quest failed! Time has expired.");
            Kaiden_Extension.getInstance().send(qObj, user);
        } catch (Exception ignored) {}
        Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[TimedQuest] expired user=" + user.getName() + " QuestID=" + questId);
    }


    public static void scheduleTimedQuestExpiry(User user, int questId, int secondsLeft) {
        if (user == null || user.properties == null || questId <= 0 || secondsLeft <= 0) {
            return;
        }

        String key = TIMED_QUEST_TASK_PREFIX + questId;

        try {
            Object old = user.properties.get(key);
            if (old instanceof ScheduledFuture) {
                ScheduledFuture<?> future = (ScheduledFuture<?>) old;
                if (!future.isDone() && !future.isCancelled()) {
                    return;
                }
            }
        } catch (Exception ignored) {}

        try {
            ScheduledFuture<?> future = Executor.getInstance().scheduleTask(
                    new QuestTimedExpire(user, questId),
                    secondsLeft,
                    TimeUnit.SECONDS
            );
            user.properties.put(key, future);
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[TimedQuest] schedule failed QuestID=" + questId + ": " + e.getMessage());
        }
    }

    public static void cancelTimedQuestExpiry(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return;
        }

        String key = TIMED_QUEST_TASK_PREFIX + questId;
        try {
            Object old = user.properties.remove(key);
            if (old instanceof ScheduledFuture) {
                ((ScheduledFuture<?>) old).cancel(false);
            }
        } catch (Exception ignored) {}
    }

    public static void expireTimedQuestIfExpired(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return;
        }

        if (isTimedQuestExpired(user, questId)) {
            expireTimedQuest(user, questId);
            return;
        }

        QuestBean quest = StorageCache.getInstance().getQuest(questId);
        int fallback = quest == null ? 0 : quest.getTimeLimitTotalSeconds();
        int left = getTimedQuestSecondsLeft(user, questId, fallback);
        if (left > 0) {
            scheduleTimedQuestExpiry(user, questId, left);
        }
    }


    private static Room getCurrentRoom(User user) {
        try {
            if (user == null) return null;
            return Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
        } catch (Exception ignored) {
            return null;
        }
    }

    private static boolean isQuestRestorableInCurrentRoom(QuestBean questObj, Room room) {
        if (questObj == null) {
            return false;
        }
        if (questObj.locations == null || questObj.locations.isEmpty()) {
            return true;
        }
        if (room == null || room.getName() == null) {
            return false;
        }
        try {
            ZoneBean area = StorageCache.getInstance().getArea(room.getName().split("-")[0]);
            return area != null && questObj.locations.contains(area.getId());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static JSONObject buildGetQuestsPayload(Set<Integer> questIds) {
        return buildGetQuestsPayload(null, questIds);
    }

    public static JSONObject buildGetQuestsPayload(User user, Set<Integer> questIds) {
        JSONObject q = new JSONObject();
        JSONObject arrQuests = new JSONObject();
        if (questIds != null) {
            for (Integer questId : questIds) {
                if (questId == null) continue;
                QuestBean questObj = StorageCache.getInstance().getQuest(questId);
                if (questObj == null) continue;
                JSONObject questJson = QuestPacketHelper.buildQuestJson(user, questId.intValue(), true);
                if (questJson == null) continue;
                questJson.put("status", "p");
                questJson.put("strStatus", "p");
                questJson.put("bAccepted", 1);
                questJson.put("MapID", getQuestMapId(questObj));
                questJson.put("iMap", getQuestMapId(questObj));
                putQuestTimerFields(user, questId.intValue(), questObj, questJson);
                arrQuests.put(String.valueOf(questId.intValue()), questJson);
            }
        }
        q.put("cmd", "getQuests");
        q.put("quests", arrQuests);
        return q;
    }

    public static int getQuestMapId(QuestBean questObj) {
        if (questObj == null || questObj.locations == null || questObj.locations.isEmpty()) {
            return 0;
        }
        try {
            Object first = questObj.locations.iterator().next();
            if (first instanceof Integer) {
                return (Integer) first;
            }
            return Integer.parseInt(String.valueOf(first));
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static void acceptQuest(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return;
        }

        ensureSchema();

        Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
        // Persist first. Never advertise an active quest when the DB write failed.
        QuestBean quest = StorageCache.getInstance().getQuest(questId);
        int totalSeconds = quest == null ? 0 : quest.getTimeLimitTotalSeconds();

        try {
            if (totalSeconds > 0) {
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_quests_active (UserID, QuestID, AcceptedAt, UpdatedAt, ExpiresAt, TimerStartedAt, TimerEndsAt, TimeLimitSeconds) " +
                                "VALUES (?, ?, NOW(), NOW(), DATE_ADD(NOW(), INTERVAL 16 HOUR), NOW(), DATE_ADD(NOW(), INTERVAL ? SECOND), ?) " +
                                "ON DUPLICATE KEY UPDATE UpdatedAt=NOW(), ExpiresAt=DATE_ADD(NOW(), INTERVAL 16 HOUR), " +
                                "TimerStartedAt=IFNULL(TimerStartedAt, VALUES(TimerStartedAt)), " +
                                "TimerEndsAt=IFNULL(TimerEndsAt, VALUES(TimerEndsAt)), " +
                                "TimeLimitSeconds=VALUES(TimeLimitSeconds)",
                        user.properties.get(Properties.ID),
                        questId,
                        totalSeconds,
                        totalSeconds
                );
            } else {
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_quests_active (UserID, QuestID, AcceptedAt, UpdatedAt, ExpiresAt, TimerStartedAt, TimerEndsAt, TimeLimitSeconds) " +
                                "VALUES (?, ?, NOW(), NOW(), DATE_ADD(NOW(), INTERVAL 16 HOUR), NULL, NULL, 0) " +
                                "ON DUPLICATE KEY UPDATE UpdatedAt=NOW(), ExpiresAt=DATE_ADD(NOW(), INTERVAL 16 HOUR)",
                        user.properties.get(Properties.ID),
                        questId
                );
            }
            if (quests != null) {
                quests.add(questId);
            }
            if (totalSeconds > 0) {
                int secondsLeft = getTimedQuestSecondsLeft(user, questId, totalSeconds);
                scheduleTimedQuestExpiry(user, questId, secondsLeft);
            } else {
                cancelTimedQuestExpiry(user, questId);
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] accept save failed: " + e.getMessage());
        }
    }

    public static void removeQuest(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return;
        }

        String lockKey = "REMOVE_QUEST_LOCK_" + questId;

        /*
         * Hard once-only guard.
         *
         * removeQuest can be reached from abandon, turn-in cleanup, restore cleanup,
         * and sometimes repeated client/server sync packets. Without this guard the
         * same quest can spam DB deletes/logs even after it was already removed.
         */
        if (user.properties.get(lockKey) != null) {
            return;
        }

        user.properties.put(lockKey, true);

        try {
            Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);

            /*
             * If the quest is not active in memory anymore, it was already removed.
             * Stop here before touching DB or logging again.
             */
            if (quests == null || !quests.contains(questId)) {
                return;
            }

            /*
             * Remove from memory FIRST. This immediately blocks any repeated
             * removeQuest call from executing the DB cleanup again.
             */
            quests.remove(questId);
            cancelTimedQuestExpiry(user, questId);

            Storage.getInstance().getJdbc().run(
                    "DELETE FROM users_quests_active WHERE UserID=? AND QuestID=?",
                    user.properties.get(Properties.ID),
                    questId
            );

            // Prevent an already prepared login snapshot from replaying this quest.
            Object restoredQuests = user.properties.get(RESTORED_QUESTS);
            if (restoredQuests instanceof Set) {
                ((Set<?>) restoredQuests).remove(Integer.valueOf(questId));
            }
            cleanupQuestTempItems(user, questId);
            cleanupQuestPendingDrops(user, questId);
            pruneItems(user);
            QueryResult remaining = null;
            try {
                remaining = Storage.getInstance().getJdbc().query(
                        "SELECT QuestID FROM users_quests_active WHERE UserID=? AND QuestID=? LIMIT 1",
                        user.properties.get(Properties.ID), questId);
                if (remaining.next()) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage("red",
                            "[QuestProgress] ABANDON DB DELETE NOT EFFECTIVE user="
                                    + user.getName() + " QuestID=" + questId);
                }
            } finally {
                try { if (remaining != null) remaining.close(); } catch (Exception ignored) {}
            }

            Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[QuestProgress] removed active quest once user=" + user.getName() + " QuestID=" + questId);
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] remove quest failed: " + e.getMessage());
        } finally {
            user.properties.remove(lockKey);
        }
    }

    /** Refresh only this player's active quest IDs from persistent state.
     * Never accepts quests, writes active rows, or reloads shared definitions.
     * Returns false on database errors; callers must not authorize quest drops then.
     */
    public static boolean reloadActiveQuests(User user) {
        if (user == null || user.properties == null) return false;
        Set<Integer> fresh = new HashSet<Integer>();
        QueryResult rows = null;
        try {
            rows = Storage.getInstance().getJdbc().query(
                    "SELECT QuestID FROM users_quests_active WHERE UserID=? " +
                    "AND (ExpiresAt IS NULL OR ExpiresAt > NOW()) " +
                    "AND (TimerEndsAt IS NULL OR TimerEndsAt > NOW())",
                    user.properties.get(Properties.ID));
            while (rows.next()) {
                int id = rows.getInt("QuestID");
                if (StorageCache.getInstance().getQuest(id) != null) fresh.add(id);
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red",
                    "[QuestProgress] reloadActiveQuests failed user=" + user.getName() + " err=" + e.getMessage());
            return false;
        } finally {
            try { if (rows != null) rows.close(); } catch (Exception ignored) {}
        }
        Set<Integer> active = (Set<Integer>) user.properties.get(Properties.QUESTS);
        if (active == null) {
            active = new HashSet<Integer>();
            user.properties.put(Properties.QUESTS, active);
        }
        active.clear();
        active.addAll(fresh);
        Object snapshot = user.properties.get(RESTORED_QUESTS);
        if (snapshot instanceof Set) {
            ((Set<Integer>) snapshot).retainAll(fresh);
        }
        Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                "[QuestProgress] refreshed active DB quests user=" + user.getName() + " ids=" + fresh);
        return true;
    }

    public static boolean abandonQuest(User user, int questId) {
        if (user == null || user.properties == null || questId <= 0) {
            return false;
        }

        String lockKey = "ABANDON_QUEST_LOCK_" + questId;
        if (user.properties.get(lockKey) != null) {
            return false;
        }

        user.properties.put(lockKey, true);

        try {
            /*
             * Abandon must be authoritative.  The DB row can still exist even when
             * the in-memory QUESTS set is missing/out-of-sync (for example after a
             * restore/map transition).  Never gate the DELETE on the memory set.
             */
            Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
            if (quests != null) {
                quests.remove(questId);
            }

            cancelTimedQuestExpiry(user, questId);

            // Abandon is authoritative and must delete the persistent row even
            // when the in-memory active-quest set was already stale. Use the
            // account/database UserID stored in Properties.ID (not the SFS id).
            Storage.getInstance().getJdbc().run(
                    "DELETE FROM users_quests_active WHERE UserID = ? AND QuestID = ?",
                    user.properties.get(Properties.ID),
                    questId
            );

            // Prevent an already prepared login snapshot from replaying this quest.
            Object restoredQuests = user.properties.get(RESTORED_QUESTS);
            if (restoredQuests instanceof Set) {
                ((Set<?>) restoredQuests).remove(Integer.valueOf(questId));
            }
            cleanupQuestTempItems(user, questId);
            cleanupQuestPendingDrops(user, questId);
            pruneItems(user);
            QueryResult remaining = null;
            try {
                remaining = Storage.getInstance().getJdbc().query(
                        "SELECT QuestID FROM users_quests_active WHERE UserID=? AND QuestID=? LIMIT 1",
                        user.properties.get(Properties.ID), questId);
                if (remaining.next()) {
                    throw new IllegalStateException(
                            "ABANDON DB DELETE NOT EFFECTIVE user="
                                    + user.getName() + " QuestID=" + questId);
                }
            } finally {
                try { if (remaining != null) remaining.close(); } catch (Exception ignored) {}
            }

            if (!reloadActiveQuests(user)) return false;
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[QuestProgress] abandoned quest + deleted active DB row user="
                            + user.getName() + " QuestID=" + questId
            );
            return true;
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[QuestProgress] abandon quest failed: " + e.getMessage()
            );
            return false;
        } finally {
            user.properties.remove(lockKey);
        }
    }

    public static void saveTempItem(User user, int itemId) {
        if (user == null || user.properties == null || itemId <= 0) {
            return;
        }

        ConcurrentHashMap<Integer, Integer> tempItems = (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);
        if (tempItems == null) {
            return;
        }

        Integer quantity = tempItems.get(itemId);
        saveTempQuantity(user, itemId, quantity == null ? 0 : quantity);
    }

    public static void saveAll(User user) {
        if (user == null || user.properties == null) {
            return;
        }
        ensureSchema();

        // The DB is authoritative for accepted quests. UpdateQuest/saveAll is a
        // synchronization request, NEVER a quest acceptance operation. Previously
        // acceptQuest() here could recreate an abandoned quest during logout.
        Set<Integer> quests = (Set<Integer>) user.properties.get(Properties.QUESTS);
        if (quests != null) {
            Set<Integer> persisted = new HashSet<Integer>();
            QueryResult activeRows = null;
            try {
                activeRows = Storage.getInstance().getJdbc().query(
                        "SELECT QuestID FROM users_quests_active WHERE UserID=? " +
                        "AND (ExpiresAt IS NULL OR ExpiresAt > NOW()) " +
                        "AND (TimerEndsAt IS NULL OR TimerEndsAt > NOW())",
                        user.properties.get(Properties.ID));
                while (activeRows.next()) persisted.add(activeRows.getInt("QuestID"));
                quests.retainAll(persisted);
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red",
                        "[QuestProgress] saveAll quest reconciliation failed user="
                                + user.getName() + " err=" + e.getMessage());
                return;
            } finally {
                try { if (activeRows != null) activeRows.close(); } catch (Exception ignored) {}
            }
        }

        ConcurrentHashMap<Integer, Integer> tempItems = (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);
        if (tempItems != null) {
            for (Map.Entry<Integer, Integer> entry : tempItems.entrySet()) {
                ItemBean item = StorageCache.getInstance().getItem(entry.getKey());
                if (item != null && (item.isTemporary() || getFirstActiveQuestForItem(user, item) > 0)) {
                    saveTempQuantity(user, entry.getKey(), entry.getValue() == null ? 0 : entry.getValue());
                }
            }
        }

        ConcurrentHashMap<Integer, UserDrop> drops = (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");
        if (drops != null) {
            for (UserDrop drop : drops.values()) {
                ItemBean item = StorageCache.getInstance().getItem(drop.getItemId());
                // Only quest-owned temporary drops require an active quest.
                // Standalone temporary items may be earned without accepting a quest.
                savePendingDrop(user, drop);
            }
        }
    }

    public static void savePendingDrop(User user, UserDrop drop) {
        if (user == null || user.properties == null || drop == null || drop.getItemId() <= 0) {
            return;
        }

        // Restored pending drops are already in users_quests_drops as pending.
        // When we re-send them to the client after login/map join, do not write
        // them again or update quantity, otherwise every relog/map refresh can multiply them.
        if (isRestoreReplayingDrops(user)) {
            return;
        }

        ItemBean item = StorageCache.getInstance().getItem(drop.getItemId());
        if (item == null) {
            return;
        }

        int questId = getFirstActiveQuestForItem(user, item);

        try {
            Storage.getInstance().getJdbc().run(
                    "INSERT INTO users_quests_drops (UserID, ItemID, QuestID, Quantity, IsTemp, Bank, Status, CreatedAt, UpdatedAt, ExpiresAt) " +
                            "VALUES (?, ?, ?, ?, 0, ?, 'pending', NOW(), NOW(), DATE_ADD(NOW(), INTERVAL 16 HOUR)) " +
                            "ON DUPLICATE KEY UPDATE QuestID=?, Quantity=?, IsTemp=0, Bank=?, Status='pending', UpdatedAt=NOW(), ExpiresAt=DATE_ADD(NOW(), INTERVAL 16 HOUR)",
                    user.properties.get(Properties.ID),
                    drop.getItemId(),
                    questId,
                    drop.getQuantity(),
                    drop.isBank() ? 1 : 0,
                    questId,
                    drop.getQuantity(),
                    drop.isBank() ? 1 : 0
            );
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] pending drop save failed item=" + drop.getItemId() + ": " + e.getMessage());
        }
    }

    /** True only while the persisted pending drop still exists and has not expired. */
    /** Validate a Quest Item at pickup time against freshly loaded accepted quests. */
    public static boolean isQuestDropPickupAllowed(User user, int itemId) {
        if (user == null || user.properties == null || itemId <= 0) return false;
        if (!reloadActiveQuests(user)) return false;
        ItemBean item = StorageCache.getInstance().getItem(itemId);
        return item != null && getFirstActiveQuestForItem(user, item) > 0;
    }

    public static boolean isPendingDropValid(User user, int itemId) {
        if (user == null || user.properties == null || itemId <= 0) return false;
        ensureSchema();
        QueryResult rs = null;
        try {
            rs = Storage.getInstance().getJdbc().query(
                    "SELECT d.ItemID FROM users_quests_drops d " +
                            "LEFT JOIN users_quests_active a ON a.UserID=d.UserID AND a.QuestID=d.QuestID " +
                            "WHERE d.UserID=? AND d.ItemID=? AND d.Status='pending' " +
                            "AND (d.ExpiresAt IS NULL OR d.ExpiresAt > NOW()) " +
                            "AND (d.QuestID IS NULL OR d.QuestID=0 OR " +
                            "(a.QuestID IS NOT NULL AND (a.ExpiresAt IS NULL OR a.ExpiresAt > NOW()) " +
                            "AND (a.TimerEndsAt IS NULL OR a.TimerEndsAt > NOW()))) LIMIT 1",
                    user.properties.get(Properties.ID), itemId);
            return rs.next();
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] pending drop validity check failed item=" + itemId + ": " + e.getMessage());
            return false;
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
        }
    }

    public static void markDropAccepted(User user, int itemId) {
        removePendingDrop(user, itemId, "accepted");
    }

    public static void markDropDeclined(User user, int itemId) {
        removePendingDrop(user, itemId, "declined");
    }

    private static void removePendingDrop(User user, int itemId, String status) {
        if (user == null || user.properties == null || itemId <= 0) {
            return;
        }
        ensureSchema();
        Object restored = user.properties.get(RESTORED_PENDING_DROPS);
        if (restored instanceof Map) {
            ((Map<?, ?>) restored).remove(Integer.valueOf(itemId));
        }
        try {
            // Accepted/declined drops must leave the pending restore list completely.
            // Keeping old rows around caused restored drops to reappear after relog/map join.
            Storage.getInstance().getJdbc().run(
                    "DELETE FROM users_quests_drops WHERE UserID=? AND ItemID=? AND Status='pending'",
                    user.properties.get(Properties.ID),
                    itemId
            );
            if (isPendingDropValid(user, itemId)) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("red",
                        "[QuestProgress] DROP DELETE NOT EFFECTIVE user=" + user.getName() + " ItemID=" + itemId);
            } else {
                Kaiden_Engine.getInstance().sendEmulatorMessage("green",
                        "[QuestProgress] pending drop removed status=" + status + " user=" + user.getName() + " ItemID=" + itemId);
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] pending drop " + status + " delete failed item=" + itemId + ": " + e.getMessage());
        }
    }

    private static void saveTempQuantity(User user, int itemId, int quantity) {
        ensureSchema();
        try {
            if (quantity <= 0) {
                Storage.getInstance().getJdbc().run(
                        "DELETE FROM users_quests_items WHERE UserID=? AND ItemID=?",
                        user.properties.get(Properties.ID),
                        itemId
                );
                return;
            }

            Storage.getInstance().getJdbc().run(
                    "INSERT INTO users_quests_items (UserID, ItemID, Quantity, UpdatedAt, ExpiresAt) " +
                            "VALUES (?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 16 HOUR)) " +
                            "ON DUPLICATE KEY UPDATE Quantity=?, UpdatedAt=NOW(), ExpiresAt=DATE_ADD(NOW(), INTERVAL 16 HOUR)",
                    user.properties.get(Properties.ID),
                    itemId,
                    quantity,
                    quantity
            );
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[QuestProgress] item save failed item=" + itemId + ": " + e.getMessage());
        }
    }

    private static boolean isQuestItemActive(Set<Integer> activeQuestIds, ItemBean itemObj) {
        if (activeQuestIds == null || activeQuestIds.isEmpty() || itemObj == null) {
            return false;
        }

        // Quest requirements are authoritative even when legacy item ReqQuests is empty.
        for (Integer questId : activeQuestIds) {
            if (questId == null) continue;
            QuestBean quest = StorageCache.getInstance().getQuest(questId);
            if (quest != null && quest.requirements != null && quest.requirements.containsKey(itemObj.getId())) {
                return true;
            }
        }

        String reqQuests = itemObj.getReqQuests();
        if (reqQuests == null || reqQuests.trim().isEmpty()) {
            return false;
        }

        try {
            if (reqQuests.contains(",")) {
                String[] questIds = reqQuests.split(",");
                for (String questId : questIds) {
                    if (questId == null || questId.trim().isEmpty()) {
                        continue;
                    }
                    if (activeQuestIds.contains(Integer.valueOf(questId.trim()))) {
                        return true;
                    }
                }
            } else {
                return activeQuestIds.contains(Integer.valueOf(reqQuests.trim()));
            }
        } catch (Exception ignored) {}

        return false;
    }

    private static int getFirstActiveQuestForItem(User user, ItemBean itemObj) {
        if (user == null || user.properties == null || itemObj == null) return 0;
        Set<Integer> activeQuestIds = (Set<Integer>) user.properties.get(Properties.QUESTS);
        if (activeQuestIds == null || activeQuestIds.isEmpty()) return 0;

        // Quest requirements are authoritative. This fixes legacy items whose
        // ReqQuests/Temporary columns do not match the quest definition.
        for (Integer questId : activeQuestIds) {
            if (questId == null) continue;
            QuestBean quest = StorageCache.getInstance().getQuest(questId);
            if (quest != null && quest.requirements != null && quest.requirements.containsKey(itemObj.getId())) {
                return questId;
            }
        }

        // Compatibility fallback for non-turn-in quest drops that only use ReqQuests.
        String reqQuests = itemObj.getReqQuests();
        if (reqQuests == null || reqQuests.trim().isEmpty()) return 0;
        try {
            for (String part : reqQuests.split(",")) {
                if (part == null || part.trim().isEmpty()) continue;
                int questId = Integer.parseInt(part.trim());
                if (activeQuestIds.contains(questId)) return questId;
            }
        } catch (Exception ignored) {}
        return 0;
    }

    private static boolean itemBelongsToQuest(ItemBean itemObj, int questId) {
        if (itemObj == null || questId <= 0) return false;

        QuestBean quest = StorageCache.getInstance().getQuest(questId);
        if (quest != null && quest.requirements != null && quest.requirements.containsKey(itemObj.getId())) {
            return true;
        }

        String reqQuests = itemObj.getReqQuests();
        if (reqQuests == null || reqQuests.trim().isEmpty()) return false;
        try {
            for (String part : reqQuests.split(",")) {
                if (part != null && !part.trim().isEmpty() && Integer.parseInt(part.trim()) == questId) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static void cleanupQuestTempItems(User user, int questId) {
        QuestBean quest = StorageCache.getInstance().getQuest(questId);
        Set<Integer> requirementIds = new HashSet<Integer>();
        if (quest != null && quest.requirements != null) requirementIds.addAll(quest.requirements.keySet());

        /*
         * AQW quest-chain rule:
         * Completing/abandoning one quest must NOT destroy a temporary item that is
         * still required by another active quest.  A common chain is:
         *   quest A rewards Item X -> quest B (already active) requires Item X.
         *
         * Legacy ReqQuests can list both A and B.  The old cleanup treated that list
         * as ownership and deleted X as soon as A completed, immediately after the
         * reward had been persisted.  The client therefore showed 1/1 while the
         * authoritative TEMP_ITEMS/users_quests_items state was back to zero.
         */
        Set<Integer> activeQuestIds = (Set<Integer>) user.properties.get(Properties.QUESTS);
        Set<Integer> preserve = new HashSet<Integer>();
        if (activeQuestIds != null) {
            for (Integer activeId : activeQuestIds) {
                if (activeId == null || activeId == questId) continue;
                QuestBean activeQuest = StorageCache.getInstance().getQuest(activeId);
                if (activeQuest != null && activeQuest.requirements != null) {
                    preserve.addAll(activeQuest.requirements.keySet());
                }
            }
        }

        ConcurrentHashMap<Integer, Integer> tempItems =
                (ConcurrentHashMap<Integer, Integer>) user.properties.get(Properties.TEMP_ITEMS);

        Set<Integer> candidates = new HashSet<Integer>();
        candidates.addAll(requirementIds);
        if (tempItems != null) {
            for (Integer itemId : tempItems.keySet()) {
                ItemBean itemObj = StorageCache.getInstance().getItem(itemId);
                if (requirementIds.contains(itemId) || itemBelongsToQuest(itemObj, questId)) {
                    candidates.add(itemId);
                }
            }
        }

        for (Integer itemId : candidates) {
            if (itemId == null || preserve.contains(itemId)) {
                if (itemId != null && preserve.contains(itemId)) {
                    // Re-save so DB and memory stay authoritative for the next quest.
                    saveTempItem(user, itemId);
                    Kaiden_Engine.getInstance().sendEmulatorMessage(
                            "green", "[QuestProgress] preserved chained quest item user=" +
                                    user.getName() + " ItemID=" + itemId + " after QuestID=" + questId);
                }
                continue;
            }

            if (tempItems != null) tempItems.remove(itemId);
            // Do not re-save an abandoned quest item during logout.
            // Also remove any pending drop for this item from the live session.
            ConcurrentHashMap<Integer, UserDrop> liveDrops =
                    (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");
            if (liveDrops != null) liveDrops.remove(itemId);
            try {
                Storage.getInstance().getJdbc().run(
                        "DELETE FROM users_quests_items WHERE UserID=? AND ItemID=?",
                        user.properties.get(Properties.ID), itemId);
            } catch (Exception e) {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "red", "[QuestProgress] quest temp cleanup failed QuestID=" + questId +
                                " ItemID=" + itemId + ": " + e.getMessage());
            }
        }
    }

    private static void cleanupQuestPendingDrops(User user, int questId) {
        try {
            Storage.getInstance().getJdbc().run(
                    "DELETE FROM users_quests_drops WHERE UserID=? AND QuestID=?",
                    user.properties.get(Properties.ID),
                    questId
            );
        } catch (Exception ignored) {}
    }

    private static void pruneItems(User user) {
        try {
            Storage.getInstance().getJdbc().run(
                    "DELETE qi FROM users_quests_items qi " +
                            "LEFT JOIN users_quests_active qa ON qa.UserID=qi.UserID AND qa.ExpiresAt >= NOW() " +
                            "WHERE qi.UserID=? AND qa.UserID IS NULL",
                    user.properties.get(Properties.ID)
            );
        } catch (Exception ignored) {}
    }
}
