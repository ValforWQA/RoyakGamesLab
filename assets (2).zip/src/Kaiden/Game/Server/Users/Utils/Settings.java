package Kaiden.Game.Server.Users.Utils;

//import Kaiden.Game.Server.Users.Utils.Achievement;
import it.gotoandplay.smartfoxserver.data.User;

public class Settings {

    public static final String ANIMATION = "bWAnim";
    public static final String CLOAK = "bCloak";
    public static final String DUEL = "bDuel";
    public static final String FBSHARE = "bFBShare";
    public static final String FRIEND = "bFriend";
    public static final String GOTO = "bGoto";
    public static final String TRADE = "bTrade";
    public static final String GUILD = "bGuild";
    public static final String HELM = "bHelm";
    public static final String MUSIC = "bMusicOn";
    public static final String PARTY = "bParty";
    public static final String PET = "bPet";
    public static final String SOUND = "bSoundOn";
    public static final String TOOLTIPS = "bTT";
    public static final String WHISPER = "bWhisper";
    public static final String TRADE_MESSAGE_OFF = "Ignoring trade invites.";
    public static final String TRADE_NESSAGE_ON = "Accepting trade invites.";
    public static final String DUEL_MESSAGE_OFF = "Ignoring duel invites.";
    public static final String DUEL_MESSAGE_ON = "Accepting duel invites.";
    public static final String FRIEND_MESSAGE_OFF = "Ignoring Friend requests.";
    public static final String FRIEND_MESSAGE_ON = "Accepting Friend requests.";
    public static final String GOTO_MESSAGE_OFF = "Blocking goto requests.";
    public static final String GOTO_MESSAGE_ON = "Accepting goto requests.";
    public static final String GUILD_MESSAGE_OFF = "Ignoring guild invites.";
    public static final String GUILD_MESSAGE_ON = "Accepting guild invites.";
    public static final String PARTY_MESSAGE_OFF = "Ignoring party invites.";
    public static final String PARTY_MESSAGE_ON = "Accepting party invites.";
    public static final String TOOLTIPS_MESSAGE_OFF = "Ability ToolTips will not show on mouseover during combat.";
    public static final String TOOLTIPS_MESSAGE_ON = "Ability ToolTips will always show on mouseover.";
    public static final String WHISPER_MESSAGE_OFF = "Ignoring PMs.";
    public static final String WHISPER_MESSAGE_ON = "Accepting PMs.";

    public static boolean isAllowed(String pref, User user, User client) {
        return getPreferences(pref, client.properties.get("settings")) || user.isAdmin() || user.isModerator();
    }

    public static boolean getPreferences(String pref, Object setting) {
        return getPreferences(pref, Integer.parseInt(setting.toString()));
    }

    public static boolean getPreferences(String pref, int setting) {
        switch (pref) {
            case Settings.CLOAK:
                return Achievement.get(setting, 0) == 0;
            case Settings.HELM:
                return Achievement.get(setting, 1) == 0;
            case Settings.PET:
                return Achievement.get(setting, 2) == 0;
            case Settings.ANIMATION:
                return Achievement.get(setting, 3) == 0;
            case Settings.GOTO:
                return Achievement.get(setting, 4) == 0;
            case Settings.SOUND:
                return Achievement.get(setting, 5) == 0;
            case Settings.MUSIC:
                return Achievement.get(setting, 6) == 0;
            case Settings.FRIEND:
                return Achievement.get(setting, 7) == 0;
            case Settings.PARTY:
                return Achievement.get(setting, 8) == 0;
            case Settings.GUILD:
                return Achievement.get(setting, 9) == 0;
            case Settings.WHISPER:
                return Achievement.get(setting, 10) == 0;
            case Settings.TOOLTIPS:
                return Achievement.get(setting, 11) == 0;
            case Settings.FBSHARE:
                return Achievement.get(setting, 12) == 0;
            case Settings.DUEL:
                return Achievement.get(setting, 13) == 0;
            case Settings.TRADE:
                return Achievement.get(setting, 19) == 0;
        }
        return false;
    }

    public static int setPreferences(String pref, int intValue, boolean value) {
        int setting = value ? 0 : 1;
        switch (pref) {
            case Settings.CLOAK:
                return Achievement.update(intValue, 0, setting);
            case Settings.HELM:
                return Achievement.update(intValue, 1, setting);
            case Settings.PET:
                return Achievement.update(intValue, 2, setting);
            case Settings.ANIMATION:
                return Achievement.update(intValue, 3, setting);
            case Settings.GOTO:
                return Achievement.update(intValue, 4, setting);
            case Settings.SOUND:
                return Achievement.update(intValue, 5, setting);
            case Settings.MUSIC:
                return Achievement.update(intValue, 6, setting);
            case Settings.FRIEND:
                return Achievement.update(intValue, 7, setting);
            case Settings.PARTY:
                return Achievement.update(intValue, 8, setting);
            case Settings.GUILD:
                return Achievement.update(intValue, 9, setting);
            case Settings.WHISPER:
                return Achievement.update(intValue, 10, setting);
            case Settings.TOOLTIPS:
                return Achievement.update(intValue, 11, setting);
            case Settings.FBSHARE:
                return Achievement.update(intValue, 12, setting);
            case Settings.DUEL:
                return Achievement.update(intValue, 13, setting);
            case Settings.TRADE:
                return Achievement.update(intValue, 19, setting);
        }
        return 0;
    }
}