package Kaiden.Game.Server.Users.Utils;

public class ClassRank {
    private static final int[] arrRanks = new int[10]; // Rank 10 is max

    static {
        for (int i = 1; i < arrRanks.length; i++) {
            int rankExperience = (int) (Math.pow(i + 1, 3.0D) * 100.0D);
            if (i > 1) {
                arrRanks[i] = rankExperience + arrRanks[i - 1];
            } else {
                arrRanks[i] = rankExperience + 100;
            }
        }
    }


    public static int getRankFromPoints(int classPoints) {
        for (int i = 1; i < arrRanks.length; i++) {
            if (classPoints < arrRanks[i]) {
                return i;
            }
        }
        // Otherwise, return 10 for Rank 10.
        return 10;
    }
    private ClassRank() {
        throw new UnsupportedOperationException("Not allowed to have an instance of a static class");
    }
}
