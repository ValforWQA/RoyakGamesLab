package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.AsyncDbExecutor;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Event-driven server count updater.
 *
 * DeadConnection COUNT(*) polling is intentionally not used. Login/logout updates an
 * in-memory counter immediately and one async DB sync writes the latest count. If a
 * sync is already running while another login/logout happens, the manager marks the
 * count dirty and runs one more sync afterward instead of dropping the update.
 */
public final class ServerCountManager {

    private static final String SERVER_COUNTED_KEY = "serverCounted";
    private static final AtomicInteger ONLINE_COUNT = new AtomicInteger(0);
    private static final AtomicBoolean SYNC_RUNNING = new AtomicBoolean(false);
    private static final AtomicBoolean DIRTY = new AtomicBoolean(false);

    private ServerCountManager() {}

    private static boolean isPlayableWorld() {
        return Boolean.getBoolean("kaiden.manager.child") || !Configuration.ALLOW_INTERFACE;
    }

    public static void login(User user) {
        if (!isPlayableWorld()) return;
        if (user == null || user.properties == null) {
            return;
        }

        if (Boolean.TRUE.equals(user.properties.get(SERVER_COUNTED_KEY))) {
            updateUserServerAsync(user, Configuration.SERVER_NAME);
            requestSync("login-already-counted", user);
            return;
        }

        user.properties.put(SERVER_COUNTED_KEY, true);
        user.properties.put(Properties.CURRENT_SERVER, Configuration.SERVER_NAME);
        ONLINE_COUNT.incrementAndGet();

        updateUserServerAsync(user, Configuration.SERVER_NAME);
        requestSync("login", user);
    }

    public static void logout(User user) {
        if (!isPlayableWorld()) return;
        if (user == null || user.properties == null) {
            return;
        }

        if (!Boolean.TRUE.equals(user.properties.get(SERVER_COUNTED_KEY))) {
            user.properties.put(Properties.CURRENT_SERVER, "Offline");
            updateUserServerAsync(user, "Offline");
            requestSync("logout-not-counted", user);
            return;
        }

        user.properties.remove(SERVER_COUNTED_KEY);
        user.properties.put(Properties.CURRENT_SERVER, "Offline");
        ONLINE_COUNT.updateAndGet(v -> Math.max(0, v - 1));

        updateUserServerAsync(user, "Offline");
        requestSync("logout", user);
    }

    public static int getOnlineCount() {
        return ONLINE_COUNT.get();
    }

    /** Kept for older callers. This no longer performs COUNT(*) polling. */
    public static void recalc(String reason, User user) {
        if (!isPlayableWorld()) return;
        requestSync(reason == null ? "recalc" : reason, user);
    }

    public static void resetOnBoot() {
        if (!isPlayableWorld()) return;
        ONLINE_COUNT.set(0);
        DIRTY.set(true);
        AsyncDbExecutor.submit("server-count-boot-reset", new Runnable() {
            @Override
            public void run() {
                try {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE servers SET Count=0 WHERE Name=?",
                            Configuration.SERVER_NAME
                    );
                    Kaiden_Engine.getInstance().sendEmulatorMessage("cyan", "[ServerCount] reset count to 0 on boot");
                } catch (Throwable t) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[ServerCount] boot reset failed: " + t.getMessage());
                }
            }
        });
    }

    private static void requestSync(final String reason, final User user) {
        DIRTY.set(true);
        if (!SYNC_RUNNING.compareAndSet(false, true)) {
            return;
        }

        AsyncDbExecutor.submit("server-count-sync", new Runnable() {
            @Override
            public void run() {
                try {
                    do {
                        DIRTY.set(false);
                        syncLatestCount(reason, user);
                    } while (DIRTY.get());
                } finally {
                    SYNC_RUNNING.set(false);
                    if (DIRTY.get()) {
                        requestSync("dirty-resync", user);
                    }
                }
            }
        });
    }

    private static void syncLatestCount(String reason, User user) {
        try {
            int botCount = 0;
            try {
                botCount = BotManager.getInstance().getActiveBotCountForServer(Configuration.SERVER_NAME);
            } catch (Throwable ignored) {}

            int finalCount = Math.max(0, ONLINE_COUNT.get() + botCount);
            Storage.getInstance().getJdbc().run(
                    "UPDATE servers SET Count=?, DailyPlayers=GREATEST(DailyPlayers, ?) WHERE Name=?",
                    finalCount,
                    finalCount,
                    Configuration.SERVER_NAME
            );

            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "cyan",
                    "[ServerCount] " + reason + " user=" + (user == null ? "unknown" : user.getName()) + " count=" + finalCount
            );
        } catch (Throwable t) {
            // Do not break login/logout if DB is under pressure. The next event will retry.
            DIRTY.set(true);
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "[ServerCount] sync skipped: " + t.getMessage());
        }
    }

    private static void updateUserServerAsync(final User user, final String serverName) {
        if (user == null || user.properties == null || user.properties.get(Properties.ID) == null) {
            return;
        }

        final Object userId = user.properties.get(Properties.ID);
        AsyncDbExecutor.submit("user-current-server", new Runnable() {
            @Override
            public void run() {
                Storage.getInstance().getJdbc().run(
                        "UPDATE users SET CurrentServer=? WHERE id=?",
                        serverName,
                        userId
                );
            }
        });
    }
}
