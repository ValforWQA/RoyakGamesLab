package Kaiden.Game.Server.Users.Utils;

import it.gotoandplay.smartfoxserver.SmartFoxServer;

import java.text.DecimalFormat;

public class ServerUtils {
    public static String getUptime() {
        StringBuilder result = new StringBuilder();
        long now = System.currentTimeMillis();
        long start = SmartFoxServer.getInstance().getServerStartTime();
        long elapsed = now - start;
        int days = (int) Math.floor(elapsed / 86400000L);
        long temp = 86400000L * days;
        elapsed -= temp;
        int hours = (int) Math.floor(elapsed / 3600000L);
        temp = 3600000L * hours;
        elapsed -= temp;
        int minutes = (int) Math.floor(elapsed / 60000L);
        String s_days = String.valueOf(days);
        for (int i = 0; i < 4 - s_days.length(); i++) {
            result.append("0");
        }
        result.append(s_days);
        result.append(":");
        if (hours < 10) {
            result.append("0");
        }
        result.append(hours);
        result.append(":");
        if (minutes < 10) {
            result.append("0");
        }
        result.append(minutes);
        return result.toString();
    }

    public static String formatSize(long size) {
        double k = size / 1024.0;
        double m = ((size / 1024.0) / 1024.0);
        double g = (((size / 1024.0) / 1024.0) / 1024.0);
        double t = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);
        DecimalFormat dec = new DecimalFormat("0.00");
        if (t > 1) {
            return dec.format(t).concat(" TB");
        } else if (g > 1) {
            return dec.format(g).concat(" GB");
        } else if (m > 1) {
            return dec.format(m).concat(" MB");
        } else if (k > 1) {
            return dec.format(k).concat(" KB");
        }
        return dec.format((double) size).concat(" B");
    }
}
