package Kaiden.Game.Server.Users.Utils;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class SpanUtils {

    public static int millisToDays(long millis) {
        return (int) TimeUnit.MILLISECONDS.toDays(millis);
    }

    public static int millisToHours(long millis) {
        return (int) TimeUnit.MILLISECONDS.toHours(millis);
    }

    public static int millisToSeconds(long millis) {
        return (int) TimeUnit.MILLISECONDS.toSeconds(millis);
    }

    public static String getTimeRemainBanBySeconds(int seconds) {
        int day = (int) TimeUnit.SECONDS.toDays(seconds);
        long hours = TimeUnit.SECONDS.toHours(seconds) - (day * 24L);
        long minute = TimeUnit.SECONDS.toMinutes(seconds) - (TimeUnit.SECONDS.toHours(seconds) * 60);
        long second = TimeUnit.SECONDS.toSeconds(seconds) - (TimeUnit.SECONDS.toMinutes(seconds) * 60);
        return day + " Day(s), " + hours + " Hour(s), " + minute + " Minute(s), " + second + " Second(s)";
    }

    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }

    public static int roundTens(int value) {
        for (int i = 0; i < 9 && value % 10 != 0; ++i) {
            ++value;
        }
        return value;
    }

    public static Date getDateByHours(int hours) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.HOUR_OF_DAY, hours);
        return cal.getTime();
    }
}
