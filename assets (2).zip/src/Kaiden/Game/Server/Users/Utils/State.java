package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.log4j.Logger;

public abstract class State {

    private static final Logger LOGGER = Logger.getLogger(State.class);

    // -----------------------------
    // Core stats/state
    // -----------------------------
    private int maxHealth;
    private int maxMana;
    private int dash;
    private int maxDash;
    private volatile int health;
    private volatile int mana;

    // 0=Dead, 1=Neutral, 2=Combat
    private volatile int state;

    // -----------------------------
    // Combat targets
    // -----------------------------
    private final Set<Integer> monsterTargets = java.util.Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());
    private final Set<String> playerTargets = java.util.Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private volatile int currentShield = 0;

    // -----------------------------
    // Auras (tracked)
    // -----------------------------
    //public static final int AURA_STACK_LIMIT = 4;
    private final Set<RemoveAura> auras = java.util.Collections.newSetFromMap(new ConcurrentHashMap<RemoveAura, Boolean>());



    public State(int maxHealth, int maxMana, int dash) {
        this.health = maxHealth;
        this.mana = maxMana;
        this.dash = dash;
        this.maxDash = dash;
        this.maxHealth = maxHealth;
        this.maxMana = maxMana;
        this.state = 1;
    }

    public int getHealth() {
        return this.health;
    }

    public void setHealth(int health) {
        if (health <= 0) {
            this.die();
        } else if (health > this.maxHealth) {
            this.health = this.maxHealth;
        } else {
            this.health = health;
        }
    }

    public boolean isNeutral() {
        return this.state == 1;
    }

    public boolean isDead() {
        return this.state == 0;
    }

    public boolean onCombat() {
        return this.state == 2;
    }

    public int getDash() { return this.dash; }
    public int getMana() {
        return this.mana;
    }
    public int getMaxDash() { return this.maxDash; }

    public void setDash(int dash) {
        if (dash < 0) {
            this.dash = 0;
        } else if (dash > this.maxDash) {
            this.dash = this.maxDash;
        } else {
            this.dash = dash;
        }
    }

    public void setMana(int mana) {
        if (mana < 0) {
            this.mana = 0;
        } else if (mana > this.maxMana) {
            this.mana = this.maxMana;
        } else {
            this.mana = mana;
        }
    }

    public void decreaseHealth(int health) {
        this.setHealth(this.getHealth() - health);
    }

    public void increaseHealth(int health) {
        this.setHealth(this.getHealth() + health);
    }

    public void decreaseMana(int mana) {
        this.setMana(this.getMana() - mana);
        //Kaiden_Engine.getInstance().sendEmulatorMessage("blue", "use total :" + mana);
    }

    public void decreaseManaSpend(int mana) {
        int spend = mana;
        try {
            if (this instanceof UserState) {
                User user = ((UserState) this).getUser();
                if (user != null) {
                    Stats stats = (Stats) user.properties.get("stats");
                    if (stats != null) {
                        spend = (int) Math.max(0, Math.round(mana * Math.max(0.05D, stats.get$cmc())));
                    }
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        this.setMana(this.getMana() - spend);
    }

    public void increaseMana(int mana) {
        this.setMana(this.getMana() + mana);
    }

    public void decreaseDash(int amount) {
        this.setDash(this.getDash() - amount);
    }

    public void increaseDash(int amount) {
        this.setDash(this.getDash() + amount);
    }

    public void increaseDashByPercent(double percent) {
        int amount = (int) Math.max(1, Math.round((double) this.maxDash * percent));
        this.setDash(this.getDash() + amount);
    }

    public void decreaseHealthByPercent(double percent) {
        int amount = (int) ((double) this.maxHealth * percent);
        this.setHealth(this.getHealth() - amount);
    }

    public void increaseHealthByPercent(double percent) {
        int amount = (int) ((double) this.maxHealth * percent);
        this.setHealth(this.getHealth() + amount);
    }

    public void increaseManaByPercent(double percent) {
        int amount = (int) ((double) this.maxMana * percent);
        this.setMana(this.getMana() + amount);
    }

    public void increaseCalAQWHealth(double percent) {
        int amount = (int) Math.max(1, (this.maxHealth * percent));
        this.setHealth(this.getHealth() + amount);
    }

    public void increaseCalAQWmana(double percent) {
        int amount = (int) Math.max(1, (this.maxMana * percent));
        this.setMana(this.getMana() + amount);
    }


    public int getCurrentShield() {
        return this.currentShield;
    }

    public void setCurrentShield(int currentShield) {
        this.currentShield = Math.max(0, currentShield);
    }

    public int absorbShield(int amount) {
        if (amount <= 0 || this.currentShield <= 0) return amount;
        int absorbed = Math.min(amount, this.currentShield);
        this.currentShield -= absorbed;
        return Math.max(0, amount - absorbed);
    }


    public void syncShieldFromStats(User user) {
        if (user == null) return;
        try {
            Stats stats = (Stats) user.properties.get("stats");
            if (stats == null) return;
            int statShield = (int) Math.max(0, Math.round(stats.get$shield()));
            if (this.currentShield > statShield) {
                this.currentShield = statShield;
            } else if (this.currentShield <= 0 && statShield > 0) {
                this.currentShield = statShield;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }
    public void regenUser(User user) {
        Users.getInstance().regen(user);
    }

    public void die() {
        this.health = 0;
        this.state = 0;
        this.mana = 0;
    }

    public void restore() {
        this.state = 1;
        this.health = this.maxHealth;
        this.mana = this.maxMana;
        this.dash = this.maxDash;
        // restore usually implies you're not in combat anymore
        this.clearTargets();
    }

    public void reset() {
        this.state = 1;
        this.refreshCombatState();
    }

    public int getState() {
        return this.state;
    }

    public void setState(int state) {
        if (state >= 0 && state <= 2) {
            this.state = state;
        } else {
            throw new IllegalArgumentException("invalid state value");
        }
    }

    public int getMaxHealth() {
        return this.maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
        if (this.health > this.maxHealth) {
            this.health = this.maxHealth;
        }
    }

    public int getMaxMana() {
        return this.maxMana;
    }

    public void setMaxMana(int maxMana) {
        this.maxMana = maxMana;
        if (this.mana > this.maxMana) {
            this.mana = this.maxMana;
        }
    }

    public void setMaxDash(int dash) {
        this.maxDash = Math.max(0, dash);
        if (this.dash > this.maxDash) {
            this.dash = this.maxDash;
        }
    }
    public JSONObject getData() {
        JSONObject data = new JSONObject();
        data.put("intMP", this.mana);
        data.put("intHP", this.health);
        // Keep dash out of generic combat/state packets so unrelated ct/stu/uotls
        // refreshes do not snap the client back to 100 while the client is
        // tracking dash consumption locally.
        data.put("intState", this.state);
        return data;
    }

    public void refreshCombatState() {
        if (this.state == 0) return;
        cleanupInvalidTargetsInternal();
        boolean hasTargets = (!this.monsterTargets.isEmpty()) || (!this.playerTargets.isEmpty());
        this.state = hasTargets ? 2 : 1;
    }

    private void cleanupInvalidTargetsInternal() {
        playerTargets.remove("");
        playerTargets.remove("0");
        monsterTargets.remove(0);

        try {
            java.util.Iterator<String> pit = playerTargets.iterator();
            while (pit.hasNext()) {
                String name = pit.next();
                if (name == null || name.trim().isEmpty() || "0".equals(name)) {
                    pit.remove();
                    continue;
                }
                User target = Kaiden_Extension.getInstance().getZone().getUserByName(name);
                if (target == null) {
                    pit.remove();
                    continue;
                }
                Object stateObj = target.properties.get("state");
                if (!(stateObj instanceof State) || ((State) stateObj).isDead()) {
                    pit.remove();
                }
            }
        } catch (Throwable t) {
            LOGGER.error("cleanupInvalidTargetsInternal failed while cleaning player targets", t);
            Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[StateDebug] cleanup player targets failed: " + t.getClass().getSimpleName() + " - " + t.getMessage());
        }

        try {
            java.util.Iterator<Integer> mit = monsterTargets.iterator();
            while (mit.hasNext()) {
                Integer monMapId = mit.next();
                if (monMapId == null || monMapId.intValue() <= 0) {
                    mit.remove();
                    continue;
                }
                MonsterAI ai = MonsterAI.getAIByMonMapId(monMapId.intValue());
                if (ai == null || ai.getState() == null || ai.getState().isDead()) {
                    mit.remove();
                }
            }
        } catch (Throwable t) {
            LOGGER.error("cleanupInvalidTargetsInternal failed while cleaning monster targets", t);
            Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[StateDebug] cleanup monster targets failed: " + t.getClass().getSimpleName() + " - " + t.getMessage());
        }
    }

    // ----------------------------------------
    // Auras helpers / stacking (cap = 4)
    // ----------------------------------------
    private synchronized void cleanupExpiredAurasLocked() {
        long now = System.currentTimeMillis();
        java.util.Iterator<RemoveAura> it = this.auras.iterator();
        while (it.hasNext()) {
            RemoveAura ra = it.next();
            if (ra == null || ra.getAura() == null) {
                it.remove();
                continue;
            }
            if (ra.isFinished()) {
                it.remove();
                continue;
            }
            long end = ra.getEndTime();
            if (end > 0L && end <= now) {
                // Never call RemoveAura.run() from inside synchronized State helpers.
                // CombatAction owns the room combat lock before entering State, while
                // RemoveAura.run() owns the room combat lock before entering State.
                // Running expiration here can deadlock the whole room.
                it.remove();
            }
        }
    }

    public synchronized java.util.Set<RemoveAura> getActiveAurasById(int auraId) {
        this.cleanupExpiredAurasLocked();
        java.util.Set<RemoveAura> matches = new java.util.HashSet<RemoveAura>();
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            if (ra.getAura().getId() == auraId) {
                matches.add(ra);
            }
        }
        return matches;
    }

    public synchronized RemoveAura getActiveAura(int auraId) {
        this.cleanupExpiredAurasLocked();
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            if (ra.getAura().getId() == auraId) {
                return ra;
            }
        }
        return null;
    }


    public synchronized RemoveAura removeNewestAuraInstance(int auraId) {
        this.cleanupExpiredAurasLocked();
        RemoveAura newest = null;
        long bestEnd = Long.MIN_VALUE;
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null || aura.getId() != auraId) continue;
            long end = ra.getEndTime();
            if (end <= 0L) {
                newest = ra;
                break;
            }
            if (end > bestEnd) {
                bestEnd = end;
                newest = ra;
            }
        }
        if (newest != null) {
            this.auras.remove(newest);
        }
        return newest;
    }

    public synchronized boolean isAuraStackFull(int auraId, int maxStacks) {
        return this.getAuraStackCount(auraId) >= Math.max(1, maxStacks);
    }

    public synchronized int getAuraStackCount(int auraId) {
        this.cleanupExpiredAurasLocked();
        int count = 0;
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura != null && aura.getId() == auraId) {
                count += Math.max(1, ra.getStackCount());
            }
        }
        return count;
    }



    private String normalizeAuraSource(String sourceInf) {
        return sourceInf == null ? "" : sourceInf.trim().toLowerCase();
    }

    public synchronized int getAuraStackCountBySource(int auraId, String sourceInf) {
        this.cleanupExpiredAurasLocked();
        String wanted = normalizeAuraSource(sourceInf);
        int count = 0;
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            if (ra.getAura().getId() != auraId) continue;
            if (!wanted.equals(normalizeAuraSource(ra.getSourceInf()))) continue;
            count += Math.max(1, ra.getStackCount());
        }
        return count;
    }

    public synchronized boolean isAuraStackFullForSource(int auraId, int maxStacks, String sourceInf) {
        return this.getAuraStackCountBySource(auraId, sourceInf) >= Math.max(1, maxStacks);
    }

    public synchronized RemoveAura getEarliestExpiringAura(int auraId) {
        this.cleanupExpiredAurasLocked();
        RemoveAura best = null;
        long bestEnd = Long.MAX_VALUE;

        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null || aura.getId() != auraId) continue;

            long end = ra.getEndTime();
            if (end <= 0L) {
                return ra;
            }
            if (end < bestEnd) {
                bestEnd = end;
                best = ra;
            }
        }

        return best;
    }


    public synchronized RemoveAura getLatestExpiringAuraBySource(int auraId, String sourceInf) {
        this.cleanupExpiredAurasLocked();
        String wanted = normalizeAuraSource(sourceInf);
        RemoveAura best = null;
        long bestEnd = Long.MIN_VALUE;

        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null || aura.getId() != auraId) continue;
            if (!wanted.equals(normalizeAuraSource(ra.getSourceInf()))) continue;
            long end = ra.getEndTime();
            if (end <= 0L) return ra;
            if (end > bestEnd) {
                bestEnd = end;
                best = ra;
            }
        }
        return best;
    }

    public synchronized RemoveAura getLatestExpiringAura(int auraId) {
        this.cleanupExpiredAurasLocked();
        RemoveAura best = null;
        long bestEnd = Long.MIN_VALUE;

        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null || aura.getId() != auraId) continue;
            long end = ra.getEndTime();
            if (end <= 0L) return ra;
            if (end > bestEnd) {
                bestEnd = end;
                best = ra;
            }
        }
        return best;
    }

    public synchronized boolean hasAuraCategory(String category, long excludingInstanceId) {
        if (category == null || category.trim().isEmpty()) return false;
        String wanted = category.trim().toLowerCase();
        long now = System.currentTimeMillis();
        java.util.Iterator<RemoveAura> it = this.auras.iterator();
        while (it.hasNext()) {
            RemoveAura ra = it.next();
            if (ra == null || ra.getAura() == null) {
                it.remove();
                continue;
            }
            long end = ra.getEndTime();
            if (end > 0L && end <= now) {
                it.remove();
                continue;
            }
            if (ra.getInstanceId() == excludingInstanceId) continue;
            String cat = ra.getAura().getCategory();
            if (cat != null && wanted.equals(cat.trim().toLowerCase())) return true;
        }
        return false;
    }

    public synchronized boolean isDisabled() {
        this.cleanupExpiredAurasLocked();
        for (RemoveAura ra : new HashSet<RemoveAura>(this.auras)) {
            AuraBean aura = ra.getAura();
            if (aura == null) continue;

            String cat = aura.getCategory() == null ? "" : aura.getCategory().trim().toLowerCase();
            if ("stun".equals(cat)
                    || "freeze".equals(cat)
                    || "frozen".equals(cat)
                    || "stone".equals(cat)
                    || "disabled".equals(cat)
                    || "disable".equals(cat)) {
                return true;
            }
        }
        return false;
    }

    public void clearAuras() {
        // Avoid ConcurrentModification: aura.run() / aura.cancel() may remove from this.auras
        Set<RemoveAura> copy = this.getAuras();
        for (RemoveAura aura : copy) {
            try {
                aura.run();
            } catch (Throwable ignored) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[StateDebug] clearAuras run failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
            }
            try {
                aura.cancel();
            } catch (Throwable ignored) {
                Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "[StateDebug] clearAuras run failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
            }
        }
        this.auras.clear();
    }

    public synchronized boolean hasAura(int auraId) {
        this.cleanupExpiredAurasLocked();
        for (RemoveAura ra : this.auras) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura != null && aura.getId() == auraId) {
                return true;
            }
        }
        return false;
    }

    public boolean hasAuras() {
        return !this.auras.isEmpty();
    }

    public synchronized Set<RemoveAura> getAuras() {
        this.cleanupExpiredAurasLocked();
        return new HashSet<RemoveAura>(this.auras);
    }

    public synchronized void removeAura(RemoveAura ra) {
        this.auras.remove(ra);
        CombatTrace.info("State.removeAura", CombatTrace.aura(ra) + ", size=" + this.auras.size());

        //this.refreshCombatState();
    }

    public synchronized void addAura(RemoveAura ra) {
        this.auras.add(ra);
        CombatTrace.info("State.addAura", CombatTrace.aura(ra) + ", size=" + this.auras.size());
    }

    public RemoveAura applyAura(AuraBean aura, String sourceInf) {
        return this.applyAura(aura);
    }

    public abstract RemoveAura applyAura(AuraBean var1);

    public String getStateByID(int id) {
        switch (id) {
            case 0:
                return "Dead";
            case 1:
                return "Neutral";
            case 2:
                return "Combat";
            default:
                return "Unknown state [209]";
        }
    }

    // ----------------------------------------
    // Target tracking + auto state updates
    // ----------------------------------------
    public void addMonsterTarget(int monsterMapId) {
        if (monsterMapId <= 0) return;
        monsterTargets.add(monsterMapId);
        this.refreshCombatState();
    }

    public void removeMonsterTarget(int monsterMapId) {
        monsterTargets.remove(monsterMapId);
        this.refreshCombatState();
    }


    public Set<Integer> getMonsterTargets() {
        return new HashSet<Integer>(monsterTargets);
    }

    public boolean isFightingMonster(int monsterMapId) {
        return monsterTargets.contains(monsterMapId);
    }

    public void addPlayerTarget(String username) {
        if (username == null) return;
        String normalized = username.trim();
        if (normalized.isEmpty() || "0".equals(normalized)) return;
        playerTargets.add(normalized);
        this.refreshCombatState();
    }

    public void removePlayerTarget(String username) {
        if (username == null) {
            this.refreshCombatState();
            return;
        }
        String normalized = username.trim();
        if (!normalized.isEmpty()) {
            playerTargets.remove(normalized);
        }
        this.refreshCombatState();
    }

    public Set<String> getPlayerTargets() {
        return new HashSet<String>(playerTargets);
    }

    public boolean isFightingPlayer(String username) {
        return playerTargets.contains(username);
    }

    public void clearTargets() {
        monsterTargets.clear();
        playerTargets.clear();
        this.refreshCombatState();
    }

    public void cleanupInvalidTargets() {
        cleanupInvalidTargetsInternal();
        this.refreshCombatState();
    }
}
