package Kaiden.Game.Server.Users.Utils;

import Kaiden.Database.Storage;
import Kaiden.Game.Threads.LiveRewards;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;

/**
 * Bridges the account-management reward tables with Kaiden's existing
 * users_live_drops delivery system.
 *
 * Manual rewards are queued by the website. Automatic achievement rewards
 * are queued here as soon as an achievement is granted, and again at login
 * so old achievements can backfill newly-created rewards.
 */
public final class AccountRewardSync {

    private AccountRewardSync() {}

    public static void onAchievementGranted(User user, int achievementId) {
        if (user == null || user.properties == null || achievementId <= 0) {
            return;
        }

        int userId = getDatabaseUserId(user);
        if (userId <= 0) {
            return;
        }

        queueAutomaticRewards(userId, achievementId);
    }

    public static void syncAutomaticRewards(User user) {
        if (user == null || user.properties == null) {
            return;
        }

        int userId = getDatabaseUserId(user);
        if (userId <= 0) {
            return;
        }

        QueryResult result = null;
        boolean queuedAny = false;

        try {
            result = Storage.getInstance().getJdbc().query(
                    "SELECT ar.* " +
                    "FROM account_rewards ar " +
                    "INNER JOIN users_achievements ua " +
                    "ON ua.AchID = ar.RequiredAchievementID AND ua.UserID = ? " +
                    "WHERE ar.Enabled = 1 " +
                    "AND LOWER(ar.ClaimMode) = 'automatic' " +
                    "AND ar.RequiredAchievementID > 0",
                    userId
            );

            while (result.next()) {
                if (queueRewardFromResult(userId, result, "achievement_login_sync", result.getInt("RequiredAchievementID"))) {
                    queuedAny = true;
                }
            }
        } catch (Exception e) {
            log("[AccountRewards] login sync skipped userId=" + userId + ": " + e.getMessage());
        } finally {
            if (result != null) {
                try { result.close(); } catch (Exception ignored) {}
            }
        }

        if (queuedAny) {
            LiveRewards.scheduleImmediate();
        }
    }

    private static void queueAutomaticRewards(int userId, int achievementId) {
        QueryResult result = null;
        boolean queuedAny = false;

        try {
            result = Storage.getInstance().getJdbc().query(
                    "SELECT * FROM account_rewards " +
                    "WHERE Enabled = 1 " +
                    "AND LOWER(ClaimMode) = 'automatic' " +
                    "AND RequiredAchievementID = ?",
                    achievementId
            );

            while (result.next()) {
                if (queueRewardFromResult(userId, result, "achievement", achievementId)) {
                    queuedAny = true;
                }
            }
        } catch (Exception e) {
            log("[AccountRewards] achievement sync skipped userId=" + userId +
                    " achievementId=" + achievementId + ": " + e.getMessage());
        } finally {
            if (result != null) {
                try { result.close(); } catch (Exception ignored) {}
            }
        }

        if (queuedAny) {
            LiveRewards.scheduleImmediate();
        }
    }

    private static boolean queueRewardFromResult(int userId, QueryResult reward, String source, int sourceId) {
        int rewardId = reward.getInt("id");
        if (rewardId <= 0) {
            return false;
        }

        // account_reward_claims is the one-time guard shared by website + emulator.
        QueryResult existingClaim = null;
        try {
            existingClaim = Storage.getInstance().getJdbc().query(
                    "SELECT id FROM account_reward_claims WHERE UserID = ? AND RewardID = ? LIMIT 1",
                    userId,
                    rewardId
            );
            if (existingClaim.next()) {
                return false;
            }
        } finally {
            if (existingClaim != null) {
                try { existingClaim.close(); } catch (Exception ignored) {}
            }
        }

        Storage.getInstance().getJdbc().run(
                "INSERT IGNORE INTO account_reward_claims " +
                "(UserID, RewardID, Status, ClaimedAt) VALUES (?, ?, 'queued', NOW())",
                userId,
                rewardId
        );

        String rewardKey = "account_reward:" + rewardId;

        try {
            Storage.getInstance().getJdbc().run(
                    "INSERT IGNORE INTO users_live_drops " +
                    "(UserID, ItemID, Quantity, Coins, Gold, Experience, ClassPoints, UpgradeDays, AchievementID, " +
                    "RequiredAchievementID, RewardID, RewardKey, RewardName, RewardMessage, Source, SourceID, Claimed, CreatedAt) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())",
                    userId,
                    reward.getInt("ItemID"),
                    Math.max(1, reward.getInt("Quantity")),
                    reward.getInt("Coins"),
                    reward.getInt("Gold"),
                    reward.getInt("Experience"),
                    reward.getInt("ClassPoints"),
                    reward.getInt("UpgradeDays"),
                    reward.getInt("GrantAchievementID"),
                    reward.getInt("RequiredAchievementID"),
                    rewardId,
                    rewardKey,
                    reward.getString("Name"),
                    reward.getString("RewardMessage"),
                    source,
                    sourceId
            );

            log("[AccountRewards] queued rewardId=" + rewardId + " userId=" + userId + " source=" + source);
            return true;
        } catch (Exception e) {
            // If queueing fails, release the claim so it can be retried later.
            try {
                Storage.getInstance().getJdbc().run(
                        "DELETE FROM account_reward_claims WHERE UserID = ? AND RewardID = ? AND Status = 'queued'",
                        userId,
                        rewardId
                );
            } catch (Exception ignored) {}

            log("[AccountRewards] queue failed rewardId=" + rewardId + " userId=" + userId + ": " + e.getMessage());
            return false;
        }
    }

    private static int getDatabaseUserId(User user) {
        Object idObj = user.properties.get(Kaiden.Game.Server.Users.Properties.ID);
        if (idObj instanceof Number) {
            return ((Number) idObj).intValue();
        }
        if (idObj != null) {
            try { return Integer.parseInt(String.valueOf(idObj)); } catch (Exception ignored) {}
        }
        return 0;
    }

    private static void log(String message) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage("cyan", message);
        } catch (Exception ignored) {}
    }
}
