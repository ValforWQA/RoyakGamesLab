package Kaiden.Game.Server;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Utils.SpanUtils;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.text.DecimalFormat;
import java.util.*;

public class Server {
    private static Server instance;
    public static Server getInstance() {
        if (instance == null) {
            instance = new Server();
        }
        return instance;
    }
    public Calendar calendar;
    public Random random = new Random();
    public static int damage;
    public static int timeleft;

    public int setDamage(int newdamage) {
        String damageS = String.valueOf(damage);
        String ndammage = String.valueOf(newdamage);
        return damage = Integer.valueOf(damageS.replace(damageS, ndammage));
    }

    public int setTimeLeft(int newtimeleft) {
        String oldTime = String.valueOf(timeleft);
        String ntimeleft = String.valueOf(newtimeleft);
        return timeleft = Integer.valueOf(oldTime.replace(oldTime, ntimeleft));
    }

    public int getTimeLeft() {
        return timeleft;
    }

    public int getDamage() {
        return damage;
    }
    public int getExpToLevel(int playerLevel) {
        return playerLevel < (StorageCache.getInstance().getCoreValue("intLevelMax")).intValue() ? SpanUtils.roundTens(this.getBaseValueByLevel(1000, 850000, 1.66D, playerLevel).intValue()) : 200000000;
    }

    public int getManaByLevel(int level) {
        int base = StorageCache.getInstance().getCoreValue("PCmpBase1").intValue();
        int delta = StorageCache.getInstance().getCoreValue("PCmpBase100").intValue();
        double curve = StorageCache.getInstance().getCoreValue("curveExponent") + (double) base / (double) delta;
        return this.getBaseValueByLevel(base, delta, curve, level).intValue();
    }

    public int getHealthByLevel(int level) {
        int base = StorageCache.getInstance().getCoreValue("PChpGoal1").intValue();
        int delta = StorageCache.getInstance().getCoreValue("PChpGoal100").intValue();
        double curve = 1.5D + (double) base / (double) delta;
        return this.getBaseValueByLevel(base, delta, curve, level).intValue();
    }

    public int getBaseHPByLevel(int level) {
        int base = StorageCache.getInstance().getCoreValue("PChpBase1").intValue();
        double curve = StorageCache.getInstance().getCoreValue("curveExponent");
        int delta = StorageCache.getInstance().getCoreValue("PChpDelta").intValue();
        return this.getBaseValueByLevel(base, delta, curve, level).intValue();
    }

    public int getIBudget(int itemLevel, int iRty) {
        int GstBase = StorageCache.getInstance().getCoreValue("GstBase").intValue();
        int GstGoal = StorageCache.getInstance().getCoreValue("GstGoal").intValue();
        double statsExponent = StorageCache.getInstance().getCoreValue("statsExponent");
        int rarity = iRty < 1 ? 1 : iRty;
        int level = itemLevel + rarity - 1;
        int delta = GstGoal - GstBase;
        return this.getBaseValueByLevel(GstBase, delta, statsExponent, level).intValue();
    }

    public int getInnateStats(int userLevel) {
        int PCstBase = StorageCache.getInstance().getCoreValue("PCstBase").intValue();
        int PCstGoal = StorageCache.getInstance().getCoreValue("PCstGoal").intValue();
        double statsExponent = StorageCache.getInstance().getCoreValue("statsExponent");
        int delta = PCstGoal - PCstBase;
        return this.getBaseValueByLevel(PCstBase, delta, statsExponent, userLevel).intValue();
    }

    public Double getBaseValueByLevel(int base, int delta, double curve, int userLevel) {
        int levelCap = StorageCache.getInstance().getCoreValue("intLevelCap").intValue();
        int level = userLevel < 1 ? 1 : (userLevel > levelCap ? levelCap : userLevel);
        double x = (double) (level - 1) / (double) (levelCap - 1);
        return (double) base + Math.pow(x, curve) * (double) delta;
    }

    public Map<String, Double> getItemStats(EnhancementBean enhancement, String equipment) {
        Map<String, Double> itemStats = new HashMap<String, Double>();
        itemStats.put("END", 0.0D);
        itemStats.put("STR", 0.0D);
        itemStats.put("INT", 0.0D);
        itemStats.put("DEX", 0.0D);
        itemStats.put("WIS", 0.0D);
        itemStats.put("LCK", 0.0D);

        if (enhancement == null) {
            return itemStats;
        }

        Double equipmentRatio = (Double) Stats.ratioByEquipment.get(equipment);
        if (equipmentRatio == null || equipmentRatio.doubleValue() <= 0.0D) {
            return itemStats;
        }

        Kaiden.Database.Beans.EnhancementPatternBean patternBean = null;
        try {
            patternBean = StorageCache.getInstance().getEnhancementPattern(enhancement.getPatternId());
            if (patternBean == null) {
                patternBean = StorageCache.getInstance().getEnhancementPattern(enhancement.getClientPatternId());
            }
        } catch (Exception ignored) {}
        if (patternBean == null || patternBean.getStats() == null || patternBean.getStats().isEmpty()) {
            return itemStats;
        }

        int rarity = Math.max(1, enhancement.getRarity());
        int level = Math.max(1, enhancement.getLevel());
        double slotRatio = equipmentRatio.doubleValue();

        // AQW-style: pattern weights are the identity; do not multiply them again by heavy rarity/level scales.
        int levelBand = Math.max(0, Math.min(15, (level - 1) / 20));
        double baseBudget = 6.0D + (levelBand * 1.5D);
        double rarityScale = 1.0D + (Math.max(0, rarity - 1) * 0.03D);
        int iBudget = (int) Math.max(1, Math.round(baseBudget * slotRatio * rarityScale));

        Map<String, Double> statPattern = patternBean.getStats();
        List<Map.Entry<String, Double>> weighted = new ArrayList<Map.Entry<String, Double>>();
        double totalWeight = 0.0D;
        for (String key : itemStats.keySet()) {
            Double rawObj = statPattern.get(key);
            double weight = rawObj == null ? 0.0D : Math.max(0.0D, rawObj.doubleValue());
            weighted.add(new AbstractMap.SimpleEntry<String, Double>(key, weight));
            totalWeight += weight;
        }
        if (totalWeight <= 0.0D) {
            totalWeight = (double) weighted.size();
            weighted.clear();
            for (String key : itemStats.keySet()) {
                weighted.add(new AbstractMap.SimpleEntry<String, Double>(key, 1.0D));
            }
        }

        Collections.sort(weighted, new Comparator<Map.Entry<String, Double>>() {
            @Override
            public int compare(Map.Entry<String, Double> a, Map.Entry<String, Double> b) {
                return Double.compare(b.getValue(), a.getValue());
            }
        });

        int distributed = 0;
        for (Map.Entry<String, Double> entry : weighted) {
            double weight = Math.max(0.0D, entry.getValue());
            if (weight <= 0.0D) {
                continue;
            }
            int value = (int) Math.floor((weight / totalWeight) * iBudget);
            if (value < 0) value = 0;
            itemStats.put(entry.getKey(), (double) value);
            distributed += value;
        }

        int idx = 0;
        while (distributed < iBudget && !weighted.isEmpty()) {
            Map.Entry<String, Double> entry = weighted.get(idx % weighted.size());
            itemStats.put(entry.getKey(), itemStats.get(entry.getKey()) + 1.0D);
            distributed++;
            idx++;
        }

        return itemStats;
    }
    
    public String toProperNumber(int amount) {
        DecimalFormat formatter = new DecimalFormat("#,###");
        return formatter.format(amount);
    }

    public int calculateCP(int playerLevel, int monsterLevel) {
        final int MIN_XP = 10;
        final int MAX_XP = 20000;

        // Base curve tuned so lvl 70 ≈ 100 XP
        double baseXP = 0.4 * Math.pow(monsterLevel, 1.3);

        int diff = monsterLevel - playerLevel;
        double multiplier;

        if (diff < 0) {
            // Lower-level monster → reduce XP
            multiplier = Math.max(0.3, 1.0 + (diff * 0.015));
        } else {
            // Higher-level monster → small boost
            multiplier = 1.0 + (diff * 0.01);
        }

        int xp = (int)(baseXP * multiplier);

        // Clamp
        xp = Math.max(MIN_XP, xp);
        xp = Math.min(MAX_XP, xp);

        //Kaiden_Engine.getInstance().sendEmulatorMessage("blue", "calc return :"+ xp);
        return xp;


    }
    
    public void sendServerMessage(String message) {
        JSONObject umsg = new JSONObject();
        umsg.put("cmd", "umsg");
        umsg.put("s", message);
        Kaiden_Extension.getInstance().send(umsg, Kaiden_Extension.getInstance().getZone().getChannelList());
    }

    public void sendServerNotifaction(String message, User user) {
        JSONObject umsg = new JSONObject();
        umsg.put("cmd", "umsg");
        umsg.put("s", message);
        Kaiden_Extension.getInstance().send(umsg, user);
    }
}
