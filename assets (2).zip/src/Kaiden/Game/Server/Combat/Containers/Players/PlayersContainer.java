package Kaiden.Game.Server.Combat.Containers.Players;

/**
 * Root container for player combat systems.
 * Existing player combat engines remain in Server.Combat.Player and can be
 * migrated behind this container incrementally.
 */
public final class PlayersContainer {
    private PlayersContainer() {
    }
}
