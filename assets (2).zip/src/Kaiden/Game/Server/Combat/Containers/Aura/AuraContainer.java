package Kaiden.Game.Server.Combat.Containers.Aura;

/**
 * Root container for aura combat systems.
 * Existing aura engines remain in Server.Combat.Auras and can be migrated
 * behind this container without changing packet behavior.
 */
public final class AuraContainer {
    private AuraContainer() {
    }
}
