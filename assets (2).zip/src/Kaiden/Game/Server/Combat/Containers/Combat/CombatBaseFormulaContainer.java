package Kaiden.Game.Server.Combat.Containers.Combat;

import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Utils.Stats;

/**
 * AQW base combat functions used by dsrc.
 *
 * Reference model:
 * Base HP = 360 + (((EnhancementLevel - 1) / (LevelCap - 1)) ^ 0.66) * 1640
 * WDPS    = (Base HP / 2000) * 0.85 * 100
 * AP1     = WDPS + (0.10 * Attack Power)
 * SP1     = WDPS + (0.10 * Spell Power)
 * AP2     = WeaponRangeRoll * (2 * AP1)
 * SP2     = WeaponRangeRoll * (2 * SP1)
 */
public final class CombatBaseFormulaContainer {

    private CombatBaseFormulaContainer() {
    }

    public static double baseHp(int enhancementLevel, int levelCap) {
        int cap = Math.max(2, levelCap);
        int level = Math.max(1, Math.min(enhancementLevel, cap));
        double progression = (double) (level - 1) / (double) (cap - 1);
        return 360.0D + (Math.pow(progression, 0.66D) * 1640.0D);
    }

    public static double wdpsFromEnhancementLevel(int enhancementLevel, int levelCap) {
        return (baseHp(enhancementLevel, levelCap) / 2000.0D) * 0.85D * 100.0D;
    }

    /**
     * Prefer the level-based AQW WDPS curve. If the required metadata is not
     * available for a legacy character/item, preserve Kaiden's computed WDPS.
     */
    public static double wdps(Stats stats) {
        if (stats == null) return 1.0D;

        int enhancementLevel = stats.getWeaponEnhancementLevel();
        int levelCap = 100;
        try {
            Double configuredCap = StorageCache.getInstance().getCoreValue("intLevelCap");
            if (configuredCap != null && configuredCap.intValue() > 1) {
                levelCap = configuredCap.intValue();
            }
        } catch (Exception ignored) {
            // Keep the safe AQW level-100 default.
        }

        if (enhancementLevel > 0) {
            return Math.max(1.0D, wdpsFromEnhancementLevel(enhancementLevel, levelCap));
        }

        return Math.max(1.0D, stats.getWeaponDpsBase());
    }

    public static double ap1(Stats stats) {
        return wdps(stats) + (Math.max(0.0D, stats.get$ap()) * 0.10D);
    }

    public static double sp1(Stats stats) {
        return wdps(stats) + (Math.max(0.0D, stats.get$sp()) * 0.10D);
    }

    /**
     * Conservative hybrid mix until an authoritative separate APSP weighting
     * is recovered: average the already-derived AP1 and SP1 bases.
     */
    public static double apsp1(Stats stats) {
        return (ap1(stats) + sp1(stats)) / 2.0D;
    }
}
