package Kaiden.Game.Server.Combat;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Game.Threads.RemoveAura;
import net.sf.json.JSONObject;

import java.util.Random;
import java.util.Set;

public class Damage {
    private static final Random rand = new Random();

    private static double clamp01(double v) {
        if (v < 0D) return 0D;
        if (v > 1D) return 1D;
        return v;
    }

    public static JSONObject getDamageResult(String fromTgt, String tgt, int damage, DamageType type) {
        JSONObject damageResult = new JSONObject();
        damageResult.put("hp", damage);
        damageResult.put("cInf", fromTgt);
        damageResult.put("tInf", tgt);
        if (type.equals(DamageType.DAMAGE_OVER_TIME)) {
            damageResult.put("typ", type.toString());
        } else {
            damageResult.put("type", type.toString());
        }
        return damageResult;
    }

    public static JSONObject getDamageResult(String tgt, int damage, DamageType type) {
        JSONObject damageResult = new JSONObject();
        damageResult.put("hp", damage);
        damageResult.put("tInf", tgt);
        if (type.equals(DamageType.DAMAGE_OVER_TIME)) {
            damageResult.put("typ", type.toString());
        } else {
            damageResult.put("type", type.toString());
        }
        return damageResult;
    }

    public static int getRandomDamage(DamageType type, int maxDmg, int minDmg) {
        if (maxDmg < minDmg) {
            int tmp = maxDmg;
            maxDmg = minDmg;
            minDmg = tmp;
        }

        if (maxDmg == minDmg) {
            maxDmg = minDmg + 1;
        }

        int damage = rand.nextInt(maxDmg - minDmg) + minDmg;

        if (type.equals(DamageType.CRITICAL)) {
            damage = (int) Math.round((double) damage * 1.5D);
        }

        if (type.equals(DamageType.DODGE)
                || type.equals(DamageType.PARRY)
                || type.equals(DamageType.MISS)
                || type.equals(DamageType.NONE)) {
            damage = 0;
        }

        return Math.max(0, damage);
    }

    public static DamageType evaluateDamageType(double missChance, double dodgeChance, double critChance) {
        return evaluateDamageType(missChance, dodgeChance, 0D, critChance);
    }

    public static DamageType evaluateDamageType(double missChance, double dodgeChance, double parryChance, double critChance) {
        missChance = clamp01(missChance);
        dodgeChance = clamp01(dodgeChance);
        parryChance = clamp01(parryChance);
        critChance = clamp01(critChance);

        // Keep the combat table sane so avoidance never consumes the full roll space.
        double avoidTotal = missChance + dodgeChance + parryChance;
        if (avoidTotal > 0.80D) {
            double scale = 0.80D / avoidTotal;
            missChance *= scale;
            dodgeChance *= scale;
            parryChance *= scale;
        }

        // AQW-like combat: allow high crit builds to actually crit often; clamp handled above.
        critChance = Math.min(critChance, 0.95D);

        double roll = rand.nextDouble();
        double cursor = missChance;
        if (roll < cursor) return DamageType.MISS;

        cursor += dodgeChance;
        if (roll < cursor) return DamageType.DODGE;

        cursor += parryChance;
        if (roll < cursor) return DamageType.PARRY;

        cursor += critChance;
        if (roll < cursor) return DamageType.CRITICAL;

        return DamageType.HIT;
    }

    public static int evaluateAuras(int damage, Set<RemoveAura> auras) {
        if (auras == null || auras.isEmpty()) return Math.max(0, damage);
        java.util.Set<RemoveAura> snapshot = new java.util.HashSet<RemoveAura>(auras);
        return getReducedDamage(getIncreasedDamage(damage, snapshot), snapshot);
    }

    public static int getIncreasedDamage(int damage, Set<RemoveAura> auras) {
        if (auras == null || auras.isEmpty()) return Math.max(0, damage);
        for (RemoveAura ra : auras) {
            if (ra == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null) continue;
            String category = aura.getCategory();
            if (category != null && !category.equals("d")) {
                damage = (int) ((double) damage * (1.0D + aura.getDamageIncrease()));
            }
        }
        return Math.max(0, damage);
    }

    public static int getReducedDamage(int damage, Set<RemoveAura> auras) {
        if (auras == null || auras.isEmpty()) return Math.max(0, damage);
        for (RemoveAura ra : auras) {
            if (ra == null) continue;
            AuraBean aura = ra.getAura();
            if (aura == null) continue;
            String category = aura.getCategory();
            if (category != null && !category.equals("d")) {
                damage = (int) ((double) damage * (1.0D - aura.getDamageTakenDecrease()));
            }
        }
        return Math.max(0, damage);
    }
}
