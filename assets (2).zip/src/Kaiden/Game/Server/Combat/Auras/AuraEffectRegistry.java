package Kaiden.Game.Server.Combat.Auras;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Central registry for aura effect stat keys. Keep aliases here so panel/wiki
 * imports can evolve without scattering string translations across combat code.
 */
public final class AuraEffectRegistry {
    private static final Map<String, String> ALIASES;

    static {
        LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
        // Canonical Kaiden keys.
        String[] canonical = {
            "tha","tdo","thi","tcr","tcm","tpa","tbl","tre",
            "physres","magres","allres","incdmg","outdmg","physboost","magboost",
            "healin","healboost","dotres","dotboost","manacost","manaret","lifesteal","shield",
            "str","dex","int","end","wis","lck","range","hot","dot","2stun","forcecrit","hitcounter"
        };
        for (String key : canonical) m.put(key, key);

        // Friendly/legacy aliases.
        m.put("haste", "tha");
        m.put("dodge", "tdo"); m.put("evasion", "tdo");
        m.put("hit", "thi"); m.put("accuracy", "thi");
        m.put("crit", "tcr"); m.put("critical", "tcr");
        m.put("critmult", "tcm"); m.put("critmultiplier", "tcm");
        m.put("physicalresistance", "physres");
        m.put("magicalresistance", "magres");
        m.put("damageresistance", "allres"); m.put("defense", "allres");
        m.put("outgoingdamage", "outdmg");
        m.put("incomingdamage", "incdmg");
        m.put("outgoingphysicaldamage", "physboost"); m.put("physicaldamage", "physboost"); m.put("physicaldamageboost", "physboost");
        m.put("outgoingmagicaldamage", "magboost"); m.put("magicaldamage", "magboost"); m.put("magicdamage", "magboost"); m.put("magicaldamageboost", "magboost");
        m.put("damage", "outdmg"); m.put("damageoutput", "outdmg"); m.put("damagedealt", "outdmg");
        m.put("critdamage", "tcm"); m.put("criticaldamage", "tcm"); m.put("criticalmultiplier", "tcm");
        m.put("critchance", "tcr"); m.put("criticalchance", "tcr");
        m.put("hitchance", "thi"); m.put("dodgechance", "tdo");
        m.put("physicalresist", "physres"); m.put("magicresistance", "magres"); m.put("magicresist", "magres");
        m.put("resistance", "allres"); m.put("damage reduction", "allres"); m.put("damagereduction", "allres");
        m.put("incominghealing", "healin"); m.put("healingreceived", "healin");
        m.put("healing", "healboost"); m.put("healingpower", "healboost");
        m.put("dotpower", "dotboost"); m.put("damageovertimepower", "dotboost");
        m.put("dotresistance", "dotres"); m.put("damageovertimeresistance", "dotres");
        m.put("healintake", "healin");
        m.put("manaconsume", "manacost"); m.put("manaconsumption", "manacost");
        m.put("rng", "range");
        m.put("force_crit", "forcecrit"); m.put("forcedcrit", "forcecrit");
        m.put("hit_count", "hitcounter"); m.put("hitcount", "hitcounter");
        ALIASES = Collections.unmodifiableMap(m);
    }

    private AuraEffectRegistry() {}

    public static String canonicalize(String key) {
        if (key == null) return "";
        String normalized = key.trim().toLowerCase();
        if (normalized.isEmpty()) return "";
        String direct = ALIASES.get(normalized);
        if (direct != null) return direct;
        String compact = normalized.replace("_", "").replace("-", "").replace(" ", "");
        direct = ALIASES.get(compact);
        return direct != null ? direct : normalized;
    }

    public static boolean isPercentageStat(String key) {
        String k = canonicalize(key);
        return "physres".equals(k) || "magres".equals(k) || "allres".equals(k)
                || "outdmg".equals(k) || "incdmg".equals(k) || "manaret".equals(k) || "lifesteal".equals(k)
                || "tcm".equals(k) || "tpa".equals(k) || "tbl".equals(k) || "tre".equals(k)
                || "physboost".equals(k) || "magboost".equals(k) || "healin".equals(k) || "healboost".equals(k)
                || "dotres".equals(k) || "dotboost".equals(k) || "manacost".equals(k)
                || "tha".equals(k) || "tdo".equals(k) || "thi".equals(k) || "tcr".equals(k);
    }

    /** Accept either DB fractions (0.20) or human percentages (20). */
    public static double normalizeValue(String key, double value) {
        if (isPercentageStat(key) && Math.abs(value) > 1.0D) return value / 100.0D;
        return value;
    }

    public static boolean isSupported(String key) {
        String canonical = canonicalize(key);
        return ALIASES.containsKey(canonical) && ALIASES.get(canonical).equals(canonical);
    }
}
