package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.MonsterSkillsBean;
import Kaiden.Database.Beans.SkillBean;
import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.UserState;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.concurrent.ThreadLocalRandom;

public class CombatEvaluator {
    private static final double PLAYER_CRIT_CAP = 0.85D;
    private static final double MONSTER_CRIT_CAP = 0.14D;
    private static final double PLAYER_EVADE_CAP = 0.80D;
    private static final double MONSTER_EVADE_CAP = 0.60D;

    private CombatEvaluator() {}

    public static double clampChance(double v) {
        return clampChance(v, 0.95D);
    }

    public static double clampChance(double v, double cap) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return 0.0D;
        if (v < 0.0D) return 0.0D;
        if (v > cap) return cap;
        return v;
    }

    public static double clampDisplayedChance(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return 0.0D;
        if (v < 0.0D) return 0.0D;
        if (v > 1.0D) return 1.0D;
        return v;
    }

    public static DamageType resolvePlayerVsMonster(User user, MonsterAI monster, Stats attacker) {
        double baseMiss = StorageCache.getInstance().getCoreValue("baseMiss");
        double baseDodge = StorageCache.getInstance().getCoreValue("baseDodge");
        double baseHit = StorageCache.getInstance().getCoreValue("baseHit");
        double accuracy = Math.max(0.0D, baseHit + (attacker != null ? attacker.get_thi() : 0.0D));
        double critChance = getPlayerCritChance(attacker);

        int playerLevel = 1;
        if (user != null && user.properties.get(Properties.LEVEL) instanceof Number) {
            playerLevel = ((Number) user.properties.get(Properties.LEVEL)).intValue();
        }
        int monsterLevel = (monster != null && monster.getMonster() != null) ? monster.getMonster().getLevel() : playerLevel;

        double levelDodgeAdj = clamp(monsterLevel - playerLevel, -10.0D, 20.0D) * 0.0035D;
        double missChance = clampChance(baseMiss - (accuracy * 1.15D), 0.60D);
        double auraDodge = (monster != null && monster.getState() != null) ? monster.getState().getMonsterDodge() : 0.0D;
        double dodgeChance = clampChance((baseDodge + levelDodgeAdj + auraDodge) - (accuracy * 0.80D), MONSTER_EVADE_CAP);

        if (EnhancementProcAuras.hasAura(monster, EnhancementProcAuras.PRAXIS)) {
            dodgeChance = Math.max(0.0D, dodgeChance - 0.05D);
        }
        if (EnhancementProcAuras.hasAura(monster, EnhancementProcAuras.LACERATE)) {
            dodgeChance = Math.max(0.0D, dodgeChance - 0.10D);
        }

        return Damage.evaluateDamageType(missChance, dodgeChance, 0.0D, critChance);
    }

    public static DamageType resolvePlayerVsPlayer(Stats attacker, Stats defender) {
        double baseMiss = StorageCache.getInstance().getCoreValue("baseMiss");
        double baseHit = StorageCache.getInstance().getCoreValue("baseHit");
        double accuracy = Math.max(0.0D, baseHit + (attacker != null ? attacker.get_thi() : 0.0D));
        double evade = Math.max(0.0D, defender != null ? defender.get_tdo() : 0.0D);
        double parry = Math.max(0.0D, defender != null ? defender.get_tpa() : 0.0D);
        double critChance = getPlayerCritChance(attacker);

        double missChance = clampChance(baseMiss - (accuracy * 1.10D), 0.60D);
        double dodgeChance = clampChance(evade - (accuracy * 0.85D), PLAYER_EVADE_CAP);
        double parryChance = clampChance(parry - (accuracy * 0.55D), 0.45D);

        return Damage.evaluateDamageType(missChance, dodgeChance, parryChance, critChance);
    }


    public static double getPlayerCritChance(Stats attacker) {
        return clampChance(attacker != null ? attacker.get_tcr() : 0.0D, PLAYER_CRIT_CAP);
    }

    public static double getMonsterCritChance(MonsterAI monster) {
        if (monster == null || monster.getMonster() == null) {
            return 0.03D;
        }

        int monsterLevel = Math.max(1, monster.getMonster().getLevel());
        int monsterDps = Math.max(1, monster.getMonster().getDPS());
        int attackDelayMs = Math.max(800, monster.getMonster().getAttack());

        double intLevelMax = Math.max(1.0D, StorageCache.getInstance().getCoreValue("intLevelMax"));
        double levelPart = ((double) monsterLevel / intLevelMax) * 0.045D;
        double dpsPart = Math.min(0.040D, Math.log10(Math.max(10.0D, (double) monsterDps)) * 0.016D);
        double speedPart = Math.max(0.0D, Math.min(0.020D, ((double) attackDelayMs - 1500.0D) / 3500.0D * 0.020D));

        double critChance = 0.020D + levelPart + dpsPart + speedPart;

        if (monster.getState() != null && EnhancementProcAuras.hasAura(monster, EnhancementProcAuras.LACERATE)) {
            critChance += 0.02D;
        }
        if (monster.getState() != null) {
            critChance += monster.getState().getMonsterCrit();
        }

        return clampChance(critChance, MONSTER_CRIT_CAP);
    }

    public static DamageType resolveMonsterVsPlayer(MonsterAI monster, Stats defender) {
        return resolveMonsterVsPlayer(monster, defender, null);
    }

    public static DamageType resolveMonsterVsPlayer(MonsterAI monster, Stats defender, User defenderUser) {
        double baseMiss = StorageCache.getInstance().getCoreValue("baseMiss");
        double baseHit = StorageCache.getInstance().getCoreValue("baseHit");
        double dodgeChance = clampChance(defender != null ? defender.get$tdo() : 0.0D, PLAYER_EVADE_CAP);
        double parryChance = Math.min(0.35D, Math.max(0.0D, defender != null ? defender.get$tpa() * 0.75D : 0.0D));

        int monsterLevel = (monster != null && monster.getMonster() != null) ? Math.max(1, monster.getMonster().getLevel()) : 1;
        int defenderLevel = 1;
        if (defenderUser != null && defenderUser.properties.get(Properties.LEVEL) instanceof Number) {
            defenderLevel = Math.max(1, ((Number) defenderUser.properties.get(Properties.LEVEL)).intValue());
        }
        double levelPressure = clamp(monsterLevel - defenderLevel, -15.0D, 20.0D) * 0.0025D;
        double auraHit = (monster != null && monster.getState() != null) ? monster.getState().getMonsterHit() : 0.0D;
        double monsterHit = Math.max(0.0D, baseHit + auraHit);
        double missChance = clampChance(baseMiss - levelPressure - monsterHit, 0.60D);

        return Damage.evaluateDamageType(missChance, dodgeChance, parryChance, getMonsterCritChance(monster));
    }

    public static int rollMonsterAutoAttackDamage(MonsterAI monster) {
        return rollMonsterBaseDamage(monster, 1.0D, 0.08D, 0.12D);
    }

    public static int rollMonsterSkillDamage(MonsterAI monster, MonsterSkillsBean skill) {
        double scalar = scalarForMonsterSkill(skill);
        return rollMonsterBaseDamage(monster, scalar, 0.06D, 0.10D);
    }

    public static double scalarForMonsterSkill(MonsterSkillsBean skill) {
        if (skill == null) return 1.0D;
        double v = Math.abs(skill.getDamage());
        if (v <= 0.0D) return 1.0D;
        if (v > 10.0D) v = v / 100.0D;
        if (v < 0.05D) v = 0.05D;
        if (v > 12.0D) v = 12.0D;
        return v;
    }

    private static int rollMonsterBaseDamage(MonsterAI monster, double scalar, double lowVariance, double highVariance) {
        if (monster == null || monster.getMonster() == null) return 1;

        int monsterDps = Math.max(1, monster.getMonster().getDPS());
        int attackDelayMs = Math.max(1, monster.getMonster().getAttack());

        /*
         * Treat monsters.DPS as actual damage-per-second and monsters.Attack as
         * the delay between attacks in milliseconds.  A slower monster therefore
         * hits harder per swing while preserving the configured DPS:
         *
         *     average swing = DPS * (Attack / 1000.0)
         *
         * Example: DPS 9, Attack 2500 => 22.5 average damage per swing.
         */
        double attackSeconds = Math.max(0.001D, (double) attackDelayMs / 1000.0D);
        double blendedBase = Math.max(1.0D, monsterDps * attackSeconds);
        blendedBase *= Math.max(0.05D, scalar);

        int min = Math.max(1, (int) Math.floor(blendedBase * (1.0D - Math.max(0.0D, lowVariance))));
        int max = Math.max(min, (int) Math.ceil(blendedBase * (1.0D + Math.max(0.0D, highVariance))));

        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    public static int applyPlayerOutgoingModifiers(Stats stats, int amount, boolean magical) {
        if (stats == null || amount <= 0) return amount;
        double out = Math.max(0.05D, stats.get$outdmg());
        double typed = magical ? Math.max(0.05D, stats.get$cmo()) : Math.max(0.05D, stats.get$cpo());
        return (int) Math.max(0, Math.round(amount * out * typed));
    }

    public static int applyMonsterOutgoingModifiers(MonsterAI monster, int amount, boolean magical) {
        if (monster == null || monster.getState() == null || amount <= 0) return amount;

        double out = Math.max(0.05D, 1.0D + monster.getState().getMonsterOutDmg());
        double typed = Math.max(0.05D, 1.0D + (magical ? monster.getState().getMonsterMagBoost() : monster.getState().getMonsterPhysBoost()));
        double outMultiplier = out * typed;

        int consumedStacks = EnhancementProcAuras.getAuraStacks(monster, EnhancementProcAuras.CONSUMED);
        if (consumedStacks > 0) {
            double penalty = Math.min(0.30D, 0.10D + (0.01D * consumedStacks));
            outMultiplier *= Math.max(0.05D, 1.0D - penalty);
        }

        return Math.max(0, (int)Math.round(amount * outMultiplier));
    }

    public static int applyPlayerIncomingModifiers(Stats targetStats, State targetState, int amount, boolean magical, User targetUser) {
        if (targetStats == null || amount <= 0) return amount;

        double incoming = Math.max(0.05D, targetStats.get$incdmg());
        double typedResist = magical ? targetStats.get$magres() : targetStats.get$physres();
        double resistTotal = clamp(targetStats.get$allres() + typedResist, 0.0D, 0.80D);
        double adjusted = amount * incoming;

        adjusted *= (1.0D - resistTotal);
        int finalAmount = (int) Math.max(0, Math.round(adjusted));
        if (targetState != null) {
            finalAmount = targetState.absorbShield(finalAmount);
        } else {
            double shield = Math.max(0.0D, targetStats.get$shield());
            if (shield > 0.0D) finalAmount = (int) Math.max(0, Math.round(finalAmount - shield));
        }
        return finalAmount;
    }

    public static int applyMonsterIncomingModifiers(MonsterAI monster, int amount, boolean magical) {
        if (monster == null || monster.getState() == null || amount <= 0) return amount;
        double incomingMod = monster.getState().getMonsterIncDmg();
        double incomingMultiplier = Math.max(0.05D, 1.0D + incomingMod);
        double typedResist = magical ? monster.getState().getMonsterMagRes() : monster.getState().getMonsterPhysRes();
        double resistTotal = clamp(monster.getState().getMonsterAllRes() + typedResist, 0.0D, 0.80D);

        double adjusted = amount * incomingMultiplier;
        adjusted *= (1.0D - resistTotal);
        int finalAmount = (int) Math.max(0, Math.round(adjusted));

        if (monster.getState().getCurrentShield() <= 0 && monster.getState().getMonsterShieldValue() > 0.0D) {
            monster.getState().setCurrentShield((int) Math.max(0, Math.round(monster.getState().getMonsterShieldValue())));
        }
        return monster.getState().absorbShield(finalAmount);
    }

    public static double getDisplayedCritChance(Stats stats) {
        return clampDisplayedChance(getPlayerCritChance(stats));
    }

    public static double getDisplayedEvadeChance(Stats stats) {
        return clampDisplayedChance(stats != null ? stats.get_tdo() : 0.0D);
    }

    public static double getDisplayedHitChance(Stats stats) {
        double hit = stats != null ? stats.get_thi() : 0.0D;
        if (Double.isNaN(hit) || Double.isInfinite(hit)) return 0.0D;
        return Math.max(0.0D, Math.min(5.0D, hit));
    }

    public static double getDisplayedHaste(Stats stats) {
        double haste = stats != null ? stats.get_tha() : 0.0D;
        if (Double.isNaN(haste) || Double.isInfinite(haste)) return 0.0D;
        return Math.max(-0.50D, Math.min(0.50D, haste));
    }

    public static double scalarForSkill(SkillBean skill) {
        if (skill == null) return 1.0D;
        double v = Math.abs(skill.getDamage());
        if (v <= 0.0D) return 1.0D;
        if (v > 10.0D) v = v / 100.0D;
        if (v < 0.05D) v = 0.05D;
        if (v > 12.0D) v = 12.0D;
        return v;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
