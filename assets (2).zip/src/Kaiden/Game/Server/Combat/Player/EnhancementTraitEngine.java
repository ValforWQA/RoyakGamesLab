package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Database.Beans.AuraBean;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EnhancementTraitEngine {

    public static final int PROC_SPIRAL_CARVE = 2;
    public static final int PROC_AWE_BLAST = 3;
    public static final int PROC_HEALTH_VAMP = 4;
    public static final int PROC_MANA_VAMP = 5;
    public static final int PROC_POWERWORD_DIE = 6;
    public static final int PROC_LACERATE = 7;
    public static final int PROC_SMITE = 8;
    public static final int PROC_VALIANCE = 9;
    public static final int PROC_ARCANAS_CONCERTO = 10;
    public static final int PROC_ACHERON = 11;
    public static final int PROC_ELYSIUM = 12;
    public static final int PROC_PRAXIS = 13;
    public static final int PROC_DAUNTLESS = 14;
    public static final int PROC_RAVENOUS = 15;

    private EnhancementTraitEngine() {}

    @SuppressWarnings("unchecked")
    private static Map<String, Long> userExpiries(User user) {
        Map<String, Long> map = (Map<String, Long>) user.properties.get("enhTraitExpiries");
        if (map == null) {
            map = new ConcurrentHashMap<String, Long>();
            user.properties.put("enhTraitExpiries", map);
        }
        return map;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Integer> userStacks(User user) {
        Map<String, Integer> map = (Map<String, Integer>) user.properties.get("enhTraitStacks");
        if (map == null) {
            map = new ConcurrentHashMap<String, Integer>();
            user.properties.put("enhTraitStacks", map);
        }
        return map;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Long> userCooldowns(User user) {
        Map<String, Long> map = (Map<String, Long>) user.properties.get("enhTraitCooldowns");
        if (map == null) {
            map = new ConcurrentHashMap<String, Long>();
            user.properties.put("enhTraitCooldowns", map);
        }
        return map;
    }

    public static String normalizeEnhancementName(EnhancementBean enhancement) {
        if (enhancement == null || enhancement.getName() == null) return "";
        return enhancement.getName().trim().toLowerCase(Locale.US)
                .replace("’", "'")
                .replace("`", "'")
                .replace("  ", " ");
    }

    public static boolean isNamed(EnhancementBean enhancement, String... names) {
        String normalized = normalizeEnhancementName(enhancement);
        for (String name : names) {
            if (normalized.startsWith(name.toLowerCase(Locale.US))) return true;
        }
        return false;
    }

    public static boolean skillMatchesTrigger(String skillRef, String trigger) {
        String ref = skillRef == null ? "" : skillRef.trim().toLowerCase(Locale.US);
        String trg = trigger == null ? "" : trigger.trim().toLowerCase(Locale.US);

        if ("autoattack".equals(trg) || "aa".equals(trg)) return "aa".equals(ref);
        if ("second".equals(trg) || "a1".equals(trg)) return "a1".equals(ref);
        if ("third".equals(trg) || "a2".equals(trg)) return "a2".equals(ref);
        if ("fourth".equals(trg) || "a3".equals(trg)) return "a3".equals(ref);
        if ("fifth".equals(trg) || "a4".equals(trg)) return "a4".equals(ref);
        return trg.equals(ref);
    }

    public static boolean tryConsumeCooldown(User user, String key, long cooldownMs) {
        long now = System.currentTimeMillis();
        Map<String, Long> cds = userCooldowns(user);
        Long next = cds.get(key);
        if (next != null && next.longValue() > now) return false;
        cds.put(key, now + Math.max(0L, cooldownMs));
        return true;
    }

    public static void setUserEffect(User user, String key, int stacks, long durationMs) {
        if (user == null || key == null || key.trim().isEmpty()) return;
        long now = System.currentTimeMillis();
        userExpiries(user).put(key, now + Math.max(1L, durationMs));
        userStacks(user).put(key, Math.max(1, stacks));
    }

    public static int addUserStacks(User user, String key, int add, int maxStacks, long durationMs) {
        clearExpiredUserEffects(user);
        Map<String, Integer> stacks = userStacks(user);
        int next = Math.max(0, stacks.containsKey(key) ? stacks.get(key) : 0) + add;
        next = Math.min(maxStacks, next);
        setUserEffect(user, key, next, durationMs);
        return next;
    }

    public static boolean hasUserEffect(User user, String key) {
        clearExpiredUserEffects(user);
        Long expiry = userExpiries(user).get(key);
        return expiry != null && expiry.longValue() > System.currentTimeMillis();
    }

    public static int getUserStacks(User user, String key) {
        clearExpiredUserEffects(user);
        Integer stacks = userStacks(user).get(key);
        return stacks == null ? 0 : Math.max(0, stacks.intValue());
    }

    public static void clearExpiredUserEffects(User user) {
        if (user == null) return;
        long now = System.currentTimeMillis();
        Map<String, Long> expiries = userExpiries(user);
        Map<String, Integer> stacks = userStacks(user);
        for (Map.Entry<String, Long> e : expiries.entrySet()) {
            if (e.getValue() == null || e.getValue().longValue() <= now) {
                expiries.remove(e.getKey());
                stacks.remove(e.getKey());
            }
        }
    }

    public static int getProcId(EnhancementBean enhancement) {
        return enhancement == null ? 0 : enhancement.getProcId();
    }

    public static int getProcAuraId(int procId) {
        switch (procId) {
            case PROC_SPIRAL_CARVE: return EnhancementProcAuras.SPIRAL_CARVE;
            case PROC_AWE_BLAST: return EnhancementProcAuras.AWE_BLAST;
            case PROC_LACERATE: return EnhancementProcAuras.LACERATE;
            case PROC_VALIANCE: return EnhancementProcAuras.VALIANCE;
            case PROC_ARCANAS_CONCERTO: return EnhancementProcAuras.ARCANAS_CONCERTO;
            case PROC_ACHERON: return EnhancementProcAuras.ACHERON;
            case PROC_ELYSIUM: return EnhancementProcAuras.ELYSIUM;
            case PROC_PRAXIS: return EnhancementProcAuras.PRAXIS;
            case PROC_DAUNTLESS: return EnhancementProcAuras.DAUNTLESS;
            case PROC_RAVENOUS: return EnhancementProcAuras.RAVENOUS;
            default: return 0;
        }
    }

    public static boolean isProcAuraDriven(int procId) {
        return getProcAuraId(procId) > 0;
    }

    public static String getProcDisplayName(int procId) {
        switch (procId) {
            case PROC_SPIRAL_CARVE: return "Spiral Carve";
            case PROC_AWE_BLAST: return "Awe Blast";
            case PROC_HEALTH_VAMP: return "Health Vamp";
            case PROC_MANA_VAMP: return "Mana Vamp";
            case PROC_POWERWORD_DIE: return "Powerword DIE";
            case PROC_LACERATE: return "Laceration";
            case PROC_SMITE: return "Smite";
            case PROC_VALIANCE: return "Valiance";
            case PROC_ARCANAS_CONCERTO: return "Arcana's Concerto";
            case PROC_ACHERON: return "Stygian";
            case PROC_ELYSIUM: return "Elysian";
            case PROC_PRAXIS: return "Praxis";
            case PROC_DAUNTLESS: return "Dauntless";
            case PROC_RAVENOUS: return "Ravenous";
            default: return "";
        }
    }

    public static double getProcChance(EnhancementBean enhancement) {
        return getProcChance(getProcId(enhancement));
    }

    public static double getProcChance(int procId) {
        switch (procId) {
            case PROC_SPIRAL_CARVE: return 0.15D;
            case PROC_AWE_BLAST: return 0.30D;
            case PROC_HEALTH_VAMP: return 0.50D;
            case PROC_MANA_VAMP: return 0.80D;
            case PROC_POWERWORD_DIE: return 0.003D;
            case PROC_ARCANAS_CONCERTO: return 0.50D;
            default: return 1.0D;
        }
    }

    public static boolean skillMatchesProcTrigger(String skillRef, int procId) {
        switch (procId) {
            case PROC_SPIRAL_CARVE:
            case PROC_AWE_BLAST:
            case PROC_HEALTH_VAMP:
            case PROC_MANA_VAMP:
            case PROC_POWERWORD_DIE:
            case PROC_VALIANCE:
            case PROC_ARCANAS_CONCERTO:
             return skillMatchesTrigger(skillRef, "aa");
            case PROC_LACERATE:
            case PROC_PRAXIS:
            case PROC_DAUNTLESS:
            return skillMatchesTrigger(skillRef, "a1");
            case PROC_ACHERON:
            case PROC_ELYSIUM:
            case PROC_RAVENOUS:
            return skillMatchesTrigger(skillRef, "a2");
            case PROC_SMITE:
            return skillMatchesTrigger(skillRef, "a4");
            default:
                return false;
        }
    }

    public static double getProcChance(String normalizedName) {
        if (normalizedName.startsWith("spiral carve")) return 0.15D;
        if (normalizedName.startsWith("awe blast")) return 0.30D;
        if (normalizedName.startsWith("mana vamp")) return 0.80D;
        if (normalizedName.startsWith("health vamp")) return 0.50D;
        if (normalizedName.startsWith("powerword die")) return 0.003D;
        if (normalizedName.startsWith("arcana")) return 0.50D;
        return 1.0D;
    }

    public static void applyMonsterTimedDebuffs(MonsterState state) {
        if (state == null) return;
        state.clearExpiredTraitEffects();
    }


    public static boolean blocksAuraOnUser(User user, AuraBean aura) {
        if (user == null || aura == null || aura.getName() == null) return false;
        if (!hasUserEffect(user, "stygian")) return false;
        String name = aura.getName().trim().toLowerCase(Locale.US).replace("’", "'");
        return name.contains("arcane shield") || name.contains("safeguard");
    }

    public static void applyStygian(User user, int stacksToAdd) {
        int add = Math.max(1, stacksToAdd);
        addUserStacks(user, "stygian", add, 30, 6000L);
        setUserEffect(user, "acheron", 1, 6000L);
    }

    public static void tickUserTraitEffects(User user) {
        if (user == null) return;
        clearExpiredUserEffects(user);
        long now = System.currentTimeMillis();
        Long lastObj = (Long) user.properties.get("enhTraitLastTick");
        long last = lastObj == null ? now : lastObj.longValue();
        long elapsed = now - last;
        if (elapsed < 1000L) return;
        int ticks = (int) Math.min(10L, elapsed / 1000L);
        user.properties.put("enhTraitLastTick", now);

        State state = (State) user.properties.get("state");
        if (state == null) return;

        int stygianStacks = getUserStacks(user, "stygian");
        if (stygianStacks > 0) {
            for (int i = 0; i < ticks; i++) {
                int selfDot = (int) Math.max(1, Math.round(state.getMaxHealth() * (0.0010D * stygianStacks)));
                int perTickCap = (int) Math.max(1, Math.round(state.getMaxHealth() * 0.06D));
                selfDot = Math.min(selfDot, perTickCap);
                int maxAllowed = Math.max(0, state.getHealth() - 1);
                if (maxAllowed <= 0) {
                    break;
                }
                selfDot = Math.min(selfDot, maxAllowed);
                if (selfDot <= 0) {
                    break;
                }
                state.decreaseHealth(selfDot);
                if (state.isDead()) break;
            }
        }

        int elysianStacks = getUserStacks(user, "elysian");
        if (elysianStacks > 0 && !state.isDead()) {
            for (int i = 0; i < ticks; i++) {
                state.increaseMana(4 * elysianStacks);
                state.increaseHealth(Math.max(1, (int) Math.round(state.getMaxHealth() * 0.01D * elysianStacks)));
            }
        }
    }
    public static void applyElysian(User user, int targetsHit) {
        int add = Math.max(1, targetsHit);
        addUserStacks(user, "elysian", add, 3, 8000L);
        State state = (State) user.properties.get("state");
        if (state != null) {
            state.increaseMana(4 * add);
            state.increaseHealth(Math.max(1, (int) Math.round(state.getMaxHealth() * 0.01D * add)));
        }
    }

    public static void applyValiance(User user) {
        setUserEffect(user, "valiance", 1, 20000L);
    }

    public static void applySpiralCarve(User user) {
        setUserEffect(user, "spiralcarve", 1, 10000L);
    }

    public static void applyDauntless(User user) {
        setUserEffect(user, "dauntless", 1, 12000L);
        setUserEffect(user, "decay", 1, 6000L);
    }

    public static void applyRavenous(User user) {
        setUserEffect(user, "ravenous", 1, 10000L);
    }

    public static boolean targetIsMonster(String targetInf) {
        return targetInf != null && targetInf.startsWith("m:");
    }

    public static boolean targetIsPlayer(String targetInf) {
        return targetInf != null && targetInf.startsWith("p:");
    }

    public static void applyTargetDebuff(User userTarget, String key, int stacks, long durationMs) {
        if (userTarget == null) return;
        setUserEffect(userTarget, key, stacks, durationMs);
    }

    public static int addTargetDebuffStacks(User userTarget, String key, int add, int maxStacks, long durationMs) {
        if (userTarget == null) return 0;
        return addUserStacks(userTarget, key, add, maxStacks, durationMs);
    }

    public static void applyTargetDebuff(MonsterAI monster, String key, int stacks, long durationMs) {
        if (monster != null && monster.getState() != null) {
            monster.getState().setTraitEffect(key, stacks, durationMs);
        }
    }

    public static int addTargetDebuffStacks(MonsterAI monster, String key, int add, int maxStacks, long durationMs) {
        if (monster == null || monster.getState() == null) return 0;
        return monster.getState().addTraitStacks(key, add, maxStacks, durationMs);
    }
}
