package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Beans.SkillBean;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * AQW-style usable item handler for the action-bar potion slot.
 *
 * Flow:
 *   geia [Link, Meta, ItemID]
 *   seia loads Meta skill into action slot i1
 *   gar [actId, i1>target, ItemID, wvz]
 *
 * Direct-only:
 *   203 Health Potion
 *   204 Mana Potion
 *
 * Aura/combat handled by normal CombatAction:
 *   205 Potion of Speed
 *   207 Potion of Evasion
 *   228 Scroll of Ice Shard
 *   229 Scroll of Life Steal
 *   226 Scroll of Chain Lightning
 *   227 Scroll of Fireblast
 *   230 Scroll of Pangs
 *   246 Scroll of Fireball
 *   2651 Sleeping Potion
 */
public class PotionAffectHandler {

    public static final int HEALTH_POTION_META = 203;
    public static final int MANA_POTION_META = 204;

    private PotionAffectHandler() {
    }

    public static boolean isPotionSlot(SkillBean skill) {
        return skill != null && "i1".equalsIgnoreCase(safe(skill.getReference()));
    }

    public static boolean isUsableItem(ItemBean item) {
        if (item == null) return false;

        String link = safe(item.getLink()).toLowerCase();
        return "potion".equals(link) || "scroll".equals(link);
    }

    public static boolean isDirectPotion(ItemBean item) {
        if (item == null) return false;
        if (!"potion".equalsIgnoreCase(safe(item.getLink()))) return false;

        int meta = parseInt(item.getMeta(), -1);
        return meta == HEALTH_POTION_META || meta == MANA_POTION_META;
    }

    public static void validateEquippedItem(User user, SkillBean skill, ItemBean item) throws Exception {
        if (user == null) throw new Exception("Missing user.");
        if (skill == null) throw new Exception("Missing potion skill.");
        if (item == null) throw new Exception("Missing equipped potion item.");
        if (!isUsableItem(item)) throw new Exception("Item is not a potion or scroll.");

        int itemMeta = parseInt(item.getMeta(), -1);

        if (itemMeta != skill.getId()) {
            throw new Exception("Equipped item meta does not match loaded potion skill. itemMeta="
                    + itemMeta + ", skillId=" + skill.getId());
        }
    }

    public static boolean consumeEquippedItem(User user, ItemBean item) {
        if (user == null || item == null) return false;
        return Users.getInstance().turnInItem(user, item.getId(), 1);
    }

    public static boolean handleDirectPotion(User user, Room room, int actId, SkillBean skill, ItemBean item, String[] targets) throws Exception {
        validateEquippedItem(user, skill, item);

        if (!isDirectPotion(item)) {
            return false;
        }

        State state = (State) user.properties.get("state");
        if (state == null) throw new Exception("User state missing.");
        if (state.isDead()) throw new Exception("User is dead and cannot use potions.");

        if (!consumeEquippedItem(user, item)) {
            Users.getInstance().log(user, "Packet Edit [Potion]",
                    "TurnIn failed when using potion item " + item.getId() + ".");
            throw new Exception("TurnIn failed when using potion.");
        }

        int meta = parseInt(item.getMeta(), -1);
        String resultText;

        switch (meta) {
            case HEALTH_POTION_META: {
                int heal = calculateHealthPotionHeal(user, skill);
                state.increaseHealth(heal);
                resultText = "+" + heal + " HP";
                break;
            }

            case MANA_POTION_META: {
                int restore = Math.max(0, state.getMaxMana() - state.getMana());
                state.setMana(state.getMaxMana());
                resultText = "+" + restore + " MP";
                break;
            }

            default:
                return false;
        }

        sendPotionCombatPacket(user, room, actId, skill, item, state, targets, resultText);
        Users.getInstance().sendUotls(user, true, false, false, true, false, false, true);

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "[PotionEffect] " + user.getName()
                        + " used " + item.getName()
                        + " meta=" + meta
                        + " result=" + resultText
        );

        return true;
    }

    private static int calculateHealthPotionHeal(User user, SkillBean skill) {
        try {
            Stats stats = (Stats) user.properties.get("stats");

            if (stats != null) {
                stats.updateIfDirty();

                double scalar = skill == null ? 1.30D : Math.max(0.05D, skill.getDamage());
                return Math.max(1, stats.rollWeaponDamage(scalar));
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "orange",
                    "[PotionEffect] Health potion stat roll failed: " + e.getMessage()
            );
        }

        State state = (State) user.properties.get("state");
        return state == null ? 1 : Math.max(1, (int) Math.round(state.getMaxHealth() * 0.25D));
    }

    private static void sendPotionCombatPacket(User user, Room room, int actId, SkillBean skill, ItemBean item,
                                               State state, String[] targets, String resultText) {
        try {
            String target = firstTargetOrSelf(user, targets);
            String caster = "p:" + user.getUserId();

            JSONArray sarsa = new JSONArray();

            JSONObject sarsaAction = new JSONObject();
            sarsaAction.put("cInf", caster);
            sarsaAction.put("tInf", target);
            sarsaAction.put("a", new JSONArray());
            sarsaAction.put("actID", actId);
            sarsaAction.put("iRes", 1);
            sarsa.add(sarsaAction);

            JSONObject players = new JSONObject();
            players.put(user.getName(), state.getData());

            JSONObject ct = new JSONObject();
            ct.put("cmd", "ct");
            ct.put("m", new JSONObject());
            ct.put("a", new JSONArray());
            ct.put("p", players);
            ct.put("anims", buildPotionAnim(user, target, skill, item));
            ct.put("sarsa", sarsa);

            if (room != null) {
                Kaiden_Extension.getInstance().sendToRoomButOne(ct, user, room);
            }

            Kaiden_Extension.getInstance().send(ct, user);

            if (resultText != null && resultText.length() > 0) {
                Kaiden_Extension.getInstance().sendToUser(
                        "server",
                        item.getName() + " used: " + resultText,
                        user
                );
            }
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "orange",
                    "[PotionEffect] Failed to send potion packet: " + e.getMessage()
            );
        }
    }

    private static JSONArray buildPotionAnim(User user, String target, SkillBean skill, ItemBean item) {
        JSONArray anims = new JSONArray();

        JSONObject anim = new JSONObject();
        anim.put("cInf", "p:" + user.getUserId());
        anim.put("tInf", target);
        anim.put("animStr", skill == null ? "Cheer" : safeDefault(skill.getAnimation(), "Cheer"));
        anim.put("fx", skill == null ? "" : safe(skill.getEffects()));
        anim.put("strl", skill == null ? "none" : safeDefault(skill.getStrl(), "none"));
        anim.put("dsrc", skill == null ? "" : safe(skill.getDsrc()));
        anim.put("sMsg", item == null ? "Potion" : item.getName());

        anims.add(anim);
        return anims;
    }

    private static String firstTargetOrSelf(User user, String[] targets) {
        if (targets != null) {
            for (String target : targets) {
                if (target != null && target.trim().length() > 0) {
                    return target;
                }
            }
        }

        return "p:" + user.getUserId();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static String safeDefault(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) {
            return fallback;
        }

        return value;
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return fallback;
        }
    }
}