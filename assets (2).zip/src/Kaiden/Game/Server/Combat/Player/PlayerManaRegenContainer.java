package Kaiden.Game.Server.Combat.Player;

import Kaiden.Game.Server.Users.Utils.ClassCategory;
import Kaiden.Game.Server.Users.Utils.State;
import it.gotoandplay.smartfoxserver.data.User;

public class PlayerManaRegenContainer {
    private static PlayerManaRegenContainer instance;

    public static PlayerManaRegenContainer getInstance() {
        if (instance == null) instance = new PlayerManaRegenContainer();
        return instance;
    }

    public int applyDamageManaRegen(User user, int damage) {
        if (user == null || damage <= 0) return 0;
        State userState = (State) user.properties.get("state");
        if (userState == null || userState.isDead()) return 0;

        String cat = ClassCategory.normalizeCode((String) user.properties.get("classcat"));
        double procChance = getProcChance(cat, damage);
        if (Math.random() > procChance) return 0;

        double manaMultiplier = getManaMultiplier(cat);
        int manaRegen = (int) Math.round(damage * manaMultiplier);
        int minRegen = Math.max(2, (int) Math.round(userState.getMaxMana() * getMinPercent(cat)));
        int maxRegen = Math.max(minRegen, (int) Math.round(userState.getMaxMana() * getMaxPercent(cat)));
        manaRegen = Math.max(minRegen, Math.min(manaRegen, maxRegen));
        userState.increaseMana(manaRegen);
        return manaRegen;
    }

    private double getProcChance(String cat, int damage) {
        double base = 0.22D + Math.min(0.22D, damage / 2500.0D);
        if (ClassCategory.C1.equals(cat) || ClassCategory.C2.equals(cat)) base *= 1.10D;
        else if (ClassCategory.C3.equals(cat) || ClassCategory.M3.equals(cat) || ClassCategory.S1.equals(cat)) base *= 1.03D;
        return clamp(base, 0.18D, 0.48D);
    }

    private double getManaMultiplier(String cat) {
        if (ClassCategory.C1.equals(cat)) return 0.0506D; // 10% above 0.046
        if (ClassCategory.C2.equals(cat)) return 0.0484D; // 10% above 0.044
        if (ClassCategory.C3.equals(cat)) return 0.044D;
        if (ClassCategory.M3.equals(cat)) return 0.042D;
        if (ClassCategory.S1.equals(cat)) return 0.041D;
        if (ClassCategory.M2.equals(cat)) return 0.038D;
        if (ClassCategory.M4.equals(cat)) return 0.037D;
        return 0.036D;
    }

    private double getMinPercent(String cat) {
        if (ClassCategory.C1.equals(cat) || ClassCategory.C2.equals(cat)) return 0.030D;
        if (ClassCategory.C3.equals(cat) || ClassCategory.M3.equals(cat)) return 0.025D;
        return 0.020D;
    }

    private double getMaxPercent(String cat) {
        if (ClassCategory.C1.equals(cat) || ClassCategory.C2.equals(cat)) return 0.12D;
        if (ClassCategory.C3.equals(cat) || ClassCategory.M3.equals(cat) || ClassCategory.S1.equals(cat)) return 0.10D;
        return 0.085D;
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
