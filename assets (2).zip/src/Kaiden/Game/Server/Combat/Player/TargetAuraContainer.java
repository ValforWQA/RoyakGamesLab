package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Extension;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;

public class TargetAuraContainer {

    private static final Logger LOGGER = Logger.getLogger(TargetAuraContainer.class);
    private static TargetAuraContainer instance;
    private static final java.util.Set<String> EXCLUSIVE_CATEGORIES = new java.util.HashSet<String>(java.util.Arrays.asList(
            "stun", "stone", "freeze", "disabled"
    ));

    public static TargetAuraContainer getInstance() {
        if (instance == null) instance = new TargetAuraContainer();
        return instance;
    }

    public JSONObject applyAuraToUser(User userTgt, int auraId, String fromTarget, int damage) {
        try {
            CombatTrace.info("TargetAura.applyUser", "start target=" + CombatTrace.who(userTgt) + ", auraId=" + auraId + ", from=" + fromTarget + ", damage=" + damage);
            JSONObject aInfo = new JSONObject();
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null || userTgt == null) {
                CombatTrace.warn("TargetAura.applyUser", "missing aura or target auraId=" + auraId);
                return null;
            }

            if (!rollAuraChance(aura)) {
                CombatTrace.warn("TargetAura.applyMonster", "chance failed " + CombatTrace.aura(aura));
                CombatTrace.warn("TargetAura.applyUser", "chance failed " + CombatTrace.aura(aura));
                aInfo.put("cInf", fromTarget);
                aInfo.put("cmd", "aura*");
                aInfo.put("auras", "*");
                aInfo.put("tInf", "p:" + userTgt.getUserId());
                return aInfo;
            }

            State userState = (State) userTgt.properties.get("state");
            if (userState == null) {
                CombatTrace.warn("TargetAura.applyUser", "missing state for " + CombatTrace.who(userTgt));
                return null;
            }

            int maxStacks = Math.max(1, aura.getStack());
            String sourceKey = fromTarget == null ? "" : fromTarget.trim().toLowerCase();

            aInfo.put("cInf", fromTarget);
            aInfo.put("cmd", "aura+");
            aInfo.put("tInf", "p:" + userTgt.getUserId());

            RemoveAura ra = Users.getInstance().applyAura(userTgt, aura, sourceKey);
            if (ra == null) {
                CombatTrace.warn("TargetAura.applyUser", "applyAura returned null " + CombatTrace.aura(aura));
                return null;
            }

            int resultingTotal = userState.getAuraStackCount(aura.getId());
            int resultingSource = sourceKey.isEmpty() ? resultingTotal : userState.getAuraStackCountBySource(aura.getId(), sourceKey);
            if (resultingTotal > maxStacks || resultingSource > maxStacks) {
                CombatTrace.warn("TargetAura.applyUser", "stack overflow rollback " + CombatTrace.aura(ra));
                Users.getInstance().removeAura(userTgt, ra);
                ra.cancel();
                return null;
            }

            aInfo.put("auras", aura.getAuraArray(resultingTotal == 1, ra.getRemainingDurationSeconds()));
            if (!ra.isRefreshedOnly()) {
                applyStatEffectsToUser(ra, aura, userTgt);
                PlayerCombatContainer.getInstance().applyAuraCategorySideEffects(ra, aura, userTgt, null, damage, fromTarget);
            } else {
                CombatTrace.info("TargetAura.applyUser", "refreshed existing aura without duplicate side effects " + CombatTrace.aura(ra));
            }
            CombatTrace.info("TargetAura.applyUser", "success " + CombatTrace.aura(ra) + ", target=" + CombatTrace.who(userTgt) + ", totalStacks=" + userState.getAuraStackCount(aura.getId()) + "/" + maxStacks + ", refreshed=" + ra.isRefreshedOnly());
            return aInfo;
        } catch (Throwable ignored) {
            CombatTrace.error("TargetAura.applyUser", ignored);
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] applyAuraToUser failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
            return null;
        }
    }

    public JSONObject applyAuraToMonster(MonsterAI ai, int auraId, String fromTarget, int damage) {
        try {
            CombatTrace.info("TargetAura.applyUser", "start target=" + CombatTrace.who(ai) + ", auraId=" + auraId + ", from=" + fromTarget + ", damage=" + damage);
            JSONObject aInfo = new JSONObject();
            AuraBean aura = StorageCache.getInstance().getAura(auraId);
            if (aura == null || ai == null) {
                CombatTrace.warn("TargetAura.applyMonster", "missing aura or monster auraId=" + auraId);
                return null;
            }

            if (!rollAuraChance(aura)) {
                CombatTrace.warn("TargetAura.applyUser", "chance failed " + CombatTrace.aura(aura));
                aInfo.put("cInf", fromTarget);
                aInfo.put("cmd", "aura*");
                aInfo.put("auras", "*");
                aInfo.put("tInf", "m:" + ai.getMapMonster().getMonMapId());
                return aInfo;
            }

            State monsterState = ai.getState();
            if (monsterState == null) {
                CombatTrace.warn("TargetAura.applyMonster", "missing state for " + CombatTrace.who(ai));
                return null;
            }

            int maxStacks = Math.max(1, aura.getStack());
            String sourceKey = fromTarget == null ? "" : fromTarget.trim().toLowerCase();

            aInfo.put("cInf", fromTarget);
            aInfo.put("cmd", "aura+");
            aInfo.put("tInf", "m:" + ai.getMapMonster().getMonMapId());

            RemoveAura ra = ai.getState().applyAura(aura, sourceKey);
            if (ra == null) {
                CombatTrace.warn("TargetAura.applyMonster", "applyAura returned null " + CombatTrace.aura(aura));
                return null;
            }

            int resultingTotal = monsterState.getAuraStackCount(aura.getId());
            int resultingSource = sourceKey.isEmpty() ? resultingTotal : monsterState.getAuraStackCountBySource(aura.getId(), sourceKey);
            if (resultingTotal > maxStacks || resultingSource > maxStacks) {
                CombatTrace.warn("TargetAura.applyMonster", "stack overflow rollback " + CombatTrace.aura(ra));
                monsterState.removeAura(ra);
                ra.cancel();
                return null;
            }

            aInfo.put("auras", aura.getAuraArray(resultingTotal == 1, ra.getRemainingDurationSeconds()));
            if (!ra.isRefreshedOnly()) {
                PlayerCombatContainer.getInstance().applyAuraCategorySideEffects(ra, aura, null, ai, damage, fromTarget);
            } else {
                CombatTrace.info("TargetAura.applyMonster", "refreshed existing aura without duplicate side effects " + CombatTrace.aura(ra));
            }
            CombatTrace.info("TargetAura.applyMonster", "success " + CombatTrace.aura(ra) + ", target=" + CombatTrace.who(ai) + ", totalStacks=" + monsterState.getAuraStackCount(aura.getId()) + "/" + maxStacks + ", refreshed=" + ra.isRefreshedOnly());
            return aInfo;
        } catch (Throwable ignored) {
            CombatTrace.error("TargetAura.applyMonster", ignored);
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] applyAuraToMonster failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
            return null;
        }
    }

    public void applyStatEffectsToUser(RemoveAura ra, AuraBean aura, User userTgt) {
        if (ra == null || aura == null || userTgt == null || aura.effects == null || aura.effects.isEmpty()) return;
        Stats stats = (Stats) userTgt.properties.get("stats");
        State state = (State) userTgt.properties.get("state");
        if (stats == null) return;

        Set<AuraEffectsBean> changed = new HashSet<AuraEffectsBean>();
        for (int effectId : aura.effects) {
            AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
            if (ae == null) continue;
            if (!stats.hasEffect(ae)) {
                stats.addEffect(ae);
                changed.add(ae);
            }
            ra.addAppliedEffect(ae);
        }
        if (!changed.isEmpty() || !ra.isRefreshedOnly()) {
            if (changed.isEmpty()) {
                for (int effectId : aura.effects) {
                    AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                    if (ae != null) changed.add(ae);
                }
            }
            CombatTrace.info("TargetAura.statUser", "applying/recalculating effects count=" + changed.size() + ", target=" + CombatTrace.who(userTgt) + ", aura=" + CombatTrace.aura(aura) + ", stacks=" + ra.getStackCount());
            stats.markDirty();
            stats.update();
            try {
                if (state != null && stats.get$shield() > 0.0D && state.getCurrentShield() <= 0) {
                    state.setCurrentShield((int) Math.max(0, Math.round(stats.get$shield())));
                }
            } catch (Throwable ignored) {}
            try { stats.sendStatChanges(changed); } catch (Throwable ignored) {}
            try { Users.getInstance().sendStats(userTgt); } catch (Throwable ignored) {}
        }
    }


    private boolean isCategoryExclusiveAndActiveOnUser(State state, AuraBean aura) {
        if (state == null || aura == null) return false;
        String cat = normalizedCategory(aura);
        return EXCLUSIVE_CATEGORIES.contains(cat) && state.hasAuraCategory(cat, -1L);
    }

    private boolean isCategoryExclusiveAndActiveOnMonster(State state, AuraBean aura) {
        if (state == null || aura == null) return false;
        String cat = normalizedCategory(aura);
        return EXCLUSIVE_CATEGORIES.contains(cat) && state.hasAuraCategory(cat, -1L);
    }

    private String normalizedCategory(AuraBean aura) {
        if (aura == null || aura.getCategory() == null) return "";
        String cat = aura.getCategory().trim().toLowerCase();
        return "d".equals(cat) ? "dot" : cat;
    }

    private boolean rollAuraChance(AuraBean aura) {
        double chance = 1.0D;
        try {
            if (aura != null) chance = aura.getAuraChance();
        } catch (Exception e) { LOGGER.error("TargetAuraContainer exception", e); }
        if (chance >= 1.0D) return true;
        if (chance <= 0.0D) return false;
        return Math.random() < chance;
    }
}