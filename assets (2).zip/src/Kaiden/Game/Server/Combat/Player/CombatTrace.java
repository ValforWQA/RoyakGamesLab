package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import it.gotoandplay.smartfoxserver.data.User;

public final class CombatTrace {
    private CombatTrace() {}

    private static final int MAX_LEN = 220;

    private static String trim(String value) {
        if (value == null) return "null";
        String clean = value.replace("\n", " ").replace("\r", " ");
        return clean.length() > MAX_LEN ? clean.substring(0, MAX_LEN) + "..." : clean;
    }

    /**
     * Trace logging is intentionally muted.
     *
     * The old CombatTrace logs were too noisy during normal combat:
     * CombatAction.handle/process/target, TargetAura, State.addAura/removeAura,
     * RemoveAura, and Stats.update all passed through this helper.
     * Keep these methods as no-ops so existing call sites compile, but do not spam the emulator log.
     */
    public static void log(String color, String area, String message) {
        // muted
    }

    public static void info(String area, String message) {
        // muted
    }

    public static void warn(String area, String message) {
        // muted
    }

    public static void error(String area, Throwable t) {
        // muted
    }

    public static void charm(String area, String message) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[Charm][" + area + "] " + trim(message)
            );
        } catch (Throwable ignored) {
        }
    }

    public static boolean isCharmAura(AuraBean aura) {
        if (aura == null) return false;
        try {
            String cat = aura.getCategory() == null ? "" : aura.getCategory().trim().toLowerCase();
            if ("charm".equals(cat)) return true;
        } catch (Throwable ignored) {}
        try {
            if (aura.effects != null) {
                for (Integer effectId : aura.effects) {
                    if (effectId == null) continue;
                    Kaiden.Database.Beans.AuraEffectsBean ae = Kaiden.Database.StorageCache.getInstance().getAuraEffect(effectId);
                    if (ae == null || ae.getStat() == null) continue;
                    String stat = ae.getStat().trim().toLowerCase();
                    if ("charm".equals(stat) || "monster_charm".equals(stat) || "monster_confuse".equals(stat)) {
                        return true;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public static String who(User user) {
        if (user == null) return "user:null";
        try {
            return "user:" + user.getName() + "#" + user.getUserId();
        } catch (Throwable ignored) {
            return "user:unknown";
        }
    }

    public static String who(MonsterAI ai) {
        if (ai == null) return "monster:null";
        try {
            return "monster:" + ai.getMonster().getName() + "#" + ai.getMapMonster().getMonMapId();
        } catch (Throwable ignored) {
            return "monster:unknown";
        }
    }

    public static String aura(RemoveAura ra) {
        if (ra == null) return "aura:null";
        AuraBean aura = ra.getAura();
        return aura(aura) + ",stackCount=" + ra.getStackCount() + ",instance=" + ra.getInstanceId() + ",src=" + trim(ra.getSourceInf()) + ",remaining=" + ra.getRemainingDurationSeconds() + "s";
    }

    public static String aura(AuraBean aura) {
        if (aura == null) return "aura:null";
        String cat = aura.getCategory() == null ? "" : aura.getCategory();
        return "aura:" + aura.getName() + "#" + aura.getId() + ",cat=" + trim(cat) + ",dur=" + aura.getDuration() + "s,stack=" + aura.getStack();
    }

    public static String state(State state) {
        if (state == null) return "state:null";
        try {
            return "hp=" + state.getHealth() + "/" + state.getMaxHealth()
                    + ",mp=" + state.getMana() + "/" + state.getMaxMana()
                    + ",auras=" + state.getAuras().size()
                    + ",combat=" + state.onCombat()
                    + ",dead=" + state.isDead();
        } catch (Throwable ignored) {
            return "state:unavailable";
        }
    }
}
