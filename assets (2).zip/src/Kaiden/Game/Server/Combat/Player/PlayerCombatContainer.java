package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.External.Combat.CombatAction;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Threads.DamageOverTime;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.HealOverTime;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class PlayerCombatContainer extends CombatAction {

    private static PlayerCombatContainer instance;

    public static PlayerCombatContainer getInstance() {
        if (instance == null) {
            instance = new PlayerCombatContainer();
        }
        return instance;
    }

    public String normalizeAuraCategory(AuraBean aura) {
        if (aura == null || aura.getCategory() == null) return "";
        String cat = aura.getCategory().trim().toLowerCase();
        return "d".equals(cat) ? "dot" : cat;
    }

    public boolean isCategoryExclusive(String category) {
        if (category == null) return false;
        switch (category) {
            case "stun":
            case "freeze":
            case "frozen":
            case "stone":
            case "disabled":
            case "disable":
                return true;
            default:
                return false;
        }
    }

    public RemoveAura findCategoryAura(Set<RemoveAura> auras, AuraBean aura) {
        if (auras == null || aura == null) return null;
        String incoming = normalizeAuraCategory(aura);
        if (!isCategoryExclusive(incoming)) return null;

        RemoveAura best = null;
        long bestEnd = Long.MAX_VALUE;
        for (RemoveAura ra : auras) {
            if (ra == null || ra.getAura() == null) continue;
            String existing = normalizeAuraCategory(ra.getAura());
            if (!incoming.equals(existing)) continue;
            long end = ra.getEndTime();
            if (best == null || end < bestEnd) {
                best = ra;
                bestEnd = end;
            }
        }
        return best;
    }

    public void applyAuraCategorySideEffects(RemoveAura ra, AuraBean aura, User userTgt, MonsterAI monTgt, int damage, String fromTarget) {
        try {
            if (aura == null) return;
            CombatTrace.info("PlayerCombat.sideEffects", "start " + CombatTrace.aura(aura) + ", userTarget=" + CombatTrace.who(userTgt) + ", monTarget=" + CombatTrace.who(monTgt) + ", damage=" + damage + ", from=" + fromTarget);

            String cat = (aura.getCategory() == null)
                    ? ""
                    : aura.getCategory().trim().toLowerCase();

            if (cat.isEmpty()) return;

            if (cat.equals("d")) cat = "dot";

            int tick = Math.max(1, Math.abs(damage));
            long duration = Math.max(1L, aura.getDuration());

            switch (cat) {
                case "clean":
                case "cleanse":
                case "purify":
                    if (userTgt != null) cleanseNegativeAurasUser(userTgt);
                    if (monTgt != null) cleanseNegativeAurasMonster(monTgt);
                    break;

                case "dot":
                    applyDot(ra, userTgt, monTgt, tick, duration, fromTarget);
                    break;

                case "poison":
                case "burn":
                case "bleed":
                    applyDot(ra, userTgt, monTgt, tick, duration, fromTarget);
                    if (userTgt != null) sendFxUser(userTgt, aura.getCategory(), 1);
                    if (monTgt != null) sendFxMonster(monTgt, aura.getCategory(), 1);
                    break;

                case "hot":
                case "regen":
                case "healhot":
                    applyHot(ra, aura, userTgt, monTgt, tick, duration, fromTarget);
                    break;

                case "stun":
                case "stone":
                case "freeze":
                case "frozen":
                case "disabled":
                case "disable":
                    applyHardCC(userTgt, monTgt);
                    if (userTgt != null) sendFxUser(userTgt, aura.getCategory(), 1);
                    if (monTgt != null) sendFxMonster(monTgt, aura.getCategory(), 1);
                    break;

                case "buff":
                    pushAuraStatEffectsToTargets(aura, userTgt, monTgt);
                    // optional client FX "buff"
                    // if (userTgt != null) sendFxUser(userTgt, "buff", 1);
                    // if (monTgt != null) sendFxMonster(monTgt, "buff", 1);
                    break;

                case "debuff":
                    pushAuraStatEffectsToTargets(aura, userTgt, monTgt);
                    // optional client FX "debuff"
                    // if (userTgt != null) sendFxUser(userTgt, "debuff", 1);
                    // if (monTgt != null) sendFxMonster(monTgt, "debuff", 1);
                    break;

                case "physicalresist":
                case "magicalresist":
                case "allresist":
                case "outgoingdamageup":
                case "outgoingdamagedown":
                case "incomingdamageup":
                case "incomingdamagedown":
                case "manafeed":
                case "shield":
                case "trigger_ondamagetaken":
                case "trigger_ondamagedealt":
                    pushAuraStatEffectsToTargets(aura, userTgt, monTgt);
                    break;

                case "consume":
                    break;

                default:
                    break;
            }
            CombatTrace.info("PlayerCombat.sideEffects", "done " + CombatTrace.aura(aura));
        } catch (Exception ignored) {
            CombatTrace.error("PlayerCombat.sideEffects", ignored);
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }


    private void applyDot(RemoveAura ra, User userTgt, MonsterAI monTgt, int tick, long duration, String fromTarget) {
        try {
            if (ra == null || ra.getAura() == null) return;

            int auraId = ra.getAura().getId();
            long excludingId = ra.getInstanceId();

            DamageOverTime dot = null;

            if (userTgt != null) {
                if (hasActiveDotFromCaster(userTgt, auraId, fromTarget, excludingId)) return;
                dot = new DamageOverTime(userTgt, auraId, tick, fromTarget, auraIsSelfTarget(ra));
            } else if (monTgt != null) {
                if (hasActiveDotFromCaster(monTgt, auraId, fromTarget, excludingId)) return;
                dot = new DamageOverTime(monTgt, auraId, tick, fromTarget);
            }

            if (dot != null) {
                dot.setRunning(Executor.getInstance().scheduleTask(dot, 2L, TimeUnit.SECONDS, true));
                ra.setDot(dot);
                CombatTrace.info("PlayerCombat.applyDot", CombatTrace.aura(ra) + ", tick=" + tick + ", duration=" + duration + ", from=" + fromTarget);
            }
        } catch (Exception ignored) {
            CombatTrace.error("PlayerCombat.applyDot", ignored);
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }


    private boolean auraIsSelfTarget(RemoveAura ra) {
        try {
            return ra != null && ra.getAura() != null && ra.getAura().isSelfTarget();
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean hasActiveDotFromCaster(User userTgt, int auraId, String fromTarget, long excludingInstanceId) {
        try {
            @SuppressWarnings("unchecked")
            Set<RemoveAura> auras = (Set<RemoveAura>) userTgt.properties.get("auras");
            if (auras == null) return false;
            String wanted = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            for (RemoveAura existing : auras) {
                if (existing == null || existing.getAura() == null) continue;
                if (existing.getInstanceId() == excludingInstanceId) continue;
                if (existing.getAura().getId() != auraId) continue;
                long end = existing.getEndTime();
                if (end > 0L && end <= now) continue;
                String src = existing.getSourceInf() == null ? "" : existing.getSourceInf().trim().toLowerCase();
                if (!wanted.equals(src)) continue;
                if (existing.getDot() != null) return true;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return false;
    }

    private boolean hasActiveDotFromCaster(MonsterAI monTgt, int auraId, String fromTarget, long excludingInstanceId) {
        try {
            if (monTgt == null || monTgt.getState() == null) return false;
            Set<RemoveAura> auras = monTgt.getState().getAuras();
            if (auras == null) return false;
            String wanted = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            for (RemoveAura existing : auras) {
                if (existing == null || existing.getAura() == null) continue;
                if (existing.getInstanceId() == excludingInstanceId) continue;
                if (existing.getAura().getId() != auraId) continue;
                long end = existing.getEndTime();
                if (end > 0L && end <= now) continue;
                String src = existing.getSourceInf() == null ? "" : existing.getSourceInf().trim().toLowerCase();
                if (!wanted.equals(src)) continue;
                if (existing.getDot() != null) return true;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return false;
    }

    private boolean hasActiveHotFromCaster(User userTgt, int auraId, String fromTarget, long excludingInstanceId) {
        try {
            @SuppressWarnings("unchecked")
            Set<RemoveAura> auras = (Set<RemoveAura>) userTgt.properties.get("auras");
            if (auras == null) return false;
            String wanted = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            for (RemoveAura existing : auras) {
                if (existing == null || existing.getAura() == null) continue;
                if (existing.getInstanceId() == excludingInstanceId) continue;
                if (existing.getAura().getId() != auraId) continue;
                long end = existing.getEndTime();
                if (end > 0L && end <= now) continue;
                String src = existing.getSourceInf() == null ? "" : existing.getSourceInf().trim().toLowerCase();
                if (!wanted.equals(src)) continue;
                if (existing.getHot() != null || existing.getHotRunning() != null) return true;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return false;
    }

    private boolean hasActiveHotFromCaster(MonsterAI monTgt, int auraId, String fromTarget, long excludingInstanceId) {
        try {
            if (monTgt == null || monTgt.getState() == null) return false;
            Set<RemoveAura> auras = monTgt.getState().getAuras();
            if (auras == null) return false;
            String wanted = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            for (RemoveAura existing : auras) {
                if (existing == null || existing.getAura() == null) continue;
                if (existing.getInstanceId() == excludingInstanceId) continue;
                if (existing.getAura().getId() != auraId) continue;
                long end = existing.getEndTime();
                if (end > 0L && end <= now) continue;
                String src = existing.getSourceInf() == null ? "" : existing.getSourceInf().trim().toLowerCase();
                if (!wanted.equals(src)) continue;
                if (existing.getHot() != null || existing.getHotRunning() != null) return true;
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return false;
    }


    private double getAuraEffectValue(AuraBean aura, String... stats) {
        if (aura == null || aura.effects == null || aura.effects.isEmpty() || stats == null) return 0.0D;
        for (int effectId : aura.effects) {
            AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
            if (ae == null || ae.getStat() == null) continue;
            String stat = ae.getStat().trim().toLowerCase();
            for (String wanted : stats) {
                if (wanted != null && stat.equals(wanted.toLowerCase())) {
                    return ae.getValue();
                }
            }
        }
        return 0.0D;
    }


    private User resolveCasterUser(String fromTarget) {
        try {
            String src = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
            if (src.startsWith("p:")) {
                int uid = Integer.parseInt(src.substring(2));
                return Kaiden_Extension.getInstance().getHelper().getUserById(uid);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return null;
    }

    private int resolveEnhancementLevelFromSource(String fromTarget, User userTgt) {
        int enhLevel = 1;
        try {
            User caster = resolveCasterUser(fromTarget);
            if (caster != null) {
                Kaiden.Database.Beans.EnhancementBean enh = (Kaiden.Database.Beans.EnhancementBean) caster.properties.get("weaponitemenhancement");
                if (enh != null) return Math.max(1, enh.getLevel());
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        try {
            Kaiden.Database.Beans.EnhancementBean enh = (Kaiden.Database.Beans.EnhancementBean) userTgt.properties.get("weaponitemenhancement");
            if (enh != null) enhLevel = Math.max(1, enh.getLevel());
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return enhLevel;
    }

    private double resolveCasterHealingBoost(String fromTarget) {
        try {
            User caster = resolveCasterUser(fromTarget);
            if (caster != null) {
                Stats casterStats = (Stats) caster.properties.get("stats");
                if (casterStats != null) {
                    return Math.max(0.0D, casterStats.get$cho());
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return 1.0D;
    }

    private int resolveHotTick(AuraBean aura, User userTgt, int fallbackTick, String fromTarget) {
        int tick = Math.max(1, fallbackTick);
        try {
            State state = (State) userTgt.properties.get("state");
            Stats targetStats = (Stats) userTgt.properties.get("stats");
            double hotValue = getAuraEffectValue(aura, "hot", "regen", "healhot");
            int enhLevel = resolveEnhancementLevelFromSource(fromTarget, userTgt);
            double casterHealBoost = resolveCasterHealingBoost(fromTarget);
            double targetHealIntake = targetStats != null ? Math.max(0.0D, targetStats.get$chi()) : 1.0D;

            if (state != null && hotValue > 0.0D) {
                double pct = hotValue > 1.0D ? (hotValue / 100.0D) : hotValue;
                if (pct <= 0.0D) pct = 0.01D;
                double base = Math.max(2.0D, Math.max(state.getMaxHealth() * pct, (targetStats != null ? ((targetStats.get$WIS() * 0.015D) + (targetStats.get$INT() * 0.012D)) : 0.0D)));
                double enhancementScale = 1.0D + Math.min(0.25D, enhLevel / 600.0D);
                double roll = 0.92D + (Math.random() * 0.16D);
                double scaled = base * enhancementScale * roll;
                if (casterHealBoost > 0.0D) {
                    scaled *= Math.min(1.60D, casterHealBoost);
                }
                if (targetHealIntake > 0.0D) {
                    scaled *= Math.min(1.60D, targetHealIntake);
                }
                int perTickCap = (int) Math.max(2, Math.round(state.getMaxHealth() * 0.08D));
                tick = (int) Math.max(1, Math.round(Math.min(scaled, perTickCap)));
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return Math.max(2, tick);
    }

    private int resolveMonsterHotTick(AuraBean aura, MonsterAI monTgt, int fallbackTick) {
        int tick = Math.max(1, fallbackTick);
        try {
            if (monTgt != null && monTgt.getState() != null) {
                double hotValue = getAuraEffectValue(aura, "hot", "regen", "healhot");
                if (hotValue > 0.0D) {
                    double pct = hotValue > 1.0D ? (hotValue / 100.0D) : hotValue;
                    double base = Math.max(2.0D, monTgt.getState().getMaxHealth() * pct);
                    double scaled = base * (0.80D + (Math.random() * 0.40D));
                    int perTickCap = (int) Math.max(2, Math.round(monTgt.getState().getMaxHealth() * 0.08D));
                    tick = (int) Math.max(1, Math.round(Math.min(scaled, perTickCap)));
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
        return Math.max(2, tick);
    }

    private void applyHot(RemoveAura ra, AuraBean aura, User userTgt, MonsterAI monTgt, int tick, long duration, String fromTarget) {
        try {
            if (ra == null || aura == null) return;
            int auraId = aura.getId();
            long excludingId = ra.getInstanceId();

            if (userTgt != null) {
                if (hasActiveHotFromCaster(userTgt, auraId, fromTarget, excludingId)) return;
                int resolvedTick = resolveHotTick(aura, userTgt, tick, fromTarget);
                HealOverTime hot = new HealOverTime(userTgt, auraId, resolvedTick, fromTarget);
                hot.setRunning(Executor.getInstance().scheduleTask(hot, 2L, TimeUnit.SECONDS, true));
                ra.setHot(hot);
            } else if (monTgt != null && monTgt.getState() != null) {
                if (hasActiveHotFromCaster(monTgt, auraId, fromTarget, excludingId)) return;
                final ScheduledFuture<?>[] ref = new ScheduledFuture<?>[1];
                ref[0] = Executor.getInstance().scheduleTask(() -> {
                    try {
                        java.util.Set<RemoveAura> active = monTgt.getState() != null ? monTgt.getState().getAuras() : null;
                        boolean linked = false;
                        String wanted = fromTarget == null ? "" : fromTarget.trim().toLowerCase();
                        long now = System.currentTimeMillis();
                        if (active != null) {
                            for (RemoveAura existing : active) {
                                if (existing == null || existing.getAura() == null) continue;
                                if (existing.getAura().getId() != auraId) continue;
                                long end = existing.getEndTime();
                                if (end > 0L && end <= now) continue;
                                String src = existing.getSourceInf() == null ? "" : existing.getSourceInf().trim().toLowerCase();
                                if (wanted.equals(src)) { linked = true; break; }
                            }
                        }
                        if (!linked) {
                            try { if (ref[0] != null) ref[0].cancel(false); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                            return;
                        }
                        if (!monTgt.getState().isDead()) {
                            int resolvedTick = resolveMonsterHotTick(aura, monTgt, tick);
                            monTgt.getState().increaseHealth(resolvedTick);
                        }
                    } catch (Throwable ignored) {
                        Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] throwable: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
                    }
                }, 2L, TimeUnit.SECONDS, true);
                ra.setHotRunning(ref[0]);
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void applyHardCC(User userTgt, MonsterAI monTgt) {
        if (userTgt != null) {
            State s = (State) userTgt.properties.get("state");
            if (s != null) {
                s.isDisabled();
            }
        }

        if (monTgt != null && monTgt.getState() != null) {
            monTgt.getState().isDisabled();
        }
    }

    private void cleanseNegativeAurasMonster(MonsterAI ai) {
        try {
            if (ai == null || ai.getState() == null) return;

            Set<RemoveAura> auras = ai.getState().getAuras();
            if (auras == null || auras.isEmpty()) return;

            List<RemoveAura> copy = new ArrayList<RemoveAura>(auras);

            for (RemoveAura ra : copy) {
                if (ra == null || ra.getAura() == null) continue;

                String cat = ra.getAura().getCategory();
                if (isNegativeAuraCategory(cat)) {

                    if (ra.getDot() != null) {
                        try { ra.getDot().cancel(); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                    }

                    ra.run();
                }
            }

        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private void cleanseNegativeAurasUser(User target) {
        try {
            @SuppressWarnings("unchecked")
            Set<RemoveAura> auras =
                    (Set<RemoveAura>) target.properties.get("auras");

            if (auras == null || auras.isEmpty()) return;

            List<RemoveAura> copy = new ArrayList<RemoveAura>(auras);

            for (RemoveAura ra : copy) {
                if (ra == null || ra.getAura() == null) continue;

                String cat = ra.getAura().getCategory();
                if (isNegativeAuraCategory(cat)) {

                    if (ra.getDot() != null) {
                        try { ra.getDot().cancel(); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                    }

                    ra.run();
                }
            }

        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

    private boolean isNegativeAuraCategory(String cat) {
        if (cat == null) return false;

        String c = cat.trim().toLowerCase();

        switch (c) {
            case "debuff":
            case "dot":
            case "poison":
            case "burn":
            case "bleed":
            case "stun":
            case "stone":
            case "freeze":
            case "frozen":
            case "disabled":
            case "disable":
            case "d":
                return true;

            default:
                return false;
        }

    }
    private void applyStatEffectsIfAny(AuraBean aura, User userTgt) {
        pushAuraStatEffectsToTargets(aura, userTgt, null);
    }

    public void pushAuraStatEffectsToTargets(AuraBean aura, User userTgt, MonsterAI monTgt) {
        try {
            if (aura == null || aura.effects == null || aura.effects.isEmpty()) return;

            if (userTgt != null) {
                Stats stats = (Stats) userTgt.properties.get("stats");
                if (stats != null) {
                    Set<AuraEffectsBean> auraEffects = new HashSet<AuraEffectsBean>();
                    for (int effectId : aura.effects) {
                        AuraEffectsBean ae = null;
                        try { ae = StorageCache.getInstance().getAuraEffect(effectId); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                        if (ae == null) continue;
                        String statName = ae.getStat() == null ? "" : ae.getStat().trim().toLowerCase();
                        //Kaiden_Engine.getInstance().sendEmulatorMessage("green", "pushing" + statName);
                        if (!stats.hasEffect(ae)) {
                            stats.addEffect(ae);
                            auraEffects.add(ae);
                        }
                    }

                    if (!auraEffects.isEmpty()) {
                        stats.update();
                        try {
                            State state = (State) userTgt.properties.get("state");
                            if (state != null && stats.get$shield() > 0.0D && state.getCurrentShield() <= 0) {
                                state.setCurrentShield((int) Math.max(0, Math.round(stats.get$shield())));
                            }
                        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                        stats.sendStatChanges(auraEffects);
                        Users.getInstance().sendStats(userTgt);
                    }
                }
            }

            if (monTgt != null && monTgt.getState() != null) {
                for (int effectId : aura.effects) {
                    AuraEffectsBean ae = null;
                    try { ae = StorageCache.getInstance().getAuraEffect(effectId); } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
                    if (ae == null) continue;
                    String statName = ae.getStat() == null ? "" : ae.getStat().trim().toLowerCase();
                    //Kaiden_Engine.getInstance().sendEmulatorMessage("green", "pushing" + statName);
                }
                int shield = monTgt.getState().getMonsterShieldValue();
                if (shield > 0 && monTgt.getState().getCurrentShield() <= 0) {
                    monTgt.getState().setCurrentShield(shield);
                }
            }
        } catch (Exception ignored) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[AuraDebug] silent exception: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
        }
    }

}