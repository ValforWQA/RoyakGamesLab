package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BoostContainer {

    private static final BoostContainer INSTANCE = new BoostContainer();

    public static BoostContainer getInstance() {
        return INSTANCE;
    }

    private BoostContainer() {}

    private static final String PROP_BOOST_STATE = "boost_state";

    public double validateBoost(User attacker, MonsterAI monster, boolean isPvP) {
        if (attacker == null) return 1.0D;

        @SuppressWarnings("unchecked")
        Map<String, Double> boostState = (Map<String, Double>) attacker.properties.get(PROP_BOOST_STATE);

        if (boostState == null) {
            boostState = buildBoostStateFromEquipmentScan(attacker);
            attacker.properties.put(PROP_BOOST_STATE, boostState);
        }

        double allMult = getMult(boostState, "dmgall");

        if (isPvP) {
            return clamp(allMult);
        }

        String raceKey = "";
        if (monster != null && monster.getMonster() != null) {
            raceKey = normalizeRace(monster.getMonster().getRace());
        }

        double raceMult = 1.0D;
        if (!raceKey.isEmpty()) {
            switch (raceKey) {
                case "undead":
                case "human":
                case "chaos":
                case "dragonkin":
                case "orc":
                case "drakath":
                case "elemental":
                    raceMult = getMult(boostState, raceKey);
                    break;
                default:
                    raceMult = 1.0D;
                    break;
            }
        }

        return clamp(allMult * raceMult);
    }

    public double validateExpBoost(User user) {
        return validateRewardBoost(user, "exp");
    }

    public double validateGoldBoost(User user) {
        return validateRewardBoost(user, "gold");
    }

    public double validateRepBoost(User user) {
        return validateRewardBoost(user, "rep");
    }

    public double validateClassBoost(User user) {
        return validateRewardBoost(user, "cp");
    }

    private double validateRewardBoost(User user, String key) {
        if (user == null || key == null) {
            return 1.0D;
        }

        @SuppressWarnings("unchecked")
        Map<String, Double> boostState = (Map<String, Double>) user.properties.get(PROP_BOOST_STATE);

        if (boostState == null) {
            boostState = buildBoostStateFromEquipmentScan(user);
            user.properties.put(PROP_BOOST_STATE, boostState);
        }

        return clamp(getMult(boostState, key));
    }

    public void onItemEquipped(User user, int itemId) {
        if (user == null || itemId <= 0) return;

        ItemBean item = StorageCache.getInstance().getItem(itemId);
        if (item == null) return;

        String meta = item.getMeta();
        if (meta == null || meta.trim().isEmpty()) return;

        @SuppressWarnings("unchecked")
        Map<String, Double> boostState = (Map<String, Double>) user.properties.get(PROP_BOOST_STATE);
        if (boostState == null) {
            boostState = new HashMap<String, Double>();
            user.properties.put(PROP_BOOST_STATE, boostState);
        }

        applyMetaIntoBoostState(meta, boostState);
    }

    public void rebuildFromEquipment(User user) {
        if (user == null) return;
        Map<String, Double> boostState = buildBoostStateFromEquipmentScan(user);
        user.properties.put(PROP_BOOST_STATE, boostState);
    }

    private Map<String, Double> buildBoostStateFromEquipmentScan(User user) {
        Map<String, Double> boostState = new HashMap<String, Double>();

        try {
            Object eqpObj = user.properties.get("equipment");
            if (!(eqpObj instanceof JSONObject)) return boostState;

            JSONObject eqp = (JSONObject) eqpObj;

            for (Object k : eqp.keySet()) {
                Object leafObj = eqp.get(k);
                if (!(leafObj instanceof JSONObject)) continue;

                JSONObject leaf = (JSONObject) leafObj;

                int itemId = 0;
                try { itemId = leaf.getInt("ItemID"); } catch (Exception ignored) {}
                if (itemId <= 0) continue;

                ItemBean item = StorageCache.getInstance().getItem(itemId);
                if (item == null) continue;

                String meta = item.getMeta();
                if (meta == null || meta.trim().isEmpty()) continue;

                applyMetaIntoBoostState(meta, boostState);
            }
        } catch (Exception ignored) {}

        return boostState;
    }

    private void applyMetaIntoBoostState(String meta, Map<String, Double> boostState) {
        if (meta == null) return;

        String[] parts = meta.split(",");
        for (String part : parts) {
            if (part == null) continue;

            String p = part.trim();
            if (p.isEmpty()) continue;

            String[] kv = p.split(":");
            if (kv.length != 2) continue;

            String key = kv[0].trim().toLowerCase();
            String val = kv[1].trim();

            double d;
            try {
                d = Double.parseDouble(val);
            } catch (Exception ignored) {
                continue;
            }

            if (d <= 0.0D) continue;

            switch (key) {
                case "dmgall":
                case "undead":
                case "human":
                case "chaos":
                case "dragonkin":
                case "orc":
                case "drakath":
                case "elemental":
                case "gold":
                case "rep":
                case "cp":
                case "exp":
                    putHighest(boostState, key, d);
                    break;

                default:
                    break;
            }
        }
    }

    private void putHighest(Map<String, Double> boostState, String key, double value) {
        Double current = boostState.get(key);
        if (current == null || value > current) {
            boostState.put(key, value);
        }
    }

    private double getMult(Map<String, Double> boostState, String key) {
        if (boostState == null || key == null) return 1.0D;
        Double d = boostState.get(key);
        return (d != null && d > 0.0D) ? d : 1.0D;
    }

    private String normalizeRace(String race) {
        if (race == null) return "";
        String r = race.trim().toLowerCase();
        switch (r) {
            case "dragon":
            case "dragons":
                return "dragonkin";
            default:
                return r;
        }
    }

    private double clamp(double mult) {
        if (mult < 0.01D) return 0.01D;
        if (mult > 50.0D) return 50.0D;
        return mult;
    }
}