package Kaiden.Game.Server.Combat.Player;

import Kaiden.Database.Beans.*;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Stats;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.*;

public class PassiveContainer {
    private static PassiveContainer instance;

    public static PassiveContainer getInstance() {
        if (instance == null) {
            instance = new PassiveContainer();
        }
        return instance;
    }

    public int getUnlockRank(SkillBean skill) {
        if (skill == null || skill.getReference() == null) {
            return 4;
        }

        String ref = skill.getReference().trim().toLowerCase();

        if ("p1".equals(ref)) return 4;
        if ("p2".equals(ref)) return 7;
        if ("p3".equals(ref)) return 10;

        return 4;
    }

    public boolean isPassiveUnlocked(SkillBean skill, int rank) {
        return rank >= getUnlockRank(skill);
    }

    private String getPassiveClassSignature(ClassBean classObj) {
        if (classObj == null) {
            return null;
        }

        Collection skills = classObj.getSkills();
        if (skills == null || skills.isEmpty()) {
            return null;
        }

        TreeSet<Integer> ordered = new TreeSet<Integer>();

        for (Object o : skills) {
            if (o instanceof Integer) {
                ordered.add((Integer) o);
            }
        }

        return ordered.toString();
    }

    private Integer getCurrentPassiveRank(User user) {
        Object value = user.properties.get("passiveRank");
        return value instanceof Integer ? (Integer) value : null;
    }

    private boolean isPassiveStateCurrent(User user, int rank, ClassBean classObj) {
        if (user == null || classObj == null) {
            return false;
        }

        Object sigObj = user.properties.get("passiveClassSig");
        if (!(sigObj instanceof String)) {
            return false;
        }

        Integer currentRank = getCurrentPassiveRank(user);
        if (currentRank == null || currentRank.intValue() != rank) {
            return false;
        }

        List passiveEffects = (List) user.properties.get("passiveEffects");
        if (passiveEffects == null || passiveEffects.isEmpty()) {
            return false;
        }

        String newSig = getPassiveClassSignature(classObj);
        return newSig != null && newSig.equals((String) sigObj);
    }

    public void clearPassiveAuras(User user, boolean sendStats) {
        if (user == null) return;

        Stats stats = (Stats) user.properties.get("stats");
        if (stats == null) return;

        boolean changed = false;
        List passiveEffects = (List) user.properties.get("passiveEffects");

        if (passiveEffects != null && !passiveEffects.isEmpty()) {
            for (Object o : new ArrayList(passiveEffects)) {
                if (o instanceof AuraEffectsBean) {
                    if (stats.removeEffect((AuraEffectsBean) o)) {
                        changed = true;
                    }
                }
            }
            passiveEffects.clear();
            changed = true;
        }

        Set passiveAuraIds = (Set) user.properties.get("passiveAuraIds");
        if (passiveAuraIds != null && !passiveAuraIds.isEmpty()) {
            passiveAuraIds.clear();
            changed = true;
        }

        if (user.properties.remove("passiveEffects") != null) changed = true;
        if (user.properties.remove("passiveAuraIds") != null) changed = true;
        if (user.properties.remove("passiveClassSig") != null) changed = true;
        if (user.properties.remove("passiveRank") != null) changed = true;
        if (user.properties.remove("passiveAurasJson") != null) changed = true;

        if (changed) {
            stats.updateIfDirty();
            if (sendStats) {
                Users.getInstance().sendStatsIfDirty(user);
            }
        }
    }

    public void reapplyCurrentClassPassives(User user) {
        if (user == null) return;

        Object cls = user.properties.get("equippedClassItem");
        Object cp = user.properties.get("cp");

        if (!(cls instanceof ItemBean)) return;
        if (!(cp instanceof Integer)) return;

        ItemBean item = (ItemBean) cls;
        ClassBean classObj = item.getItemClass();

        if (classObj == null) return;

        applyPassiveAuras(user, ((Integer) cp).intValue(), classObj);
    }


    public void ensurePassiveAurasCurrent(User user, int rank, ClassBean classObj) {
        if (user == null || classObj == null) return;
        if (isPassiveStateCurrent(user, rank, classObj)) {
            sendPassiveAuraPacket(user);
            return;
        }
        applyPassiveAuras(user, rank, classObj);
    }


    public boolean restoreCachedPassiveEffects(User user, boolean sendStats) {
        if (user == null) return false;

        Stats stats = (Stats) user.properties.get("stats");
        if (stats == null) return false;

        List passiveEffects = (List) user.properties.get("passiveEffects");
        if (passiveEffects == null || passiveEffects.isEmpty()) return false;

        boolean changed = false;
        for (Object o : passiveEffects) {
            if (!(o instanceof AuraEffectsBean)) continue;
            AuraEffectsBean ae = (AuraEffectsBean) o;
            if (!stats.hasEffect(ae)) {
                stats.addEffect(ae);
                changed = true;
            }
        }

        if (changed) {
            stats.updateIfDirty();
            if (sendStats) {
                Users.getInstance().sendStatsIfDirty(user);
            }
        }

        sendPassiveAuraPacket(user);
        return true;
    }

    private void sendPassiveAuraPacket(User user) {
        if (user == null) return;

        Object cached = user.properties.get("passiveAurasJson");
        JSONArray aurasJson =
                cached instanceof JSONArray ? (JSONArray) cached : new JSONArray();

        JSONObject data = new JSONObject();
        data.put("cmd", "aura+p");
        data.put("tInf", "p:" + user.getUserId());
        data.put("auras", aurasJson);

        Kaiden.Kaiden_Extension.getInstance().send(data, user);
    }

    public void applyPassiveAuras(User user, int rank, ClassBean classObj) {
        if (user == null || classObj == null) return;

        Stats stats = (Stats) user.properties.get("stats");
        if (stats == null) return;

        if (isPassiveStateCurrent(user, rank, classObj)) {
            sendPassiveAuraPacket(user);
            return;
        }

        clearPassiveAuras(user, false);

        List<AuraEffectsBean> passiveEffects =
                new ArrayList<AuraEffectsBean>();

        Set<Integer> passiveAuraIds =
                new LinkedHashSet<Integer>();

        JSONArray auraJson = new JSONArray();

        Collection skills = classObj.getSkills();

        if (skills != null) {
            for (Object obj : skills) {
                if (!(obj instanceof Integer)) continue;

                int skillId = ((Integer) obj).intValue();

                SkillBean skill =
                        StorageCache.getInstance().getSkill(skillId);

                if (skill == null) continue;
                if (!"passive".equalsIgnoreCase(skill.getType())) continue;
                if (!isPassiveUnlocked(skill, rank)) continue;

                Set<Integer> auraIds = collectAuraIds(skill);

                for (Integer auraId : auraIds) {
                    if (auraId == null || auraId.intValue() <= 0) continue;

                    AuraBean aura =
                            StorageCache.getInstance().getAura(auraId.intValue());

                    if (aura == null) continue;

                    passiveAuraIds.add(auraId);

                    JSONObject auraObj = new JSONObject();
                    JSONArray effectsJson = new JSONArray();

                    if (aura.effects != null) {
                        for (int effectId : aura.effects) {
                            AuraEffectsBean ae =
                                    StorageCache.getInstance()
                                            .getAuraEffect(effectId);

                            if (ae == null) continue;

                            JSONObject effect = new JSONObject();
                            effect.put("typ", ae.getType());
                            effect.put("sta", ae.getStat());
                            effect.put("id", ae.getId());
                            effect.put("val", ae.getValue());

                            effectsJson.add(effect);

                            stats.addEffect(ae);
                            passiveEffects.add(ae);
                        }
                    }

                    String iconName = "";

                    try {
                        SkillIconBean icon =
                                StorageCache.getInstance()
                                        .getSkillIcon(
                                                Integer.valueOf(aura.getIcon())
                                        );

                        if (icon != null) {
                            iconName = icon.getName();
                        }
                    } catch (Exception ignored) {
                    }

                    auraObj.put("nam", aura.getName());
                    auraObj.put("icon", iconName);
                    auraObj.put("e", effectsJson);

                    auraJson.add(auraObj);
                }
            }
        }

        user.properties.put("passiveEffects", passiveEffects);
        user.properties.put("passiveAuraIds", passiveAuraIds);
        user.properties.put(
                "passiveClassSig",
                getPassiveClassSignature(classObj)
        );
        user.properties.put("passiveRank", Integer.valueOf(rank));
        user.properties.put("passiveAurasJson", auraJson);

        stats.updateIfDirty();
        Users.getInstance().sendStatsIfDirty(user);
        sendPassiveAuraPacket(user);
    }

    public Set<Integer> collectAuraIds(SkillBean skill) {
        Set<Integer> auraIds = new LinkedHashSet<Integer>();

        if (skill == null) {
            return auraIds;
        }

        if (skill.auraLinks != null) {
            for (Object o : skill.auraLinks) {
                if (o instanceof SkillAuraBean) {
                    SkillAuraBean link = (SkillAuraBean) o;

                    if (link.getAuraId() > 0) {
                        auraIds.add(link.getAuraId());
                    }
                }
            }
        }

        if (skill.auras != null) {
            auraIds.addAll(skill.auras.keySet());
        }

        if (skill.hasAuraId()) {
            auraIds.add(skill.getAuraId());
        }

        return auraIds;
    }
}