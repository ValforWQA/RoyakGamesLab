package Kaiden.Game.Server.Combat.Player;

import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

public final class CombatLockRegistry {
    private static final ConcurrentHashMap<String, ReentrantLock> LOCKS = new ConcurrentHashMap<String, ReentrantLock>();

    private CombatLockRegistry() {}

    public static ReentrantLock get(Room room, User user) {
        /*
         * Combat packets must be serialized per actor, NOT per room.
         *
         * The old implementation preferred the room key whenever a Room was
         * supplied. That made every player in battleon-1/yulgar/etc share one
         * fair ReentrantLock. A single expensive aura/skill calculation could
         * therefore hold every other player's CombatAction packet for seconds.
         *
         * A per-user lock still prevents the same client from overlapping its
         * own casts while allowing unrelated players to execute concurrently.
         */
        if (user != null) {
            return LOCKS.computeIfAbsent("user:" + user.getUserId(), k -> new ReentrantLock());
        }
        if (room != null) {
            String roomKey;
            try {
                roomKey = room.getName();
            } catch (Throwable ignored) {
                roomKey = String.valueOf(System.identityHashCode(room));
            }
            return LOCKS.computeIfAbsent("room-fallback:" + roomKey, k -> new ReentrantLock());
        }
        return LOCKS.computeIfAbsent("global:fallback", k -> new ReentrantLock());
    }
}
