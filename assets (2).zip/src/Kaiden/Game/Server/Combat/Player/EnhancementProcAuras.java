package Kaiden.Game.Server.Combat.Player;

import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Utils.State;
import it.gotoandplay.smartfoxserver.data.User;

public final class EnhancementProcAuras {
    private EnhancementProcAuras() {}

    // DB-backed proc aura IDs added after the existing aura table tail.

    public static final int SPIRAL_CARVE = 102;
    public static final int AWE_BLAST = 103;
    public static final int LACERATE = 104;
    public static final int VALIANCE = 105;
    public static final int ARCANAS_CONCERTO = 106;
    public static final int ACHERON = 107;
    public static final int ELYSIUM = 108;
    public static final int PRAXIS = 109;
    public static final int DAUNTLESS = 110;
    public static final int RAVENOUS = 111;
    public static final int CONSUMED = 112;

    public static boolean hasAura(User user, int auraId) {
        if (user == null) return false;
        Object st = user.properties.get("state");
        return st instanceof State && ((State) st).hasAura(auraId);
    }

    public static int getAuraStacks(User user, int auraId) {
        if (user == null) return 0;
        Object st = user.properties.get("state");
        return st instanceof State ? ((State) st).getAuraStackCount(auraId) : 0;
    }

    public static boolean hasAura(MonsterAI monster, int auraId) {
        return monster != null && monster.getState() != null && monster.getState().hasAura(auraId);
    }

    public static int getAuraStacks(MonsterAI monster, int auraId) {
        return (monster != null && monster.getState() != null) ? monster.getState().getAuraStackCount(auraId) : 0;
    }
}
