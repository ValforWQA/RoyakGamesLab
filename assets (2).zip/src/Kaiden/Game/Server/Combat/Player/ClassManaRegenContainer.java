package Kaiden.Game.Server.Combat.Player;

import Kaiden.Game.Server.Users.Utils.ClassCategory;
import Kaiden.Game.Server.Users.Utils.State;
import it.gotoandplay.smartfoxserver.data.User;

public class ClassManaRegenContainer {
    private static ClassManaRegenContainer instance;

    public static ClassManaRegenContainer getInstance() {
        if (instance == null) instance = new ClassManaRegenContainer();
        return instance;
    }

    public int applyOnDamageDealt(User user, State userState, int damage) {
        if (user == null || userState == null || damage <= 0 || userState.isDead()) return 0;

        String cat = ClassCategory.normalizeCode((String) user.properties.get("classcat"));
        double procChance = getProcChance(cat, damage);
        if (Math.random() > procChance) return 0;

        double manaMultiplier = getManaMultiplier(cat);
        int manaRegen = (int) Math.max(1, Math.round(damage * manaMultiplier));
        int softCap = (int) Math.max(1, Math.round(userState.getMaxMana() * getMaxPercentCap(cat)));
        manaRegen = Math.min(manaRegen, softCap);
        userState.increaseMana(manaRegen);
        return manaRegen;
    }

    private double getManaMultiplier(String cat) {
        double base = 0.032D;
        if ("C1".equals(cat) || "C2".equals(cat) || "C3".equals(cat) || "M3".equals(cat)) {
            base *= 1.10D; // healer / mage line + hybrid caster
        } else if ("S1".equals(cat)) {
            base *= 1.05D;
        } else if ("M1".equals(cat) || "M2".equals(cat) || "M4".equals(cat)) {
            base *= 0.95D;
        }
        return base;
    }

    private double getProcChance(String cat, int damage) {
        double chance = 0.18D;
        if (damage >= 1500) chance += 0.04D;
        else if (damage >= 700) chance += 0.02D;

        if ("C1".equals(cat) || "C2".equals(cat) || "C3".equals(cat) || "M3".equals(cat)) chance += 0.02D;
        return Math.max(0.08D, Math.min(0.30D, chance));
    }

    private double getMaxPercentCap(String cat) {
        if ("C1".equals(cat) || "C2".equals(cat) || "C3".equals(cat) || "M3".equals(cat)) return 0.14D;
        if ("S1".equals(cat)) return 0.13D;
        return 0.12D;
    }
}
