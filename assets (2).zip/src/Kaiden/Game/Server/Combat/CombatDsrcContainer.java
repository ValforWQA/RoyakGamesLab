package Kaiden.Game.Server.Combat;

import Kaiden.Database.Beans.SkillBean;
import Kaiden.Game.Server.Users.Utils.Stats;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Central AQW skill damage-source (dsrc) resolver.
 *
 * Keeps dsrc selection out of packet handlers. Known AP/SP/APSP source
 * families are handled here. Special/legacy sources are deliberately kept
 * visible with FINISH FORMULA markers until their original AQW formulas are
 * verified.
 */
public final class CombatDsrcContainer {

    private CombatDsrcContainer() {
    }

    public static int resolve(Stats stats, SkillBean skill, boolean heal) {
        if (stats == null || skill == null) return 0;

        double scalar = normalizeSkillScalar(skill.getDamage());
        String dsrc = normalize(skill.getDsrc());

        if (dsrc.isEmpty()) {
            return resolveLegacy(stats, skill, heal, scalar);
        }

        switch (dsrc.toUpperCase()) {
            case "AP1":
                // Attack Power source, type 1: normalized/static source.
                return staticAmount(stats.get$ap(), scalar);

            case "AP2":
                // Attack Power source, type 2: 2x base with weapon-range roll.
                return rangedAmount(stats.get$ap() * 2.0D, stats.getWeaponDamageRangePct(), scalar);

            case "SP1":
                // Spell Power source, type 1: normalized/static source.
                return staticAmount(stats.get$sp(), scalar);

            case "SP2":
                // Spell Power source, type 2: 2x base with weapon-range roll.
                return rangedAmount(stats.get$sp() * 2.0D, stats.getWeaponDamageRangePct(), scalar);

            case "APSP1":
                // Hybrid AP/SP type 1: normalized/static hybrid source.
                return staticAmount(hybridPower(stats), scalar);

            case "APSP2":
                // Hybrid AP/SP type 2: 2x hybrid base with weapon-range roll.
                return rangedAmount(hybridPower(stats) * 2.0D, stats.getWeaponDamageRangePct(), scalar);

            case "HPD":
                // FINISH FORMULA: verify AQW HPd current/max/missing-HP source.
                return resolveLegacy(stats, skill, heal, scalar);

            case "SPELL1":
                // FINISH FORMULA: verify exact AQW Spell1 vs SP1 behavior.
                return resolveLegacy(stats, skill, heal, scalar);

            case "CHRONO2":
                // FINISH FORMULA: verify exact AQW Chrono2 source/scaling.
                return resolveLegacy(stats, skill, heal, scalar);

            case "THIEF2":
                // FINISH FORMULA: verify exact AQW Thief2 source/scaling.
                return resolveLegacy(stats, skill, heal, scalar);

            default:
                // Unknown/legacy dsrc: preserve Kaiden's existing behavior.
                return resolveLegacy(stats, skill, heal, scalar);
        }
    }

    private static double hybridPower(Stats stats) {
        return (Math.max(0.0D, stats.get$ap()) + Math.max(0.0D, stats.get$sp())) / 2.0D;
    }

    private static int staticAmount(double source, double scalar) {
        return (int) Math.max(1L, Math.round(Math.max(1.0D, source) * scalar));
    }

    private static int rangedAmount(double source, double rangePct, double scalar) {
        double base = Math.max(1.0D, source) * scalar;
        double radius = clamp(rangePct, 0.0D, 0.95D);
        int min = (int) Math.max(1L, (long) Math.floor(base - (base * radius)));
        int max = Math.max(min, (int) Math.ceil(base + (base * radius)));
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    private static int resolveLegacy(Stats stats, SkillBean skill, boolean heal, double scalar) {
        boolean useWeaponDps = shouldUseWeaponDps(skill, heal);
        if (useWeaponDps) {
            return (int) Math.max(1L, Math.round(stats.getWeaponDpsBase() * Math.max(0.10D, scalar)));
        }
        return Math.max(1, stats.rollWeaponDamage(Math.max(0.10D, scalar)));
    }

    private static boolean shouldUseWeaponDps(SkillBean skill, boolean heal) {
        if (skill == null) return heal;

        String hay = (safeLower(skill.getDescription()) + " "
                + safeLower(skill.getEffects()) + " "
                + safeLower(skill.getReference()) + " "
                + safeLower(skill.getStrl()) + " "
                + safeLower(skill.getType()) + " "
                + safeLower(skill.getName())).trim();

        if (hay.contains("weapon dps") || hay.contains("weapondps") || hay.contains("wdps")) {
            return true;
        }
        if (hay.contains("weapon damage") || hay.contains("weapondamage") || hay.contains("wdmg")) {
            return false;
        }
        return heal;
    }

    public static double normalizeSkillScalar(double raw) {
        double v = Math.abs(raw);
        if (v <= 0.0D) return 1.0D;
        if (v > 10.0D) v = v / 100.0D;
        return Math.max(0.05D, Math.min(5.0D, v));
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim();
    }

    private static String safeLower(String value) {
        return value == null ? "" : value.trim().toLowerCase();
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
