package Kaiden.Game.Server.Combat;

public enum DamageType {
    HIT("hit"),
    MISS("miss"),
    DODGE("dodge"),
    PARRY("parry"),
    CRITICAL("crit"),
    DAMAGE_OVER_TIME("d"),
    MAGIC("magic"),
    NONE("none");
    
    private final String type;
    
    DamageType(String type) {
        this.type = type;
    }
    
    @Override
    public String toString() {
        return type;
    }
}
