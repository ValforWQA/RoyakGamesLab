package Kaiden.Game.Server.Bots;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Game.Threads.RemoveAura;

public class BotState extends Kaiden.Game.Server.Users.Utils.State {
    private final BotSession bot;

    public BotState(BotSession bot, int maxHealth, int maxMana, int dash) {
        super(maxHealth, maxMana, dash);
        this.bot = bot;
    }

    public BotSession getBot() {
        return bot;
    }

    @Override
    public synchronized RemoveAura applyAura(AuraBean aura) {
        return null;
    }
}
