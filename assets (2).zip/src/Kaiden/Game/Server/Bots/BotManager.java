package Kaiden.Game.Server.Bots;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.EnhancementBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Player.TargetAuraContainer;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Threads.Executor;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings({"rawtypes", "unchecked"})
public class BotManager {
    private static final BotManager instance = new BotManager();
    private static final String ROOM_KEY = "visible_player_bots";
    private static final String TASK_KEY = "visible_player_bot_tasks";
    private static final AtomicInteger NEXT_ENT_ID = new AtomicInteger(2000000000);
    private static final Map<Integer, BotSession> GLOBAL_BOTS = new ConcurrentHashMap<Integer, BotSession>();
    private static final Random RNG = new Random();
    private static final long BOT_MAP_TRAVEL_MIN_MS = 18000L;
    private static final long BOT_MAP_TRAVEL_ROLL_MS = 7000L;

    public static BotManager getInstance() { return instance; }

    public int getActiveBotCountForServer(String serverName) {
        if (serverName == null || serverName.trim().isEmpty()) return GLOBAL_BOTS.size();
        int count = 0;
        String wanted = serverName.trim().toLowerCase();
        for (BotSession bot : GLOBAL_BOTS.values()) {
            if (bot == null || !bot.isActive()) continue;
            String current = bot.getDbRow().optString("CurrentServer", "");
            if (current != null && wanted.equals(current.trim().toLowerCase())) count++;
        }
        return count;
    }

    public Map<Integer, BotSession> getRoomBots(Room room) {
        if (room == null) return new ConcurrentHashMap<Integer, BotSession>();
        Object o = room.properties.get(ROOM_KEY);
        if (o instanceof Map) return (Map<Integer, BotSession>) o;
        Map<Integer, BotSession> created = new ConcurrentHashMap<Integer, BotSession>();
        room.properties.put(ROOM_KEY, created);
        return created;
    }

    private Map<Integer, List<ScheduledFuture<?>>> getRoomTasks(Room room) {
        if (room == null) return new ConcurrentHashMap<Integer, List<ScheduledFuture<?>>>();
        Object o = room.properties.get(TASK_KEY);
        if (o instanceof Map) return (Map<Integer, List<ScheduledFuture<?>>>) o;
        Map<Integer, List<ScheduledFuture<?>>> created = new ConcurrentHashMap<Integer, List<ScheduledFuture<?>>>();
        room.properties.put(TASK_KEY, created);
        return created;
    }

    public BotSession getBotByEntId(int entId) { return GLOBAL_BOTS.get(entId); }

    public void appendBotsToArea(Room room, JSONArray uoBranch) {
        if (room == null || uoBranch == null) return;
        for (BotSession bot : getRoomBots(room).values()) {
            if (bot != null && bot.isActive()) uoBranch.add(bot.getRoomProperties());
        }
    }

    public JSONObject getInitUserDataPacket(BotSession bot) {
        JSONObject uid = new JSONObject();
        uid.put("cmd", "initUserData");
        uid.put("data", bot.getUserData());
        uid.put("strFrame", bot.getFrame());
        uid.put("strPad", bot.getPad());
        uid.put("uid", bot.getEntId());
        return uid;
    }

    public JSONObject getInitUserDatasEntry(BotSession bot) {
        JSONObject row = new JSONObject();
        row.put("uid", bot.getEntId());
        row.put("strFrame", bot.getFrame());
        row.put("strPad", bot.getPad());
        row.put("data", bot.getUserData());
        return row;
    }

    public void spawnBots(Room room, User admin, int count, int attackMs, int moveMs, boolean useAllAuras) {
        if (room == null || admin == null || count <= 0) return;
        ensureBotPool(count);
        List<JSONObject> selected = selectBots(count);
        if (selected.isEmpty()) {
            Kaiden_Extension.getInstance().send(new String[]{"server", "No bot accounts were found in users_bots."}, admin);
            return;
        }

        syncBotsFromAdmin(admin, selected);

        int baseX = readInt(admin.properties.get("tx"), 0);
        int baseY = readInt(admin.properties.get("ty"), 0);
        int spawned = 0;
        for (JSONObject row : selected) {
            BotSession bot = buildBotSession(row);
            if (bot == null) continue;
            bot.setRoomName(room.getName());
            bot.setCell(stringVal(admin.properties.get("frame"), "Enter"), stringVal(admin.properties.get("pad"), "Spawn"));
            bot.setPosition(baseX, baseY, 8);
            bot.updateDbCurrentServer(stringVal(admin.properties.get(Properties.CURRENT_SERVER), "Bots"));
            markBotCurrentServer(bot.getBotId(), stringVal(admin.properties.get(Properties.CURRENT_SERVER), "Bots"), room.getName(), bot.getFrame(), bot.getPad(), baseX, baseY);
            getRoomBots(room).put(bot.getEntId(), bot);
            GLOBAL_BOTS.put(bot.getEntId(), bot);
            broadcastJoin(room, bot);
            // Developer-controlled bots begin idle. No background tasks until commanded.
            spawned++;
        }
        Kaiden_Extension.getInstance().send(new String[]{"server", "Spawned " + spawned + " AI player bots in " + room.getName() + ". They are idle until a developer starts a behavior."}, admin);
    }

    /** Change behavior for bots in the current room. Tasks are cancelled before switching. */
    public int controlBots(Room room, User owner, String action) {
        if (room == null || owner == null || action == null) return 0;
        String mode = action.toLowerCase(Locale.ENGLISH);
        if (!(mode.equals("idle") || mode.equals("stop") || mode.equals("move") ||
              mode.equals("follow") || mode.equals("combat") || mode.equals("travel"))) return 0;
        int changed = 0;
        for (BotSession bot : new ArrayList<BotSession>(getRoomBots(room).values())) {
            if (bot == null || !bot.isActive()) continue;
            cancelBotTasks(bot);
            if (mode.equals("move") || mode.equals("follow")) {
                scheduleMovement(room, bot, 1000, bot.getTx(), bot.getTy(), owner);
            } else if (mode.equals("combat")) {
                scheduleCombat(room, bot, 600, true);
            } else if (mode.equals("travel")) {
                scheduleMapTravel(room, bot, owner);
            } else {
                bot.getState().refreshCombatState();
                sendBotUotls(room, bot, false, false, false, true);
            }
            changed++;
        }
        return changed;
    }

    public int clearBots(Room room) {
        if (room == null) return 0;
        int removed = 0;
        for (BotSession bot : new ArrayList<BotSession>(GLOBAL_BOTS.values())) {
            if (bot == null) continue;
            if (!room.getName().equalsIgnoreCase(stringVal(bot.getRoomName(), ""))) continue;
            bot.setActive(false);
            cancelBotTasks(bot);
            broadcastExit(room, bot);
            getRoomBots(room).remove(bot.getEntId());
            GLOBAL_BOTS.remove(bot.getEntId());
            bot.updateDbCurrentServer("");
            try { Storage.getInstance().getJdbc().run("UPDATE users_bots SET CurrentServer=NULL WHERE id=?", bot.getBotId()); } catch (Exception ignored) {}
            removed++;
        }
        getRoomBots(room).clear();
        return removed;
    }

    private void cancelBotTasks(BotSession bot) {
        if (bot == null) return;
        for (Room room : getCandidateRooms()) {
            try {
                Map<Integer, List<ScheduledFuture<?>>> tasks = getRoomTasks(room);
                List<ScheduledFuture<?>> fs = tasks.remove(bot.getEntId());
                if (fs == null) continue;
                for (ScheduledFuture<?> f : fs) if (f != null) f.cancel(false);
            } catch (Exception ignored) {}
        }
    }

    private void broadcastJoin(Room room, BotSession bot) {
        JSONObject join = new JSONObject();
        JSONObject o = new JSONObject();
        o.put("entID", bot.getEntId());
        o.put("entType", "p");
        o.put("uoName", bot.getName());
        o.put("strUsername", bot.getName());
        o.put("strFrame", bot.getFrame());
        o.put("strPad", bot.getPad());
        o.put("tx", bot.getTx());
        o.put("ty", bot.getTy());
        o.put("intState", bot.getState().getState());
        o.put("intHP", bot.getState().getHealth());
        o.put("intHPMax", bot.getState().getMaxHealth());
        o.put("intMP", bot.getState().getMana());
        o.put("intMPMax", bot.getState().getMaxMana());
        o.put("intSP", bot.getState().getDash());
        o.put("intLevel", bot.getRoomProperties().optInt("intLevel", 1));
        o.put("showCloak", true);
        o.put("showHelm", true);
        join.put("cmd", "uotls");
        join.put("o", o);
        join.put("unm", bot.getName());
        Kaiden_Extension.getInstance().send(join, room.getChannellList());
        Kaiden_Extension.getInstance().send(getInitUserDataPacket(bot), room.getChannellList());
    }

    private void broadcastExit(Room room, BotSession bot) {
        Kaiden_Extension.getInstance().send(new String[]{"exitArea", String.valueOf(bot.getEntId()), bot.getName()}, room.getChannellList());
    }

    private void scheduleMovement(final Room spawnRoom, final BotSession bot, int moveMs, final int anchorX, final int anchorY, final User owner) {
        ScheduledFuture<?> future = Executor.getInstance().scheduleTask(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!bot.isActive()) return;
                    Room room = getBotRoom(bot);
                    if (room == null) return;

                    int baseX = bot.getTx();
                    int baseY = bot.getTy();
                    User follow = pickFollowPlayer(room);
                    if (follow != null) {
                        bot.setCell(stringVal(follow.properties.get("frame"), bot.getFrame()), stringVal(follow.properties.get("pad"), bot.getPad()));
                        baseX = readInt(follow.properties.get("tx"), bot.getTx());
                        baseY = readInt(follow.properties.get("ty"), bot.getTy());
                    } else {
                        MonsterAI target = getBestMonster(room, bot);
                        if (target != null && target.getMapMonster() != null) {
                            bot.setCell(target.getMapMonster().getFrame(), bot.getPad());
                            baseX = (int) Math.round(target.getMapMonster().getPosX());
                            baseY = (int) Math.round(target.getMapMonster().getPosY());
                        } else if (baseX == 0 && baseY == 0) {
                            baseX = anchorX;
                            baseY = anchorY;
                        }
                    }

                    int nx = baseX + RNG.nextInt(220) - 110;
                    int ny = baseY + RNG.nextInt(140) - 70;
                    int speed = RNG.nextInt(100) < 12 && bot.getState().getDash() > 0 ? 24 : 8;
                    if (speed >= 24) bot.getState().setDash(0);
                    else if (bot.getState().getDash() < bot.getState().getMaxDash()) bot.getState().increaseDashByPercent(0.03D);

                    bot.setPosition(nx, ny, speed);
                    sendBotUotls(room, bot, true, true, true, false);
                } catch (Throwable t) {
                    logBot("orange", "movement tick failed for " + bot.getName() + ": " + t.getClass().getSimpleName() + " - " + t.getMessage());
                }
            }
        }, Math.max(450, moveMs), TimeUnit.MILLISECONDS, true);
        rememberTask(spawnRoom, bot.getEntId(), future);
    }

    private void scheduleCombat(final Room spawnRoom, final BotSession bot, int attackMs, final boolean useAllAuras) {
        ScheduledFuture<?> future = Executor.getInstance().scheduleTask(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!bot.isActive()) return;
                    Room room = getBotRoom(bot);
                    if (room == null || bot.getState().isDead()) return;

                    MonsterAI target = getBestMonster(room, bot);
                    if (target == null || target.getState() == null || target.getState().isDead()) {
                        bot.getState().refreshCombatState();
                        sendBotUotls(room, bot, false, false, false, true);
                        return;
                    }

                    int monMapId = target.getMapMonster().getMonMapId();
                    int damage = rollBotDamage(bot);
                    target.getState().decreaseHealth(damage);
                    bot.getState().setState(Properties.STATE_COMBAT);
                    bot.getState().addMonsterTarget(monMapId);
                    target.getState().addTarget(bot.getEntId());
                    target.getState().addPlayerTarget(bot.getName());

                    JSONObject monstersJson = new JSONObject();
                    monstersJson.put(String.valueOf(monMapId), target.getState().getData().accumulate("targets", target.getState().getTargets()));

                    JSONArray damagePackets = new JSONArray();
                    JSONObject action = new JSONObject();
                    action.put("hp", damage);
                    action.put("cInf", "p:" + bot.getEntId());
                    action.put("tInf", "m:" + monMapId);
                    action.put("type", RNG.nextInt(100) < 8 ? "crit" : "hit");
                    damagePackets.add(action);

                    JSONArray auraPackets = new JSONArray();
                    if (useAllAuras && (System.currentTimeMillis() - bot.getLastAuraSweepAt()) >= 2500L) {
                        bot.setLastAuraSweepAt(System.currentTimeMillis());
                        applyBotProcAuras(bot, target, damage, auraPackets);
                    }

                    JSONArray sarsa = new JSONArray();
                    JSONObject sarsaAction = new JSONObject();
                    sarsaAction.put("cInf", "p:" + bot.getEntId());
                    sarsaAction.put("tInf", "m:" + monMapId);
                    sarsaAction.put("a", damagePackets);
                    sarsaAction.put("actID", bot.nextActId());
                    sarsaAction.put("iRes", 1);
                    sarsa.add(sarsaAction);

                    JSONObject players = new JSONObject();
                    players.put(bot.getName(), bot.getState().getData());

                    JSONObject ct = new JSONObject();
                    ct.put("cmd", "ct");
                    ct.put("m", monstersJson);
                    ct.put("a", auraPackets);
                    ct.put("p", players);
                    ct.put("anims", getBotAttackAnim(bot, target));
                    ct.put("sarsa", sarsa);
                    Kaiden_Extension.getInstance().send(ct, room.getChannellList());
                } catch (Throwable t) {
                    logBot("red", "combat tick failed for " + bot.getName() + ": " + t.getClass().getSimpleName() + " - " + t.getMessage());
                }
            }
        }, Math.max(400, attackMs), TimeUnit.MILLISECONDS, true);
        rememberTask(spawnRoom, bot.getEntId(), future);
    }

    private void applyBotProcAuras(BotSession bot, MonsterAI target, int damage, JSONArray auraPackets) {
        if (bot == null || target == null || auraPackets == null) return;
        try {
            int procId = bot.getWeaponProcId();
            if (procId <= 0) return;
            int[] auraIds = resolveProcAuraIds(procId);
            for (int auraId : auraIds) {
                AuraBean aura = StorageCache.getInstance().getAura(auraId);
                if (aura == null) continue;
                JSONObject auraPacket = TargetAuraContainer.getInstance().applyAuraToMonster(target, auraId, "p:" + bot.getEntId(), damage);
                if (auraPacket != null) auraPackets.add(auraPacket);
            }
        } catch (Throwable t) {
            logBot("orange", "proc aura failed for " + bot.getName() + ": " + t.getClass().getSimpleName() + " - " + t.getMessage());
        }
    }

    private int[] resolveProcAuraIds(int procId) {
        switch (procId) {
            case 3:  return new int[]{103};
            case 11: return new int[]{82};
            case 12: return new int[]{84};
            case 14: return new int[]{81};
            case 15: return new int[]{83};
            default: return new int[0];
        }
    }

    private Room getBotRoom(BotSession bot) {
        if (bot == null || bot.getRoomName() == null) return null;
        try { return Kaiden_Extension.getInstance().getZone().getRoomByName(bot.getRoomName()); } catch (Exception ignored) { return null; }
    }

    private MonsterAI getBestMonster(Room room, BotSession bot) {
        if (room == null || bot == null) return null;
        Object monsObj = room.properties.get("monsters");
        if (!(monsObj instanceof HashMap)) return null;
        HashMap<Integer, MonsterAI> monsters = (HashMap<Integer, MonsterAI>) monsObj;
        MonsterAI target = null;
        long now = System.currentTimeMillis();
        if (bot.getTargetMonMapId() != null && (now - bot.getLastTargetSwapAt()) < 2500L) {
            target = monsters.get(bot.getTargetMonMapId());
            if (target != null && target.getState() != null && !target.getState().isDead()) return target;
        }
        double best = Double.MAX_VALUE;
        for (MonsterAI ai : monsters.values()) {
            if (ai == null || ai.getState() == null || ai.getState().isDead() || ai.getMapMonster() == null) continue;
            String monFrame = ai.getMapMonster().getFrame();
            if (monFrame != null && bot.getFrame() != null && !monFrame.equals(bot.getFrame())) continue;
            double dx = ai.getMapMonster().getPosX() - bot.getTx();
            double dy = ai.getMapMonster().getPosY() - bot.getTy();
            double dist = Math.sqrt((dx * dx) + (dy * dy));
            if (dist < best && dist <= 1200.0D) { best = dist; target = ai; }
        }
        if (target != null) {
            bot.setTargetMonMapId(target.getMapMonster().getMonMapId());
            bot.setLastTargetSwapAt(now);
        }
        return target;
    }

    private User pickFollowPlayer(Room room) {
        try {
            User[] users = room.getAllUsers();
            if (users == null || users.length == 0) return null;
            return users[RNG.nextInt(users.length)];
        } catch (Exception ignored) { return null; }
    }

    private void sendBotUotls(Room room, BotSession bot, boolean includePosition, boolean includeCell, boolean includeSpeed, boolean includeVitals) {
        if (room == null || bot == null) return;
        JSONObject uotls = new JSONObject();
        JSONObject o = new JSONObject();
        uotls.put("cmd", "uotls");
        uotls.put("unm", bot.getName());
        if (includePosition) { o.put("tx", bot.getTx()); o.put("ty", bot.getTy()); }
        if (includeCell) { o.put("strFrame", bot.getFrame()); o.put("strPad", bot.getPad()); }
        if (includeSpeed) o.put("sp", bot.getSpeed());
        if (includeVitals) {
            o.put("intHP", bot.getState().getHealth());
            o.put("intHPMax", bot.getState().getMaxHealth());
            o.put("intMP", bot.getState().getMana());
            o.put("intMPMax", bot.getState().getMaxMana());
            o.put("intSP", bot.getState().getDash());
            o.put("intState", bot.getState().getState());
        }
        uotls.put("o", o);
        Kaiden_Extension.getInstance().send(uotls, room.getChannellList());
    }

    private JSONArray getBotAttackAnim(BotSession bot, MonsterAI target) {
        JSONArray anims = new JSONArray();
        if (bot == null || target == null || target.getMapMonster() == null) return anims;
        JSONObject anim = new JSONObject();
        anim.put("strFrame", bot.getFrame());
        anim.put("cInf", "p:" + bot.getEntId());
        anim.put("fx", "m");
        anim.put("tInf", "m:" + target.getMapMonster().getMonMapId());
        anim.put("animStr", "Attack1,Attack2");
        anims.add(anim);
        return anims;
    }

    private int rollBotDamage(BotSession bot) {
        int dps = Math.max(1, bot != null ? bot.getWeaponDps() : 8);
        int base = Math.max(1, (dps * 2) + RNG.nextInt(Math.max(2, dps + 1)));
        if (RNG.nextInt(100) < 8) base = (int) Math.round(base * 1.75D);
        return base;
    }

    private void scheduleMapTravel(final Room spawnRoom, final BotSession bot, final User owner) {
        ScheduledFuture<?> future = Executor.getInstance().scheduleTask(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!bot.isActive()) return;
                    Room current = getBotRoom(bot);
                    if (current == null) return;
                    if (current.getUserCount() > 0 && RNG.nextInt(100) < 70) return;
                    if (System.currentTimeMillis() - bot.getLastRoomSwapAt() < BOT_MAP_TRAVEL_MIN_MS) return;
                    if (RNG.nextInt(100) < 55) return;
                    Room destination = pickBotDestination(current, owner);
                    if (destination != null && destination.getId() != current.getId()) moveBotToRoom(bot, current, destination);
                } catch (Throwable t) {
                    logBot("orange", "map travel failed for " + bot.getName() + ": " + t.getClass().getSimpleName() + " - " + t.getMessage());
                }
            }
        }, BOT_MAP_TRAVEL_ROLL_MS, TimeUnit.MILLISECONDS, true);
        rememberTask(spawnRoom, bot.getEntId(), future);
    }

    private Room pickBotDestination(Room current, User owner) {
        try {
            if (owner != null) {
                Room ownerRoom = Kaiden_Extension.getInstance().getZone().getRoom(owner.getRoom());
                if (ownerRoom != null && ownerRoom.getId() != current.getId()) return ownerRoom;
            }
            QueryResult qr = Storage.getInstance().getJdbc().query("SELECT Name FROM maps WHERE PvP=0 AND Staff=0 AND MaxPlayers > 0 ORDER BY RAND() LIMIT 1");
            String map = null;
            if (qr.next()) map = qr.getString("Name");
            qr.close();
            if (map == null || map.trim().isEmpty()) return null;
            map = map.toLowerCase();
            Room existing = Kaiden_Extension.getInstance().getZone().getRoomByName(map + "-1");
            if (existing != null) return existing;
            if (owner != null) return Rooms.getInstance().generateRoom(map + "-1", owner);
        } catch (Throwable ignored) {}
        return null;
    }

    private void moveBotToRoom(BotSession bot, Room from, Room to) {
        if (bot == null || from == null || to == null) return;
        getRoomBots(from).remove(bot.getEntId());
        broadcastExit(from, bot);
        bot.setRoomName(to.getName());
        bot.setCell("Enter", "Spawn");
        bot.setPosition(0, 0, 8);
        bot.setTargetMonMapId(null);
        bot.setLastRoomSwapAt(System.currentTimeMillis());
        bot.getState().restore();
        getRoomBots(to).put(bot.getEntId(), bot);
        markBotCurrentServer(bot.getBotId(), bot.getDbRow().optString("CurrentServer", "Bots"), to.getName(), bot.getFrame(), bot.getPad(), 0, 0);
        broadcastJoin(to, bot);
        logBot("cyan", "bot " + bot.getName() + " moved from " + from.getName() + " to " + to.getName());
    }

    private void rememberTask(Room room, int entId, ScheduledFuture<?> future) {
        if (future == null || room == null) return;
        Map<Integer, List<ScheduledFuture<?>>> tasks = getRoomTasks(room);
        List<ScheduledFuture<?>> list = tasks.get(entId);
        if (list == null) { list = new ArrayList<ScheduledFuture<?>>(); tasks.put(entId, list); }
        list.add(future);
    }

    private List<Room> getCandidateRooms() {
        List<Room> rooms = new ArrayList<Room>();
        for (BotSession bot : GLOBAL_BOTS.values()) {
            Room r = getBotRoom(bot);
            if (r != null && !rooms.contains(r)) rooms.add(r);
        }
        return rooms;
    }

    private void ensureBotPool(int required) {
        if (required <= 0) return;
        int current = 0;
        QueryResult countQr = Storage.getInstance().getJdbc().query("SELECT COUNT(*) AS rowcount FROM users_bots");
        if (countQr.next()) current = countQr.getInt("rowcount");
        countQr.close();
        for (int i = current + 1; i <= required; i++) {
            String name = String.format("StressBot_%03d", i);
            Storage.getInstance().getJdbc().run(
                    "INSERT INTO users_bots (Name, LoginToken, Access, Role, RoleColor, NameColor, Gold, Coins, Souls, Level, Exp, FactionID, PerkID, Gender, HairID, ColorHair, ColorSkin, ColorEye, ColorBase, ColorTrim, ColorAccessory, CurrentServer, LastArea, LastLocation, LastLogin) VALUES (?, '', 1, '', '#CCCCCC', '#CCCCCC', 0, 0, 0, 1, 0, 0, 0, 'M', 1, 'FFFFFF', 'FFFFFF', 'FFFFFF', 'FFFFFF', 'FFFFFF', 'FFFFFF', '', 'battleon|Enter|Spawn', 'battleon', NOW())",
                    name
            );
        }
    }

    private List<JSONObject> selectBots(int count) {
        List<JSONObject> list = new ArrayList<JSONObject>();
        QueryResult qr = Storage.getInstance().getJdbc().query("SELECT * FROM users_bots ORDER BY id ASC LIMIT ?", count);
        while (qr.next()) {
            JSONObject row = new JSONObject();
            row.put("id", qr.getInt("id"));
            row.put("Name", qr.getString("Name"));
            row.put("Gold", qr.getInt("Gold"));
            row.put("Coins", qr.getInt("Coins"));
            row.put("Souls", qr.getInt("Souls"));
            row.put("Level", qr.getInt("Level"));
            row.put("Exp", qr.getInt("Exp"));
            row.put("Access", qr.getInt("Access"));
            row.put("Role", qr.getString("Role"));
            row.put("RoleColor", qr.getString("RoleColor"));
            row.put("NameColor", qr.getString("NameColor"));
            row.put("PerkID", qr.getInt("PerkID"));
            row.put("FactionID", qr.getInt("FactionID"));
            row.put("Gender", qr.getString("Gender"));
            row.put("ColorHair", qr.getString("ColorHair"));
            row.put("ColorSkin", qr.getString("ColorSkin"));
            row.put("ColorEye", qr.getString("ColorEye"));
            row.put("ColorBase", qr.getString("ColorBase"));
            row.put("ColorTrim", qr.getString("ColorTrim"));
            row.put("ColorAccessory", qr.getString("ColorAccessory"));
            row.put("HairID", qr.getInt("HairID"));
            row.put("CurrentServer", qr.getString("CurrentServer"));
            list.add(row);
        }
        qr.close();
        return list;
    }

    private void markBotCurrentServer(int botId, String currentServer, String roomName, String frame, String pad, int tx, int ty) {
        try {
            Storage.getInstance().getJdbc().run(
                    "UPDATE users_bots SET CurrentServer=?, LastArea=?, LastLocation=? WHERE id=?",
                    currentServer,
                    roomName + "|" + frame + "|" + pad,
                    roomName + "|" + tx + "|" + ty,
                    botId
            );
        } catch (Exception ignored) {}
    }

    private void syncBotsFromAdmin(User admin, List<JSONObject> selected) {
        if (admin == null || selected == null || selected.isEmpty()) return;
        List<Map<String, Object>> items = collectAdminEquippedItems(admin);
        for (JSONObject bot : selected) {
            int botId = bot.getInt("id");
            Storage.getInstance().getJdbc().run(
                    "UPDATE users_bots SET Gold=?, Coins=?, Souls=?, Level=?, Exp=?, Access=?, Role=?, RoleColor=?, NameColor=?, PerkID=?, FactionID=?, Gender=?, ColorHair=?, ColorSkin=?, ColorEye=?, ColorBase=?, ColorTrim=?, ColorAccessory=?, HairID=?, CurrentServer=?, LastArea=?, LastLocation=?, LastLogin=NOW() WHERE id=?",
                    admin.properties.get(Properties.GOLD), admin.properties.get(Properties.COINS), admin.properties.get(Properties.SOULS), admin.properties.get(Properties.LEVEL), admin.properties.get(Properties.EXPERIENCE), admin.properties.get(Properties.ACCESS),
                    stringVal(admin.properties.get(Properties.ROLE_NAME), ""), stringVal(admin.properties.get(Properties.ROLE_COLOR), "#CCCCCC"), stringVal(admin.properties.get(Properties.NAME_COLOR), "#CCCCCC"),
                    readInt(admin.properties.get(Properties.FACTION_PERK), 0), readInt(admin.properties.get(Properties.FACTION), 0), stringVal(admin.properties.get("gender"), "M"),
                    toHex(readInt(admin.properties.get("colorhair"), 0)), toHex(readInt(admin.properties.get("colorskin"), 0)), toHex(readInt(admin.properties.get("coloreye"), 0)), toHex(readInt(admin.properties.get("colorbase"), 0)), toHex(readInt(admin.properties.get("colortrim"), 0)), toHex(readInt(admin.properties.get("coloraccessory"), 0)),
                    readInt(admin.properties.get("hairId"), 1), stringVal(admin.properties.get(Properties.CURRENT_SERVER), "Bots"), stringVal(admin.properties.get("lastarea"), "battleon|Enter|Spawn"), stringVal(admin.properties.get("lastlocation"), "battleon"), botId
            );
            Storage.getInstance().getJdbc().run("DELETE FROM users_bots_items WHERE UserID = ?", botId);
            for (Map<String, Object> item : items) {
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO users_bots_items (UserID, ItemID, EnhID, Equipped, Quantity, Bank, Wear, DatePurchased) VALUES (?, ?, ?, ?, ?, 0, ?, NOW())",
                        botId, item.get("ItemID"), item.get("EnhID"), item.get("Equipped"), item.get("Quantity"), item.get("Wear")
                );
            }
        }
    }

    private List<Map<String, Object>> collectAdminEquippedItems(User admin) {
        List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
        QueryResult qr = Storage.getInstance().getJdbc().query("SELECT * FROM users_items WHERE UserID = ? AND Equipped = 1 AND Bank = 0", admin.properties.get(Properties.ID));
        while (qr.next()) {
            Map<String, Object> row = new LinkedHashMap<String, Object>();
            row.put("ItemID", qr.getInt("ItemID"));
            row.put("EnhID", qr.getInt("EnhID"));
            row.put("Equipped", qr.getInt("Equipped"));
            row.put("Quantity", qr.getInt("Quantity"));
            row.put("Wear", safeGetInt(qr, "Wear", 0));
            rows.add(row);
        }
        qr.close();
        return rows;
    }

    private BotSession buildBotSession(JSONObject row) {
        try {
            int botId = row.getInt("id");
            JSONObject equipment = new JSONObject();
            ItemBean weaponItem = null;
            int weaponDps = 8;
            int weaponProcId = 0;
            int classPoints = 1;
            QueryResult result = Storage.getInstance().getJdbc().query("SELECT * FROM users_bots_items WHERE UserID = ? AND Equipped = 1 AND Bank = 0", botId);
            while (result.next()) {
                ItemBean itemObj = StorageCache.getInstance().getItem(result.getInt("ItemID"));
                if (itemObj == null) continue;
                EnhancementBean enhancement = StorageCache.getInstance().getEnhancement(result.getInt("EnhID"));
                JSONObject eqpObj = new JSONObject();
                eqpObj.put("ItemID", itemObj.getId());
                eqpObj.put("sFile", itemObj.getFile());
                eqpObj.put("sLink", itemObj.getLink());
                eqpObj.put("sMeta", itemObj.getMeta());
                eqpObj.put("sName", itemObj.getName());
                eqpObj.put("sES", itemObj.getEquipment());
                eqpObj.put("iDPS", itemObj.getDPS());
                eqpObj.put("iRng", itemObj.getClientRange());
                eqpObj.put("EnhRng", itemObj.getClientRange());
                if (enhancement != null) {
                    eqpObj.put("EnhID", enhancement.getId());
                    eqpObj.put("EnhLvl", enhancement.getLevel());
                    eqpObj.put("EnhPatternID", enhancement.getClientPatternId());
                    eqpObj.put("EnhRty", enhancement.getRarity());
                    eqpObj.put("ProcID", enhancement.getProcId());
                    eqpObj.put("EnhDPS", enhancement.getDPS());
                }
                if ("Weapon".equals(itemObj.getEquipment())) {
                    eqpObj.put("sType", itemObj.getType());
                    weaponItem = itemObj;
                    weaponDps = Math.max(1, itemObj.getDPS());
                    if (enhancement != null) weaponProcId = enhancement.getProcId();
                }
                if ("ar".equals(itemObj.getEquipment())) classPoints = Math.max(1, result.getInt("Quantity"));
                equipment.put(itemObj.getEquipment(), eqpObj);
            }
            result.close();

            return new BotSession(botId, NEXT_ENT_ID.getAndIncrement(), row.getString("Name"), row, equipment, row.optInt("Level", 1), row.optInt("HairID", 1), row.optString("Gender", "M"), parseHexColor(row.optString("ColorHair", "FFFFFF")), parseHexColor(row.optString("ColorSkin", "FFFFFF")), parseHexColor(row.optString("ColorEye", "FFFFFF")), parseHexColor(row.optString("ColorBase", "FFFFFF")), parseHexColor(row.optString("ColorTrim", "FFFFFF")), parseHexColor(row.optString("ColorAccessory", "FFFFFF")), row.optString("Role", ""), row.optString("RoleColor", "#CCCCCC"), row.optString("NameColor", "#CCCCCC"), row.optInt("Access", 1), row.optInt("Gold", 0), row.optInt("Coins", 0), row.optInt("Souls", 0), resolveClassName(equipment), classPoints, row.optInt("FactionID", 0), row.optInt("PerkID", 0), weaponItem, weaponDps, weaponProcId);
        } catch (Exception ignored) { return null; }
    }

    private String resolveClassName(JSONObject equipment) {
        try { Object ar = equipment.opt("ar"); if (ar instanceof JSONObject) return ((JSONObject) ar).optString("sName", "Novice"); } catch (Exception ignored) {}
        return "Novice";
    }

    private static int parseHexColor(String value) {
        try { String normalized = value == null ? "FFFFFF" : value.replace("#", "").trim(); if (normalized.isEmpty()) normalized = "FFFFFF"; return Integer.valueOf(normalized, 16); } catch (Exception ignored) { return Integer.valueOf("FFFFFF", 16); }
    }

    private static String toHex(int value) {
        String hex = Integer.toHexString(Math.max(0, value)).toUpperCase();
        while (hex.length() < 6) hex = "0" + hex;
        if (hex.length() > 6) hex = hex.substring(hex.length() - 6);
        return hex;
    }

    private static int readInt(Object value, int fallback) {
        if (value == null) return fallback;
        if (value instanceof Number) return ((Number) value).intValue();
        try { return Integer.parseInt(String.valueOf(value)); } catch (Exception ignored) { return fallback; }
    }

    private static String stringVal(Object value, String fallback) { return value == null ? fallback : String.valueOf(value); }

    private static int safeGetInt(QueryResult qr, String column, int fallback) { try { return qr.getInt(column); } catch (Exception ignored) { return fallback; } }

    private void logBot(String color, String message) {
        try { Kaiden_Engine.getInstance().sendEmulatorMessage(color, "[BotAI] " + message); } catch (Throwable ignored) {}
    }
}
