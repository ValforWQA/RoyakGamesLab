package Kaiden.Game.Server.Bots;

import Kaiden.Database.Beans.HairBean;
import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.State;
import net.sf.json.JSONObject;

public class BotSession {
    private final int botId;
    private final int entId;
    private final String name;
    private final JSONObject dbRow;
    private final JSONObject equipment;
    private final int level;
    private final int hairId;
    private final String gender;
    private final int colorHair;
    private final int colorSkin;
    private final int colorEye;
    private final int colorBase;
    private final int colorTrim;
    private final int colorAccessory;
    private final String roleName;
    private final String roleColor;
    private final String nameColor;
    private final int access;
    private final int gold;
    private final int coins;
    private final int souls;
    private final String className;
    private final int classPoints;
    private final int factionId;
    private final int perkId;
    private final ItemBean weaponItem;
    private final int weaponDps;
    private final int weaponProcId;

    private volatile String roomName;
    private volatile String frame;
    private volatile String pad;
    private volatile int tx;
    private volatile int ty;
    private volatile int speed;
    private volatile State state;
    private volatile boolean active;
    private volatile Integer targetMonMapId;
    private volatile long lastTargetSwapAt;
    private volatile long lastAuraSweepAt;
    private volatile long lastRoomSwapAt;
    private volatile int actId;

    public BotSession(int botId, int entId, String name, JSONObject dbRow, JSONObject equipment,
                      int level, int hairId, String gender,
                      int colorHair, int colorSkin, int colorEye, int colorBase, int colorTrim, int colorAccessory,
                      String roleName, String roleColor, String nameColor,
                      int access, int gold, int coins, int souls,
                      String className, int classPoints, int factionId, int perkId,
                      ItemBean weaponItem, int weaponDps, int weaponProcId) {
        this.botId = botId;
        this.entId = entId;
        this.name = name;
        this.dbRow = dbRow == null ? new JSONObject() : JSONObject.fromObject(dbRow);
        this.equipment = equipment == null ? new JSONObject() : JSONObject.fromObject(equipment);
        this.level = Math.max(1, level);
        this.hairId = hairId;
        this.gender = gender == null || gender.trim().isEmpty() ? "M" : gender;
        this.colorHair = colorHair;
        this.colorSkin = colorSkin;
        this.colorEye = colorEye;
        this.colorBase = colorBase;
        this.colorTrim = colorTrim;
        this.colorAccessory = colorAccessory;
        this.roleName = roleName == null ? "" : roleName;
        this.roleColor = roleColor == null ? "#CCCCCC" : roleColor;
        this.nameColor = nameColor == null ? "#CCCCCC" : nameColor;
        this.access = access;
        this.gold = gold;
        this.coins = coins;
        this.souls = souls;
        this.className = className == null ? "Novice" : className;
        this.classPoints = Math.max(1, classPoints);
        this.factionId = factionId;
        this.perkId = perkId;
        this.weaponItem = weaponItem;
        this.weaponDps = Math.max(1, weaponDps);
        this.weaponProcId = Math.max(0, weaponProcId);
        this.frame = "Enter";
        this.pad = "Spawn";
        this.speed = 8;
        int hpMax = Math.max(100, 100 + (this.level * 35));
        int mpMax = Math.max(100, 100 + (this.level * 12));
        this.state = new BotState(this, hpMax, mpMax, 100);
        this.state.setState(Properties.STATE_NORMAL);
        this.active = true;
        this.lastRoomSwapAt = System.currentTimeMillis();
        this.actId = 0;
    }

    public int getBotId() { return botId; }
    public int getEntId() { return entId; }
    public String getName() { return name; }
    public JSONObject getDbRow() { return JSONObject.fromObject(dbRow); }
    public String getRoomName() { return roomName; }
    public void setRoomName(String roomName) { this.roomName = roomName; }
    public String getFrame() { return frame; }
    public String getPad() { return pad; }
    public void setCell(String frame, String pad) { this.frame = frame == null ? "Enter" : frame; this.pad = pad == null ? "Spawn" : pad; }
    public int getTx() { return tx; }
    public int getTy() { return ty; }
    public int getSpeed() { return speed; }
    public void setPosition(int tx, int ty, int speed) { this.tx = tx; this.ty = ty; this.speed = Math.max(8, speed); }
    public State getState() { return state; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public JSONObject getEquipment() { return JSONObject.fromObject(equipment); }
    public int getWeaponDps() { return weaponDps; }
    public int getWeaponProcId() { return weaponProcId; }
    public ItemBean getWeaponItem() { return weaponItem; }
    public Integer getTargetMonMapId() { return targetMonMapId; }
    public void setTargetMonMapId(Integer targetMonMapId) { this.targetMonMapId = targetMonMapId; }
    public long getLastTargetSwapAt() { return lastTargetSwapAt; }
    public void setLastTargetSwapAt(long lastTargetSwapAt) { this.lastTargetSwapAt = lastTargetSwapAt; }
    public long getLastAuraSweepAt() { return lastAuraSweepAt; }
    public void setLastAuraSweepAt(long lastAuraSweepAt) { this.lastAuraSweepAt = lastAuraSweepAt; }
    public long getLastRoomSwapAt() { return lastRoomSwapAt; }
    public void setLastRoomSwapAt(long lastRoomSwapAt) { this.lastRoomSwapAt = lastRoomSwapAt; }
    public synchronized int nextActId() { this.actId++; if (this.actId > 999999) this.actId = 1; return this.actId; }

    public synchronized void updateDbCurrentServer(String currentServer) {
        this.dbRow.put("CurrentServer", currentServer == null ? "" : currentServer);
    }

    public JSONObject getUserData() {
        HairBean hair = StorageCache.getInstance().getHair(this.hairId);
        JSONObject userData = new JSONObject();
        userData.put("eqp", this.getEquipment());
        userData.put("iCP", this.classPoints);
        userData.put("iUpgDays", 9999);
        userData.put("intAccessLevel", this.access);
        userData.put("intColorAccessory", this.colorAccessory);
        userData.put("intColorBase", this.colorBase);
        userData.put("intColorEye", this.colorEye);
        userData.put("intColorHair", this.colorHair);
        userData.put("intColorSkin", this.colorSkin);
        userData.put("intColorTrim", this.colorTrim);
        userData.put("intLevel", this.level);
        userData.put("strClassName", this.className);
        userData.put("strGender", this.gender);
        userData.put("strHairFilename", hair != null ? hair.getFile() : "");
        userData.put("strHairName", hair != null ? hair.getName() : "");
        userData.put("FactionID", this.factionId);
        userData.put("PerkID", this.perkId);
        userData.put("strUsername", this.name);
        userData.put("CharID", this.botId);
        userData.put("rolecolor", this.roleColor);
        userData.put("namecolor", this.nameColor);
        userData.put("rolename", this.roleName);
        userData.put("intGold", this.gold);
        userData.put("intCoins", this.coins);
        userData.put("intSouls", this.souls);
        return userData;
    }

    public JSONObject getRoomProperties() {
        JSONObject userprop = new JSONObject();
        userprop.put("afk", false);
        userprop.put("currentserver", dbRow.optString("CurrentServer", "Bots"));
        userprop.put("entID", this.entId);
        userprop.put("entType", "p");
        userprop.put("intGold", this.gold);
        userprop.put("intCoins", this.coins);
        userprop.put("intHP", this.state.getHealth());
        userprop.put("intHPMax", this.state.getMaxHealth());
        userprop.put("intSouls", this.souls);
        userprop.put("intLevel", this.level);
        userprop.put("intMP", this.state.getMana());
        userprop.put("intMPMax", this.state.getMaxMana());
        userprop.put("intSP", this.state.getDash());
        userprop.put("intState", this.state.getState());
        userprop.put("showCloak", true);
        userprop.put("showHelm", true);
        userprop.put("strFrame", this.frame);
        userprop.put("strPad", this.pad);
        userprop.put("CharID", this.botId);
        userprop.put("FactionID", this.factionId);
        userprop.put("FactionPerk", this.perkId);
        userprop.put("strUsername", this.name);
        userprop.put("rolename", this.roleName);
        userprop.put("rolecolor", this.roleColor);
        userprop.put("namecolor", this.nameColor);
        userprop.put("tx", this.tx);
        userprop.put("ty", this.ty);
        userprop.put("sp", this.speed);
        userprop.put("uoName", this.name);
        return userprop;
    }
}
