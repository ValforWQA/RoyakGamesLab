package Kaiden.Game.Server.Rooms;

import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.StorageCache;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class WarzoneQueue {
    private static WarzoneQueue instance;
    private final ConcurrentHashMap<String, LinkedBlockingQueue<User>> warzoneQueues = new ConcurrentHashMap();

    public static WarzoneQueue getInstance() {
        if (instance == null) {
            instance = new WarzoneQueue();
        }
        return instance;
    }

    public LinkedBlockingQueue<User> get(String warzone) {
        if (Configuration.SERVER_PVP) {
            if (this.warzoneQueues.containsKey(warzone)) {
                return this.warzoneQueues.get(warzone);
            } else {
                ZoneBean area = StorageCache.getInstance().getArea(warzone);
                if (area != null) {
                    if (area.isPvP()) {
                        this.warzoneQueues.putIfAbsent(warzone, new LinkedBlockingQueue());
                        return this.warzoneQueues.get(warzone);
                    }
                }
            }
        }
        return null;
    }

    public boolean remove(User user) {
        if (Configuration.SERVER_PVP) {
            for (LinkedBlockingQueue<User> users : this.warzoneQueues.values()) {
                if (users.contains(user)) {
                    users.remove(user);
                    return true;
                }
            }
        }
        return false;
    }

    public void queue(String warzone, User user) {
        if (Configuration.SERVER_PVP) {
            this.remove(user);
            LinkedBlockingQueue pq = this.get(warzone);
            pq.offer(user);
        }
    }

    public void check(String warzone) {
        if (Configuration.SERVER_PVP) {
            ZoneBean area = StorageCache.getInstance().getArea(warzone);
            if (area != null) {
                LinkedBlockingQueue<User> queues = this.get(warzone);
                int size = queues.size();
                int max = area.getMaxPlayers();
                if (size >= max) {
                    this.join(warzone, queues);
                } else {
                    for (User user : queues) {
                        Kaiden_Extension.getInstance().send(new String[]{"server", "Warzone \"" + warzone + "\" is waitting players: " + size + "/" + max}, user);
                    }
                }
            }
        }
    }

    public void join(String warzone, LinkedBlockingQueue<User> queues) {
        if (Configuration.SERVER_PVP) {
            Room room = Rooms.getInstance().createRoom(warzone + "-" + (new Random()).nextInt(99999), null);
            int count = 0;
            JSONObject pvi = new JSONObject();
            pvi.put("cmd", "PVPI");
            pvi.put("warzone", warzone);
            for (User user : queues) {
                user.properties.put("roomqueued", room);
                if (count % 2 == 0) {
                    user.properties.put("pvpteam", 0);
                } else {
                    user.properties.put("pvpteam", 1);
                }
                Kaiden_Extension.getInstance().send(new String[]{"server", "A new Warzone battle has started!"}, user);
                Kaiden_Extension.getInstance().send(pvi, user);
                count++;
            }
            this.warzoneQueues.get(warzone).clear();
        }
    }
}
