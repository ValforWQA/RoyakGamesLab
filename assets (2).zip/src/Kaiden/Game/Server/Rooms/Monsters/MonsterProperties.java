package Kaiden.Game.Server.Rooms.Monsters;

@SuppressWarnings("ALL")
public class MonsterProperties {

    public static final double AQW_REGEN_HP_NORMAL = 0.0015D;  // 0.15%
    public static final double AQW_REGEN_HP_ELITE  = 0.0040D;  // 0.40%
    public static final double AQW_REGEN_HP_BOSS   = 0.0120D;  // 1.20%
    public static final double AQW_REGEN_HP_RAID   = 0.0250D;  // 2.50%

    // Mana regen is double the health regen
    public static final double AQW_REGEN_MP_NORMAL = AQW_REGEN_HP_NORMAL * 2; // 0.30%
    public static final double AQW_REGEN_MP_ELITE  = AQW_REGEN_HP_ELITE  * 2; // 0.80%
    public static final double AQW_REGEN_MP_BOSS   = AQW_REGEN_HP_BOSS   * 2; // 2.40%
    public static final double AQW_REGEN_MP_RAID   = AQW_REGEN_HP_RAID   * 2; // 5.00%


}
