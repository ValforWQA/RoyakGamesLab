package Kaiden.Game.Server.Rooms.Monsters;

    public class MonsterSkill {
        public int skillId;
        public boolean cooldown = false;

        public void cooldown() {
            this.cooldown = true;
        }

        public boolean onCooldown() {
            return this.cooldown;
        }
    }
