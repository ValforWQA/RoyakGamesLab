package Kaiden.Game.Server.Rooms.Monsters;

import Kaiden.Database.Beans.MapMonsterBean;
import Kaiden.Database.Beans.MonsterBean;
import Kaiden.Database.Beans.MonsterSkillsBean;
import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Configuration.Log.Ansi;
import Kaiden.Database.StorageCache;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Bots.BotSession;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Server.Users.Utils.UserState;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.MonsterAttack;
import Kaiden.Game.Threads.MonsterRegeneration;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Rooms.Monsters.Combat.MonsterCombatMana;
import Kaiden.Game.Server.Rooms.Monsters.Combat.MonsterCombatNotifier;
import Kaiden.Game.Server.Rooms.Monsters.Combat.MonsterCombatTiming;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import jdbchelper.QueryResult;

import java.nio.channels.SocketChannel;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * MonsterAI with:
 * - Ordered skill list (sorted by skill ID ascending: 1,2,3,4,...).
 * - Skill Duration -> then Cooldown (AQW boss style).
 * - Global skill phases:
 *      * After combat starts, wait SKILL_PHASE_GAP_MS before ANY skills can be used.
 *      * After that, use skills in order while off cooldown.
 *      * Once all skills are on cooldown / unusable, wait another SKILL_PHASE_GAP_MS
 *        before they can be used again (fallback to auto attacks meanwhile).
 * - Fallback to Attack1,Attack2 when no skills are available / allowed.
 * - While a skill is casting, no basic attacks are sent (no anim stomping).
 * - Heal skill can trigger a regen window where monster is immune to damage.
 * - "repell" skill type reflects a portion of incoming damage back to attacker.
 * - 🔗 Linked pet → boss behavior via linkGroupId/linkBoss on MapMonsterBean.
 */
public class MonsterAI implements Runnable {

    private static final String PROP_VAMPIRE_IMMORTAL_READY_AT = "vampireImmortalReadyAt";
    private static final long VAMPIRE_IMMORTAL_COOLDOWN_MS = 90000L;
    private static final double VAMPIRE_IMMORTAL_HEALTH_TRIGGER = 0.20D;
    private static final double VAMPIRE_IMMORTAL_HEAL = 0.30D;

    public ScheduledFuture attacking;
    private final MonsterState state;
    private final MapMonsterBean mapMonster;
    private final MonsterBean monster;
    private final Room room;
    public Set<RemoveAura> auras;
    private MonsterRegeneration regenTask;


    // regen damage-immune window (while heal is active)
    private volatile long regenImmuneUntil = 0L;

    // ordered list of skill IDs (sorted ascending)
    private final List<Integer> skillOrder = new ArrayList<>();

    // Per-spawn, database-driven activators. An empty list preserves the legacy rotation.
    private final List<Activator> activators = new ArrayList<Activator>();
    private final Map<Integer, Integer> activatorUses = new HashMap<Integer, Integer>();
    private final Map<Integer, Long> activatorLastAt = new HashMap<Integer, Long>();
    private final Map<Integer, Long> activatorSeenCompletion = new HashMap<Integer, Long>();
    private long combatStartedAt = 0L;
    private int lastCompletedSkill = -1;
    private long skillCompletionSerial = 0L;
    // Universal, per-monster chain ownership; no monster IDs or animation labels.
    private int pendingChainSkill = -1;
    private int pendingChainSource = -1;
    private long chainUnlockAt = 0L;
    private static final class Activator {
        int id, skillId, relatedSkillId, maxUses;
        long delay, cooldown;
        double threshold;
        String type;
    }

    private void loadActivators() {
        QueryResult result = null;
        try {
            result = Storage.getInstance().getJdbc().query(
                "SELECT id,SkillID,TriggerType,ThresholdValue,RelatedSkillID,DelayMs,CooldownMs,MaxActivations " +
                "FROM monster_skill_activators WHERE MonsterID=? AND Enabled=1 ORDER BY Priority DESC,id ASC",
                this.monster.getId());
            while (result.next()) {
                Activator a = new Activator();
                a.id = result.getInt("id");
                a.skillId = result.getInt("SkillID");
                a.type = result.getString("TriggerType");
                a.threshold = result.getDouble("ThresholdValue");
                a.relatedSkillId = result.getInt("RelatedSkillID");
                a.delay = result.getLong("DelayMs");
                a.cooldown = result.getLong("CooldownMs");
                a.maxUses = result.getInt("MaxActivations");
                if (this.skillOrder.contains(a.skillId)) activators.add(a);
            }
        } catch (Exception ex) {
            SmartFoxServer.log.fine("Monster activators unavailable for " + this.monster.getId() + ": " + ex.getMessage());
        } finally {
            try { if (result != null) result.close(); } catch (Exception ignored) {}
        }
    }

    private Activator findReadyActivator(long now) {
        if (isCasting() || combatStartedAt == 0L) return null;
        double hp = 100.0D * Math.max(0, state.getHealth()) / Math.max(1, monster.getHealth());
        // Completion chains have exclusive priority over persistent HP conditions.
        // If the follow-up is cooling down, keep waiting rather than re-transforming.
        if (pendingChainSkill != -1) {
            for (Activator a : activators) {
                if (!"skill_complete".equals(a.type) ||
                    a.skillId != pendingChainSkill ||
                    a.relatedSkillId != pendingChainSource) continue;
                if (activatorEligible(a, now) && !isSkillOnCooldown(a.skillId)) return a;
            }
            return null;
        }
        if (now < chainUnlockAt) return null;
        for (Activator a : activators) {
            if ("skill_complete".equals(a.type)) continue;
            if (!activatorEligible(a, now)) continue;
            boolean ready = false;
            if ("hp_below".equals(a.type)) ready = hp <= a.threshold;
            else if ("hp_above".equals(a.type)) ready = hp >= a.threshold;
            else if ("combat_start".equals(a.type) || "elapsed".equals(a.type) || "interval".equals(a.type))
                ready = true;
            if (!ready || isSkillOnCooldown(a.skillId)) continue;
            MonsterSkillsBean skill = StorageCache.getInstance().getMonsterSkills(a.skillId);
            if (skill == null || !MonsterCombatMana.hasEnoughMana(this, skill)) continue;
            return a;
        }
        return null;
    }

    private boolean activatorEligible(Activator a, long now) {
        int uses = activatorUses.containsKey(a.id) ? activatorUses.get(a.id) : 0;
        if (a.maxUses > 0 && uses >= a.maxUses) return false;
        long last = activatorLastAt.containsKey(a.id) ? activatorLastAt.get(a.id) : 0L;
        if (last > 0 && now - last < a.cooldown) return false;
        if (now - combatStartedAt < a.delay) return false;
        MonsterSkillsBean skill = StorageCache.getInstance().getMonsterSkills(a.skillId);
        return skill != null && MonsterCombatMana.hasEnoughMana(this, skill);
    }

    private void markActivated(Activator a, long now) {
        activatorUses.put(a.id, (activatorUses.containsKey(a.id) ? activatorUses.get(a.id) : 0) + 1);
        activatorLastAt.put(a.id, now);
        if ("skill_complete".equals(a.type)) {
            activatorSeenCompletion.put(a.id, skillCompletionSerial);
            pendingChainSkill = -1;
            pendingChainSource = -1;
            // Hold the next trigger until this follow-up has completed.
            chainUnlockAt = Long.MAX_VALUE;
        }
    }

    private void markSkillCompleted(int id) {
        lastCompletedSkill = id;
        skillCompletionSerial++;
        if (chainUnlockAt == Long.MAX_VALUE) {
            chainUnlockAt = System.currentTimeMillis() + 3000L;
            return;
        }
        if (pendingChainSkill != -1) return;
        for (Activator a : activators) {
            if (!"skill_complete".equals(a.type) || a.relatedSkillId != id) continue;
            if (!activatorEligible(a, System.currentTimeMillis())) continue;
            long seen = activatorSeenCompletion.containsKey(a.id) ? activatorSeenCompletion.get(a.id) : 0L;
            if (skillCompletionSerial <= seen) continue;
            pendingChainSkill = a.skillId;
            pendingChainSource = id;
            break;
        }
    }

    // Next skill cursor. This makes monster skills cycle 1,2,3,4... instead of always picking the first ready skill.
    private int currentSkillIndex = 0;

    // After the last special in the ordered rotation casts, do not start a new
    // rotation until EVERY configured special skill is off cooldown.
    private boolean waitingForFullSkillCycle = false;

    // per-skill cooldowns for this monster (skillId -> nextAvailableEpochMillis)
    private final ConcurrentHashMap<Integer, Long> skillCooldowns = new ConcurrentHashMap<>();

    // monster is "busy" (casting/performing a skill) until this epoch millis
    private volatile long castingUntil = 0L;

    // Skill type being performed during castingUntil. Non-empty typed skills block player damage and show 0.
    private volatile String castingSkillType = "";

    // Incremented whenever the monster is restored/respawned. Delayed tasks
    // from a previous life must never alter the new life's cooldown state.
    private volatile long combatGeneration = 0L;

    // global "skill phase" gate -> when skills are allowed again
    // NOTE: initialized lazily on first AI tick so delay is relative to combat start,
    // not spawn time.
    private volatile long nextSkillPhaseAt = Long.MAX_VALUE;

    // gap between skill phases (and initial delay)
    private static final long SKILL_PHASE_GAP_MS = Configuration.MONSTER_ALLOWED_TIME;

    // Charm only lets a monster attack other alive monsters close enough on the same frame.
    private static final double CHARM_MONSTER_RANGE = 650.0D;

    // reserved for possible future cancellation of per-skill tasks
    private final ConcurrentHashMap<Integer, Object> scheduledFinishTasks = new ConcurrentHashMap<>();

    // logger interval seconds (optional)
    private static final int COOLDOWN_LOG_INTERVAL_SECONDS = 5;

    // 🔗 LINKED GROUPS: runtime registry
    // groupId -> definition (boss + pets)
    private static final Map<Integer, LinkedGroup> LINKED_GROUPS_BY_ID =
            new ConcurrentHashMap<>();
    // monMapId -> group
    private static final Map<Integer, LinkedGroup> LINKED_GROUPS_BY_MONMAP =
            new ConcurrentHashMap<>();
    // monMapId -> MonsterAI instance
    private static final Map<Integer, MonsterAI> AIS_BY_MONMAP =
            new ConcurrentHashMap<>();

    // Linked group holder
    private static final class LinkedGroup {
        final int groupId;
        volatile Integer bossMonMapId;
        final Set<Integer> petMonMapIds =
                Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());

        LinkedGroup(int groupId) {
            this.groupId = groupId;
        }
    }

    public MonsterAI(MapMonsterBean mapMon, Room room) {
        this.mapMonster = mapMon;
        this.monster = StorageCache.getInstance().getMonster(mapMon.getMonsterId());
        this.room = room;
        this.state = new MonsterState(this, this.monster.getHealth(), this.monster.getMana(), 100);
        this.regenTask = new MonsterRegeneration(this.mapMonster, this);

        // thread-safe set for auras (RemoveAura tasks)
        this.auras = Collections.newSetFromMap(new ConcurrentHashMap<RemoveAura, Boolean>());

        // 🔗 Register in linked group registry (if configured)
        registerInLinkedGroup();

        // Fill skills from monster.skills then sort ascending by ID
        try {
            for (MonsterSkill skill : this.monster.skills) {
                this.skillOrder.add(skill.skillId);
                MonsterSkillsBean msb = StorageCache.getInstance().getMonsterSkills(skill.skillId);
                if (msb != null) {
                    SmartFoxServer.log.info("Monster " + this.monster.getName() +
                            " registered skill: " + msb.getName() + " (" + skill.skillId + ")");
                } else {
                    SmartFoxServer.log.info("Monster skill id not found in cache: " + skill.skillId);
                }
            }

            Collections.sort(this.skillOrder);

            SmartFoxServer.log.info("Monster " + this.monster.getName() +
                    " skillOrder (ascending IDs): " + this.skillOrder);
        } catch (Exception e) {
            SmartFoxServer.log.fine("Error initializing monster skills for monsterId=" +
                    mapMon.getMonsterId() + " : " + e.getMessage());
        }

        loadActivators();
        // NOTE: nextSkillPhaseAt is initialized lazily on first AI tick
        // so the delay is relative to combat start, not spawn.
    }

    // 🔗 Register this monster into global linked-group maps
    private void registerInLinkedGroup() {
        if (this.mapMonster == null) return;

        int monMapId = this.mapMonster.getMonMapId();
        AIS_BY_MONMAP.put(monMapId, this);

        LinkedGroup stale = LINKED_GROUPS_BY_MONMAP.remove(monMapId);
        if (stale != null) {
            stale.petMonMapIds.remove(monMapId);
            if (stale.bossMonMapId != null && stale.bossMonMapId == monMapId) stale.bossMonMapId = null;
        }

        int groupId = this.mapMonster.getLinkGroupId();
        if (groupId <= 0) {
            // not part of a linked group
            return;
        }

        LinkedGroup group = LINKED_GROUPS_BY_ID.get(groupId);
        if (group == null) {
            group = new LinkedGroup(groupId);
            LINKED_GROUPS_BY_ID.put(groupId, group);
        }

        if (this.mapMonster.isLinkBoss()) {
            group.bossMonMapId = monMapId;
        } else {
            group.petMonMapIds.add(monMapId);
        }

        LINKED_GROUPS_BY_MONMAP.put(monMapId, group);
    }

    /** Convenience: true if this monster is currently mid-skill (Duration window). */
    private boolean isCasting() {
        return System.currentTimeMillis() < this.castingUntil;
    }

    /**
     * During a typed monster skill duration, player hits should still show the normal
     * damage number packet, but the amount is 0 and monster HP is not reduced.
     */
    public boolean blocksPlayerDamageWhileCastingTypedSkill() {
        // Only Heal owns the temporary 0-damage protection window.
        // Other typed monster skills must not make the monster invulnerable just
        // because they have a Duration value.
        return isCasting() && ("heal".equalsIgnoreCase(this.castingSkillType) || "invulnerable".equalsIgnoreCase(this.castingSkillType));
    }

    /** True if monster is in a heal-based regen immunity window. */
    public boolean isRegenImmune() {
        return System.currentTimeMillis() < this.regenImmuneUntil;
    }

    private void startCooldownLogger() {
        try {
            Executor.getInstance().scheduleTask(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (mapMonster == null || state == null || state.isDead()) {
                            return;
                        }
                        logCooldownsNow();
                    } catch (Throwable t) {
                        SmartFoxServer.log.fine("Cooldown logger error: " + t.getMessage());
                    } finally {
                        try {
                            if (mapMonster != null && state != null && !state.isDead()) {
                                Executor.getInstance().scheduleTask(this, COOLDOWN_LOG_INTERVAL_SECONDS, TimeUnit.SECONDS);
                            }
                        } catch (Throwable ignore) {}
                    }
                }
            }, COOLDOWN_LOG_INTERVAL_SECONDS, TimeUnit.SECONDS);
        } catch (Throwable t) {
            SmartFoxServer.log.fine("Failed to start cooldown logger: " + t.getMessage());
        }
    }

    public void logCooldownsNow() {
        long now = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();

        sb.append(Ansi.YELLOW)
                .append("[MonsterCD] ")
                .append("Monster[")
                .append(mapMonster != null ? mapMonster.getMonMapId() : "unknown")
                .append("] active cooldowns: ");

        boolean any = false;

        for (Map.Entry<Integer, Long> e : skillCooldowns.entrySet()) {
            int skillId = e.getKey();
            long nextAvailable = e.getValue();
            long remMs = nextAvailable - now;
            if (remMs <= 0) {
                continue;
            }

            long remSec = (remMs + 999) / 1000; // round up to seconds

            MonsterSkillsBean msb = StorageCache.getInstance().getMonsterSkills(skillId);
            String name = (msb != null) ? msb.getName() : "skill#" + skillId;

            sb.append("[")
                    .append(skillId)
                    .append(":")
                    .append(name)
                    .append("=")
                    .append(remSec)
                    .append("s] ");

            any = true;
        }

        if (!any) {
            sb.append("none");
        }

        sb.append(Ansi.RESET);

        //System.out.println(sb.toString());
    }

    public void cancel() {
        if (!this.state.hasTargets() || this.state.isNeutral()) {
            try {
                this.restore();
            } catch (Exception e) {
                SmartFoxServer.log.fine("Error while restoring monster state: " + e.getMessage());
            }
            if (this.attacking != null && !this.attacking.isDone()) {
                this.attacking.cancel(false);
            }
            // stop regen if active
            if (this.regenTask != null && this.regenTask.isRegenerating()) {
                this.regenTask.cancel();
            }
            this.regenImmuneUntil = 0L;
        }
    }

    @Override
    public void run() {
        try {
            if (this.state.isDead()) {
                if (this.attacking != null) this.attacking.cancel(false);
                return;
            }

            if (isCasting()) {
                return;
            }

            if (this.state.hasAuraEffect("charm")) {
                this.state.removeAuraSourceTargets("charm");

                MonsterAI charmedTarget = getRandomCharmMonsterTarget();
                if (charmedTarget != null) {
                    this.attackMonster(charmedTarget);
                }

                // While charmed, never fall back to attacking the caster/player target list.
                return;
            }

            int userId = this.state.getRandomTarget();

            if (!this.state.hasTargets()) {
                this.cancel();
                return;
            }

            User user = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
            if (user == null) {
                BotSession botTarget = BotManager.getInstance().getBotByEntId(userId);
                if (botTarget != null && botTarget.isActive()) {
                    if (this.room != null
                            && this.room.getName().equalsIgnoreCase(botTarget.getRoomName())
                            && this.mapMonster.getFrame().equals(botTarget.getFrame())
                            && botTarget.getState() != null
                            && !botTarget.getState().isDead()) {
                        this.attackBot(botTarget);
                        return;
                    }
                }

                // UPDATED: avoid NPE when user is gone
                this.state.removeTarget(userId);

                if (!this.state.hasTargets()) {
                    this.cancel();
                }
                return;
            }

            State targetState = (State) user.properties.get("state");
            if (targetState == null) {
                this.state.removeTarget(userId);
                this.state.clearAuras();
                Users.getInstance().sendUotls(user, false, false, false, false, false, false, true);
                if (!this.state.hasTargets()) {
                    this.cancel();
                }
                return;
            }

            // If the target is already dead, just stop targeting them.
            if (targetState.isDead()) {
                this.state.removeTarget(userId);
                targetState.clearAuras();
                this.state.clearAuras();
                targetState.removeMonsterTarget(this.getMapMonster().getMonMapId());
                Users.getInstance().sendUotls(user, false, false, false, false, false, false, true);
                if (!this.state.hasTargets()) {
                    this.cancel();
                }
                return;
            }

            if (targetState.getMana() <= 1) {
                targetState.setMana(targetState.getMana() + 10);
            }

            if (!(this.room.getId() == user.getRoom()
                    && this.mapMonster.getFrame().equals(user.properties.get("frame")))) {

                targetState.setState(Properties.STATE_NORMAL);
                targetState.clearAuras();
                this.state.clearAuras();
                this.state.regenUser(user); // regen when out-of-room/frame
                this.state.removeTarget(userId);
                targetState.removeMonsterTarget(this.getMapMonster().getMonMapId());
                Users.getInstance().sendUotls(user, false, false,false, false, false, false, true);
                if (!this.state.hasTargets()) {
                    this.cancel();
                }
                return;
            }

            // Initialize the *first* skill phase gate on first AI tick
            if (this.nextSkillPhaseAt == Long.MAX_VALUE) {
                this.nextSkillPhaseAt = System.currentTimeMillis() + SKILL_PHASE_GAP_MS;
            }

            long now = System.currentTimeMillis();
            if (this.combatStartedAt == 0L) this.combatStartedAt = now;
            Activator selectedActivator = activators.isEmpty() ? null : findReadyActivator(now);
            boolean skillsPhaseOpen = !activators.isEmpty() || now >= this.nextSkillPhaseAt;

            // If we are still in the global wait window, or no skills configured:
            // -> ONLY do basic Attack1/Attack2.
            if (!skillsPhaseOpen || this.skillOrder.isEmpty()) {
                fallbackBasicAttackIfPossible(user);
                return;
            }

            // attempt to find a usable skill from the ordered list
            Integer usableSkillId = activators.isEmpty() ? findUsableSkillId() : (selectedActivator == null ? -1 : selectedActivator.skillId);

            if (usableSkillId != null && usableSkillId != -1) {
                MonsterSkillsBean skillBean = StorageCache.getInstance().getMonsterSkills(usableSkillId);
                if (skillBean != null) {
                    if (isSkillOnCooldown(usableSkillId)) {
                        fallbackBasicAttackIfPossible(user);
                        return;
                    }

                    int manaCost = getSkillManaCost(skillBean);
                    if (MonsterCombatMana.hasEnoughMana(this, skillBean)) {
                        /*
                         * Spend monster skill MP immediately when the skill is accepted for casting.
                         * This is the single mana-spend path for monster skills.
                         *
                         * Old behavior checked mana here but tried to spend later in MonsterAttack,
                         * which could make mana appear unchanged or be skipped depending on timing.
                         */
                        if (!MonsterCombatMana.consumeForSkill(this, user, skillBean)) {
                            fallbackBasicAttackIfPossible(user);
                            return;
                        }

                        final long durationMs = getSkillDurationMs(skillBean);

                        String castType = skillBean.getType();
                        this.castingSkillType = "I".equalsIgnoreCase(skillBean.getEffects()) ? "invulnerable" : (castType == null ? "" : castType.trim().toLowerCase());

                        // Type hooks only run after mana was successfully spent.
                        if (!this.castingSkillType.isEmpty()) {
                            handleSkillTypeOnCast(user, skillBean);
                        }
                        final long cooldownMs = getSkillCooldownMsFromBean(skillBean);
                        final boolean healSkill = "heal".equals(this.castingSkillType);

                        /*
                         * Normal special skills begin cooldown immediately.
                         * Heal is intentionally different: its Duration is the active
                         * heal/protection phase. During that phase incoming player
                         * damage stays at 0. Only when the heal phase actually ends do
                         * we place Heal on cooldown and release the 0-damage window.
                         */
                        if (!healSkill) {
                            setSkillCooldown(usableSkillId, cooldownMs);
                        }

                        // The ordered rotation advances only after this exact skill
                        // has successfully consumed mana and been accepted for cast.
                        if (activators.isEmpty()) advanceSkillCursor();
                        else markActivated(selectedActivator, now);

                        final int completedSkillId = usableSkillId;
                        final long castGeneration = this.combatGeneration;
                        if (durationMs > 0L) {
                            final long endCast = System.currentTimeMillis() + durationMs;
                            this.castingUntil = endCast;

                            try {
                                Executor.getInstance().scheduleTask(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (combatGeneration != castGeneration) {
                                            return;
                                        }
                                        if (castingUntil == endCast) {
                                            // For Heal, transition from ACTIVE -> COOLDOWN here.
                                            if (healSkill) {
                                                setSkillCooldown(usableSkillId, cooldownMs);
                                            }
                                            castingUntil = 0L;
                                            castingSkillType = "";
                                            finishSkillDuration(skillBean);
                                            markSkillCompleted(completedSkillId);
                                        }
                                    }
                                }, durationMs, TimeUnit.MILLISECONDS);
                            } catch (Throwable t) {
                                if (healSkill) {
                                    setSkillCooldown(usableSkillId, cooldownMs);
                                }
                                this.castingUntil = 0L;
                                this.castingSkillType = "";
                            }
                        } else {
                            if (healSkill) {
                                // Instant Heal: there is no active protection window,
                                // so cooldown begins immediately after the cast.
                                setSkillCooldown(usableSkillId, cooldownMs);
                            }
                            this.castingUntil = 0L;
                            this.castingSkillType = "";
                            finishSkillDuration(skillBean);
                            markSkillCompleted(completedSkillId);
                        }

                        // Send/apply the monster skill immediately.
                        Executor.getInstance().scheduleTask(
                                new MonsterAttack(this, user, skillBean),
                                0,
                                TimeUnit.MILLISECONDS
                        );
                    } else {
                        fallbackBasicAttackIfPossible(user);
                    }
                } else {
                    fallbackBasicAttackIfPossible(user);
                }
            } else {
                // No usable skill (all on cooldown / no mana / no targets) -> auto,
                // and phase lock handled inside findUsableSkillId
                fallbackBasicAttackIfPossible(user);
            }
        } catch (Throwable t) {
            SmartFoxServer.log.fine("MonsterAI.run() error for mapMonsterId=" +
                    (mapMonster != null ? mapMonster.getMonMapId() : "unknown") +
                    " : " + t.getMessage());
            t.printStackTrace();
        }
    }

    /**
     * Fallback to basic Attack1/Attack2 when no skills are usable.
     */
    private void fallbackBasicAttackIfPossible(User user) {
        if (isCasting()) {
            return;
        }
        this.attack(user);
    }

    private boolean isDead() {
        if (this.state.isDead()) {
            if (this.attacking != null) {
                this.attacking.cancel(true);
            }
            return true;
        } else {
            return false;
        }
    }



    private void handlePlayerDeathFromMonster(User user, State userState) {
        if (user == null || userState == null) return;
        if (!userState.isDead()) return;

        incrementPlayerMonsterDeath(user);

        //System.out.println(Ansi.BLUE + ("Handling death for user: " + user.getName()));

        // Prefer UserState so we get respawntime + aura clear.
        UserState combatState = (UserState) user.properties.get("state");
        if (combatState != null && !combatState.isDead()) {
            combatState.die();
        }
        userState.die();

        // Clean monster-side and player-side combat state/auras
        this.state.removeTarget(user.getUserId());
        this.state.clearAuras();
        userState.clearAuras();
        this.cancel();
    }

    private void incrementPlayerMonsterDeath(User user) {
        if (user == null) {
            return;
        }

        final String countedKey = "monsterdeathcounted";
        if (Boolean.TRUE.equals(user.properties.get(countedKey))) {
            return;
        }

        try {
            Object currentDeaths = user.properties.get(Properties.DEATH_COUNT);
            if (currentDeaths instanceof Number) {
                user.properties.put(Properties.DEATH_COUNT, ((Number) currentDeaths).intValue() + 1);
            }

            user.properties.put(countedKey, true);

            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[MonsterDeath] " + user.getName() + " was defeated by "
                            + (this.monster != null ? this.monster.getName() : "monster")
                            + " (+1 DeathCount)"
            );
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[MonsterDeath] Failed to update DeathCount for " + user.getName() + ": " + e.getMessage()
            );
        }
    }

    /**
     * Public hook so other threads (like MonsterAttack) can route
     * kill events through the same death pipeline.
     */
    public void onPlayerKilledByMonster(User user) {
        if (user == null) return;
        State s = (State) user.properties.get("state");
        if (s == null) return;
        if (!s.isDead()) return;
        handlePlayerDeathFromMonster(user, s);
    }

    private void attackBot(final BotSession bot) {
        if (isCasting() || bot == null || bot.getState() == null) {
            return;
        }

        if (!this.isDead() && !this.state.isDisabled()) {
            if (bot.getState().isDead()) {
                this.state.removeTarget(bot.getEntId());
                return;
            }

            DamageType type = DamageType.HIT;
            int damage = CombatEvaluator.rollMonsterAutoAttackDamage(this);
            if (Math.random() < 0.08D) {
                type = DamageType.CRITICAL;
                damage = (int) Math.round(damage * 1.5D);
            } else if (Math.random() < 0.06D) {
                type = DamageType.MISS;
                damage = 0;
            }

            damage = applyMonsterOutgoingModifiers(damage);
            damage = bot.getState().absorbShield(damage);

            MonsterCombatMana.regenAfterAction(this, 0.02D);
            this.state.applyMonsterOnDamageDealt(damage);
            bot.getState().decreaseHealth(damage);
            bot.getState().setState(bot.getState().isDead() ? Properties.STATE_DEAD : Properties.STATE_COMBAT);

            if (bot.getState().isDead()) {
                this.state.removeTarget(bot.getEntId());
                Executor.getInstance().scheduleTask(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            bot.getState().restore();
                            if (room != null && room.getName().equalsIgnoreCase(bot.getRoomName())) {
                                JSONObject uotls = new JSONObject();
                                JSONObject o = new JSONObject();
                                o.put("intHP", bot.getState().getHealth());
                                o.put("intHPMax", bot.getState().getMaxHealth());
                                o.put("intMP", bot.getState().getMana());
                                o.put("intMPMax", bot.getState().getMaxMana());
                                o.put("intState", bot.getState().getState());
                                uotls.put("cmd", "uotls");
                                uotls.put("o", o);
                                uotls.put("unm", bot.getName());
                                Kaiden_Extension.getInstance().send(uotls, room.getChannellList());
                            }
                        } catch (Throwable ignored) {}
                    }
                }, 3500L, TimeUnit.MILLISECONDS);
            }

            JSONObject p = (new JSONObject()).accumulate(bot.getName(), bot.getState().getData());
            JSONArray sara = (new JSONArray()).element(
                    (new JSONObject()).accumulate("actionResult", this.getAction(type, damage, bot))
                            .accumulate("iRes", 1));
            JSONObject m = (new JSONObject()).accumulate(
                    String.valueOf(this.mapMonster.getMonMapId()),
                    (new JSONObject())
                            .accumulate("intMP", this.state.getMana())
                            .accumulate("intMPMax", this.state.getMaxMana()));
            JSONObject ct = (new JSONObject()).accumulate(
                            "anims", (new JSONArray()).element(this.getAnim(bot)))
                    .accumulate("p", p)
                    .accumulate("m", m)
                    .accumulate("sara", sara)
                    .accumulate("cmd", "ct");
            Kaiden_Extension.getInstance().send(ct, this.room.getChannellList());
        }
    }

    @SuppressWarnings("unchecked")
    private MonsterAI getRandomCharmMonsterTarget() {
        try {
            if (this.room == null || this.room.properties == null || this.mapMonster == null) return null;

            Object monsterObj = this.room.properties.get("monsters");
            if (!(monsterObj instanceof Map)) return null;

            Map<Integer, MonsterAI> monsters = (Map<Integer, MonsterAI>) monsterObj;
            List<MonsterAI> candidates = new ArrayList<MonsterAI>();

            for (MonsterAI other : monsters.values()) {
                if (other == null || other == this || other.getState() == null || other.getMapMonster() == null) continue;
                if (other.getState().isDead()) continue;
                if (other.getMapMonster().getMonMapId() == this.mapMonster.getMonMapId()) continue;

                String myFrame = this.mapMonster.getFrame();
                String otherFrame = other.getMapMonster().getFrame();
                if (myFrame == null || otherFrame == null || !myFrame.equals(otherFrame)) continue;

                if (!isMonsterInCharmRange(other)) continue;

                candidates.add(other);
            }

            if (candidates.isEmpty()) return null;
            return candidates.get(new Random().nextInt(candidates.size()));
        } catch (Throwable t) {
            SmartFoxServer.log.fine("Charm target pick failed for mapMonsterId="
                    + (mapMonster != null ? mapMonster.getMonMapId() : "unknown")
                    + " : " + t.getMessage());
            return null;
        }
    }

    private boolean isMonsterInCharmRange(MonsterAI other) {
        if (other == null || other.getMapMonster() == null || this.mapMonster == null) return false;

        double dx = other.getMapMonster().getPosX() - this.mapMonster.getPosX();
        double dy = other.getMapMonster().getPosY() - this.mapMonster.getPosY();
        double distance = Math.sqrt((dx * dx) + (dy * dy));

        return distance <= CHARM_MONSTER_RANGE;
    }

    private void attackMonster(final MonsterAI targetMonster) {
        if (isCasting() || targetMonster == null || targetMonster.getState() == null || targetMonster.getMapMonster() == null) {
            return;
        }

        if (this.isDead() || this.state.isDisabled() || targetMonster.getState().isDead()) {
            return;
        }

        DamageType type = DamageType.HIT;
        int damage = CombatEvaluator.rollMonsterAutoAttackDamage(this);

        if (Math.random() < 0.08D) {
            type = DamageType.CRITICAL;
            damage = (int) Math.round(damage * 1.5D);
        } else if (Math.random() < 0.06D) {
            type = DamageType.MISS;
            damage = 0;
        }

        if (!MonsterAI.canDamageMonster(targetMonster)) {
            damage = 0;
            type = DamageType.HIT;
        } else {
            damage = applyMonsterOutgoingModifiers(damage);
            damage = applyIncomingMonsterModifiers(targetMonster, damage);

            MonsterCombatMana.regenAfterAction(this, 0.02D);
            this.state.applyMonsterOnDamageDealt(damage);
            targetMonster.getState().decreaseHealth(damage);
            targetMonster.getState().applyMonsterOnDamageTaken(damage);

            int charmOwnerUserId = this.state.getAuraSourceUserIdByEffect("charm");
            if (charmOwnerUserId > 0) {
                targetMonster.getState().addTarget(charmOwnerUserId);
            }
        }

        if (targetMonster.getState().isDead()) {
            targetMonster.getState().die();
        }

        JSONObject m = new JSONObject();
        m.put(
                String.valueOf(this.mapMonster.getMonMapId()),
                new JSONObject()
                        .accumulate("intMP", this.state.getMana())
                        .accumulate("intMPMax", this.state.getMaxMana())
                        .accumulate("intState", this.state.getState())
        );
        m.put(
                String.valueOf(targetMonster.getMapMonster().getMonMapId()),
                targetMonster.getState().getData().accumulate("targets", targetMonster.getState().getTargets())
        );

        JSONArray sara = new JSONArray().element(
                new JSONObject()
                        .accumulate("actionResult", this.getAction(type, damage, targetMonster))
                        .accumulate("iRes", 1)
        );

        JSONObject ct = new JSONObject()
                .accumulate("anims", new JSONArray().element(this.getAnim(targetMonster)))
                .accumulate("m", m)
                .accumulate("sara", sara)
                .accumulate("cmd", "ct");

        Kaiden_Extension.getInstance().send(ct, this.room.getChannellList());
    }

    private int applyIncomingMonsterModifiers(MonsterAI targetMonster, int amount) {
        if (targetMonster == null || targetMonster.getState() == null || amount <= 0) return amount;
        double incoming = Math.max(0.05D, 1.0D + targetMonster.getState().getMonsterIncDmg());
        double resistTotal = Math.max(0.0D, Math.min(0.85D, targetMonster.getState().getMonsterAllRes() + targetMonster.getState().getMonsterPhysRes()));
        int adjusted = (int) Math.max(0, Math.round(amount * incoming * (1.0D - resistTotal)));
        return targetMonster.getState().absorbShield(adjusted);
    }

    private void attack(User user) {
        if (isCasting()) {
            return;
        }

        if (!this.isDead() && !this.state.isDisabled()) {
            if (user == null) {
                return;
            }

            Stats stats = (Stats) user.properties.get("stats");
            @SuppressWarnings("unchecked")
            Set<RemoveAura> userAuras = (((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set<RemoveAura>) user.properties.get("auras"));
            State userState = (State) user.properties.get("state");

            if (userState == null || userState.isDead()) {
                return;
            }

            DamageType type = CombatEvaluator.resolveMonsterVsPlayer(this, stats, user);
            int damage = CombatEvaluator.rollMonsterAutoAttackDamage(this);

            switch (type) {
                case CRITICAL:
                    damage = (int) Math.round(damage * Math.max(1.05D, 1.5D + this.state.getMonsterCritMultiplier()));
                    break;
                case DODGE:
                case MISS:
                case PARRY:
                    damage = 0;
                    break;
                default:
                    break;
            }

            damage = Damage.getReducedDamage(damage, userAuras);
            damage = applyMonsterOutgoingModifiers(damage);
            if (this.state.consumeTraitEffect("spinningdragon")) {
                damage = 0;
                type = DamageType.HIT;
            }
            damage = applyIncomingPlayerModifiers(stats, userState, damage);
            damage = applyVampireImmortalIfNeeded(user, userState, userAuras, damage);

            MonsterCombatMana.regenAfterAction(this, 0.02D);
            this.state.applyMonsterOnDamageDealt(damage);
            userState.decreaseHealth(damage);

            if (Math.random() < userState.getMana()) {
                double manaMultiplier = 0.04;
                int manaRegen = (int) (damage * manaMultiplier);
                int maxRegen = (int) (userState.getMaxMana() * 0.8);
                manaRegen = Math.min(manaRegen, maxRegen);
                userState.increaseMana(manaRegen);
                //System.out.println(Ansi.RED + ("Increased to." + manaRegen));
                //userState.increaseManaByPercent(0.020D);
            }

            // Use shared death handler
            if (userState.isDead()) {
                handlePlayerDeathFromMonster(user, userState);
            }

            JSONObject p = (new JSONObject()).accumulate(user.getName(), userState.getData());
            JSONArray sara = (new JSONArray()).element(
                    (new JSONObject()).accumulate("actionResult", this.getAction(type, damage, user))
                            .accumulate("iRes", 1));
            JSONObject m = (new JSONObject()).accumulate(
                    String.valueOf(this.mapMonster.getMonMapId()),
                    (new JSONObject())
                            .accumulate("intMP", this.state.getMana())
                            .accumulate("intMPMax", this.state.getMaxMana()));
            JSONObject ct = (new JSONObject()).accumulate(
                            "anims", (new JSONArray()).element(this.getAnim(user)))
                    .accumulate("p", p)
                    .accumulate("m", m)
                    .accumulate("cmd", "ct");
            Kaiden_Extension.getInstance().send(ct, this.getUserChannelButOne(this.room, user.getUserId()));
            ct.accumulate("sara", sara);
            Kaiden_Extension.getInstance().send(ct, user);
        }
    }


    private int applyVampireImmortalIfNeeded(User targetUser, State targetState, Set<RemoveAura> userAuras, int incomingDamage) {
        if (targetUser == null || targetState == null || incomingDamage <= 0) return incomingDamage;
        if (!hasAuraEffect(userAuras, "immortal")) return incomingDamage;

        int maxHp = Math.max(1, targetState.getMaxHealth());
        int hpAfter = targetState.getHealth() - incomingDamage;
        int triggerHp = (int) Math.max(1, Math.round(maxHp * VAMPIRE_IMMORTAL_HEALTH_TRIGGER));
        if (hpAfter > triggerHp && hpAfter > 0) return incomingDamage;

        long now = System.currentTimeMillis();
        Object readyObj = targetUser.properties.get(PROP_VAMPIRE_IMMORTAL_READY_AT);
        long readyAt = (readyObj instanceof Long) ? (Long) readyObj : 0L;
        if (now < readyAt) return incomingDamage;

        targetUser.properties.put(PROP_VAMPIRE_IMMORTAL_READY_AT, now + VAMPIRE_IMMORTAL_COOLDOWN_MS);

        int reducedDamage = Math.max(0, targetState.getHealth() - 1);
        int healAfterHit = (int) Math.max(1, Math.round(maxHp * VAMPIRE_IMMORTAL_HEAL));

        targetState.decreaseHealth(reducedDamage);
        targetState.increaseHealth(healAfterHit);

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red",
                "[Vampire] Immortal Curse saved " + targetUser.getName() + " and restored " + healAfterHit + " HP."
        );

        return 0;
    }

    private boolean hasAuraEffect(Set<RemoveAura> auraSet, String effectKey) {
        if (auraSet == null || auraSet.isEmpty() || effectKey == null) return false;
        for (RemoveAura ra : auraSet) {
            if (ra == null || ra.getAura() == null) continue;
            AuraBean aura = ra.getAura();
            if (aura.effects == null || aura.effects.isEmpty()) continue;
            for (int effectId : aura.effects) {
                try {
                    AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                    if (ae != null && ae.getStat() != null && effectKey.equalsIgnoreCase(ae.getStat().trim())) {
                        return true;
                    }
                } catch (Exception ignored) {
                    Kaiden_Engine.getInstance().sendEmulatorMessage("orange", "[Vampire] effect read failed: " + ignored.getClass().getSimpleName() + " - " + ignored.getMessage());
                }
            }
        }
        return false;
    }

    private int applyMonsterOutgoingModifiers(int amount) {
        if (amount <= 0) return amount;
        double outMod = this.state.getMonsterOutDmg();
        double outMultiplier = Math.max(0.05D, 1.0D + outMod);
        int consumedStacks = this.state.getAuraStackCount(Kaiden.Game.Server.Combat.Player.EnhancementProcAuras.CONSUMED);
        if (consumedStacks > 0) {
            double penalty = Math.min(0.30D, 0.10D + (0.01D * consumedStacks));
            outMultiplier *= Math.max(0.05D, 1.0D - penalty);
        }
        return (int) Math.max(0, Math.round(amount * outMultiplier));
    }

    private int applyIncomingPlayerModifiers(Stats targetStats, State targetState, int amount) {
        if (targetStats == null || targetState == null || amount <= 0) return amount;
        double incoming = Math.max(0.05D, targetStats.get$incdmg());
        double resistTotal = Math.max(0.0D, Math.min(0.85D, targetStats.get$allres() + targetStats.get$physres()));
        int adjusted = (int) Math.max(0, Math.round(amount * incoming * (1.0D - resistTotal)));
        return targetState.absorbShield(adjusted);
    }

    public LinkedList<SocketChannel> getUserChannelButOne(Room room, int userId) {
        LinkedList<SocketChannel> list = new LinkedList<>();
        User[] usersInRoom = room.getAllUsersButOne(userId);
        for (User user : usersInRoom) {
            list.add(user.getChannel());
        }
        return list;
    }

    /**
     * Finds the next usable skill id from the ordered list.
     * We always scan the sorted list from lowest ID to highest:
     * - First ready skill wins.
     * If skills are allowed but NONE are usable, we start a new phase lock.
     */
    private Integer findUsableSkillId() {
        if (isCasting()) return -1;
        if (skillOrder.isEmpty()) return -1;

        /*
         * FULL-CYCLE GATE:
         * Once the last skill in the ordered list has cast, the monster uses
         * Attack1/Attack2 until ALL configured special skills are off cooldown.
         * This prevents Skill 1 from starting another rotation just because it
         * recovered before Skill 2/3/etc.
         */
        if (waitingForFullSkillCycle) {
            if (!areAllOrderedSkillsOffCooldown()) {
                return -1;
            }
            waitingForFullSkillCycle = false;
            currentSkillIndex = 0;
        }

        /*
         * STRICT ordered rotation.
         *
         * We only inspect the skill at currentSkillIndex. If that exact skill is
         * cooling down, lacks mana, or currently has no valid target, we DO NOT
         * skip ahead to a later special skill. The monster falls back to
         * Attack1/Attack2 until the expected skill becomes usable.
         *
         * The cursor is advanced only after a skill has actually been accepted
         * for casting in run().
         */
        if (currentSkillIndex < 0 || currentSkillIndex >= skillOrder.size()) {
            currentSkillIndex = 0;
        }

        int sid = skillOrder.get(currentSkillIndex);

        if (isSkillOnCooldown(sid)) {
            return -1;
        }

        MonsterSkillsBean skill = StorageCache.getInstance().getMonsterSkills(sid);
        if (skill == null) {
            // Bad/missing DB row should not deadlock the whole monster forever.
            advanceSkillCursor();
            return -1;
        }

        if (this.state.getMana() < getSkillManaCost(skill)) {
            return -1;
        }

        // Self-only skills (Heal and self-target Aura skills) do not need a player
        // target count. Offensive skills always require at least one live target;
        // HitTargets=0 is treated as 1 for those skills.
        if (!isSelfTargetMonsterSkill(skill)) {
            int hitTargets = Math.max(1, skill.getHitTargets());
            String targets = this.state.getRandomTargets(hitTargets);
            if (targets == null || targets.trim().isEmpty()) {
                return -1;
            }
        }

        return sid;
    }

    private void advanceSkillCursor() {
        if (skillOrder.isEmpty()) {
            currentSkillIndex = 0;
            waitingForFullSkillCycle = false;
            return;
        }

        // If this was the final skill in the ordered list, the current cycle is
        // complete. Hold at index 0 and wait until EVERY skill cooldown is ready
        // before allowing the next cycle to begin.
        if (currentSkillIndex >= skillOrder.size() - 1) {
            currentSkillIndex = 0;
            waitingForFullSkillCycle = true;
            return;
        }

        currentSkillIndex++;
    }

    private boolean areAllOrderedSkillsOffCooldown() {
        if (skillOrder.isEmpty()) {
            return true;
        }

        for (Integer skillId : skillOrder) {
            if (skillId != null && isSkillOnCooldown(skillId)) {
                return false;
            }
        }
        return true;
    }

    /**
     * True when this monster skill can be cast without selecting a player target.
     * Heal is always self-targeted. Aura-only skills are considered self-targeted when
     * their configured AuraID points to an aura whose target is self/monster.
     */
    private boolean isSelfTargetMonsterSkill(MonsterSkillsBean skill) {
        if (skill == null) return false;

        String type = skill.getType() == null ? "" : skill.getType().trim().toLowerCase();
        if ("heal".equals(type)) {
            return true;
        }

        if (skill.hasAuraId()) {
            try {
                AuraBean aura = StorageCache.getInstance().getAura(skill.getAuraId());
                if (aura != null && (aura.isSelfTarget() || aura.isMonsterTarget())) {
                    return true;
                }
            } catch (Throwable ignored) {}
        }

        return false;
    }

    private JSONObject getAction(DamageType type, int damage, User user) {
        JSONObject action = new JSONObject();
        action.put("hp", damage);
        action.put("cInf", "m:" + this.mapMonster.getMonMapId());
        action.put("tInf", "p:" + user.getUserId());
        action.put("type", type.toString());
        return action;
    }

    private JSONObject getAction(DamageType type, int damage, BotSession bot) {
        JSONObject action = new JSONObject();
        action.put("hp", damage);
        action.put("cInf", "m:" + this.mapMonster.getMonMapId());
        action.put("tInf", "p:" + bot.getEntId());
        action.put("type", type.toString());
        return action;
    }

    private JSONObject getAction(DamageType type, int damage, MonsterAI targetMonster) {
        JSONObject action = new JSONObject();
        action.put("hp", damage);
        action.put("cInf", "m:" + this.mapMonster.getMonMapId());
        action.put("tInf", "m:" + targetMonster.getMapMonster().getMonMapId());
        action.put("type", type.toString());
        return action;
    }

    private JSONObject getAnim(BotSession bot) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", bot.getFrame());
        anim.put("cInf", "m:" + this.mapMonster.getMonMapId());
        anim.put("fx", "m");
        anim.put("tInf", "p:" + bot.getEntId());
        anim.put("animStr", "Attack1,Attack2");
        return anim;
    }

    private JSONObject getAnim(String frame, String targets, MonsterSkillsBean skill) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", frame);
        anim.put("cInf", "m:" + this.mapMonster.getMonMapId());
        anim.put("fx", skill.getEffects());
        anim.put("tInf", targets);
        anim.put("animStr", skill.getAnimation());
        if (!skill.getStrl().isEmpty()) {
            anim.put("strl", skill.getStrl());
        }
        return anim;
    }

    private JSONObject getAnim(User user) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", user.properties.get("frame"));
        anim.put("cInf", "m:" + this.mapMonster.getMonMapId());
        anim.put("fx", "m");
        anim.put("tInf", "p:" + user.getUserId());
        anim.put("animStr", "Attack1,Attack2");
        return anim;
    }

    private JSONObject getAnim(MonsterAI targetMonster) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", this.mapMonster.getFrame());
        anim.put("cInf", "m:" + this.mapMonster.getMonMapId());
        anim.put("fx", "m");
        anim.put("tInf", "m:" + targetMonster.getMapMonster().getMonMapId());
        anim.put("animStr", "Attack1,Attack2");
        return anim;
    }

    public void restore() {
        this.state.restore();
        JSONObject mtls = new JSONObject();
        mtls.put("cmd", "mtls");
        mtls.put("id", this.mapMonster.getMonMapId());
        mtls.put("o", this.state.getData());
        Kaiden_Extension.getInstance().send(mtls, this.room.getChannellList());
    }

    public Room getRoom() {
        return this.room;
    }

    public synchronized void setAttacking(ScheduledFuture attacking) {
        try {
            if (this.attacking != null && !this.attacking.isDone()) {
                this.attacking.cancel(true);
            }
            this.attacking = attacking;
            if (attacking != null) {
                this.state.setState(Properties.STATE_COMBAT);
            }
        } catch (Exception e) {
            SmartFoxServer.log.fine("Error in setAttacking: " + e.getMessage());
        }
    }

    public MonsterBean getMonster() {
        return this.monster;
    }

    public MapMonsterBean getMapMonster() {
        return this.mapMonster;
    }

    public MonsterState getState() {
        return this.state;
    }

    // 🔗 LINKED GROUPS: can this boss be damaged?
    public static MonsterAI getAIByMonMapId(int monMapId) {
        return AIS_BY_MONMAP.get(monMapId);
    }

    public static boolean canDamageMonster(MonsterAI monster) {
        if (monster == null || monster.mapMonster == null) {
            return true;
        }

        MapMonsterBean mm = monster.mapMonster;
        int partnerId = mm.getLinkGroupId();

        /*
         * Legacy Kaiden linked monster support:
         *
         * Main/protected monster:
         *      PartnerID > 0
         *
         * Linked monsters:
         *      AllowPartner = 1
         *
         * While ANY linked monster in the same room is alive, the protected
         * monster takes 0 damage. This check runs every hit, so if linked
         * monsters respawn, the main monster locks again automatically.
         */
        if (partnerId <= 0) {
            return true;
        }

        try {
            @SuppressWarnings("unchecked")
            HashMap<Integer, MonsterAI> monsters =
                    monster.room == null ? null : (HashMap<Integer, MonsterAI>) monster.room.properties.get("monsters");

            if (monsters == null || monsters.isEmpty()) {
                return true;
            }

            for (MonsterAI other : monsters.values()) {
                if (other == null || other == monster) {
                    continue;
                }

                if (other.getState() == null || other.getState().isDead()) {
                    continue;
                }

                MapMonsterBean otherMap = other.getMapMonster();
                if (otherMap == null) {
                    continue;
                }

                /*
                 * Supports:
                 * 1) Direct partner by MonMapID.
                 * 2) Any alive AllowPartner monster in this room.
                 * 3) Shared PartnerID group pets.
                 */
                boolean directPartner = otherMap.getMonMapId() == partnerId;
                boolean allowPartnerLink = otherMap.isLinkBoss();
                boolean samePartnerGroup = otherMap.getLinkGroupId() == partnerId && otherMap.getMonMapId() != mm.getMonMapId();

                if (directPartner || allowPartnerLink || samePartnerGroup) {
                    return false;
                }
            }
        } catch (Throwable ignored) {
            return true;
        }

        return true;
    }

    public static boolean canDamageMonster(int monMapId) {
        MonsterAI ai = AIS_BY_MONMAP.get(monMapId);
        if (ai == null) {
            return true;
        }

        return canDamageMonster(ai);
    }

    /** Instance helper: true if THIS monster is a boss and currently locked by its pets. */
    public boolean isBossLockedByLinkedPets() {
        return !canDamageMonster(this);
    }

    // -------------------- Skill cooldown helpers --------------------

    private boolean isSkillOnCooldown(int skillId) {
        Long next = skillCooldowns.get(skillId);
        return next != null && System.currentTimeMillis() < next;
    }

    private void setSkillCooldown(int skillId, long cooldownMs) {
        if (cooldownMs <= 0) return;
        long next = System.currentTimeMillis() + cooldownMs;
        skillCooldowns.put(skillId, next);

        try {
            MonsterSkillsBean msb = StorageCache.getInstance().getMonsterSkills(skillId);
            String name = (msb != null) ? msb.getName() : ("skill#" + skillId);
            long remSec = (cooldownMs + 999) / 1000;
            //System.out.println(Ansi.RED + "Monster[" + (mapMonster != null ? mapMonster.getMonMapId() : "unknown") +
                   // "] set cooldown: " + skillId + ":" + name + " -> " + remSec + "s");
        } catch (Throwable ignore) {}
    }

    /** End-of-duration cleanup is separate from cooldown start. */
    private void finishSkillDuration(MonsterSkillsBean skill) {
        if (skill == null) return;

        String type = skill.getType() == null ? "" : skill.getType().trim().toLowerCase();
        if ("repell".equals(type)) {
            try {
                this.state.setReflectPercent(0.0D);
            } catch (Throwable ignored) {}
        }

        if (skill.getEndDescription() != null && !skill.getEndDescription().isEmpty()) {
            sendMonsterSkillEndDescription(skill);
        }
    }

    private void sendMonsterSkillEndDescription(MonsterSkillsBean skill) {
        MonsterCombatNotifier.sendSkillEndDescription(this, skill);
    }

    private int getSkillManaCost(MonsterSkillsBean skill) {
        return MonsterCombatMana.getManaCost(skill);
    }

    public boolean consumeMonsterManaForSkill(User user, MonsterSkillsBean skill, int manaCost) {
        return MonsterCombatMana.consumeForSkill(this, user, skill);
    }

    private long getSkillDurationMs(MonsterSkillsBean skill) {
        return MonsterCombatTiming.getDurationMs(skill);
    }

    private long getSkillCooldownMsFromBean(MonsterSkillsBean skill) {
        return MonsterCombatTiming.getCooldownMs(skill);
    }

    public void regenMonster() {
        MonsterRegeneration regen = this.regenTask;

        if (regen == null) {
            regen = new MonsterRegeneration(this.mapMonster, this);
            this.regenTask = regen;
        }

        if (!regen.isRegenerating()) {
            regen.setRunning(
                    Executor.getInstance().scheduleTask(regen, 1L, TimeUnit.SECONDS, true)
            );
        }
    }

    private void regenMonsterByDuration(long durationMs) {
        if (durationMs <= 0) {
            return; // no duration = no regen
        }

        try {
            if (this.regenTask == null) {
                this.regenTask = new MonsterRegeneration(this.mapMonster, this);
            }

            // Only start if it's not already running
            if (!this.regenTask.isRegenerating()) {
                // Start periodic regen quickly and keep it running for the full Heal
                // Duration window. A 5-second initial delay caused short heal skills
                // to expire before regeneration really got going.
                ScheduledFuture<?> future = Executor.getInstance()
                        .scheduleTask(this.regenTask, 1L, TimeUnit.SECONDS, true);
                this.regenTask.setRunning(future);
            }

            // mark monster as immune to damage until duration ends
            this.regenImmuneUntil = System.currentTimeMillis() + durationMs;

            // Schedule a one-shot task to stop regen AND clear immunity after the skill duration
            Executor.getInstance().scheduleTask(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (regenTask != null) {
                            regenTask.cancel();
                        }
                    } catch (Throwable ignored) {
                    } finally {
                        regenImmuneUntil = 0L;
                    }
                }
            }, durationMs, TimeUnit.MILLISECONDS);

        } catch (Throwable t) {
            SmartFoxServer.log.fine("Error starting regen for duration: " + t.getMessage());
        }
    }

    // 🔗 LINKED GROUPS: call this when this monster actually dies
    public void onMonsterDeath(User killer) {
        try {
            handleLinkedGroupOnDeath(killer);
        } catch (Throwable t) {
            //System.out.println(Ansi.RED + ("[LINK] onMonsterDeath error: " + t.getMessage()));
        }
    }

    private void handleLinkedGroupOnDeath(User killer) {
        if (this.mapMonster == null) return;

        int monMapId = this.mapMonster.getMonMapId();
        LinkedGroup g = LINKED_GROUPS_BY_MONMAP.get(monMapId);
        if (g == null) return;

        // If this is a PET, check if that was the last one alive
        if (g.petMonMapIds.contains(monMapId)) {
            boolean allDead = true;
            for (int petId : g.petMonMapIds) {
                MonsterAI petAI = AIS_BY_MONMAP.get(petId);
                if (petAI != null && petAI.state != null && !petAI.state.isDead()) {
                    allDead = false;
                    break;
                }
            }

            if (allDead && g.bossMonMapId != null) {
                MonsterAI bossAI = AIS_BY_MONMAP.get(g.bossMonMapId);
                if (bossAI != null && bossAI.state != null && !bossAI.state.isDead()) {
                    try {
                        JSONObject o = new JSONObject();
                        o.accumulate("cmd", "monUnlock");
                        o.accumulate("monMapID", g.bossMonMapId);
                        Kaiden_Extension.getInstance().send(o, bossAI.getRoom().getChannellList());
                    } catch (Throwable t) {
                        //System.out.println(Ansi.RED + ("[LINK] Failed to send monUnlock: " + t.getMessage()));
                    }
                }
            }
        }
    }

    public void restMonsterUtils() {
        try {
            final long now = System.currentTimeMillis();

            // Invalidate every delayed cast/cooldown callback from the old life.
            this.combatGeneration++;

            this.scheduledFinishTasks.clear();
            this.castingUntil = 0L;
            this.castingSkillType = "";
            this.currentSkillIndex = 0;
            this.waitingForFullSkillCycle = false;
            this.combatStartedAt = 0L;
            this.lastCompletedSkill = -1;
            this.skillCompletionSerial = 0L;
            this.pendingChainSkill = -1;
            this.pendingChainSource = -1;
            this.chainUnlockAt = 0L;
            this.activatorUses.clear();
            this.activatorLastAt.clear();
            this.activatorSeenCompletion.clear();

            // A respawn starts a completely fresh cooldown cycle. Skills are
            // not immediately ready; basic Attack1/Attack2 fills the wait time.
            this.skillCooldowns.clear();
            for (Integer skillId : this.skillOrder) {
                if (skillId == null) {
                    continue;
                }

                MonsterSkillsBean skill = StorageCache.getInstance().getMonsterSkills(skillId);
                if (skill == null) {
                    continue;
                }

                long cooldownMs = Math.max(0L, getSkillCooldownMsFromBean(skill));
                this.skillCooldowns.put(skillId, now + cooldownMs);
            }

            // Preserve the normal global skill-phase delay used by every monster.
            this.nextSkillPhaseAt = now + SKILL_PHASE_GAP_MS;
            this.regenImmuneUntil = 0L;

            try {
                if (this.state != null) {
                    this.state.setReflectPercent(0.0D);
                }
            } catch (Throwable ignored) {
            }

            try {
                if (this.regenTask != null && this.regenTask.isRegenerating()) {
                    this.regenTask.cancel();
                }
            } catch (Throwable ignored) {
            }
        } catch (Throwable t) {
            SmartFoxServer.log.fine("restMonsterUtils failed for monMapId="
                    + (mapMonster != null ? mapMonster.getMonMapId() : "unknown")
                    + " : " + t.getMessage());
        }
    }




    private void handleSkillTypeOnCast(User user, MonsterSkillsBean skillBean) {
        String rawType = skillBean.getType();
        if (rawType == null) {
            return;
        }

        String type = rawType.trim().toLowerCase();
        if (type.isEmpty()) {
            return;
        }

        State targetState = (State) user.properties.get("state");
        if (targetState == null) {
            return;
        }

        switch (type) {
            case "lifesteal":
                if (skillBean.getLifeSteal() > 0) {
                    targetState.decreaseHealth(skillBean.getLifeSteal());
                    this.state.increaseHealth(skillBean.getLifeSteal());
                }
                if (skillBean.getManaSteal() > 0) {
                    targetState.decreaseMana(skillBean.getManaSteal());
                    this.state.increaseMana(skillBean.getManaSteal());
                }

                // handle deaths caused by lifesteal
                if (targetState.isDead() || targetState.getHealth() <= 0) {
                    handlePlayerDeathFromMonster(user, targetState);
                }
                break;

            case "heal":
                // Do not start the separate fixed-rate MonsterRegeneration task here.
                // A configured HealOverTime aura is processed by PlayerCombatContainer;
                // running both systems together causes stacked healing and long immunity.
                // If this skill has no HoT aura, it should not silently grant a second,
                // hard-coded regeneration effect.
                break;

            case "repell":
                // 20% reflect (or whatever you configure in state)
                this.state.setReflectPercent(0.20D);
                long repelDur = getSkillDurationMs(skillBean);
                double reflectionState = this.state.getReflectPercent();
                if (repelDur > 0) {
                    final User fUser = user;
                    Executor.getInstance().scheduleTask(new Runnable() {
                        @Override
                        public void run() {
                            targetState.decreaseHealthByPercent(reflectionState);
                            if (targetState.isDead() || targetState.getHealth() <= 0) {
                                handlePlayerDeathFromMonster(fUser, targetState);
                            }
                        }
                    }, repelDur, TimeUnit.MILLISECONDS);
                }
                break;

            case "instantdeath": {
                final User fUser = user;
                final long delayMs = getSkillDurationMs(skillBean);

                Executor.getInstance().scheduleTask(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            // If player already dead / missing state, bail
                            State targetState = (State) fUser.properties.get("state");
                            if (targetState == null || targetState.isDead()) return;

                            int currentHp = targetState.getHealth();

                            // "skill damage + 10000" PLUS enough to guarantee kill
                            int base = (int) Math.round(skillBean.getDamage());
                            int totalDamage = base + 10000 + currentHp;

                            // Apply damage (will force die() when <= 0)
                            targetState.decreaseHealth(totalDamage);

                            // Send ct update so client actually sees HP/state change (same pattern as basic attack)
                            JSONObject p = (new JSONObject()).accumulate(fUser.getName(), targetState.getData());

                            JSONArray sara = (new JSONArray()).element(
                                    (new JSONObject())
                                            .accumulate("actionResult", getAction(DamageType.HIT, totalDamage, fUser))
                                            .accumulate("iRes", 1)
                            );

                            JSONObject m = (new JSONObject()).accumulate(
                                    String.valueOf(mapMonster.getMonMapId()),
                                    (new JSONObject())
                                            .accumulate("intMP", state.getMana())
                                            .accumulate("intMPMax", state.getMaxMana())
                            );

                            JSONObject ct = (new JSONObject())
                                    .accumulate("anims", (new JSONArray()).element(getAnim(fUser)))
                                    .accumulate("p", p)
                                    .accumulate("m", m)
                                    .accumulate("cmd", "ct");

                            // send to others
                            Kaiden_Extension.getInstance().send(ct, getUserChannelButOne(room, fUser.getUserId()));

                            // send to the player (with sara)
                            ct.accumulate("sara", sara);
                            Kaiden_Extension.getInstance().send(ct, fUser);

                            // Now run your cleanup/death pipeline
                            if (targetState.isDead() || targetState.getHealth() <= 0) {
                                handlePlayerDeathFromMonster(fUser, targetState);
                            }

                        } catch (Throwable t) {
                            //System.out.println(Ansi.RED + "instantdeath error: " + t.getMessage() + Ansi.RESET);
                        }
                    }
                }, delayMs, TimeUnit.MILLISECONDS);

                break;
            }
           }
        }
}
