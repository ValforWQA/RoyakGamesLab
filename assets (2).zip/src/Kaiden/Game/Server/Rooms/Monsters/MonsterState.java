package Kaiden.Game.Server.Rooms.Monsters;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Database.Beans.MonsterBean;
import Kaiden.Database.Beans.MonsterDropBean;
import Kaiden.Database.Beans.MonsterSkillEffectsBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.StorageCache;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.UserState;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.MonsterRespawn;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class MonsterState extends State {

    private final MonsterAI monster;
    private Set<Integer> targets;
    private final MonsterSkill skills;

    private double reflectPercent = 0.0D;
    private final List<ActiveMonsterSkillEffect> activeSkillEffects = Collections.synchronizedList(new ArrayList<ActiveMonsterSkillEffect>());
    private final Map<String, Long> traitExpiries = new ConcurrentHashMap<String, Long>();
    private final Map<String, Integer> traitStacks = new ConcurrentHashMap<String, Integer>();

    private static final class ActiveMonsterSkillEffect {
        private final MonsterSkillEffectsBean effect;
        private final long endTime;

        private ActiveMonsterSkillEffect(MonsterSkillEffectsBean effect, long endTime) {
            this.effect = effect;
            this.endTime = endTime;
        }
    }

    public MonsterState(MonsterAI monster, int maxHealth, int maxMana, int maxDash) {
        super(maxHealth, maxMana, maxDash);
        this.monster = monster;
        this.targets = Collections.newSetFromMap(new ConcurrentHashMap<>());
        this.skills = new MonsterSkill();
    }

    public void die() {
        if (!this.isDead()) {
            // Clear active auras BEFORE marking the monster dead. RemoveAura sends
            // aura-/fx-off packets here, so hard-CC visuals/state (stun, freeze,
            // frozen, stone, disabled, disable) fade immediately on death and
            // can never carry into the respawned monster.
            super.clearAuras();
            super.die();
            this.reflectPercent = 0.0D; // reset reflect on death
            this.activeSkillEffects.clear();
            this.setCurrentShield(0);

            // 🔗 Notify linked-group system about this monster death (no killer info here)
            this.monster.onMonsterDeath(null);

            Executor.getInstance().scheduleTask(
                    new MonsterRespawn(this.monster),
                    this.monster.getMonster().getRespawn(),
                    TimeUnit.SECONDS
            );

            this.giveRewards();

            this.targets.clear();
        }
    }



    private void giveRewards() {
        Set<UserDrop> userDrops = new HashSet<>();
        MonsterBean mon = this.monster.getMonster();
        int monLevel = mon.getLevel();
        int experience = mon.getExperience();
        int gold = mon.getGold();
        int coins = mon.getCoin();
        int classPoint = mon.getClassPoint();

        for (MonsterDropBean md : this.getDrops()) {
            userDrops.add(new UserDrop(md.itemId, md.quantity, false));
        }

        for (int userId : this.targets) {
            User user = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
            if (user != null) {

                incrementPlayerMonsterKill(user, mon);

                int userLevel = (int) user.properties.get(Properties.LEVEL);
                int cpCalc = Server.getInstance().calculateCP(userLevel, monLevel);

                int mapCpBonus = 0;
                try {
                    Room room = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
                    if (room != null) {
                        String mapName = room.getName();
                        if (mapName != null) {
                            mapName = mapName.toLowerCase();

                            if (mapName.startsWith("newbie") && (int)user.properties.get(Properties.LEVEL) < 9) mapCpBonus = 2;
                            else if (mapName.startsWith("shadowbattleon")) mapCpBonus = 3;
                            else if (mapName.startsWith("underlair")) mapCpBonus = 3;
                            else if (mapName.startsWith("battleunderb")) mapCpBonus = 2;
                        }
                    }
                } catch (Exception ignored) {
                }

                // base CP always comes from monster DB
                int cpBase = classPoint;

                // bonus CP only comes from the hardcoded maps
                int cpBonus = mapCpBonus > 0 ? (cpCalc * mapCpBonus) : 0;

                //Users.getInstance().RestorePlayer(user, "defeating " + mon.getName());
                Users.getInstance().dropItems(user, userDrops);
                Users.getInstance().giveRewards(
                        user,
                        experience,
                        gold,
                        cpBase,
                        0,
                        coins,
                        1,
                        cpBonus,
                        -1,
                        this.monster.getMapMonster().getMonMapId(),
                        "m"
                );

                UserState targetState = (UserState) user.properties.get("state");
                if (targetState != null) {
                    targetState.increaseManaByPercent(0.15D);
                    targetState.increaseHealthByPercent(0.15D);
                }

                Users.getInstance().regen(user);
                /*
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "green",
                        "monster name: " + this.monster.getMonster().getName()
                                + " monmapid:" + this.monster.getMapMonster().getMonMapId()
                                + " cpBase:" + cpBase
                                + " cpCalc:" + cpCalc
                                + " mapBonusRate:" + mapCpBonus
                                + " cpBonus:" + cpBonus
                );

                 */
            }
        }

        userDrops.clear();
    }
    private void incrementPlayerMonsterKill(User user, MonsterBean mon) {
        if (user == null) {
            return;
        }

        try {
            Object currentKills = user.properties.get(Properties.KILL_COUNT);
            if (currentKills instanceof Number) {
                user.properties.put(Properties.KILL_COUNT, ((Number) currentKills).intValue() + 1);
            }

            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "green",
                    "[MonsterKill] " + user.getName()
                            + " defeated " + (mon != null ? mon.getName() : "monster")
                            + " (+1 KillCount)"
            );
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[MonsterKill] Failed to update KillCount for " + user.getName() + ": " + e.getMessage()
            );
        }
    }

    private Set<MonsterDropBean> getDrops() {
        Set<MonsterDropBean> drops = new HashSet<>();
        for (MonsterDropBean md : this.monster.getMonster().drops) {
            if (Math.random() <= md.chance * Configuration.DROP_RATE) {
                drops.add(md);
            }
        }
        return drops;
    }

    private int balance(int coins, int userLevel, int monLevel) {
        return coins - Math.abs((monLevel - userLevel) * (coins / 15));
    }

    public void restore() {
        super.restore();
        this.targets.clear();
        this.reflectPercent = 0.0D;
        this.activeSkillEffects.clear();
        this.setCurrentShield(0);
        this.getMonsterAI().restMonsterUtils();
        // reset reflect on restore
    }

    public int getRandomTarget() {
        Integer[] targetArray = this.targets.toArray(new Integer[0]);
        return targetArray.length > 0 ? targetArray[new Random().nextInt(targetArray.length)] : -1;
    }

    public String getRandomTargets(int maxTargets) {
        StringBuilder sb = new StringBuilder();
        List<Integer> shuffled = new ArrayList<>(this.targets);
        Collections.shuffle(shuffled);
        for (int i = 0; i < Math.min(maxTargets, shuffled.size()); i++) {
            sb.append(",p:").append(shuffled.get(i));
        }
        return sb.length() > 0 ? sb.substring(1) : "";
    }

    public boolean hasTargets() {
        return !this.targets.isEmpty();
    }

    public void addTarget(int userId) {
        this.targets.add(userId);
    }

    public void removeTarget(int userId) {
        this.targets.remove(userId);
        // Do not clear all user auras here.
        // Removing a monster target should only break target tracking for this monster,
        // not wipe the player's full aura state (class passives, enhancement proc auras,
        // self buffs, etc.). Full aura clears here cause passive rebuild/stat update loops
        // during combat cleanup and break DB-backed proc aura behavior.
    }

    public Set<Integer> getTargets() {
        return this.targets;
    }

    public void setTargets(Set<Integer> targets) {
        this.targets = targets;
    }

    public MonsterAI getMonsterAI() {
        return this.monster;
    }


    // -------- aura immunity helpers --------
    public boolean isAuraImmune(AuraBean aura) {
        if (aura == null || this.monster == null || this.monster.getMonster() == null) {
            return false;
        }

        MonsterBean mb = this.monster.getMonster();

        // 1) Exact aura ID immunity
        if (mb.getAuraImmuneIds() != null && mb.getAuraImmuneIds().contains(aura.getId())) {
            return true;
        }

        // 2) Category-based immunity (e.g. "stun", "poison", "dot")
        String cat = aura.getCategory();
        if (cat != null && mb.getAuraImmuneCategories() != null &&
                mb.getAuraImmuneCategories().contains(cat.toLowerCase())) {
            return true;
        }

        return false;
    }

    public RemoveAura applyAura(AuraBean aura) {
        return this.applyAura(aura, "");
    }

    private String charmEffectSummary(AuraBean aura) {
        if (aura == null || aura.effects == null || aura.effects.isEmpty()) {
            return "none";
        }
        StringBuilder sb = new StringBuilder();
        for (Integer effectId : aura.effects) {
            if (effectId == null) continue;
            AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
            if (ae == null) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(ae.getStat()).append(ae.getType()).append(ae.getValue());
        }
        return sb.length() == 0 ? "none" : sb.toString();
    }

    public RemoveAura applyAura(AuraBean aura, String sourceInf) {
        if (aura == null) return null;

        final int auraId = aura.getId();
        final int maxStacks = Math.max(1, aura.getStack());

        synchronized (this) {
            String normalizedSource = sourceInf == null ? "" : sourceInf.trim().toLowerCase();
            RemoveAura categoryAura = Kaiden.Game.Server.Combat.Player.PlayerCombatContainer.getInstance().findCategoryAura(this.getAuras(), aura);
            if (categoryAura != null && categoryAura.getAura() != null) {
                if (categoryAura.getAura().getId() == auraId) {
                categoryAura.refreshDuration(aura.getRuntimeDuration());
                    categoryAura.resetRuntimePhases();
                    categoryAura.setSourceInf(normalizedSource);
                    categoryAura.setRefreshedOnly(true);
                    CombatTrace.info("MonsterState.applyAura", "refresh exclusive existing " + CombatTrace.aura(categoryAura) + ", target=" + CombatTrace.who(this.monster));
                    if (CombatTrace.isCharmAura(aura)) {
                        CombatTrace.charm("ApplyAura", "refreshed " + CombatTrace.who(this.monster) + " aura=" + aura.getName() + "#" + aura.getId() + " source=" + normalizedSource + " effects=" + charmEffectSummary(aura));
                    }
                    return categoryAura;
                }
                categoryAura.cancel();
                this.removeAura(categoryAura);
            }

            RemoveAura managed = normalizedSource.isEmpty() ? this.getLatestExpiringAura(auraId) : this.getLatestExpiringAuraBySource(auraId, normalizedSource);
            int currentStacks = this.getAuraStackCount(auraId);
            int currentStacksForSource = normalizedSource.isEmpty() ? currentStacks : this.getAuraStackCountBySource(auraId, normalizedSource);

            if (managed != null) {
            managed.refreshDuration(aura.getRuntimeDuration());
                managed.resetRuntimePhases();
                managed.setSourceInf(normalizedSource);

                if (maxStacks <= 1) {
                    managed.setRefreshedOnly(true);
                    CombatTrace.info("MonsterState.applyAura", "refresh non-stack aura " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.monster));
                    if (CombatTrace.isCharmAura(aura)) {
                        CombatTrace.charm("ApplyAura", "refreshed " + CombatTrace.who(this.monster) + " aura=" + aura.getName() + "#" + aura.getId() + " source=" + normalizedSource + " effects=" + charmEffectSummary(aura));
                    }
                    return managed;
                }

                if (currentStacks >= maxStacks || currentStacksForSource >= maxStacks) {
                    managed.setRefreshedOnly(true);
                    CombatTrace.info("MonsterState.applyAura", "refresh max-stack aura " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.monster) + ", stacks=" + currentStacks + "/" + maxStacks);
                    if (CombatTrace.isCharmAura(aura)) {
                        CombatTrace.charm("ApplyAura", "refreshed max-stack " + CombatTrace.who(this.monster) + " aura=" + aura.getName() + "#" + aura.getId() + " source=" + normalizedSource + " stacks=" + currentStacks + "/" + maxStacks + " effects=" + charmEffectSummary(aura));
                    }
                    return managed;
                }

                managed.incrementStackCount(1, maxStacks);
                managed.setRefreshedOnly(false);
                CombatTrace.info("MonsterState.applyAura", "increase managed stack " + CombatTrace.aura(managed) + ", target=" + CombatTrace.who(this.monster) + ", stacks=" + this.getAuraStackCount(auraId) + "/" + maxStacks);
                if (CombatTrace.isCharmAura(aura)) {
                    CombatTrace.charm("ApplyAura", "stacked " + CombatTrace.who(this.monster) + " aura=" + aura.getName() + "#" + aura.getId() + " source=" + normalizedSource + " stacks=" + this.getAuraStackCount(auraId) + "/" + maxStacks + " effects=" + charmEffectSummary(aura));
                }
                return managed;
            }

            long newEndTime = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(aura.getRuntimeDuration());
            RemoveAura ra = new RemoveAura(aura, this.monster, this.monster.getRoom());
            ra.setStackCount(1);
            ra.setRefreshedOnly(false);
            ra.scheduleToEndTime(newEndTime);
            ra.scheduleRuntimePhases();
            ra.setSourceInf(normalizedSource);
            this.addAura(ra);
            CombatTrace.info("MonsterState.applyAura", "add new aura " + CombatTrace.aura(ra) + ", target=" + CombatTrace.who(this.monster) + ", stacks=" + this.getAuraStackCount(auraId) + "/" + maxStacks);
            if (CombatTrace.isCharmAura(aura)) {
                CombatTrace.charm("ApplyAura", "applied " + CombatTrace.who(this.monster) + " aura=" + aura.getName() + "#" + aura.getId() + " source=" + normalizedSource + " duration=" + aura.getDuration() + "s effects=" + charmEffectSummary(aura));
            }
            return ra;
        }
    }

    public synchronized RemoveAura getLatestExpiringAura(int auraId) {
        RemoveAura best = null;
        long bestEnd = Long.MIN_VALUE;
        long now = System.currentTimeMillis();

        Iterator<RemoveAura> it = this.getAuras().iterator();
        while (it.hasNext()) {
            RemoveAura ra = it.next();
            if (ra == null || ra.getAura() == null) {
                it.remove();
                continue;
            }
            if (ra.isFinished()) {
                it.remove();
                continue;
            }
            long end = ra.getEndTime();
            if (end > 0L && end <= now) {
                // Do not run aura expiration from inside synchronized state lookups.
                // The scheduled RemoveAura task handles client aura-/fx-off safely.
                this.removeAura(ra);
                continue;
            }
            AuraBean aura = ra.getAura();
            if (aura == null || aura.getId() != auraId) continue;
            if (end <= 0L) return ra;
            if (end > bestEnd) {
                bestEnd = end;
                best = ra;
            }
        }
        return best;
    }

    public synchronized boolean hasAuraCategory(String category, long excludingInstanceId) {
        if (category == null || category.trim().isEmpty()) return false;
        String wanted = category.trim().toLowerCase();
        long now = System.currentTimeMillis();
        Iterator<RemoveAura> it = this.getAuras().iterator();
        while (it.hasNext()) {
            RemoveAura ra = it.next();
            if (ra == null || ra.getAura() == null) {
                it.remove();
                continue;
            }
            if (ra.isFinished()) {
                it.remove();
                continue;
            }
            long end = ra.getEndTime();
            if (end > 0L && end <= now) {
                // Do not run aura expiration from inside synchronized state lookups.
                // The scheduled RemoveAura task handles client aura-/fx-off safely.
                this.removeAura(ra);
                continue;
            }
            if (ra.getInstanceId() == excludingInstanceId) continue;
            String cat = ra.getAura().getCategory();
            if (cat != null && wanted.equals(cat.trim().toLowerCase())) return true;
        }
        return false;
    }

    public boolean applyMonsterSkillEffect(final MonsterSkillEffectsBean effect) {
        if (effect == null) return false;
        cleanupExpiredSkillEffects();

        int currentStacks = getMonsterSkillEffectStackCount(effect);
        int maxStacks = Math.max(1, effect.getStack());
        if (maxStacks <= 1 && currentStacks > 0) return false;
        if (currentStacks >= maxStacks) return false;

        int duration = Math.max(0, effect.getDuration());
        long endTime = duration > 0 ? (System.currentTimeMillis() + (duration * 1000L)) : 0L;
        final ActiveMonsterSkillEffect active = new ActiveMonsterSkillEffect(effect, endTime);
        this.activeSkillEffects.add(active);

        if (duration > 0) {
            Executor.getInstance().scheduleTask(new Runnable() {
                @Override
                public void run() {
                    activeSkillEffects.remove(active);
                    clampMonsterShieldToActiveEffects();
                }
            }, duration, TimeUnit.SECONDS);
        }

        if ("shield".equalsIgnoreCase(effect.getStat())) {
            int shieldGain = normalizeShieldValue(effect.getValue(), effect.getType());
            if (shieldGain > 0) {
                int newShield = getCurrentShield() + shieldGain;
                int maxShield = getMonsterShieldValue();
                setCurrentShield(maxShield > 0 ? Math.min(newShield, maxShield) : 0);
            }
        }
        return true;
    }

    private int getMonsterSkillEffectStackCount(MonsterSkillEffectsBean effect) {
        int count = 0;
        String effectStat = effect.getStat() == null ? "" : effect.getStat().trim().toLowerCase();
        String effectTarget = effect.getTarget() == null ? "" : effect.getTarget().trim().toLowerCase();
        long now = System.currentTimeMillis();
        synchronized (this.activeSkillEffects) {
            for (ActiveMonsterSkillEffect active : this.activeSkillEffects) {
                if (active == null || active.effect == null) continue;
                if (active.endTime > 0L && active.endTime <= now) continue;
                String activeStat = active.effect.getStat() == null ? "" : active.effect.getStat().trim().toLowerCase();
                String activeTarget = active.effect.getTarget() == null ? "" : active.effect.getTarget().trim().toLowerCase();
                if (active.effect.getMonsterSkillId() == effect.getMonsterSkillId()
                        && activeStat.equals(effectStat)
                        && activeTarget.equals(effectTarget)) {
                    count++;
                }
            }
        }
        return count;
    }

    private void cleanupExpiredSkillEffects() {
        cleanupExpiredSkillEffectsNoClamp();
        clampMonsterShieldToActiveEffects();
    }

    private void cleanupExpiredSkillEffectsNoClamp() {
        long now = System.currentTimeMillis();
        synchronized (this.activeSkillEffects) {
            Iterator<ActiveMonsterSkillEffect> it = this.activeSkillEffects.iterator();
            while (it.hasNext()) {
                ActiveMonsterSkillEffect active = it.next();
                if (active == null) {
                    it.remove();
                    continue;
                }
                if (active.endTime > 0L && active.endTime <= now) {
                    it.remove();
                }
            }
        }
    }

    private void clampMonsterShieldToActiveEffects() {
        int maxShield = getMonsterShieldValue();
        if (maxShield <= 0) {
            setCurrentShield(0);
            return;
        }
        if (getCurrentShield() > maxShield) setCurrentShield(maxShield);
        if (getCurrentShield() < 0) setCurrentShield(0);
    }

    private double normalizeCombatValue(String stat, double value) {
        if ("shield".equalsIgnoreCase(stat)) return value;
        return Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.normalizeValue(stat, value);
    }

    private int normalizeShieldValue(double value, String type) {
        int shield = (int) Math.max(0, Math.round(Math.abs(value)));
        if ("-".equals(type)) shield = -shield;
        return shield;
    }

    private double aggregateAuraCombatStat(String stat) {
        double total = 0.0D;
        String normalized = Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.canonicalize(stat);
        for (RemoveAura ra : this.getAuras()) {
            if (ra == null || ra.getAura() == null || ra.isFinished() || ra.isExpired()) continue;

            java.util.List<AuraEffectsBean> runtime = ra.getActiveRuntimePhaseEffects();
            if (runtime != null && !runtime.isEmpty()) {
                for (AuraEffectsBean ae : runtime) {
                    if (ae == null) continue;
                    String key = Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.canonicalize(ae.getStat());
                    if (!normalized.equals(key)) continue;
                    double v = normalizeCombatValue(key, ae.getValue());
                    if ("-".equals(ae.getType())) total -= v; else total += v;
                }
                continue;
            }

            if (ra.getAura().effects == null) continue;
            int stacks = Math.max(1, ra.getStackCount());
            for (int effectId : ra.getAura().effects) {
                AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                if (ae == null) continue;
                String key = Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.canonicalize(ae.getStat());
                if (!normalized.equals(key)) continue;
                double v = normalizeCombatValue(key, ae.getValue()) * stacks;
                if ("-".equals(ae.getType())) total -= v; else total += v;
            }
        }
        return total;
    }

    private double aggregateMonsterSkillEffectStatRaw(String stat) {
        cleanupExpiredSkillEffectsNoClamp();

        double total = 0.0D;
        String normalized = Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.canonicalize(stat);
        long now = System.currentTimeMillis();
        synchronized (this.activeSkillEffects) {
            for (ActiveMonsterSkillEffect active : this.activeSkillEffects) {
                if (active == null || active.effect == null || active.effect.getStat() == null) continue;
                if (active.endTime > 0L && active.endTime <= now) continue;
                if (!normalized.equals(Kaiden.Game.Server.Combat.Auras.AuraEffectRegistry.canonicalize(active.effect.getStat()))) continue;
                double v = normalizeCombatValue(normalized, active.effect.getValue());
                if ("-".equals(active.effect.getType())) total -= v; else total += v;
            }
        }
        return total;
    }

    private double aggregateMonsterSkillEffectStat(String stat) {
        cleanupExpiredSkillEffects();
        return aggregateMonsterSkillEffectStatRaw(stat);
    }

    public double getMonsterPhysRes() { return Math.max(0.0D, aggregateAuraCombatStat("physres") + aggregateMonsterSkillEffectStat("physres")); }
    public double getMonsterMagRes() { return Math.max(0.0D, aggregateAuraCombatStat("magres") + aggregateMonsterSkillEffectStat("magres")); }
    public double getMonsterAllRes() { return Math.max(0.0D, aggregateAuraCombatStat("allres") + aggregateMonsterSkillEffectStat("allres")); }
    public double getMonsterOutDmg() { return aggregateAuraCombatStat("outdmg") + aggregateMonsterSkillEffectStat("outdmg"); }
    public double getMonsterIncDmg() { return aggregateAuraCombatStat("incdmg") + aggregateMonsterSkillEffectStat("incdmg"); }
    public double getMonsterHaste() { return aggregateAuraCombatStat("tha") + aggregateMonsterSkillEffectStat("tha"); }
    public double getMonsterDodge() { return aggregateAuraCombatStat("tdo") + aggregateMonsterSkillEffectStat("tdo"); }
    public double getMonsterHit() { return aggregateAuraCombatStat("thi") + aggregateMonsterSkillEffectStat("thi"); }
    public double getMonsterCrit() { return aggregateAuraCombatStat("tcr") + aggregateMonsterSkillEffectStat("tcr"); }
    public double getMonsterCritMultiplier() { return aggregateAuraCombatStat("tcm") + aggregateMonsterSkillEffectStat("tcm"); }
    public double getMonsterPhysBoost() { return aggregateAuraCombatStat("physboost") + aggregateMonsterSkillEffectStat("physboost"); }
    public double getMonsterMagBoost() { return aggregateAuraCombatStat("magboost") + aggregateMonsterSkillEffectStat("magboost"); }
    public double getMonsterManaRet() { return Math.max(0.0D, aggregateAuraCombatStat("manaret") + aggregateMonsterSkillEffectStat("manaret")); }
    public int getMonsterShieldValue() { return (int) Math.max(0, Math.round(aggregateAuraCombatStat("shield") + aggregateMonsterSkillEffectStatRaw("shield"))); }

    public void applyMonsterOnDamageTaken(int damage) {
        if (damage <= 0) return;
        int mana = (int) Math.max(0, Math.round(damage * getMonsterManaRet()));
        if (mana > 0) increaseMana(mana);
    }

    public void applyMonsterOnDamageDealt(int damage) {
        if (damage <= 0) return;
        int mana = (int) Math.max(0, Math.round(damage * getMonsterManaRet()));
        if (mana > 0) increaseMana(mana);
    }


    public boolean hasAuraEffect(String... stats) {
        if (stats == null || stats.length == 0) return false;
        Set<String> wanted = new HashSet<String>();
        for (String stat : stats) {
            if (stat != null && !stat.trim().isEmpty()) {
                wanted.add(stat.trim().toLowerCase());
            }
        }
        if (wanted.isEmpty()) return false;

        for (RemoveAura ra : this.getAuras()) {
            if (ra == null || ra.getAura() == null || ra.getAura().effects == null) continue;
            if (ra.isFinished() || ra.isExpired()) continue;
            for (int effectId : ra.getAura().effects) {
                AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                if (ae == null || ae.getStat() == null) continue;
                if (wanted.contains(ae.getStat().trim().toLowerCase())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void removeAuraSourceTargets(String... stats) {
        int sourceUserId = getAuraSourceUserIdByEffect(stats);
        if (sourceUserId > 0) {
            this.removeTarget(sourceUserId);
        }
    }

    public int getAuraSourceUserIdByEffect(String... stats) {
        if (stats == null || stats.length == 0) return -1;
        Set<String> wanted = new HashSet<String>();
        for (String stat : stats) {
            if (stat != null && !stat.trim().isEmpty()) {
                wanted.add(stat.trim().toLowerCase());
            }
        }
        if (wanted.isEmpty()) return -1;

        for (RemoveAura ra : this.getAuras()) {
            if (ra == null || ra.getAura() == null || ra.getAura().effects == null) continue;
            if (ra.isFinished() || ra.isExpired()) continue;

            boolean hasWantedEffect = false;
            for (int effectId : ra.getAura().effects) {
                AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                if (ae == null || ae.getStat() == null) continue;
                if (wanted.contains(ae.getStat().trim().toLowerCase())) {
                    hasWantedEffect = true;
                    break;
                }
            }

            if (!hasWantedEffect) continue;

            String sourceInf = ra.getSourceInf() == null ? "" : ra.getSourceInf().trim().toLowerCase();
            if (sourceInf.startsWith("p:")) {
                try {
                    return Integer.parseInt(sourceInf.substring(2));
                } catch (NumberFormatException ignored) {
                    return -1;
                }
            }
        }
        return -1;
    }

    public void clearExpiredTraitEffects() {
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> entry : this.traitExpiries.entrySet()) {
            if (entry.getValue() == null || entry.getValue().longValue() <= now) {
                this.traitExpiries.remove(entry.getKey());
                this.traitStacks.remove(entry.getKey());
            }
        }
    }

    public boolean hasTraitEffect(String key) {
        clearExpiredTraitEffects();
        Long expiry = this.traitExpiries.get(key);
        return expiry != null && expiry.longValue() > System.currentTimeMillis();
    }

    public int getTraitStacks(String key) {
        clearExpiredTraitEffects();
        Integer value = this.traitStacks.get(key);
        return value == null ? 0 : Math.max(0, value.intValue());
    }

    public void setTraitEffect(String key, int stacks, long durationMs) {
        this.traitExpiries.put(key, System.currentTimeMillis() + Math.max(1L, durationMs));
        this.traitStacks.put(key, Math.max(1, stacks));
    }

    public int addTraitStacks(String key, int add, int maxStacks, long durationMs) {
        clearExpiredTraitEffects();
        int next = getTraitStacks(key) + add;
        next = Math.min(maxStacks, Math.max(0, next));
        setTraitEffect(key, next, durationMs);
        return next;
    }

    public boolean consumeTraitEffect(String key) {
        if (!hasTraitEffect(key)) return false;
        this.traitExpiries.remove(key);
        this.traitStacks.remove(key);
        return true;
    }

    public double getReflectPercent() {
        return this.reflectPercent;
    }

    public void setReflectPercent(double reflectPercent) {
        this.reflectPercent = reflectPercent;
    }

    @Override
    public void decreaseHealth(int amount) {
        if (amount <= 0) {
            return;
        }

        // 🔗 Linked boss gate: if this monster is a boss in a group and its pets are alive, ignore damage
        if (!this.isDead() && this.monster != null && this.monster.isBossLockedByLinkedPets()) {
            return;
        }

        // If this monster is currently in a heal/regen immunity window, ignore damage
        if (!this.isDead() && this.monster != null && this.monster.isRegenImmune()) {
            return;
        }

        // Normal behavior
        super.decreaseHealth(amount);
    }
}
