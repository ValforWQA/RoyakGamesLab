package Kaiden.Game.Server.Rooms.Monsters.Combat;

import Kaiden.Database.Beans.MonsterSkillsBean;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

public final class MonsterCombatNotifier {

    private MonsterCombatNotifier() {}

    public static void sendSkillDescription(MonsterAI monster, User target, MonsterSkillsBean skill) {
        if (monster == null || skill == null || target == null) {
            return;
        }
        try {
            String desc = skill.getDescription();
            if (desc == null || desc.trim().isEmpty()) {
                return;
            }
            Server.getInstance().sendServerNotifaction(monster.getMonster().getName() + " " + desc, target);
        } catch (Throwable ignored) {}
    }

    public static void sendSkillEndDescription(MonsterAI monster, MonsterSkillsBean skill) {
        if (monster == null || skill == null) {
            return;
        }
        try {
            String desc = skill.getEndDescription();
            if (desc == null || desc.trim().isEmpty()) {
                return;
            }
            JSONObject umsg = new JSONObject();
            umsg.put("cmd", "umsg");
            umsg.put("s", monster.getMonster().getName() + " " + desc);
            if (monster.getRoom() != null) {
                Kaiden_Extension.getInstance().send(umsg, monster.getRoom().getChannellList());
            }
        } catch (Throwable ignored) {}
    }
}
