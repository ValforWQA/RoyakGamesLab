package Kaiden.Game.Server.Rooms.Monsters.Combat;

import Kaiden.Database.Beans.MonsterSkillsBean;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.concurrent.ConcurrentHashMap;

public final class MonsterCombatMana {

    /*
     * =========================================================
     * MONSTER MANA SYSTEM
     * =========================================================
     *
     * Skill cast:
     *      consumeForSkill(...)
     *
     * Passive combat regen:
     *      regenPassive(...)
     *
     * Client update:
     *      sync(...)
     *
     * IMPORTANT:
     * Do not call decreaseMana/increaseMana directly from MonsterAI,
     * MonsterAttack, or monster skill type hooks.
     * =========================================================
     */

    private static final ConcurrentHashMap<Integer, Long> LAST_PASSIVE_REGEN =
            new ConcurrentHashMap<Integer, Long>();

    private static final long PASSIVE_REGEN_INTERVAL_MS = 1000L;

    private MonsterCombatMana() {}

    public static int getManaCost(MonsterSkillsBean skill) {
        if (skill == null) {
            return 0;
        }

        try {
            return Math.max(0, skill.getMana());
        } catch (Throwable ignored) {
            return 0;
        }
    }

    public static boolean hasEnoughMana(MonsterAI monster, MonsterSkillsBean skill) {
        if (monster == null || monster.getState() == null) {
            return false;
        }

        int cost = getManaCost(skill);
        if (cost <= 0) {
            return true;
        }

        synchronized (monster.getState()) {
            return monster.getState().getMana() >= cost;
        }
    }

    public static boolean consumeForSkill(MonsterAI monster, User target, MonsterSkillsBean skill) {
        if (monster == null || monster.getState() == null) {
            return false;
        }

        int cost = getManaCost(skill);
        if (cost <= 0) {
            sync(monster, target);
            return true;
        }

        int before;
        int after;

        synchronized (monster.getState()) {
            before = monster.getState().getMana();

            if (before < cost) {
                try {
                    Kaiden_Engine.getInstance().sendEmulatorMessage(
                            "yellow",
                            "[MonsterMana] " + monster.getMonster().getName()
                                    + " skipped skill=" + (skill == null ? "unknown" : skill.getName())
                                    + " MP " + before + " < cost " + cost
                    );
                } catch (Throwable ignored) {}
                return false;
            }

            monster.getState().decreaseMana(cost);
            after = monster.getState().getMana();
        }

        sync(monster, target);

        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "cyan",
                    "[MonsterMana] " + monster.getMonster().getName()
                            + " used skill=" + (skill == null ? "unknown" : skill.getName())
                            + " cost=" + cost
                            + " MP " + before + " -> " + after
            );
        } catch (Throwable ignored) {}

        return true;
    }

    /*
     * Passive monster MP regeneration while in combat.
     * This is intentionally NOT tied to player hits or monster skill hits.
     */
    public static void regenPassive(MonsterAI monster, double percent) {
        if (monster == null || monster.getState() == null || monster.getMapMonster() == null) {
            return;
        }

        if (percent <= 0.0D) {
            return;
        }

        int monMapId = monster.getMapMonster().getMonMapId();
        long now = System.currentTimeMillis();

        Long last = LAST_PASSIVE_REGEN.get(monMapId);
        if (last != null && (now - last.longValue()) < PASSIVE_REGEN_INTERVAL_MS) {
            return;
        }

        LAST_PASSIVE_REGEN.put(monMapId, now);

        int before;
        int after;

        synchronized (monster.getState()) {
            before = monster.getState().getMana();

            if (before >= monster.getState().getMaxMana()) {
                return;
            }

            monster.getState().increaseManaByPercent(percent);
            after = monster.getState().getMana();
        }

        if (after != before) {
            sync(monster, null);
        }
    }

    /*
     * Compatibility wrapper. Keep old calls from older code working,
     * but this now behaves like passive regen instead of hit-based regen.
     */
    public static void regenAfterAction(MonsterAI monster, double percent) {
        regenPassive(monster, percent);
    }

    public static void clear(MonsterAI monster) {
        if (monster == null || monster.getMapMonster() == null) {
            return;
        }
        LAST_PASSIVE_REGEN.remove(monster.getMapMonster().getMonMapId());
    }

    public static void sync(MonsterAI monster, User target) {
        if (monster == null || monster.getState() == null || monster.getMapMonster() == null) {
            return;
        }

        try {
            JSONObject m = new JSONObject().accumulate(
                    String.valueOf(monster.getMapMonster().getMonMapId()),
                    new JSONObject()
                            .accumulate("intMP", monster.getState().getMana())
                            .accumulate("intMPMax", monster.getState().getMaxMana())
            );
            JSONObject ct = new JSONObject()
                    .accumulate("cmd", "ct")
                    .accumulate("m", m);

            if (target != null) {
                Kaiden_Extension.getInstance().send(ct, target);
            }

            if (monster.getRoom() != null) {
                Kaiden_Extension.getInstance().send(ct, monster.getRoom().getChannellList());
            }
        } catch (Throwable ignored) {}
    }
}
