package Kaiden.Game.Server.Rooms.Monsters.Combat;

import Kaiden.Database.Beans.MonsterSkillsBean;

public final class MonsterCombatTiming {

    private MonsterCombatTiming() {}

    public static long getDurationMs(MonsterSkillsBean skill) {
        long duration = 0L;
        try {
            duration = skill == null ? 0L : skill.getDuration();
        } catch (Throwable ignored) {}

        if (duration <= 0) {
            return 0L;
        }

        return duration <= 60L ? duration * 1000L : duration;
    }

    public static long getCooldownMs(MonsterSkillsBean skill) {
        long cooldown = 0L;
        try {
            cooldown = skill == null ? 0L : skill.getCooldown();
        } catch (Throwable ignored) {}

        if (cooldown <= 0) {
            return 1000L;
        }

        return cooldown <= 60L ? cooldown * 1000L : cooldown;
    }
}
