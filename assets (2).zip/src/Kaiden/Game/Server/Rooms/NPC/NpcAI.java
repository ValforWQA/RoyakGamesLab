
package Kaiden.Game.Server.Rooms.NPC;

import Kaiden.Database.Beans.MapNpcBean;
import Kaiden.Database.Beans.MonsterBean;
import Kaiden.Database.Beans.SkillBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Threads.RemoveAura;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;


public class NpcAI implements Runnable {
    
 public ScheduledFuture attacking;
    private MonsterState state;
    private final MapNpcBean mapMonster;
    private final MonsterBean monster;
    private final Room room;
    public Set<RemoveAura> auras;
    public NpcAI(MapNpcBean mapMon, Room room) {
        this.mapMonster = mapMon;
        this.monster = StorageCache.getInstance().getMonster(mapMon.getNpcId());
        this.room = room;
        //this.state = new MonsterState(this, this.monster.getHealth(), this.monster.getMana());
        this.auras = Collections.newSetFromMap(new ConcurrentHashMap());
    }

    public void cancel() {
        if (!this.state.hasTargets() && !this.state.isNeutral()) {
            this.restore();
            this.attacking.cancel(false);
        }
    }

    public void run() {
        if (this.state.isDead()) {
            this.attacking.cancel(false);
        } else {
            int userId = this.state.getRandomTarget();
            User user = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
            if (user != null) {
                if (this.room.getId() == user.getRoom() && this.mapMonster.getFrame().equals(user.properties.get("frame"))) {
                    this.attack(user);
                } else {
                    this.state.removeTarget(userId);
                    this.cancel();
                }
            }
        }
    }

    private boolean isDead() {
        if (this.state.isDead()) {
            if (this.attacking != null) {
                this.attacking.cancel(true);
            }
            return true;
        } else {
            return false;
        }
    }

    private void attack(User user) {
        if (!this.isDead() && !this.state.isDisabled()) {
            Stats stats = (Stats) user.properties.get("stats");
            Set<RemoveAura> userAuras = ((((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null) ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set) user.properties.get("auras"));
            State userState = (State) user.properties.get("state");
            double critChance = 0D;
            DamageType type = Damage.evaluateDamageType(StorageCache.getInstance().getCoreValue("baseMiss"), stats.get$tdo(), stats.get$tpa(), critChance);
            int damage = Damage.getReducedDamage(Damage.getRandomDamage(type, this.monster.getMaxDmg(), this.monster.getMinDmg()), userAuras);
            this.state.increaseManaByPercent(0.02D);
            userState.decreaseHealth(damage);
            if (userState.isDead()) {
                this.state.removeTarget(user.getUserId());
                this.cancel();
            }
            JSONObject p = (new JSONObject()).accumulate(user.getName(), userState.getData());
            JSONArray sara = (new JSONArray()).element((new JSONObject()).accumulate("actionResult", this.getAction(type, damage, user)).accumulate("iRes", 1));
            JSONObject m = (new JSONObject()).accumulate(String.valueOf(this.mapMonster.getNpcId()), (new JSONObject()).accumulate("intMP", this.state.getMana()));
            JSONObject ct = (new JSONObject()).accumulate("anims", (new JSONArray()).element(this.getAnim(user))).accumulate("p", p).accumulate("m", m).accumulate("cmd", "ct");
            Kaiden_Extension.getInstance().send(ct, this.getUserChannelButOne(this.room, user.getUserId()));
            ct.accumulate("sara", sara);
            Kaiden_Extension.getInstance().send(ct, user);     
        }
        
    }

    private LinkedList getUserChannelButOne(Room room, int userId) {
        LinkedList list = new LinkedList();
        User[] usersInRoom = room.getAllUsersButOne(userId);
        for (User user : usersInRoom) {
            list.add(user.getChannel());
        }
        return list;
    }

    private void cast(int skillId) {
        SkillBean skill = StorageCache.getInstance().getSkill(skillId);
        if (skill != null) {
            if (skill.getMana() <= this.state.getMana()) {
                String targets = this.state.getRandomTargets(skill.getHitTargets());
                JSONObject p = new JSONObject();
                JSONArray a = new JSONArray();
                JSONArray auras = new JSONArray();
                String[] ct = targets.split(",");
                for (String tgt : ct) {
                    int userId = Integer.parseInt(tgt.split(":")[1]);
                    User user = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
                    if (user != null) {
                        if (this.room.getId() == user.getRoom()) {
                            Stats stats = (Stats) user.properties.get("stats");
                            Set<RemoveAura> userAuras = ((((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null) ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set) user.properties.get("auras"));
                            State userState = (State) user.properties.get("state");
                            double critChance = 0D;
                            DamageType type = Damage.evaluateDamageType(StorageCache.getInstance().getCoreValue("baseMiss"), stats.get$tdo(), stats.get$tpa(), critChance);
                            int damage = (int) ((double) Damage.evaluateAuras(Damage.evaluateAuras(Damage.getRandomDamage(type, this.monster.getMaxDmg(), this.monster.getMinDmg()), userAuras), this.state.getAuras()) * skill.getDamage());
                            this.state.increaseManaByPercent(0.02D);
                            userState.decreaseHealth(damage);
                            if (userState.isDead()) {
                                this.state.removeTarget(user.getUserId());
                                this.cancel();
                            }
                            if (skill.hasAuraId()) {
                                auras.add(userState.applyAura(StorageCache.getInstance().getAura(skill.getAuraId())));
                            }
                            a.add(Damage.getDamageResult("m:" + this.mapMonster.getNpcId(), tgt, damage, type));
                            p.put(user.getName(), userState.getData());
                        } else {
                            this.state.removeTarget(userId);
                        }
                    }
                }
                this.state.decreaseMana(skill.getMana());
                JSONObject jsonObject = (new JSONObject()).accumulate("p", p).accumulate("m", (new JSONObject()).accumulate(String.valueOf(this.mapMonster.getNpcId()), (new JSONObject()).accumulate("intMP", this.state.getMana()))).accumulate("sarsa", (new JSONArray()).element((new JSONObject()).accumulate("cInf", "m:" + this.mapMonster.getNpcMapId()).accumulate("a", a).accumulate("iRes", 1))).accumulate("cmd", "ct").accumulate("a", auras).accumulate("anims", (new JSONArray()).element(this.getAnim(this.mapMonster.getFrame(), targets, skill)));
                Kaiden_Extension.getInstance().send(jsonObject, this.room.getChannellList());
            }
        }
    }

    private JSONObject getAction(DamageType type, int damage, User user) {
        JSONObject action = new JSONObject();
        action.put("hp", damage);
        action.put("cInf", "m:" + this.mapMonster.getNpcMapId());
        action.put("tInf", "p:" + user.getUserId());
        action.put("type", type.toString());
        return action;
    }

    private JSONObject getAnim(String frame, String targets, SkillBean skill) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", frame);
        anim.put("cInf", "m:" + this.mapMonster.getNpcMapId());
        anim.put("fx", skill.getEffects());
        anim.put("tInf", targets);
        anim.put("animStr", skill.getAnimation());
        if (!skill.getStrl().isEmpty()) {
            anim.put("strl", skill.getStrl());
        }

        return anim;
    }

    private JSONObject getAnim(User user) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", user.properties.get("frame"));
        anim.put("cInf", "m:" + this.mapMonster.getNpcMapId());
        anim.put("fx", "m");
        anim.put("tInf", "p:" + user.getUserId());
        anim.put("animStr", "Attack1,Attack2");
        return anim;
    }
    

    public void restore() {
        this.state.restore();
        JSONObject mtls = new JSONObject();
        mtls.put("cmd", "mtls");
        mtls.put("id", this.mapMonster.getNpcMapId());
        mtls.put("o", this.state.getData());
        Kaiden_Extension.getInstance().send(mtls, this.room.getChannellList());
    }

    public Room getRoom() {
        return this.room;
    }

    public synchronized void setAttacking(ScheduledFuture attacking) {
        if (this.attacking != null && !this.attacking.isDone()) {
            attacking.cancel(true);
        } else {
            this.state.setState(2);
            this.attacking = attacking;
        }
    }

    public MonsterBean getMonster() {
        return this.monster;
    }

    public MapNpcBean getMapMonster() {
        return this.mapMonster;
    }

    public MonsterState getState() {
        return this.state;
    }
}