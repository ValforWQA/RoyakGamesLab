package Kaiden.Game.Server.Rooms;

import Kaiden.Database.Beans.*;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Bots.BotManager;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import Kaiden.Game.Server.Users.Utils.SpanUtils;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.WarpUser;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import it.gotoandplay.smartfoxserver.exceptions.ExtensionHelperException;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import jdbchelper.QueryResult;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class Rooms {
    private static final Logger LOGGER = Logger.getLogger(Rooms.class);
    private static Rooms instance;

    public static Rooms getInstance() {
        if (instance == null) {
            instance = new Rooms();
        }
        return instance;
    }

    private final Random privKeyGenerator = new Random();

    public void exit(Room room, User user) {
        String baseName = room.getName().split("-")[0];
        String mapName = baseName.equals("house") ? room.getName() : baseName;

        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area != null) {
            if (area.isPvP()) {
                Kaiden_Extension.getInstance().sendToRoomButOne(
                        new String[]{"server", user.getName() + " has left the match."},
                        user,
                        room
                );

                int blueCount = 0;
                int redCount = 0;
                User[] users = room.getAllUsers();
                for (User playerInRoom : users) {
                    Object teamObj = playerInRoom.properties.get("pvpteam");
                    if (teamObj instanceof Integer) {
                        int team = (Integer) teamObj;
                        if (team == 0) {
                            blueCount++;
                        } else if (team == 1) {
                            redCount++;
                        }
                    }
                }

                if (room.getUserCount() > 0) {
                    if (blueCount <= 0) {
                        this.addPvPScore(room, 1000, 1);
                    } else if (redCount <= 0) {
                        this.addPvPScore(room, 1000, 0);
                    }

                    JSONObject pvp = new JSONObject();
                    pvp.put("cmd", "ct");
                    pvp.put("pvp", this.getPvPResult(room));
                    Kaiden_Extension.getInstance().send(pvp, room.getChannellList());
                }
            }

            Kaiden_Extension.getInstance().sendToRoomButOne(
                    new String[]{"exitArea", String.valueOf(user.getUserId()), user.getName()},
                    user,
                    room
            );

            LOGGER.info("[" + room.getName() + "] remove player: " + user.getName());
        }

        room.removeUser(user, true, false);
    }

    private void moveToArea(Room room, User user) {
        String mapName = room.getName().split("-")[0].equals("house") ? room.getName() : room.getName().split("-")[0];
        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area != null) {
            JSONObject mta = new JSONObject();
            JSONArray uoBranch = new JSONArray();
            User[] users = room.getAllUsers();
            for (User userInRoom : users) {
                JSONObject userObj = Users.getInstance().getProperties(userInRoom, room);
                uoBranch.add(userObj);
            }
            BotManager.getInstance().appendBotsToArea(room, uoBranch);
            mta.put("cmd", "moveToArea");
            mta.put("areaId", room.getId());
            mta.put("areaName", room.getName());
            mta.put("sExtra", "");
            mta.put("strMapFileName", area.getFile());
            mta.put("strMapName", mapName);
            mta.put("uoBranch", uoBranch);
            mta.put("monBranch", this.getMonBranch(room, area, user));
            mta.put("npcBranch", this.getNpcBranch(room));
            mta.put("intType", 2);

            if (area instanceof HouseBean) {
                HouseBean houseBean = (HouseBean) area;
                JSONObject house = houseBean.getData();

                // Always fetch placement data for the house owner, not the joining user
                house.put("sData", Users.getInstance().getHouseData(houseBean.getOwnerId(), ((HouseBean) area).getHouseItemId()));

                mta.put("houseData", house);
            }

            if (area instanceof HallBean) {
                mta.put("guildData", Users.getInstance().getGuildHallData(((HallBean) area).getGuildId()));
                mta.put("strMapName", "guildhall");
            }

            if (area.isPvP()) {
                mta.put("pvpTeam", user.properties.get("pvpteam"));
                mta.put("PVPFactions", room.properties.get("pvpfactions"));
                JSONObject var13 = new JSONObject();
                var13.put("v", room.properties.get("bscore"));
                JSONObject var14 = new JSONObject();
                var14.put("v", room.properties.get("rscore"));
                JSONArray var15 = new JSONArray();
                var15.add(var13);
                var15.add(var14);
                mta.put("pvpScore", var15);
            }

            if (!area.monsters.isEmpty()) {
                mta.put("mondef", this.getMonsterDefinition(area));
                mta.put("monmap", this.getMonMap(area));
            }

            if (!area.npcs.isEmpty()) {
                mta.put("npcdef", this.getNpcDefinition(area));
                mta.put("npcmap", this.getNpcMap(area));
            }

            // (Legacy dynamic NPC merge was here; left intact but effectively no-op
            //  now that we use spawnNpc() / adminSpawnNpc wrapper.)

            Kaiden_Extension.getInstance().send(mta, user);
        }
    }

    public void basicRoomJoin(User user, String roomName, String roomFrame, String roomPad) {
        String baseName = roomName.split("-")[0];
        String mapName = baseName.equals("house") ? roomName : baseName;

        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area == null) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Destination does not exist!"}, user);
            return;
        }
        if (area != null) {
            Room roomToJoin = this.lookForRoom(roomName, user);
            if (roomToJoin == null) {
                roomToJoin = this.generateRoom(roomName, user);
            }
            if (roomToJoin == null) {
                Kaiden_Extension.getInstance().send(new String[]{"warning", "Destination room could not be created!"}, user);
                return;
            }
            if (this.checkLimits(roomToJoin, user) == 0) {
                this.joinRoom(roomToJoin, user, roomFrame, roomPad);
            }

        }
    }

    public void basicRoomJoin(User user, String roomName) {
        this.basicRoomJoin(user, roomName, "Enter", "Spawn");
    }

    public void joinRoom(Room room, User user) {
        this.joinRoom(room, user, "Enter", "Spawn");
    }

    public void joinRoom(Room room, User user, String frame, String pad) {
        if (room != null && user != null) {
            try {
                user.properties.put("frame", frame);
                user.properties.put("pad", pad);
                user.properties.put("tx", 0);
                user.properties.put("ty", 0);
                ExtensionHelper.instance().joinRoom(user, user.getRoom(), room.getId(), true, "", false, true);
                this.moveToArea(room, user);
                QuestProgressManager.pushRestoredState(user);
                Kaiden_Extension.getInstance().send(new String[]{"server", "You joined \"" + room.getName() + "\"!"}, user);
                LOGGER.info("[" + room.getName() + "] new player: " + user.getName());
            } catch (ExtensionHelperException var6) {
                LOGGER.info("Error joining room: " + var6.getMessage());
            }
        }
    }

    public Room lookForRoom(String name, User user) {
        Room room = ExtensionHelper.instance().getZone(Kaiden_Extension.getInstance().getExtension().getOwnerZone()).getRoomByName(name);
        if (room != null) {
            return room;
        } else {
            String[] arr = name.split("-");
            if (arr.length > 1) {
                if (SpanUtils.isInteger(arr[1])) {
                    return this.generateRoom(name, user);
                }
            }
            for (int count = 1; count < 1000; ++count) {
                String search = arr[0] + "-" + count;
                Room test = ExtensionHelper.instance().getZone(Kaiden_Extension.getInstance().getExtension().getOwnerZone()).getRoomByName(search);
                if (test != null && test.getMaxUsers() > test.howManyUsers()) {
                    return test;
                }
            }
            return null;
        }
    }

    public int checkLimits(Room room, User user) {
        if (user == null) throw new NullPointerException("user is null");
        if (room == null) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Destination room does not exist!"}, user);
            return 7;
        }
        String fullName = room.getName();
        String areaName = fullName.startsWith("house-") ? fullName : fullName.split("-", 2)[0];
        ZoneBean area = StorageCache.getInstance().getArea(areaName);
        if (area == null) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Destination does not exist!"}, user);
            return 7;
        }
        // Always enforce room existence and capacity; staff bypass map access restrictions only.
        if (room.getId() == user.getRoom()) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Cannot join a room you are currently in!"}, user);
            return 2;
        }
        if (room.howManyUsers() >= room.getMaxUsers()) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "Room join failed, destination room is full."}, user);
            return 1;
        }
        if (user.isModerator() || user.isAdmin()) return 0;
        if (fullName.toLowerCase(java.util.Locale.ROOT).contains("bludrut")) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "This room is a restriction zone!"}, user);
            return 6;
        }
        Object levelValue = user.properties.get(Properties.LEVEL);
        int level = levelValue instanceof Number ? ((Number) levelValue).intValue() : 1;
        if (area.getReqLevel() > level) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "\"" + areaName + "\" requires level " + area.getReqLevel() + " and above to enter."}, user);
            return 3;
        }
        if (area.isPvP()) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "\"" + areaName + "\" is locked zone."}, user);
            return 6;
        }
        if (area.isStaff()) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "\"" + areaName + "\" is currently being built."}, user);
            return 5;
        }
        Object upgradeValue = user.properties.get("upgdays");
        int upgradeDays = upgradeValue instanceof Number ? ((Number) upgradeValue).intValue() : 0;
        if (area.isUpgrade() && upgradeDays <= 0) {
            Kaiden_Extension.getInstance().send(new String[]{"warning", "\"" + areaName + "\" is upgrade only."}, user);
            return 4;
        }
        return 0;
    }

    public Room generateRoom(String name, User user) {
        if (name.contains("-")) {
            try {
                int areaName = Integer.parseInt(name.split("-")[1]);
                String var8;
                if (areaName >= 90000) {
                    var8 = name.split("-")[0] + "-" + (this.privKeyGenerator.nextInt(9999) + 90000);
                    return this.createRoom(var8, user);
                }

                if (areaName >= 1000) {
                    var8 = name.split("-")[0] + "-" + areaName;
                    return this.createRoom(var8, user);
                }
            } catch (NumberFormatException ignored) {
            }
        }

        String var7 = name.split("-")[0];

        for (int i = 1; i < 1000; ++i) {
            String search = var7 + "-" + i;
            Room test = ExtensionHelper.instance().getZone(Kaiden_Extension.getInstance().getExtension().getOwnerZone()).getRoomByName(search);
            if (test == null) {
                return this.createRoom(search, user);
            }
        }
        return null;
    }

    public void deleteRoom(Room room) {
        ExtensionHelper helper = ExtensionHelper.instance();
        Zone zone = helper.getZone(Kaiden_Extension.getInstance().getExtension().getOwnerZone());
        ExtensionHelper.instance().destroyRoom(zone, room.getId());
    }

    public Room createRoom(String name, User user) {
        Map map = new HashMap();
        String mapName = name.split("-")[0].equals("house") ? name : name.split("-")[0];
        ZoneBean area = StorageCache.getInstance().getArea(mapName);
        if (area != null) {
            map.put("isGame", "false");
            map.put("maxU", String.valueOf(area.getMaxPlayers()));
            map.put("name", name);
            map.put("uCount", "false");
            try {
                Room ex = ExtensionHelper.instance().createRoom(
                        ExtensionHelper.instance().getZone(Kaiden_Extension.getInstance().getExtension().getOwnerZone()),
                        map,
                        user,
                        false,
                        true
                );

                HashMap<Integer, MonsterAI> monsters = new HashMap<>();
                HashMap<Integer, MapNpcBean> npc = new HashMap<>();

                if (!area.monsters.isEmpty()) {
                    for (MapMonsterBean r : area.monsters) {
                        MonsterAI PVPFactions = new MonsterAI(r, ex);
                        monsters.put(r.getMonMapId(), PVPFactions);
                    }
                }

                for (MapNpcBean r : area.npcs) {
                    npc.put(r.getNpcMapId(), r);
                }

                if (area.isPvP()) {
                    ex.properties.put("done", false);
                    ex.properties.put("bscore", 0);
                    ex.properties.put("rscore", 0);
                    ex.properties.put("bteamname", "Team Blue");
                    ex.properties.put("rteamname", "Team Red");
                    JSONArray PVPFactions = new JSONArray();
                    PVPFactions.add(new JSONObject().accumulate("id", 8).accumulate("sName", "Team Blue"));
                    PVPFactions.add(new JSONObject().accumulate("id", 7).accumulate("sName", "Team Red"));
                    ex.properties.put("pvpfactions", PVPFactions);
                }

                ex.properties.put("monsters", monsters);
                ex.properties.put("npcs", npc);
                return ex;
            } catch (ExtensionHelperException var10) {
                return null;
            }
        }
        return null;
    }

    private JSONArray getMonMap(ZoneBean area) {
        JSONArray monMap = new JSONArray();
        for (MapMonsterBean mapMonster : area.monsters) {
            JSONObject monInfo = new JSONObject();
            monInfo.put("MonID", String.valueOf(mapMonster.getMonsterId()));
            monInfo.put("MonMapID", String.valueOf(mapMonster.getMonMapId()));
            monInfo.put("bRed", 0);
            monInfo.put("intRSS", String.valueOf(-1));
            monInfo.put("intScale", this.getMonScale(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("dPosX",  this.getMonX(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("dPosY",  this.getMonY(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("sDirection", mapMonster.getDirection() == 0 ? "left" : "right");
            monInfo.put("strFrame", mapMonster.getFrame());
            monMap.add(monInfo);
        }
        return monMap;
    }

    private JSONArray getNpcDefinition(ZoneBean area) {
        JSONArray npcDef = new JSONArray();
        for (MapNpcBean mapNpc : area.npcs) {
            NpcBean npcObj = StorageCache.getInstance().getNpc(mapNpc.getNpcId());
            JSONObject npcInfo = new JSONObject();
            npcInfo.put("NpcID", String.valueOf(mapNpc.getNpcId()));
            npcInfo.put("intHP", 100);
            npcInfo.put("intHPMax", 100);
            npcInfo.put("intLevel", 1);
            npcInfo.put("intMP", 100);
            npcInfo.put("intMPMax", 100);
            npcInfo.put("sRace", "NPC");
            npcInfo.put("strBehave", "walk");
            npcInfo.put("strElement", "None");
            npcInfo.put("sDirection", mapNpc.getDirection() == 0 ? "left" : "right");
            npcInfo.put("iNpcType", npcObj.getType());
            if (npcObj.getType() == NpcBean.TYPE_FILE) {
                npcInfo.put("strLinkage", npcObj.getLinkage());
                npcInfo.put("strFileName", npcObj.getFile());

                // aliases used by DynamicNPC debug
                npcInfo.put("strFile", npcObj.getFile());
                npcInfo.put("strLink", npcObj.getLinkage());
            }

            if (npcObj.getType() == NpcBean.TYPE_HUMAN) {
                npcInfo.put("strGender", npcObj.getGender());

                HairBean hair = StorageCache.getInstance().getHair(npcObj.getHairId());
                if (hair != null) {
                    npcInfo.put("HairID", hair.getId());
                    npcInfo.put("strHairName", hair.getName());
                    npcInfo.put("strHairFilename", hair.getFile());
                }

                npcInfo.put("intColorHair", Integer.valueOf(npcObj.getColorHair(), 16));
                npcInfo.put("intColorSkin", Integer.valueOf(npcObj.getColorSkin(), 16));
                npcInfo.put("intColorEye", Integer.valueOf(npcObj.getColorEye(), 16));
                npcInfo.put("intColorBase", Integer.valueOf(npcObj.getColorBase(), 16));
                npcInfo.put("intColorTrim", Integer.valueOf(npcObj.getColorTrim(), 16));
                npcInfo.put("intColorAccessory", Integer.valueOf(npcObj.getColorAccessory(), 16));
                npcInfo.put("showCloak", Boolean.TRUE);
                npcInfo.put("showHelm", Boolean.TRUE);

                JSONObject equipmentObj = new JSONObject();
                ItemBean armorItem = StorageCache.getInstance().getItemOrDefault(npcObj.getArmorId());
                if (armorItem != null) {
                    equipmentObj.put(Properties.ITEM_CLASS, armorItem.getEquipmentJson());
                }
                ItemBean helmItem = StorageCache.getInstance().getItemOrDefault(npcObj.getHelmId());
                if (helmItem != null) {
                    equipmentObj.put(Properties.ITEM_HELM, helmItem.getEquipmentJson());
                }

                ItemBean weaponItem = StorageCache.getInstance().getItemOrDefault(npcObj.getWeaponId());
                if (weaponItem != null) {
                    equipmentObj.put(Properties.ITEM_WEAPON, weaponItem.getEquipmentJson());
                }
                ItemBean capeItem = StorageCache.getInstance().getItemOrDefault(npcObj.getCapeId());
                if (capeItem != null) {
                    equipmentObj.put(Properties.ITEM_CAPE, capeItem.getEquipmentJson());
                }
                npcInfo.put("eqp", equipmentObj);
            }

            npcInfo.put("strName", npcObj.getName());
            npcDef.add(npcInfo);
        }

        return npcDef;
    }

    private JSONArray getNpcMap(ZoneBean area) {
        JSONArray npcMap = new JSONArray();

        for (MapNpcBean mapNpc : area.npcs) {
            NpcBean npcObj = StorageCache.getInstance().getNpc(mapNpc.getNpcId());

            JSONObject monInfo = new JSONObject();
            monInfo.put("NpcID", String.valueOf(mapNpc.getNpcId()));
            monInfo.put("NpcMapID", String.valueOf(mapNpc.getNpcMapId()));
            monInfo.put("strFrame", mapNpc.getFrame());
            monInfo.put("dPosX", mapNpc.getPosX());
            monInfo.put("dPosY", mapNpc.getPosY());
            monInfo.put("intScale", mapNpc.getScale());
            monInfo.put("sDirection", mapNpc.getDirection() == 0 ? "left" : "right");
            monInfo.put("sAnim", mapNpc.getAnimation());
            monInfo.put("bHasApop", StorageCache.getInstance().getMapNPC(mapNpc.getNpcMapId()) != null);

            if (npcObj != null && npcObj.getType() == NpcBean.TYPE_FILE) {
                // send both canonical + alias names so client/debug code works uniformly
                monInfo.put("strFileName", npcObj.getFile());
                monInfo.put("strLinkage", npcObj.getLinkage());
                monInfo.put("strFile", npcObj.getFile());
                monInfo.put("strLink", npcObj.getLinkage());
            }

            npcMap.add(monInfo);
        }

        return npcMap;
    }

    private JSONArray getNpcBranch(Room room) {
        JSONArray npcBranch = new JSONArray();
        @SuppressWarnings("unchecked")
        HashMap<Integer, MapNpcBean> monsters = (HashMap<Integer, MapNpcBean>) room.properties.get("npcs");
        //Kaiden_Engine.LOGGER.info(monsters.size());
        for (MapNpcBean actMon : monsters.values()) {
            NpcBean bean = StorageCache.getInstance().getNpc(actMon.getNpcId());
            //Kaiden_Engine.LOGGER.info(bean.getName());
            JSONObject mon = new JSONObject();
            mon.put("NpcID", String.valueOf(actMon.getNpcId()));
            mon.put("NpcMapID", String.valueOf(actMon.getNpcMapId()));
            mon.put("iLvl", 1);
            mon.put("intHP", 100);
            mon.put("intHPMax", 100);
            mon.put("intMP", 100);
            mon.put("intMPMax", 100);
            mon.put("intState", Properties.STATE_NORMAL);
            npcBranch.add(mon);
        }

        return npcBranch;
    }

    private JSONArray getMonsterDefinition(ZoneBean area) {
        JSONArray monDef = new JSONArray();
        for (MapMonsterBean mapMonster : area.monsters) {
            JSONObject monInfo = new JSONObject();
            MonsterBean monster = StorageCache.getInstance().getMonster(mapMonster.getMonsterId());
            monInfo.put("MonID", String.valueOf(mapMonster.getMonsterId()));
            monInfo.put("MonMapID", mapMonster.getMonMapId());
            monInfo.put("intHP", monster.getHealth());
            monInfo.put("intHPMax", monster.getHealth());
            monInfo.put("intLevel", monster.getLevel());
            monInfo.put("intMP", monster.getMana());
            monInfo.put("intMPMax", monster.getMana());
            monInfo.put("intScale", this.getMonScale(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("dPosX",  this.getMonX(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("dPosY",  this.getMonY(mapMonster.getMonsterId(), mapMonster.getMonMapId()));
            monInfo.put("sRace", monster.getRace());
            monInfo.put("strBehave", "walk");
            monInfo.put("sDirection", mapMonster.getDirection() == 0 ? "left" : "right");
            monInfo.put("strElement", monster.getElement());
            monInfo.put("strLinkage", monster.getLinkage());
            monInfo.put("strMonFileName", monster.getFile());
            monInfo.put("strMonName", monster.getName());
            addMonsterAvatarAppearance(monInfo, monster);
            monDef.add(monInfo);
        }
        return monDef;
    }

    /**
     * Adds NPCAvatar-compatible equipment data while preserving the normal
     * monster SWF path. monsters.Avatar is a foreign key to monsters_outfits.id.
     */
    private void addMonsterAvatarAppearance(JSONObject monInfo, MonsterBean monster) {
        if (monInfo == null || monster == null) return;

        int outfitId = monster.getAvatar();
        monInfo.put("Avatar", outfitId);
        monInfo.put("bAvatar", outfitId > 0 ? 1 : 0);
        if (outfitId <= 0) return;

        MonsterOutfitBean outfit = StorageCache.getInstance().getMonsterOutfit(outfitId);
        if (outfit == null) {
            LOGGER.warn("Avatar monster " + monster.getId() +
                    " references missing monsters_outfits.id=" + outfitId);
            return;
        }

        monInfo.put("OutfitName", outfit.getName());
        monInfo.put("strGender", normalizeGender(outfit.getGender()));
        monInfo.put("showHelm", Boolean.TRUE);
        monInfo.put("showCloak", Boolean.TRUE);
        monInfo.put("intColorHair", parseHexColor(outfit.getHairColor(), 0x000000));
        monInfo.put("intColorEye", parseHexColor(outfit.getEyeColor(), 0x000000));
        monInfo.put("intColorSkin", parseHexColor(outfit.getSkinColor(), 0xFFCC99));
        monInfo.put("intColorBase", parseHexColor(outfit.getBaseColor(), 0xFFFFFF));
        monInfo.put("intColorTrim", parseHexColor(outfit.getTrimColor(), 0xFFFFFF));
        monInfo.put("intColorAccessory", parseHexColor(outfit.getAccessoryColor(), 0xFFFFFF));

        HairBean hair = StorageCache.getInstance().getHair(outfit.getHairId());
        if (hair != null) {
            monInfo.put("HairID", hair.getId());
            monInfo.put("strHairName", hair.getName());
            monInfo.put("strHairFilename", hair.getFile());
        } else if (outfit.getHairId() > 0) {
            LOGGER.warn("Monster outfit " + outfitId + " references missing hairs.id=" + outfit.getHairId());
        }

        JSONObject equipment = new JSONObject();
        // ArmorID may be either a class-style armor (ar) or normal armor (co).
        putMonsterEquipment(equipment, outfit.getArmorId(), Properties.ITEM_CLASS, "co");
        putMonsterEquipment(equipment, outfit.getWeaponId(), Properties.ITEM_WEAPON);
        putMonsterEquipment(equipment, outfit.getHelmId(), Properties.ITEM_HELM);
        putMonsterEquipment(equipment, outfit.getCapeId(), Properties.ITEM_CAPE);
        putMonsterEquipment(equipment, outfit.getMiscId(), Properties.ITEM_GROUND, "ac");
        monInfo.put("eqp", equipment);
    }

    private String normalizeGender(String gender) {
        return gender != null && gender.trim().equalsIgnoreCase("F") ? "F" : "M";
    }

    private int parseHexColor(String value, int fallback) {
        if (value == null) return fallback;
        String cleaned = value.trim().replace("#", "").replace("0x", "").replace("0X", "");
        if (cleaned.isEmpty()) return fallback;
        try { return Integer.parseInt(cleaned, 16) & 0xFFFFFF; }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private void putMonsterEquipment(JSONObject equipment, int itemId, String... allowedSlots) {
        if (equipment == null || itemId <= 0) return;
        ItemBean item = StorageCache.getInstance().getItemOrDefault(itemId);
        if (item == null) {
            LOGGER.warn("Monster outfit references missing items.id=" + itemId);
            return;
        }

        String actualSlot = item.getEquipment() == null ? "" : item.getEquipment().trim();
        boolean allowed = false;
        for (String slot : allowedSlots) {
            if (slot != null && slot.equalsIgnoreCase(actualSlot)) {
                allowed = true;
                break;
            }
        }
        if (!allowed) {
            LOGGER.warn("Monster outfit item " + itemId + " has Equipment='" + actualSlot +
                    "' but expected one of " + java.util.Arrays.toString(allowedSlots) + "; skipping it.");
            return;
        }

        String file = item.getFile();
        String link = item.getLink();
        if (file == null || file.trim().isEmpty() || link == null || link.trim().isEmpty()) {
            LOGGER.warn("Monster outfit item " + itemId + " for slot '" + actualSlot +
                    "' has an empty File or Link; skipping it.");
            return;
        }

        // Preserve the item's real slot. This is required for co armor and
        // mi/ac ground or misc equipment to reach the correct client loader.
        equipment.put(actualSlot, item.getEquipmentJson());
    }

    private JSONArray getMonBranch(Room room, ZoneBean area, User user) {
        JSONArray monBranch = new JSONArray();
        HashMap monsters = (HashMap) room.properties.get("monsters");

        for (Object monsterObj : monsters.values()) {
            MonsterAI actMon = (MonsterAI) monsterObj;
            MonsterState state = actMon.getState();
            MonsterBean monster = actMon.getMonster();

            JSONObject mon = new JSONObject(); // ✅ NEW per monster

            mon.put("MonID", String.valueOf(monster.getId()));
            mon.put("MonMapID", String.valueOf(actMon.getMapMonster().getMonMapId()));
            mon.put("bRed", "0");
            mon.put("iLvl", monster.getLevel());
            mon.put("intHP", state.getHealth());
            mon.put("intHPMax", monster.getHealth());
            mon.put("intMP", state.getMana());
            mon.put("intMPMax", monster.getMana());

            mon.put("dPosX",  this.getMonX(actMon.getMapMonster().getMonsterId(), actMon.getMapMonster().getMonMapId()));
            mon.put("dPosY", this.getMonY(actMon.getMapMonster().getMonsterId(), actMon.getMapMonster().getMonMapId()));
            mon.put("sDirection", actMon.getMapMonster().getDirection() == 0 ? "left" : "right");

            mon.put("intScale", this.getMonScale(actMon.getMapMonster().getMonsterId(), actMon.getMapMonster().getMonMapId()));

            mon.put("intState", state.getState());
            mon.put("wDPS", monster.getDPS());

            if (area.isPvP()) {
                JSONArray react = new JSONArray();
                if (monster.getTeamId() > 0) {
                    react.add(0); react.add(1);
                } else {
                    react.add(1); react.add(0);
                }
                mon.put("react", react);
            }

            monBranch.add(mon);
        }

        return monBranch;
    }


    public void addPvPScore(Room room, int score, int teamId) {
        if (!(Boolean) room.properties.get("done")) {
            int rScore = (Integer) room.properties.get("rscore");
            int bScore = (Integer) room.properties.get("bscore");
            switch (teamId) {
                case 0:
                    room.properties.put("bscore", score + bScore >= 1000 ? 1000 : score + bScore);
                    break;
                case 1:
                    room.properties.put("rscore", score + rScore >= 1000 ? 1000 : score + rScore);
            }

        }
    }

    public double getMonScale(int monid, int monmapid) {
        QueryResult scale = Storage.getInstance().getJdbc().query(
                "SELECT * FROM maps_monsters WHERE MonMapID = ? AND MonsterID = ?",
                monmapid, monid
        );
        try {
            if (scale.next()) {
                double monScale = scale.getDouble("Scale"); // ✅ FIX
                return monScale;
            } else {
                return 1.0; // better default
            }
        } finally {
            scale.close();
        }
    }

    public int getMonX(int monid, int monmapid) {
        MonsterBean monQuery = StorageCache.getInstance().getMonster(monid);
        QueryResult X = Storage.getInstance().getJdbc().query("SELECT * FROM maps_monsters WHERE MonMapID = ? AND MonsterID = ?", monmapid, monid);
        try {
            if (X.next()) {
                int monX = X.getInt("PosX");
                return monX;
            } else {
                //Kaiden_Engine.LOGGER.info("Monster Scale is null");
                return 0;
            }
        } finally {
            X.close();
        }
    }

    public int getMonY(int monid, int monmapid) {
        MonsterBean monQuery = StorageCache.getInstance().getMonster(monid);
        QueryResult Y = Storage.getInstance().getJdbc().query("SELECT * FROM maps_monsters WHERE MonMapID = ? AND MonsterID = ?", monmapid, monid);
        try {
            if (Y.next()) {
                int monY = Y.getInt("PosY");
                return monY;
            } else {
                //Kaiden_Engine.LOGGER.info("Monster Scale is null");
                return 0;
            }
        } finally {
            Y.close();
        }
    }




    public double getNpcScale(int npcid, int npcmapid) {
        NpcBean npcQuery = StorageCache.getInstance().getNpc(npcid); // (kept as in your original; adjust if needed)
        QueryResult scale = Storage.getInstance().getJdbc().query("SELECT * FROM maps_npcs WHERE NPCMapID = ? AND NPCID = ?", npcmapid, npcid);
        try {
            if (scale.next()) {
                Double npcScale = scale.getDouble("Scale");
                //Kaiden_Engine.LOGGER.info("NPC Name: " + npcQuery.getName() + " | --> NPCScale: " + npcScale);
                return npcScale;
            } else {
                //Kaiden_Engine.LOGGER.info("NPC Scale is null");
                return 0;
            }
        } finally {
            scale.close();
        }
    }

    public void relayPvPEvent(MonsterAI ai, int teamId) {
        MonsterBean monster = ai.getMonster();
        String monName = monster.getName();
        Room room = ai.getRoom();
        JSONObject pvpe = new JSONObject();
        pvpe.put("cmd", "PVPE");
        pvpe.put("typ", "kill");
        pvpe.put("team", teamId);
        if (monName.contains("Restorer")) {
            pvpe.put("val", "Restorer");
            this.addPvPScore(room, 50, teamId);
        } else if (monName.contains("Brawler")) {
            pvpe.put("val", "Brawler");
            this.addPvPScore(room, 25, teamId);
        } else if (monName.contains("Captain")) {
            pvpe.put("val", "Captain");
            this.addPvPScore(room, 1000, teamId);
        } else if (monName.contains("General")) {
            pvpe.put("val", "General");
            this.addPvPScore(room, 100, teamId);
        } else if (monName.contains("Knight")) {
            pvpe.put("val", "Knight");
            this.addPvPScore(room, 100, teamId);
        } else {
            this.addPvPScore(room, monster.getLevel(), teamId);
        }

        if (pvpe.containsKey("val")) {
            Kaiden_Extension.getInstance().send(pvpe, room.getChannellList());
        }
    }

    public JSONObject getPvPResult(Room room) {
        JSONObject pvpcmd = new JSONObject();
        pvpcmd.put("cmd", "PVPS");
        JSONArray pvpScore = new JSONArray();
        JSONObject bs = new JSONObject();
        JSONObject rs = new JSONObject();
        int redScore = (Integer) room.properties.get("rscore");
        int blueScore = (Integer) room.properties.get("bscore");
        bs.put("v", blueScore);
        rs.put("v", redScore);
        if (!(Boolean) room.properties.get("done") && (redScore >= 1000 || blueScore >= 1000)) {
            pvpcmd.put("cmd", "PVPC");
            String rName = (String) room.properties.get("rteamname");
            String bName = (String) room.properties.get("bteamname");
            if (redScore >= 1000) {
                this.pvpStats(room, rName, bName, 1);
                pvpcmd.put("team", 1);
            } else if (blueScore >= 1000) {
                this.pvpStats(room, bName, rName, 0);
                pvpcmd.put("team", 0);
            }
            room.properties.put("done", true);
        }
        pvpScore.add(bs);
        pvpScore.add(rs);
        pvpcmd.put("pvpScore", pvpScore);
        return pvpcmd;
    }

    private void pvpStats(Room room, String win, String loser, int team) {
        String roomName = room.getName().toLowerCase().split("-")[0];
        if (roomName.equals("duel")) {
            Server.getInstance().sendServerMessage(win + " won the match against " + loser);
            Storage.getInstance().getJdbc().run("UPDATE users SET PvPSoloWin = (PvPSoloWin + 1) WHERE Name = ?", win);
            Storage.getInstance().getJdbc().run("UPDATE users SET PvPSoloLoss = (PvPSoloLoss + 1) WHERE Name = ?", loser);
        } else {
            for (User user : room.getAllUsers()) {
                if (user.properties.get("pvpteam").equals(team)) {
                    switch (roomName) {
                        case "doomarena":
                            Storage.getInstance().getJdbc().run("UPDATE users SET DoomArenaWin = (DoomArenaWin + 1) WHERE Name = ?", user.getName());
                            break;
                        case "bludrutbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPEightVSEightWin = (PvPEightVSEightWin + 1) WHERE Name = ?", user.getName());
                            break;
                        case "chaosbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPFiveVSFiveWin = (PvPFiveVSFiveWin + 1) WHERE Name = ?", user.getName());
                            break;
                        case "frostbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPThreeVSThreeWin = (PvPThreeVSThreeWin + 1) WHERE Name = ?", user.getName());
                            break;
                    }
                } else {
                    switch (roomName) {
                        case "doomarena":
                            Storage.getInstance().getJdbc().run("UPDATE users SET DoomArenaLoss = (DoomArenaLoss + 1) WHERE Name = ?", user.getName());
                            break;
                        case "bludrutbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPEightVSEightLoss = (PvPEightVSEightLoss + 1) WHERE Name = ?", user.getName());
                            break;
                        case "chaosbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPFiveVSFiveLoss = (PvPFiveVSFiveLoss + 1) WHERE Name = ?", user.getName());
                            break;
                        case "frostbrawl":
                            Storage.getInstance().getJdbc().run("UPDATE users SET PvPThreeVSThreeLoss = (PvPThreeVSThreeLoss + 1) WHERE Name = ?", user.getName());
                            break;
                    }
                }
            }
        }
        Executor.getInstance().scheduleTask(new WarpUser(room.getAllUsers(), "hometown", "Enter", "Spawn"), 12L, TimeUnit.SECONDS);
    }

   // npc & monster spawn data

    private Map<Integer, JSONObject> getDynamicMonsterMap(Room room) {
        Object prop = room.properties.get("mon_dynamic");
        if (prop instanceof Map) {
            return (Map<Integer, JSONObject>) prop;
        }
        Map<Integer, JSONObject> dyn = new HashMap<Integer, JSONObject>();
        room.properties.put("mon_dynamic", dyn);
        return dyn;
    }

    @SuppressWarnings("unchecked")
    public void spawnMonster(Room room, User srcUser, int monsterId) {
        if (room == null || srcUser == null) return;

        // frame
        String frame = (String) srcUser.properties.get("frame");
        if (frame == null || frame.isEmpty()) frame = "Enter";

        // position near player
        double posX;
        double posY;

        Object txObj = srcUser.properties.get("tx");
        Object tyObj = srcUser.properties.get("ty");

        double rawX = (txObj instanceof Number) ? ((Number) txObj).doubleValue() : 0.0;
        double rawY = (tyObj instanceof Number) ? ((Number) tyObj).doubleValue() : 0.0;

        posX = rawX + 60.0;
        posY = rawY;

        // get monster definition
        MonsterBean monster = StorageCache.getInstance().getMonster(monsterId);
        if (monster == null) return;

        // get or create monsters map
        HashMap<Integer, MonsterAI> monsters =
                (HashMap<Integer, MonsterAI>) room.properties.get("monsters");

        if (monsters == null) {
            monsters = new HashMap<>();
            room.properties.put("monsters", monsters);
        }

        int newMonMapId = nextMonMapId(room);

        // build MapMonsterBean
        MapMonsterBean mapMonster = new MapMonsterBean();
        mapMonster.setMonMapId(newMonMapId);
        mapMonster.setMonsterId(monsterId);
        mapMonster.setFrame(frame);
        mapMonster.setPosX(posX);
        mapMonster.setPosY(posY);
        mapMonster.setScale(1);
        mapMonster.setDirection(1);

        // create AI
        MonsterAI ai = new MonsterAI(mapMonster, room);
        monsters.put(newMonMapId, ai);
        room.properties.put("monsters", monsters);

        // build mondef
        JSONObject monDef = new JSONObject();
        monDef.put("MonID", String.valueOf(monster.getId()));
        monDef.put("MonMapID", newMonMapId);
        monDef.put("intHP", monster.getHealth());
        monDef.put("intHPMax", monster.getHealth());
        monDef.put("intLevel", monster.getLevel());
        monDef.put("intMP", monster.getMana());
        monDef.put("intMPMax", monster.getMana());
        monDef.put("intScale", mapMonster.getScale());
        monDef.put("dPosX", mapMonster.getPosX());
        monDef.put("dPosY", mapMonster.getPosY());
        monDef.put("sRace", monster.getRace());
        monDef.put("strBehave", "walk");
        monDef.put("sDirection", "right");
        monDef.put("strElement", monster.getElement());
        monDef.put("strLinkage", monster.getLinkage());
        monDef.put("strMonFileName", monster.getFile());
        monDef.put("strMonName", monster.getName());
        addMonsterAvatarAppearance(monDef, monster);

        // build monmap
        JSONObject monMap = new JSONObject();
        monMap.put("MonID", monster.getId());
        monMap.put("MonMapID", newMonMapId);
        monMap.put("strFrame", frame);
        monMap.put("dPosX", posX);
        monMap.put("dPosY", posY);
        monMap.put("intScale", 1);
        monMap.put("sDirection", "right");

        // branch
        JSONArray monBranch = getMonBranch(room,
                StorageCache.getInstance().getArea(room.getName().split("-")[0]),
                srcUser);

        // packet
        JSONObject pkt = new JSONObject();
        pkt.put("cmd", "monSpawn");

        JSONArray defArr = new JSONArray();
        defArr.add(monDef);
        pkt.put("mondef", defArr);

        JSONArray mapArr = new JSONArray();
        mapArr.add(monMap);
        pkt.put("monmap", mapArr);

        pkt.put("monBranch", monBranch);
        pkt.put("id", monster.getId());
        pkt.put("mapid", newMonMapId);

        Kaiden_Extension.getInstance().send(pkt, room.getChannellList());
    }


    private int nextMonMapId(Room room) {
        HashMap<Integer, MonsterAI> monsters =
                (HashMap<Integer, MonsterAI>) room.properties.get("monsters");

        int next = 1;

        if (monsters != null) {
            for (Integer key : monsters.keySet()) {
                if (key != null && key >= next) next = key + 1;
            }
        }

        Map<Integer, JSONObject> dyn = getDynamicMonsterMap(room);
        for (Integer key : dyn.keySet()) {
            if (key != null && key >= next) next = key + 1;
        }

        return next;
    }


    public void spawnNpc(Room room, User srcUser, int npcId) {
        if (room == null || srcUser == null) {
            return;
        }

        // 1) Resolve frame from player
        String frame = (String) srcUser.properties.get("frame");
        if (frame == null || frame.isEmpty()) {
            frame = "Enter"; // safe default
        }

        // 2) Resolve position from player, then adjust
        double posX;
        double posY;

        Object txObj = srcUser.properties.get("tx");
        Object tyObj = srcUser.properties.get("ty");

        //int usertx = srcUser.properties.get("tx");

        double rawX = (txObj instanceof Number) ? ((Number) txObj).doubleValue() : 0.0;
        double rawY = (tyObj instanceof Number) ? ((Number) tyObj).doubleValue() : 0.0;

        // If both coords are 0.0 (no pad leaf / default), use tooltip coords
        posX = rawX + 60.0;
        posY = rawY;

        // 3) Get / init NPC map for this room
        @SuppressWarnings("unchecked")
        HashMap<Integer, MapNpcBean> npcMap =
                (HashMap<Integer, MapNpcBean>) room.properties.get("npcs");
        if (npcMap == null) {
            npcMap = new HashMap<>();
            room.properties.put("npcs", npcMap);
        }

        // new NpcMapID unique in this room
        int newNpcMapId = 1;
        for (Integer key : npcMap.keySet()) {
            if (key != null && key >= newNpcMapId) {
                newNpcMapId = key + 1;
            }
        }

        // 4) Build runtime MapNpcBean
        MapNpcBean mapNpc = new MapNpcBean();
        mapNpc.setNpcMapId(newNpcMapId);
        mapNpc.setNpcId(npcId);
        mapNpc.setFrame(frame);
        mapNpc.setPosX(posX);
        mapNpc.setPosY(posY);
        mapNpc.setScale(1);
        mapNpc.setDirection(1);      // 0 = left, 1 = right
        mapNpc.setAnimation("Idle");

        npcMap.put(newNpcMapId, mapNpc);
        room.properties.put("npcs", npcMap);

        boolean persist = true;
        if (persist) {
            try {
                String baseName = room.getName().split("-")[0];
                String mapName = baseName.equals("house") ? room.getName() : baseName;
                ZoneBean area = StorageCache.getInstance().getArea(mapName);
                Set<MapNpcBean> npcSet;
                if (area.npcs == null || area.npcs == Collections.EMPTY_SET) {
                    npcSet = new HashSet<MapNpcBean>();
                } else {
                    npcSet = new HashSet<MapNpcBean>(area.npcs);
                }
                npcSet.add(mapNpc);
                area.npcs = npcSet;

                // --- Persist to DB as before ---
                Storage.getInstance().getJdbc().run(
                        "INSERT INTO maps_npcs (MapID, NPCID, Frame, PosX, PosY, Scale, Direction, Animation) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        area.getId(),
                        mapNpc.getNpcId(),
                        mapNpc.getFrame(),
                        mapNpc.getPosX(),
                        mapNpc.getPosY(),
                        mapNpc.getScale(),
                        mapNpc.getDirection(),
                        mapNpc.getAnimation()
                );

            } catch (Exception e) {
                //Kaiden_Engine.LOGGER.warn("[Rooms] spawnNpc: failed to sync NPC to ZoneBean/DB", e);
            }
        } else {
            //Kaiden_Engine.LOGGER.debug("[Rooms] spawnNpc: dynamic spawn, skip ZoneBean/DB sync.");
        }

        // 5) Build npcdef entry (same as getNpcDefinition)
        NpcBean npcObj = StorageCache.getInstance().getNpc(npcId);
        if (npcObj == null) {
            //Kaiden_Engine.LOGGER.warn("[Rooms] spawnNpc: NpcID " + npcId + " not found.");
            return;
        }

        // --- Shared FILE fields so BOTH npcdef and npcmap use the same values ---
        String file = null;
        String link = null;

        if (npcObj.getType() == NpcBean.TYPE_FILE) {
            file = npcObj.getFile();
            link = npcObj.getLinkage();

            if (file == null || file.isEmpty()) {
                file = "[none]";
                //Kaiden_Engine.LOGGER.warn("[Rooms] spawnNpc: file is empty. " + file);
            }
            if (link == null || link.isEmpty()) {
                link = "[none]";
                //Kaiden_Engine.LOGGER.warn("[Rooms] spawnNpc: link is empty. " + link);
            }
        }

        JSONObject npcDefInfo = new JSONObject();
        npcDefInfo.put("NpcID", String.valueOf(mapNpc.getNpcId()));
        npcDefInfo.put("intHP", 100);
        npcDefInfo.put("intHPMax", 100);
        npcDefInfo.put("intLevel", 1);
        npcDefInfo.put("intMP", 100);
        npcDefInfo.put("intMPMax", 100);
        npcDefInfo.put("sRace", "NPC");
        npcDefInfo.put("strBehave", "walk");
        npcDefInfo.put("strElement", "None");
        npcDefInfo.put("intScale", (int)mapNpc.getScale());
        npcDefInfo.put("sDirection", mapNpc.getDirection() == 0 ? "left" : "right");
        npcDefInfo.put("iNpcType", npcObj.getType());

        if (npcObj.getType() == NpcBean.TYPE_FILE) {

            npcDefInfo.put("strFileName", file);
            npcDefInfo.put("strLinkage", link);

            npcDefInfo.put("strFile", file);
            npcDefInfo.put("strLink", link);
        }

        if (npcObj.getType() == NpcBean.TYPE_HUMAN) {
            npcDefInfo.put("strGender", npcObj.getGender());

            HairBean hair = StorageCache.getInstance().getHair(npcObj.getHairId());
            if (hair != null) {
                npcDefInfo.put("HairID", hair.getId());
                npcDefInfo.put("strHairName", hair.getName());
                npcDefInfo.put("strHairFilename", hair.getFile());
            }

            npcDefInfo.put("intColorHair", Integer.valueOf(npcObj.getColorHair(), 16));
            npcDefInfo.put("intColorSkin", Integer.valueOf(npcObj.getColorSkin(), 16));
            npcDefInfo.put("intColorEye", Integer.valueOf(npcObj.getColorEye(), 16));
            npcDefInfo.put("intColorBase", Integer.valueOf(npcObj.getColorBase(), 16));
            npcDefInfo.put("intColorTrim", Integer.valueOf(npcObj.getColorTrim(), 16));
            npcDefInfo.put("intColorAccessory", Integer.valueOf(npcObj.getColorAccessory(), 16));
            npcDefInfo.put("showCloak", Boolean.TRUE);
            npcDefInfo.put("showHelm", Boolean.TRUE);

            JSONObject equipmentObj = new JSONObject();
            ItemBean armorItem = StorageCache.getInstance().getItemOrDefault(npcObj.getArmorId());
            if (armorItem != null) {
                equipmentObj.put(Properties.ITEM_CLASS, armorItem.getEquipmentJson());
            }
            ItemBean helmItem = StorageCache.getInstance().getItemOrDefault(npcObj.getHelmId());
            if (helmItem != null) {
                equipmentObj.put(Properties.ITEM_HELM, helmItem.getEquipmentJson());
            }
            ItemBean weaponItem = StorageCache.getInstance().getItemOrDefault(npcObj.getWeaponId());
            if (weaponItem != null) {
                equipmentObj.put(Properties.ITEM_WEAPON, weaponItem.getEquipmentJson());
            }
            ItemBean capeItem = StorageCache.getInstance().getItemOrDefault(npcObj.getCapeId());
            if (capeItem != null) {
                equipmentObj.put(Properties.ITEM_CAPE, capeItem.getEquipmentJson());
            }
            npcDefInfo.put("eqp", equipmentObj);

            // DEBUG: log HUMAN def including eqp keys so we can verify armor data
            try {
                //Kaiden_Engine.LOGGER.info("[Rooms] spawnNpc HUMAN def for NpcID=" + npcId + " -> " + npcDefInfo);
            } catch (Exception ignored) { }
        }

        npcDefInfo.put("strName", npcObj.getName());

        // 6) Build npcmap entry (same as getNpcMap)
        JSONObject npcMapInfo = new JSONObject();
        npcMapInfo.put("NpcID", String.valueOf(mapNpc.getNpcId()));
        npcMapInfo.put("NpcMapID", String.valueOf(mapNpc.getNpcMapId()));
        npcMapInfo.put("strFrame", mapNpc.getFrame());
        npcMapInfo.put("dPosX", mapNpc.getPosX());
        npcMapInfo.put("dPosY", mapNpc.getPosY());
        npcMapInfo.put("intScale", mapNpc.getScale());
        npcMapInfo.put("sDirection", mapNpc.getDirection() == 0 ? "left" : "right");
        npcMapInfo.put("sAnim", mapNpc.getAnimation());
        npcMapInfo.put("bHasApop", StorageCache.getInstance().getMapNPC(mapNpc.getNpcMapId()) != null);

        if (npcObj.getType() == NpcBean.TYPE_FILE) {
            npcMapInfo.put("strFileName", file);
            npcMapInfo.put("strLinkage", link);
            npcMapInfo.put("strFile", file);
            npcMapInfo.put("strLink", link);

            // Log exactly what you're seeing in chat for debugging
            //Kaiden_Engine.LOGGER.info(
                    //"[DynamicNPC] (FILE) NpcID=" + npcId +
                            //" type=" + npcObj.getType() +
                           // " file=[" + file + "] link=[" + link + "]"
           // );
        }

        // 7) Track in npc_dynamic for admin tools
        Map<Integer, JSONObject> dyn = getDynamicNpcMap(room);
        JSONObject entry = new JSONObject();
        entry.put("def", JSONObject.fromObject(npcDefInfo));
        entry.put("map", JSONObject.fromObject(npcMapInfo));
        dyn.put(newNpcMapId, entry);

        // 8) Build npcBranch for this room
        JSONArray npcBranch = this.getNpcBranch(room);

        // 9) Send npcSpawn packet
        JSONObject pkt = new JSONObject();
        pkt.put("cmd", "npcSpawn");

        JSONArray defArr = new JSONArray();
        defArr.add(npcDefInfo);
        pkt.put("npcdef", defArr);

        JSONArray mapArr = new JSONArray();
        mapArr.add(npcMapInfo);
        pkt.put("npcmap", mapArr);

        pkt.put("id", npcObj.getId());
        pkt.put("mapid", newNpcMapId);
        pkt.put("npcBranch", npcBranch);

        Kaiden_Extension.getInstance().send(pkt, room.getChannellList());

        //Kaiden_Engine.LOGGER.info(
               // "[Rooms] Spawned NPC " + npcObj.getName() +
                       // " (NpcID=" + npcId + ", NpcMapID=" + newNpcMapId + ") in room " + room.getName() +
                       // " at frame " + frame + " pos(" + posX + "," + posY + ")"
        //);
    }

    // ========================================================================
    //  Admin helpers for dynamic NPC commands
    // ========================================================================
    public void adminSpawnNpc(Room room, User admin, int npcId) {
        this.spawnNpc(room, admin, npcId);
    }

    @SuppressWarnings("unchecked")
    private Map<Integer, JSONObject> getDynamicNpcMap(Room room) {
        Object prop = room.properties.get("npc_dynamic");
        if (prop instanceof Map) {
            return (Map<Integer, JSONObject>) prop;
        }
        Map<Integer, JSONObject> dyn = new HashMap<Integer, JSONObject>();
        room.properties.put("npc_dynamic", dyn);
        return dyn;
    }

    private JSONObject buildDynamicNpcPacket(Room room) {
        Map<Integer, JSONObject> dyn = getDynamicNpcMap(room);
        if (dyn.isEmpty()) {
            return null;
        }

        JSONArray npcdefArr = new JSONArray();
        JSONArray npcmapArr = new JSONArray();

        for (Map.Entry<Integer, JSONObject> e : dyn.entrySet()) {
            JSONObject data = e.getValue();
            if (data == null) continue;

            JSONObject defObj = data.optJSONObject("def");
            JSONObject mapObj = data.optJSONObject("map");

            if (defObj != null) npcdefArr.add(defObj);
            if (mapObj != null) npcmapArr.add(mapObj);
        }

        if (npcdefArr.isEmpty() && npcmapArr.isEmpty()) {
            return null;
        }

        JSONObject out = new JSONObject();
        out.put("npcdef", npcdefArr);
        out.put("npcmap", npcmapArr);
        return out;
    }

    public void adminRemoveNpc(Room room, int npcMapId) {
        Map<Integer, JSONObject> dyn = getDynamicNpcMap(room);
        if (!dyn.containsKey(npcMapId)) {
            //Kaiden_Engine.LOGGER.info("[DYN_NPC] adminRemoveNpc: NpcMapID " + npcMapId + " not found.");
        } else {
            dyn.remove(npcMapId);
        }

        JSONObject pkt = new JSONObject();
        pkt.put("cmd", "npcRemove");
        pkt.put("npcMapId", npcMapId);
        Kaiden_Extension.getInstance().send(pkt, room.getChannellList());
    }

    public void adminClearNpcs(Room room) {
        Map<Integer, JSONObject> dyn = getDynamicNpcMap(room);
        dyn.clear();

        JSONObject pkt = new JSONObject();
        pkt.put("cmd", "npcClear");
        Kaiden_Extension.getInstance().send(pkt, room.getChannellList());

        //Kaiden_Engine.LOGGER.info("[DYN_NPC] Cleared all dynamic NPCs in room " + room.getName());
    }

    public void adminListNpcs(Room room, User admin) {
        Map<Integer, JSONObject> dyn = getDynamicNpcMap(room);

        if (dyn.isEmpty()) {
            Kaiden_Extension.getInstance().send(
                    new String[]{"server", "[NPC] No dynamic NPCs in this room."},
                    admin
            );
            return;
        }

        Kaiden_Extension.getInstance().send(
                new String[]{"server", "[NPC] Dynamic NPCs in " + room.getName() + ":"},
                admin
        );

        for (Map.Entry<Integer, JSONObject> e : dyn.entrySet()) {
            Integer npcMapId = e.getKey();
            JSONObject data = e.getValue();
            if (data == null) {
                continue;
            }

            JSONObject defObj = data.optJSONObject("def");
            JSONObject mapObj = data.optJSONObject("map");

            int npcId = -1;
            String name = "Unknown";
            int type = -1;

            if (defObj != null) {
                if (defObj.containsKey("NpcID")) {
                    try {
                        npcId = Integer.parseInt(defObj.getString("NpcID"));
                    } catch (Exception ignored) { }
                }

                if (defObj.containsKey("strName")) {
                    name = defObj.getString("strName");
                }

                if (defObj.containsKey("iNpcType")) {
                    try {
                        type = defObj.getInt("iNpcType");
                    } catch (Exception ignored) { }
                }
            }

            if (npcId == -1 && mapObj != null && mapObj.containsKey("NpcID")) {
                try {
                    npcId = Integer.parseInt(mapObj.getString("NpcID"));
                } catch (Exception ignored) { }
            }

            String frame = "Enter";
            double x = 0.0;
            double y = 0.0;
            int scale = 100;

            if (mapObj != null) {
                if (mapObj.containsKey("strFrame")) {
                    frame = mapObj.getString("strFrame");
                }
                if (mapObj.containsKey("dPosX")) {
                    try {
                        x = mapObj.getDouble("dPosX");
                    } catch (Exception ignored) { }
                }
                if (mapObj.containsKey("dPosY")) {
                    try {
                        y = mapObj.getDouble("dPosY");
                    } catch (Exception ignored) { }
                }
                if (mapObj.containsKey("intScale")) {
                    try {
                        scale = mapObj.getInt("intScale");
                    } catch (Exception ignored) { }
                }
            }

            String typeLabel;
            switch (type) {
                case NpcBean.TYPE_FILE:
                    typeLabel = "FILE";
                    break;
                case NpcBean.TYPE_HUMAN:
                    typeLabel = "HUMAN";
                    break;
                default:
                    typeLabel = String.valueOf(type);
                    break;
            }

            String msg = String.format(
                    "[NPC] NpcMapID=%d | NpcID=%d | name=%s | type=%s | frame=%s | x=%.1f | y=%.1f | scale=%d",
                    npcMapId,
                    npcId,
                    name,
                    typeLabel,
                    frame,
                    x,
                    y,
                    scale
            );

            Kaiden_Extension.getInstance().send(
                    new String[]{"server", msg},
                    admin
            );
        }
    }
}
