package Kaiden.Game.Threads;

import Kaiden.Game.Server.Users.Utils.QuestProgressManager;
import it.gotoandplay.smartfoxserver.data.User;

public class QuestTimedExpire implements Runnable {

    private final User user;
    private final int questId;

    public QuestTimedExpire(User user, int questId) {
        this.user = user;
        this.questId = questId;
    }

    @Override
    public void run() {
        QuestProgressManager.expireTimedQuestIfExpired(this.user, this.questId);
    }
}
