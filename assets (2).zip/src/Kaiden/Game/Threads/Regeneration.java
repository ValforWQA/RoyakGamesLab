package Kaiden.Game.Threads;

import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.concurrent.ScheduledFuture;

public class Regeneration implements Runnable, CancellableTask {

    private final User user;
    private ScheduledFuture running;

    public Regeneration(User user) {
        this.user = user;
    }

    public void run() {
        if (this.running != null && this.user != null) {
            State state = (State) this.user.properties.get("state");

            Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine.tickUserTraitEffects(this.user);
            boolean needsHp = state.getHealth() < state.getMaxHealth();
            boolean needsMp = state.getMana() < state.getMaxMana();

            boolean needsTraitTicks = Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine.hasUserEffect(this.user, "stygian")
                    || Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine.getUserStacks(this.user, "elysian") > 0;

            if (state.isNeutral() && (needsHp || needsMp || needsTraitTicks)) {
                state.increaseHealthByPercent(0.045D);
                state.increaseManaByPercent(0.045D);
                JSONObject ct = new JSONObject();
                JSONObject p = new JSONObject();
                p.put(this.user.getName(), state.getData());
                ct.put("cmd", "ct");
                ct.put("p", p);
                state.setState(1);
                Kaiden_Extension.getInstance().send(ct, Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom()).getChannellList());
            } else {
                this.running.cancel(false);
            }
        } else {
            throw new RuntimeException("regen handle is null, unable to continue.");
        }
    }

    public boolean isRegenerating() {
        return this.running != null && !this.running.isDone();
    }

    public void setRunning(ScheduledFuture running) {
        if (this.running != null && !this.running.isDone()) {
            running.cancel(true);
        } else {
            this.running = running;
        }
    }

    public void cancel() {
        if (this.running != null) {
            this.running.cancel(false);
        }
    }
}
