package Kaiden.Game.Threads;

import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Room;
import java.util.List;

/** Server-side idle detection. No client modifications required. */
public final class PlayerAfkMonitor implements Runnable {
    private static final long IDLE_MILLIS = 5L * 60L * 1000L;

    public static void setAfk(User user, boolean afk) {
        if (user == null || user.properties == null) return;
        if (Boolean.valueOf(afk).equals(user.properties.get("afk"))) return;
        user.properties.put("afk", afk);
        Kaiden_Extension ext = Kaiden_Extension.getInstance();
        ext.send(new String[]{"server", afk ? "You are now Away From Keyboard (AFK)." : "You are no longer Away From Keyboard (AFK)."}, user);
        try {
            Room room = ext.getZone().getRoom(user.getRoom());
            if (room != null) ext.send(new String[]{"uotls", user.getName(), "afk:" + afk}, room.getChannellList());
        } catch (Exception ignored) { }
    }

    @Override public void run() {
        Kaiden_Extension ext = Kaiden_Extension.getInstance();
        if (ext == null || ext.getZone() == null) return;
        List users = ext.getZone().getUserList();
        if (users == null) return;
        long now = System.currentTimeMillis();
        for (Object entry : users) {
            if (!(entry instanceof User)) continue;
            User user = (User) entry;
            if (user.properties == null || user.isBeingKicked) continue;
            Object last = user.properties.get("lastPlayerActivity");
            if (last instanceof Number && now - ((Number) last).longValue() >= IDLE_MILLIS) {
                setAfk(user, true);
            }
        }
    }
}
