package Kaiden.Game.Threads;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.MonsterAurasBean;
import Kaiden.Database.Beans.MonsterSkillsBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Combat.Player.CombatEvaluator;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.Combat.MonsterCombatMana;
import Kaiden.Game.Server.Rooms.Monsters.Combat.MonsterCombatNotifier;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Server.Combat.Player.TargetAuraContainer;
import Kaiden.Game.Server.Combat.Player.EnhancementTraitEngine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.Set;
import java.util.List;
import java.util.HashSet;
import java.util.concurrent.ThreadLocalRandom;

public class MonsterAttack implements Runnable {

    private final MonsterAI monster;
    private final User user;
    private final MonsterSkillsBean skill;
    private final Set<Integer> seenAuraIds = new HashSet<>();

    public MonsterAttack(MonsterAI monsterAI, User user, MonsterSkillsBean skill) {
        this.monster = monsterAI;
        this.user = user;
        this.skill = skill;
    }

    private String normalizedType() {
        String type = this.skill == null ? null : this.skill.getType();
        return type == null ? "" : type.trim().toLowerCase();
    }

    /** Heal is a self skill: it should send its animation/description but never roll
     * or apply normal attack damage to the player. */
    private boolean isSelfOnlySkill() {
        return "heal".equals(normalizedType()) || "I".equalsIgnoreCase(this.skill.getEffects());
    }

    @Override
    public void run() {
        try {
            if (this.monster == null || this.monster.getState() == null || this.monster.getState().isDead() || this.monster.getState().isDisabled()) return;
            if (this.user == null) return;

            EnhancementTraitEngine.tickUserTraitEffects(this.user);
            Stats stats = (Stats) user.properties.get("stats");
            @SuppressWarnings("unchecked")
            Set<RemoveAura> userAuras = (((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set<RemoveAura>) user.properties.get("auras"));
            State userState = (State) user.properties.get("state");

            if (userState == null || userState.isDead()) {
                try {
                    this.monster.getState().removeTarget(this.user.getUserId());
                } catch (Exception ignored) {}
                return;
            }

            /*
             * Monster skill mana is consumed once in MonsterAI when the skill is accepted
             * for casting. Do not spend it again here.
             */
            MonsterCombatNotifier.sendSkillDescription(this.monster, this.user, this.skill);

            JSONArray aurasJson = new JSONArray();

            // Apply monster skill auras from auras + auras_effects only.
            try {
                applyMonsterSkillAuras(aurasJson, (int) skill.getDamage());
            } catch (RequestExternalPacketException ignored) {
            }

            DamageType type = DamageType.HIT;
            int damage = 0;

            if (!isSelfOnlySkill()) {
                type = CombatEvaluator.resolveMonsterVsPlayer(this.monster, stats, this.user);

                boolean trueDamage = isTrueDamageSkill();
                damage = "P".equalsIgnoreCase(this.skill.getEffects())
                        ? (int) Math.round(userState.getMaxHealth() * Math.max(0.0D, this.skill.getDamage()))
                        : rollBaseDamage();

                switch (type) {
                    case CRITICAL:
                        if (!trueDamage) {
                            damage = (int) Math.round(damage * Math.max(1.05D, 1.5D + this.monster.getState().getMonsterCritMultiplier()));
                        }
                        break;
                    case DODGE:
                    case MISS:
                    case PARRY:
                        if (!trueDamage) {
                            damage = 0;
                        } else {
                            type = DamageType.HIT;
                        }
                        break;
                    default:
                        break;
                }

                if (!trueDamage) {
                    damage = Damage.getReducedDamage(damage, userAuras);
                    damage = applyMonsterOutgoingModifiers(damage);
                    if (this.monster.getState().consumeTraitEffect("spinningdragon")) {
                        damage = 0;
                        type = DamageType.HIT;
                    }
                    damage = applyIncomingPlayerModifiers(stats, userState, damage);
                }

                this.monster.getState().applyMonsterOnDamageDealt(damage);
                userState.decreaseHealth(damage);
            }

            boolean killed = userState.isDead() || userState.getHealth() <= 0;

            JSONObject p = new JSONObject().accumulate(user.getName(), userState.getData());
            JSONArray sara = new JSONArray().element(new JSONObject()
                    .accumulate("actionResult", getAction(type, damage))
                    .accumulate("iRes", 1)
            );

            JSONObject m = new JSONObject().accumulate(
                    String.valueOf(this.monster.getMapMonster().getMonMapId()),
                    new JSONObject().accumulate("intMP", this.monster.getState().getMana())
                            .accumulate("intMPMax", this.monster.getState().getMaxMana())
            );

            JSONObject ct = new JSONObject()
                    .accumulate("anims", new JSONArray().element(getAnim(this.skill.getAnimation())))
                    .accumulate("p", p)
                    .accumulate("m", m)
                    .accumulate("a", aurasJson)
                    .accumulate("cmd", "ct");

            Kaiden_Extension.getInstance().send(ct, this.monster.getUserChannelButOne(this.monster.getRoom(), user.getUserId()));
            // Self-only skills still send their animation, monster MP and aura packet,
            // but do not send a fake player hit/actionResult.
            if (!isSelfOnlySkill()) {
                ct.accumulate("sara", sara);
            }
            Kaiden_Extension.getInstance().send(ct, user);

            // If this skill killed the player, route through MonsterAI's unified death pipeline
            if (killed) {
                this.monster.onPlayerKilledByMonster(user);
            }
        } catch (Throwable ignored) {
            // swallow battle-thread exceptions so one bad aura/packet does not disconnect the session
        }
    }

    private JSONObject getAction(DamageType type, int damage) {
        JSONObject action = new JSONObject();
        action.put("hp", damage);
        action.put("cInf", "m:" + this.monster.getMapMonster().getMonMapId());
        action.put("tInf", "p:" + user.getUserId());
        action.put("type", type.toString());
        return action;
    }

    private JSONObject getAnim(String animString) {
        JSONObject anim = new JSONObject();
        anim.put("strFrame", user.properties.get("frame"));
        anim.put("cInf", "m:" + this.monster.getMapMonster().getMonMapId());
        anim.put("fx", skill.getEffects());
        anim.put("tInf", "p:" + user.getUserId());
        anim.put("animStr", animString);
        if (!animString.isEmpty()) anim.put("strl", skill.getStrl());
        return anim;
    }

    private void applyMonsterSkillAuras(JSONArray aurasJson, int damage) throws RequestExternalPacketException {
        // 1) New system: monsters_auras table
        List<MonsterAurasBean> links = StorageCache.getInstance().getMonsterAurasForSkill(this.skill.getId());
        if (links != null && !links.isEmpty()) {
            for (MonsterAurasBean link : links) {
                if (link == null) continue;
                int auraId = link.getAuraId();
                if (auraId <= 0 || !seenAuraIds.add(auraId)) continue;

                AuraBean auraObj = StorageCache.getInstance().getAura(auraId);
                if (auraObj == null) continue;

                // Respect chance
                double chance = link.getChance();
                if (chance > 1.0D) chance /= 100.0D;
                if (chance > 0.0D && chance < 1.0D && ThreadLocalRandom.current().nextDouble() > chance) continue;

                String from = "m:" + this.monster.getMapMonster().getMonMapId();
                JSONObject aj = null;
                String resolvedTarget = resolveMonsterAuraTarget(link.getTarget(), auraObj);
                if (isMonsterSideAuraTarget(resolvedTarget)) {
                    if (!canApplyAuraToMonster(this.monster, auraObj)) continue;
                    aj = this.applyAura(this.monster, auraId, from, damage);
                } else {
                    // player / players / target / other all resolve to the current player target
                    // for monster skill casts.
                    if (!canApplyAuraToUser(this.user, auraObj)) continue;
                    aj = this.applyAuraToUser(this.user, auraId, from, damage);
                }
                if (aj != null) aurasJson.add(aj);
            }
            return;
        }

        // 2) Legacy support: monsters_skills.AuraID
        // Respect the aura target from the regular auras table. This lets monster skills
        // use the same auras + auras_effects system as player skills instead of
        // monsters_skills_effects / MonsterSkillEffectsBean.
        if (skill.hasAuraId()) {
            int auraId = skill.getAuraId();
            if (auraId > 0 && seenAuraIds.add(auraId)) {
                AuraBean legacyAura = StorageCache.getInstance().getAura(auraId);
                if (legacyAura != null) {
                    String from = "m:" + this.monster.getMapMonster().getMonMapId();
                    JSONObject aj = null;

                    if (legacyAura.isSelfTarget() || legacyAura.isMonsterTarget()) {
                        if (canApplyAuraToMonster(this.monster, legacyAura)) {
                            aj = this.applyAura(this.monster, auraId, from, damage);
                        }
                    } else {
                        // target/player/players/other all resolve to the current player target
                        // for monster skill casts.
                        if (canApplyAuraToUser(this.user, legacyAura)) {
                            aj = this.applyAuraToUser(this.user, auraId, from, damage);
                        }
                    }

                    if (aj != null) aurasJson.add(aj);
                }
            }
        }
    }


    private String resolveMonsterAuraTarget(String linkTarget, AuraBean auraObj) {
        String t = linkTarget == null ? "" : linkTarget.trim().toLowerCase();
        if (t.length() == 0 || "target".equals(t)) {
            try {
                t = auraObj == null ? "target" : auraObj.normalizedTarget();
            } catch (Throwable ignored) {
                t = "target";
            }
        }
        if (t.length() == 0) return "target";
        return t;
    }

    private boolean isMonsterSideAuraTarget(String target) {
        if (target == null) return false;
        String t = target.trim().toLowerCase();
        return "self".equals(t) || "monster".equals(t) || "monsters".equals(t);
    }

    private boolean canApplyAuraToUser(User user, AuraBean aura) {
        if (aura == null || user == null) return false;
        if (EnhancementTraitEngine.blocksAuraOnUser(user, aura)) return false;

        State state = (State) user.properties.get("state");
        if (state != null) {
            String sourceKey = "m:" + this.monster.getMapMonster().getMonMapId();
            return state.getAuraStackCount(aura.getId()) < Math.max(1, aura.getStack())
                    && state.getAuraStackCountBySource(aura.getId(), sourceKey) < Math.max(1, aura.getStack());
        }

        @SuppressWarnings("unchecked")
        Set<RemoveAura> userAuras = (((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")) != null ? ((Kaiden.Game.Server.Users.Utils.State) user.properties.get("state")).getAuras() : (Set<RemoveAura>) user.properties.get("auras"));
        int currentStack = 0;
        long now = System.currentTimeMillis();
        if (userAuras != null) {
            for (RemoveAura ra : userAuras) {
                if (ra == null || ra.getAura() == null) continue;
                long end = ra.getEndTime();
                if (end > 0L && end <= now) continue;
                if (ra.getAura().getId() == aura.getId()) {
                    currentStack++;
                }
            }
        }
        return currentStack < Math.max(1, aura.getStack());
    }

    private boolean canApplyAuraToMonster(MonsterAI ai, AuraBean aura) {
        if (aura == null || ai == null || ai.getState() == null) return false;
        String sourceKey = "m:" + this.monster.getMapMonster().getMonMapId();
        return ai.getState().getAuraStackCount(aura.getId()) < Math.max(1, aura.getStack())
                && ai.getState().getAuraStackCountBySource(aura.getId(), sourceKey) < Math.max(1, aura.getStack());
    }

    private JSONObject applyAuraToUser(User userTgt, int auraId, String fromTarget, int damage) throws RequestExternalPacketException {
        try {
            return TargetAuraContainer.getInstance().applyAuraToUser(userTgt, auraId, fromTarget, damage);
        } catch (Exception e) {
            throw new RequestExternalPacketException(e.getMessage());
        }
    }

    private JSONObject applyAura(MonsterAI ai, int auraId, String fromTarget, int damage) throws RequestExternalPacketException {
        try {
            return TargetAuraContainer.getInstance().applyAuraToMonster(ai, auraId, fromTarget, damage);
        } catch (Exception e) {
            throw new RequestExternalPacketException(e.getMessage());
        }
    }


    private int applyMonsterOutgoingModifiers(int amount) {
        if (amount <= 0) return amount;
        double outMod = this.monster.getState().getMonsterOutDmg();
        double outMultiplier = Math.max(0.05D, 1.0D + outMod);
        int consumedStacks = this.monster.getState().getAuraStackCount(Kaiden.Game.Server.Combat.Player.EnhancementProcAuras.CONSUMED);
        if (consumedStacks > 0) {
            double penalty = Math.min(0.30D, 0.10D + (0.01D * consumedStacks));
            outMultiplier *= Math.max(0.05D, 1.0D - penalty);
        }
        return (int) Math.max(0, Math.round(amount * outMultiplier));
    }

    private int applyIncomingPlayerModifiers(Stats targetStats, State targetState, int amount) {
        if (targetStats == null || targetState == null || amount <= 0) return amount;
        double incoming = Math.max(0.05D, targetStats.get$incdmg());
        double resistTotal = Math.max(0.0D, Math.min(0.80D, targetStats.get$allres() + targetStats.get$physres()));
        int adjusted = (int) Math.max(0, Math.round(amount * incoming * (1.0D - resistTotal)));
        return targetState.absorbShield(adjusted);
    }

    private int rollBaseDamage() {
        // Keep offensive monster skills on the same DPS/attack-speed model as
        // normal attacks.  monsters_skills.Damage acts as the skill multiplier
        // (1.0 = 100%, 1.5 = 150%, 2.0 = 200%, etc.).
        return CombatEvaluator.rollMonsterSkillDamage(this.monster, this.skill);
    }

    private boolean isTrueDamageSkill() {
        return "P".equalsIgnoreCase(this.skill.getEffects())
                || containsTrueDamageToken(this.skill.getType())
                || containsTrueDamageToken(this.skill.getEffects())
                || containsTrueDamageToken(this.skill.getName())
                || containsTrueDamageToken(this.skill.getDescription())
                || containsTrueDamageToken(this.skill. getEndDescription());
    }

    private boolean containsTrueDamageToken(String value) {
        if (value == null) return false;
        String s = value.trim().toLowerCase();
        if (s.isEmpty()) return false;
        return s.contains("truedamage")
                || s.contains("true damage")
                || s.contains("true_dmg")
                || s.contains("true-damage")
                || s.equals("true")
                || s.equals("tdmg");
    }
}