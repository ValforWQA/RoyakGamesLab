package Kaiden.Game.Threads;

import Kaiden.Database.Storage;
import Kaiden.Game.Server.Server;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Rewards implements Runnable {

    private static final int REWARD_AMOUNT = 250;
    private final Random random = new Random();

    private User getRandomUser() {
        List users = Kaiden_Extension.getInstance().getZone().getUserList();

        if (users == null || users.isEmpty()) {
            return null;
        }

        List<User> validUsers = new ArrayList<User>();

        for (Object object : users) {
            if (!(object instanceof User)) {
                continue;
            }

            User user = (User) object;

            if (user == null || user.properties == null) {
                continue;
            }

            // prevents staff from claiming
            if (user.isAdmin() || user.isModerator()) {
                 continue;
             }

            validUsers.add(user);
        }

        return validUsers.isEmpty()
                ? null
                : validUsers.get(this.random.nextInt(validUsers.size()));
    }

    @Override
    public void run() {
        try {
            if (Kaiden_Extension.getInstance().getZone().getUserCount() <= 0) {
                return;
            }

            User rewardUser = this.getRandomUser();

            if (rewardUser == null) {
                return;
            }

            Object userId = rewardUser.properties.get(Properties.ID);
            Object username = rewardUser.properties.get(Properties.USERNAME);

            if (userId == null || username == null) {
                return;
            }

            Storage.getInstance().getJdbc().run(
                    "UPDATE users SET Coins = Coins + ? WHERE id = ?",
                    REWARD_AMOUNT,
                    userId
            );

            String rewardMessage = "Congratulations! " + username + ", you have been rewarded " + REWARD_AMOUNT + " rubies!";
            String globalMessage = "Player " + username + " has been rewarded " + REWARD_AMOUNT + " rubies!";

            Server.getInstance().sendServerMessage(
                    "Congratulations! " + rewardUser.getName() + " has been rewarded " + REWARD_AMOUNT + " rubies!"
            );

            Kaiden_Extension.getInstance().send(
                    new String[]{"moderator", rewardMessage},
                    rewardUser
            );

            Kaiden_Extension.getInstance().sendToUsers(
                    new String[]{"moderator", globalMessage}
            );

            JSONObject packet = new JSONObject();
            packet.put("cmd", "sellItem");
            packet.put("intAmount", REWARD_AMOUNT);
            packet.put("bCoins", "1");
            packet.put("CharItemID", rewardUser.hashCode());

            Kaiden_Extension.getInstance().send(packet, rewardUser);
        } catch (Exception e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "red",
                    "[Rewards] failed: " + e.getMessage()
            );
        }
    }
}