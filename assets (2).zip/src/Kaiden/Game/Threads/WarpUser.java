package Kaiden.Game.Threads;

import Kaiden.Game.Server.Rooms.Rooms;
import it.gotoandplay.smartfoxserver.data.User;

public class WarpUser implements Runnable {
    private final User[] users;

    private final String roomName;
    private final String roomFrame;
    private final String roomPad;

    public WarpUser(User[] users, String roomName, String roomFrame, String roomPad) {
        this.users = users;
        this.roomName = roomName;
        this.roomFrame = roomFrame;
        this.roomPad = roomPad;
    }

    public void run() {
        for (User user : this.users) {
            Rooms.getInstance().basicRoomJoin(user, this.roomName, this.roomFrame, this.roomPad);
        }
    }
}
