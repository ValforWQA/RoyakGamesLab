package Kaiden.Game.Threads;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import org.apache.log4j.Logger;

public class KickUser implements Runnable {
    private static final Logger LOGGER = Logger.getLogger(KickUser.class);

    private final User user;

    public KickUser(User user) {
        this.user = user;
    }

    @Override
    public void run() {
        try {
            String[] exit = new String[]{"exitArea", String.valueOf(user.getUserId()), user.getName()};
            Room room = Kaiden_Extension.getInstance().getZone().getRoom(user.getRoom());
            Kaiden_Extension.getInstance().sendToRoomButOne(exit, user, room);
            Kaiden_Extension.getInstance().send(new String[]{"logoutWarning", "", "60"}, this.user);
            Thread.sleep(200L);
            this.user.getChannel().close();
            ExtensionHelper.instance().disconnectUser(this.user);
            LOGGER.info("[ " + this.user.getName() + " ] has been kicked.");
        } catch (Exception e) {
            Log.error("Kick User", e);
        }

    }
}
