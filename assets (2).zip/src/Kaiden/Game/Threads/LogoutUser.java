package Kaiden.Game.Threads;

import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import org.apache.log4j.Logger;

public class LogoutUser implements Runnable {

    private static final Logger LOGGER = Logger.getLogger(LogoutUser.class);

    private final User user;

    public LogoutUser(User user) {
        this.user = user;
    }

    @Override
    public void run() {
        try {
            if (user == null) {
                return;
            }


            try {
                Users.getInstance().lost(user);
            } catch (Exception e) {

                Log.error("LogoutUser.save", e);
            }

            try {
                Kaiden_Extension ext = Kaiden_Extension.getInstance();
                if (ext != null) {
                    ext.send(new String[]{"server", "Session saved. Logging out..."}, user);
                }
            } catch (Exception ignored) {

            }


            try {
                Kaiden_Extension ext = Kaiden_Extension.getInstance();
                if (ext != null && ext.getZone() != null) {
                    Room room = ext.getZone().getRoom(user.getRoom());
                    if (room != null) {
                        Rooms.getInstance().exit(room, user);

                        if (room.getUserCount() <= 0) {
                            Rooms.getInstance().deleteRoom(room);
                        }
                    }
                }
            } catch (Exception e) {
                Log.error("LogoutUser.roomExit", e);
            }


            try {
                ExtensionHelper.instance().logoutUser(user, true, false);
            } catch (Exception e) {
                Log.error("LogoutUser.sfsLogout", e);
            }

            LOGGER.info("[LogoutUser] " + user.getName() + " logged out cleanly.");

        } catch (Exception e) {
            Log.error("LogoutUser", e);
        }
    }
}
