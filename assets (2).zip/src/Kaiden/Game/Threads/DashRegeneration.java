package Kaiden.Game.Threads;

import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class DashRegeneration implements Runnable, CancellableTask {

    private static final double DASH_REGEN_PERCENT = 0.03D;
    private static final long DASH_REGEN_DELAY_SECONDS = 1L;

    private final User user;
    private ScheduledFuture running;

    public DashRegeneration(User user) {
        this.user = user;
    }

    @Override
    public void run() {
        if (this.user == null) {
            this.cancel();
            return;
        }

        State state = (State) this.user.properties.get("state");
        if (state == null) {
            this.cancel();
            return;
        }

        if (state.getDash() >= state.getMaxDash()) {
            return;
        }

        int before = state.getDash();
        state.increaseDashByPercent(DASH_REGEN_PERCENT);

        if (state.getDash() != before) {
            sendDashUpdate(state);
        }
    }

    public synchronized void restart() {
        ensureRunning();
    }

    public synchronized void ensureRunning() {
        if (!isRegenerating()) {
            this.running = Executor.getInstance().scheduleTask(
                    this,
                    DASH_REGEN_DELAY_SECONDS,
                    DASH_REGEN_DELAY_SECONDS,
                    TimeUnit.SECONDS,
                    true
            );
        }
    }

    public boolean isRegenerating() {
        return this.running != null && !this.running.isDone() && !this.running.isCancelled();
    }

    public synchronized void setRunning(ScheduledFuture running) {
        cancel();
        this.running = running;
    }

    @Override
    public synchronized void cancel() {
        if (this.running != null) {
            this.running.cancel(false);
            this.running = null;
        }
    }

    private void sendDashUpdate(State state) {
        try {
            JSONObject packet = new JSONObject();
            JSONObject o = new JSONObject();

            // client uses intSP, not intSp
            o.put("intSP", state.getDash());

            packet.put("cmd", "uotls");
            packet.put("o", o);
            packet.put("unm", this.user.getName());

            Kaiden_Extension.getInstance().send(packet, this.user);
        } catch (Exception ignored) {
        }
    }
}