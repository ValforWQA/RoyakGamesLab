package Kaiden.Game.Threads;

import Kaiden.Database.Beans.MonsterSkillBean;

public class MonsterAttackCooldown implements Runnable {
    private final MonsterSkillBean skill;

    public MonsterAttackCooldown(MonsterSkillBean skill) {
        super();
        this.skill = skill;
    }

    public void run() {
        this.skill.cooldown = false;
    }
}
