package Kaiden.Game.Threads;

import Kaiden.Database.Storage;
import org.apache.log4j.Logger;

public class FreeDbPool implements Runnable {
    private static final Logger LOGGER = Logger.getLogger(FreeDbPool.class);
    private static final int ACTIVE_CONNECTION_THRESHOLD = 0;

    public void run() {
        try {
            int active = Storage.getInstance().getActiveConnectionCount();
            if (active > ACTIVE_CONNECTION_THRESHOLD) {
                LOGGER.debug("[FreeDbPool] Skipped idle cleanup because active connections=" + active);
                return;
            }
            LOGGER.debug("[FreeDbPool] Freeing idle DB connections. activeConnections=" + active);
            Storage.getInstance().freeIdleConnections();
        } catch (Exception e) {
            LOGGER.warn("[FreeDbPool] Idle cleanup skipped due to error: " + e.getMessage());
        }
    }
}
