package Kaiden.Game.Threads;

import it.gotoandplay.smartfoxserver.SmartFoxServer;

public class SystemTimer implements Runnable {

    public void run() {
      this.getUptime();
    }



public String getUptime() {
    String result = "";
        long now = System.currentTimeMillis();
        long start = SmartFoxServer.getInstance().getServerStartTime();
        long elapsed = now - start;
        int days = (int) Math.floor(elapsed / 86400000L);
        long temp = 86400000L * days;
        elapsed -= temp;
        int hours = (int) Math.floor(elapsed / 3600000L);
        temp = 3600000L * hours;
        elapsed -= temp;
        int minutes = (int) Math.floor(elapsed / 60000L);
        String s_days = String.valueOf(days);
        for (int i = 0; i < 4 - s_days.length(); i++) {
            System.out.print("0");
        }
        System.out.print(s_days);
        System.out.print(":");
        if (hours < 10) {
            System.out.print("0");
        }
        System.out.print(hours);
        System.out.print(":");
        if (minutes < 10) {
            System.out.print("0");
        }
        System.out.print(minutes);
        
        return result;
    }
}