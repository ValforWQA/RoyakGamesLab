package Kaiden.Game.Threads;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadLocalRandom;
import org.apache.log4j.Logger;

public class HealOverTime implements Runnable, CancellableTask {

    private static final Logger LOGGER = Logger.getLogger(HealOverTime.class);

    private ScheduledFuture<?> running;

    private final User user;
    private final String fromTarget;
    private final int auraId;
    private final int amountPerTick;

    public HealOverTime(User user, int auraId, int amountPerTick, String fromTarget) {
        this.user = user;
        this.auraId = auraId;
        this.fromTarget = fromTarget;
        this.amountPerTick = Math.max(1, Math.abs(amountPerTick));
    }


    private boolean hasActiveLinkedAura() {
        try {
            String wanted = this.fromTarget == null ? "" : this.fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            java.util.Set<RemoveAura> auras = (java.util.Set<RemoveAura>) this.user.properties.get("auras");
            if (auras == null) return false;
            for (RemoveAura ra : auras) {
                if (ra == null || ra.getAura() == null) continue;
                if (ra.getAura().getId() != this.auraId) continue;
                long end = ra.getEndTime();
                if (end > 0L && end <= now) continue;
                String src = ra.getSourceInf() == null ? "" : ra.getSourceInf().trim().toLowerCase();
                if (wanted.equals(src)) return true;
            }
        } catch (Exception e) { LOGGER.error("HealOverTime exception", e); }
        return false;
    }

    private User resolveCasterUser() {
        try {
            String src = this.fromTarget == null ? "" : this.fromTarget.trim().toLowerCase();
            if (!src.startsWith("p:")) return null;
            int uid = Integer.parseInt(src.substring(2));
            return Kaiden_Extension.getInstance().getHelper().getUserById(uid);
        } catch (Exception ignored) {
            return null;
        }
    }

    private int resolveTickHeal(State state, Stats targetStats) {
        double tick = Math.max(2.0D, this.amountPerTick);
        try {
            AuraBean aura = StorageCache.getInstance().getAura(this.auraId);
            User caster = resolveCasterUser();
            Stats casterStats = caster != null ? (Stats) caster.properties.get("stats") : null;

            double hotValue = 0.0D;
            if (aura != null && aura.effects != null) {
                for (int effectId : aura.effects) {
                    try {
                        Kaiden.Database.Beans.AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                        if (ae == null || ae.getStat() == null) continue;
                        String stat = ae.getStat().trim().toLowerCase();
                        if ("hot".equals(stat) || "regen".equals(stat) || "healhot".equals(stat)) {
                            hotValue = Math.max(hotValue, ae.getValue());
                        }
                    } catch (Exception ignored) {
                    }
                }
            }

            double statBase = 0.0D;
            if (casterStats != null) {
                statBase = Math.max(statBase,
                        (casterStats.get$WIS() * 0.030D)
                      + (casterStats.get$INT() * 0.027D)
                      + (casterStats.get$LCK() * 0.012D)
                      + (casterStats.get$ap() * 0.010D)
                );
            } else if (targetStats != null) {
                statBase = Math.max(statBase,
                        (targetStats.get$WIS() * 0.020D)
                      + (targetStats.get$INT() * 0.018D)
                );
            }

            if (hotValue > 0.0D) {
                double pct = hotValue > 1.0D ? (hotValue / 100.0D) : hotValue;
                pct = Math.max(0.0025D, pct);
                tick = Math.max(tick, state.getMaxHealth() * pct);
            }

            tick = Math.max(tick, 2.0D + statBase);

            double healBoost = casterStats != null ? Math.min(1.60D, Math.max(0.10D, casterStats.get$cho())) : 1.0D;
            double healIntake = targetStats != null ? Math.min(1.60D, Math.max(0.10D, targetStats.get$chi())) : 1.0D;
            double critChance = casterStats != null ? Math.max(0.0D, casterStats.get_tcr()) : 0.0D;
            if (critChance > 1.0D) critChance = critChance / 100.0D;
            critChance = Math.min(0.50D, critChance);

            tick *= healBoost;
            tick *= healIntake;
            tick *= (1.0D + (critChance * 0.08D));
            tick *= (0.94D + (ThreadLocalRandom.current().nextDouble() * 0.14D));

            int perTickCap = (int) Math.max(2, Math.round(state.getMaxHealth() * 0.08D));
            tick = Math.min(tick, perTickCap);
        } catch (Exception ignored) {
        }
        return Math.max(2, (int) Math.ceil(tick));
    }

    @Override
    public void run() {
        if (user == null) {
            cancel();
            return;
        }

        try {
            if (!hasActiveLinkedAura()) {
                cancel();
                return;
            }
            State state = (State) user.properties.get("state");
            if (state == null || state.isDead()) {
                cancel();
                return;
            }

            Stats targetStats = (Stats) user.properties.get("stats");
            int tickAmount = resolveTickHeal(state, targetStats);

            state.increaseHealth(tickAmount);

            Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
            if (room != null) {
                JSONObject ct = new JSONObject();
                ct.put("cmd", "ct");
                JSONObject action = new JSONObject()
                        .accumulate("actionResult", Damage.getDamageResult(this.fromTarget, "p:" + this.user.getUserId(), -tickAmount, DamageType.DAMAGE_OVER_TIME))
                        .accumulate("iRes", 1);
                ct.put("sara", new JSONArray().element(action));
                JSONObject p = new JSONObject();
                p.put(this.user.getName(), state.getData());
                ct.put("p", p);
                Kaiden_Extension.getInstance().sendToRoom(ct, this.user, room);
            }
        } catch (Throwable t) {
            LOGGER.error("HealOverTime fatal aura/combat exception", t);
            cancel();
        }
    }

    @Override
    public void cancel() {
        try {
            if (running != null && !running.isCancelled()) {
                running.cancel(false);
            }
        } catch (Exception ignored) {
        }
    }

    public boolean isRegenerating() {
        return this.running != null && !this.running.isDone();
    }

    public void setRunning(ScheduledFuture running) {
        try {
            if (this.running != null && !this.running.isDone()) {
                this.running.cancel(false);
            }
        } catch (Exception ignored) {
        }
        this.running = running;
    }

    public String getFromTarget() {
        return this.fromTarget;
    }

    public int getAmountPerTick() {
        return this.amountPerTick;
    }
}
