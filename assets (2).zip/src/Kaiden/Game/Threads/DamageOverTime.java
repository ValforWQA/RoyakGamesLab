package Kaiden.Game.Threads;

import Kaiden.Database.Beans.ZoneBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Combat.Damage;
import Kaiden.Game.Server.Combat.DamageType;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadLocalRandom;
import org.apache.log4j.Logger;

public class DamageOverTime implements Runnable, CancellableTask {

    private static final Logger LOGGER = Logger.getLogger(DamageOverTime.class);

    private ScheduledFuture<?> running;

    private User user;
    private MonsterAI ai;
    private State userState;

    private final String fromTarget;
    private final int auraId;
    private final int baseDamage;
    private final boolean nonLethalSelfAura;

    public DamageOverTime(User user, int auraId, int damage, String fromTarget) {
        this(user, auraId, damage, fromTarget, false);
    }

    public DamageOverTime(User user, int auraId, int damage, String fromTarget, boolean nonLethalSelfAura) {
        this.user = user;
        this.auraId = auraId;
        this.baseDamage = Math.max(1, Math.abs(damage));
        this.fromTarget = fromTarget;
        this.nonLethalSelfAura = nonLethalSelfAura;
        this.userState = (State) user.properties.get("state");
    }

    public DamageOverTime(MonsterAI ai, int auraId, int damage, String fromTarget) {
        this.ai = ai;
        this.auraId = auraId;
        this.baseDamage = Math.max(1, Math.abs(damage));
        this.fromTarget = fromTarget;
        this.nonLethalSelfAura = false;
    }

    @Override
    public void run() {
        try {
            if (!hasActiveLinkedAura()) {
                cancel();
                return;
            }
            int dotDamage = resolveTickDamage();
            if (this.user != null) {
                processUser(dotDamage);
            }
            if (this.ai != null) {
                processMonster(dotDamage);
            }
        } catch (Throwable t) {
            LOGGER.error("DamageOverTime fatal aura/combat exception", t);
            cancel();
        }
    }


    private boolean hasActiveLinkedAura() {
        try {
            String wanted = this.fromTarget == null ? "" : this.fromTarget.trim().toLowerCase();
            long now = System.currentTimeMillis();
            if (this.user != null) {
                State state = (State) this.user.properties.get("state");
                java.util.Set<RemoveAura> auras = state != null ? state.getAuras() : (java.util.Set<RemoveAura>) this.user.properties.get("auras");
                if (auras == null) return false;
                for (RemoveAura ra : auras) {
                    if (ra == null || ra.getAura() == null) continue;
                    if (ra.getAura().getId() != this.auraId) continue;
                    long end = ra.getEndTime();
                    if (end > 0L && end <= now) continue;
                    String src = ra.getSourceInf() == null ? "" : ra.getSourceInf().trim().toLowerCase();
                    if (wanted.equals(src)) return true;
                }
                return false;
            }
            if (this.ai != null && this.ai.getState() != null) {
                java.util.Set<RemoveAura> auras = this.ai.getState().getAuras();
                if (auras == null) return false;
                for (RemoveAura ra : auras) {
                    if (ra == null || ra.getAura() == null) continue;
                    if (ra.getAura().getId() != this.auraId) continue;
                    long end = ra.getEndTime();
                    if (end > 0L && end <= now) continue;
                    String src = ra.getSourceInf() == null ? "" : ra.getSourceInf().trim().toLowerCase();
                    if (wanted.equals(src)) return true;
                }
                return false;
            }
        } catch (Exception e) { LOGGER.error("DamageOverTime exception", e); }
        return false;
    }

    private User resolveCasterUser() {
        try {
            String src = this.fromTarget == null ? "" : this.fromTarget.trim().toLowerCase();
            if (!src.startsWith("p:")) return null;
            int uid = Integer.parseInt(src.substring(2));
            return Kaiden_Extension.getInstance().getHelper().getUserById(uid);
        } catch (Exception ignored) {
            return null;
        }
    }

    private int resolveTickDamage() {
        double tick = Math.max(2.0D, this.baseDamage);
        int tickCap = Integer.MAX_VALUE;

        try {
            if (this.user != null) {
                State targetState = (State) this.user.properties.get("state");
                if (targetState != null) {
                    double capPct = this.nonLethalSelfAura ? 0.06D : 0.10D;
                    tickCap = (int) Math.max(2, Math.round(targetState.getMaxHealth() * capPct));
                }
            } else if (this.ai != null && this.ai.getState() != null) {
                tickCap = (int) Math.max(2, Math.round(this.ai.getState().getMaxHealth() * 0.08D));
            }
        } catch (Exception ignored) {
        }

        try {
            User caster = resolveCasterUser();
            if (caster != null) {
                Stats casterStats = (Stats) caster.properties.get("stats");
                if (casterStats != null) {
                    double apFloor = Math.max(0.0D, casterStats.get$ap());
                    double statFloor = Math.max(
                            Math.max(casterStats.get$INT(), casterStats.get$STR()),
                            Math.max(casterStats.get$WIS(), Math.max(casterStats.get$DEX(), casterStats.get$LCK()))
                    );

                    /*
                     * DoT ticks should scale, but not explode with high enhancements,
                     * crit value, outgoing damage buffs, or class ultimates. Keep the
                     * stat floor small and cap final tick by target max HP below.
                     */
                    tick = Math.max(tick, 2.0D + (apFloor * 0.018D) + (statFloor * 0.022D));

                    double critChance = Math.max(0.0D, casterStats.get_tcr());
                    if (critChance > 1.0D) critChance = critChance / 100.0D;
                    critChance = Math.min(0.50D, critChance);

                    tick *= (1.0D + (critChance * 0.15D));
                    tick *= Math.min(1.60D, Math.max(0.10D, casterStats.get$dotboost()));
                    tick *= Math.min(1.35D, Math.max(0.10D, casterStats.get$outdmg()));
                    tick *= Math.min(1.60D, Math.max(0.10D, casterStats.get$cdo()));
                }
            }

            if (this.user != null) {
                Stats targetStats = (Stats) this.user.properties.get("stats");
                if (targetStats != null) {
                    tick *= Math.min(1.50D, Math.max(0.05D, targetStats.get$dotres()));
                    tick *= Math.min(1.50D, Math.max(0.05D, targetStats.get$incdmg()));
                    tick *= Math.min(1.50D, Math.max(0.05D, targetStats.get$cdi()));
                }
            }

            double roll = 0.92D + (ThreadLocalRandom.current().nextDouble() * 0.16D);
            tick *= roll;
        } catch (Exception ignored) {
        }

        int resolved = Math.max(2, (int) Math.ceil(tick));
        if (tickCap != Integer.MAX_VALUE) {
            resolved = Math.min(resolved, tickCap);
        }
        return Math.max(2, resolved);
    }

    private void processMonster(int dotDamage) {
        try {
            if (this.ai == null || this.ai.getState() == null || this.ai.getRoom() == null || this.ai.getMapMonster() == null) {
                cancel();
                return;
            }

            MonsterState state = this.ai.getState();
            if (state.isDead()) {
                cancel();
                return;
            }

            JSONObject ct = new JSONObject();
            ct.put("cmd", "ct");

            JSONObject action = new JSONObject()
                    .accumulate("actionResult",
                            Damage.getDamageResult(this.fromTarget, "m:" + this.ai.getMapMonster().getMonMapId(), dotDamage, DamageType.DAMAGE_OVER_TIME))
                    .accumulate("iRes", 1);

            ct.put("sara", new JSONArray().element(action));

            JSONObject p = new JSONObject();

            state.decreaseHealth(dotDamage);

            if (state.isDead()) {
                cancel();

                handleMonsterDeath(state, ct, p);
            }

            ct.put("m", (new JSONObject()).accumulate(
                    String.valueOf(this.ai.getMapMonster().getMonMapId()),
                    state.getData().accumulate("targets", state.getTargets())
            ));

            if (!p.isEmpty()) {
                ct.put("p", p);
            }

            Kaiden_Extension.getInstance().send(ct, this.ai.getRoom().getChannellList());
        } catch (Throwable t) {
            LOGGER.error("DamageOverTime fatal aura/combat exception", t);
            cancel();
        }
    }

    private void handleMonsterDeath(MonsterState state, JSONObject ct, JSONObject playersObj) {
        try {
            if (this.ai == null || state == null || this.ai.getRoom() == null || this.ai.getMapMonster() == null) {
                return;
            }

            try {
                state.clearAuras();
            } catch (Exception ignored) {
            }

            ZoneBean area = StorageCache.getInstance().getArea(this.ai.getRoom().getName().split("-")[0]);
            if (area != null && area.isPvP()) {
                int monTargets = StorageCache.getInstance().getMonster(this.ai.getMapMonster().getMonsterId()).getTeamId() == 1 ? 0 : 1;
                Rooms.getInstance().relayPvPEvent(this.ai, monTargets);
                ct.put("pvp", Rooms.getInstance().getPvPResult(this.ai.getRoom()));
            }

            java.util.Set<Integer> targetIds = new java.util.HashSet<Integer>(state.getTargets());
            int monMapId = this.ai.getMapMonster().getMonMapId();

            for (Integer userId : targetIds) {
                User userTgt = Kaiden_Extension.getInstance().getHelper().getUserById(userId);
                if (userTgt == null) {
                    continue;
                }

                State targetState = (State) userTgt.properties.get("state");
                if (targetState != null) {
                    targetState.removeMonsterTarget(monMapId);
                }

                Users.getInstance().sendUotls(userTgt, false, false, false, false, false, false, true);

                if (playersObj != null && targetState != null) {
                    playersObj.put(userTgt.getName(), targetState.getData());
                }
            }

            try {
                state.clearTargets();
            } catch (Exception ignored) {
            }

            User caster = resolveCasterUser();
            if (caster != null) {
                State casterState = (State) caster.properties.get("state");
                if (casterState != null) {
                    casterState.refreshCombatState();
                    casterState.removeMonsterTarget(monMapId);
                }
                Users.getInstance().regen(caster);
            }
        } catch (Throwable ignored) {
        }
    }

    private void processUser(int dotDamage) {
        try {
            if (this.user == null) {
                cancel();
                return;
            }

            Room room = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
            if (room == null) {
                cancel();
                return;
            }

            State state = (State) this.user.properties.get("state");
            if (state == null || state.isDead()) {
                cancel();
                return;
            }

            if (this.nonLethalSelfAura) {
                int maxAllowed = Math.max(0, state.getHealth() - 1);
                if (maxAllowed <= 0) {
                    cancel();
                    return;
                }
                dotDamage = Math.min(dotDamage, maxAllowed);
            }

            JSONObject ct = new JSONObject();
            ct.put("cmd", "ct");

            JSONObject action = new JSONObject()
                    .accumulate("actionResult",
                            Damage.getDamageResult(this.fromTarget, "p:" + this.user.getUserId(), dotDamage, DamageType.DAMAGE_OVER_TIME))
                    .accumulate("iRes", 1);

            ct.put("sara", new JSONArray().element(action));

            JSONObject p = new JSONObject();

            state.decreaseHealth(dotDamage);

            if (state.isDead()) {
                cancel();

                ZoneBean area = StorageCache.getInstance().getArea(room.getName().split("-")[0]);
                if (area != null && area.isPvP()) {
                    int teamId = ((Integer) this.user.properties.get("pvpteam") == 0) ? 1 : 0;

                    if (room.getName().split("-")[0].equals("deadlock")) {
                        Rooms.getInstance().addPvPScore(room, 1000, teamId);
                    } else {
                        Rooms.getInstance().addPvPScore(room, (int) this.user.properties.get(Properties.LEVEL), teamId);
                    }

                    ct.put("pvp", Rooms.getInstance().getPvPResult(room));
                }
            }

            p.put(this.user.getName(), state.getData());
            ct.put("p", p);

            Kaiden_Extension.getInstance().sendToRoom(ct, this.user, room);
        } catch (Throwable t) {
            LOGGER.error("DamageOverTime fatal aura/combat exception", t);
            cancel();
        }
    }

    @Override
    public void cancel() {
        try {
            if (this.running != null && !this.running.isCancelled()) {
                this.running.cancel(false);
            }
        } catch (Exception ignored) {
        }
    }

    public void setRunning(ScheduledFuture running) {
        this.running = running;
    }
}
