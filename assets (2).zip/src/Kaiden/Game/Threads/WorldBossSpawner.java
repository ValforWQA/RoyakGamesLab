package Kaiden.Game.Threads;

import Kaiden.Database.Beans.MonsterBean;
import Kaiden.Database.Beans.WorldBossBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Rooms;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class WorldBossSpawner implements Runnable {

    public HashMap<Integer, Long> deathTimes = new HashMap<>();
    public HashMap<Integer, Long> spawnTimes = new HashMap<>();

    public WorldBossSpawner() {
        try {
            // mirror your original constructor logic
            for (Map.Entry<Integer, WorldBossBean> entry : StorageCache.getInstance().worldbosses.entrySet()) {
                String mapName = Storage.getInstance().getJdbc().queryForString(
                        "SELECT Name FROM maps WHERE id = ?",
                        Integer.valueOf(entry.getValue().mapId)
                );

                StorageCache.getInstance().worldBossMaps.put(Integer.valueOf(entry.getValue().mapId), mapName);

                deathTimes.put(entry.getValue().monsterId, System.currentTimeMillis());
                spawnTimes.put(entry.getValue().monsterId, System.currentTimeMillis());
            }

            Storage.getInstance().getJdbc().run("UPDATE monsters_bosses SET DeathTime = NOW()");
            //SmartFoxServer.log.info("WorldBossSpawner initialized (KaidenEngine).");
        } catch (Exception e) {
            SmartFoxServer.log.warning("WorldBossSpawner failed to init: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        try {
            for (Map.Entry<Integer, WorldBossBean> entry : StorageCache.getInstance().worldbosses.entrySet()) {

                SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM dd, yyyy (hh:mm:ss a)");

                // === Keep your original timing math (even if unused elsewhere) ===
                Calendar now = Calendar.getInstance();
                now.add(Calendar.MILLISECOND, -(int) (System.currentTimeMillis() - deathTimes.get(entry.getValue().monsterId)));
                now.add(Calendar.MILLISECOND, (int) (entry.getValue().spawnInterval));

                // 4-minute notify flag (same as your code; you can hook a packet here later if you want)
                long millisUntilSpawn = ((deathTimes.get(entry.getValue().monsterId) + entry.getValue().spawnInterval) - System.currentTimeMillis());
                if (TimeUnit.MILLISECONDS.toMinutes(millisUntilSpawn) == 4 && !entry.getValue().isNotified) {
                    entry.getValue().isNotified = true;
                }

                // === SPAWN ===
                if (System.currentTimeMillis() - deathTimes.get(entry.getValue().monsterId) > entry.getValue().spawnInterval
                        && !entry.getValue().isActive) {

                    entry.getValue().isNotified = false;
                    entry.getValue().isActive = true;
                    entry.getValue().roomNumber = 1;

                    String baseMap = StorageCache.getInstance().worldBossMaps.get(entry.getValue().mapId);
                    if (baseMap == null) {
                        // safety: map missing, mark dead-time and skip
                        entry.getValue().isActive = false;
                        deathTimes.put(entry.getValue().monsterId, System.currentTimeMillis());
                        continue;
                    }

                    String roomName = baseMap.toLowerCase() + "-" + entry.getValue().roomNumber;
                    Room bossRoom = Kaiden_Extension.getInstance().getZone().getRoomByName(roomName);

                    spawnTimes.put(entry.getValue().monsterId, System.currentTimeMillis());

                    if (bossRoom == null) {
                        // Rooms.createRoom is package-private; this WorldBossSpawner lives in same package to keep your logic intact
                        bossRoom = Rooms.getInstance().createRoom(roomName, null);
                    }

                    MonsterBean mon = StorageCache.getInstance().getMonster(entry.getValue().monsterId);
                    if (mon == null) {
                        entry.getValue().isActive = false;
                        deathTimes.put(entry.getValue().monsterId, System.currentTimeMillis());
                        continue;
                    }

                    // Your same invite payload (cmd + fields)
                    JSONObject umsg = new JSONObject();
                    umsg.put("cmd", "WorldBossInvite");
                    umsg.put("room", roomName);
                    umsg.put("monName", mon.getName());
                    umsg.put("monLevel", mon.getLevel());
                    umsg.put("monFile", mon.getFile());
                    umsg.put("monLink", mon.getLinkage());
                    umsg.put("spawnTime", spawnTimes.get(entry.getValue().monsterId));
                    umsg.put("timeLimit", entry.getValue().timeLimit * 1000);
                    umsg.put("timestamp", System.currentTimeMillis());

                    // Broadcast to whole zone (same effect as iterating channels)
                    Kaiden_Extension.getInstance().sendToUsers(umsg);

                    // Respawn boss monster inside that room (Kaiden style)
                    if (bossRoom != null) {
                        Map<Integer, MonsterAI> monsters = (HashMap<Integer, MonsterAI>) bossRoom.properties.get("monsters");
                        if (monsters != null) {
                            for (MonsterAI actMon : monsters.values()) {
                                if (actMon != null && actMon.getMonster() != null
                                        && actMon.getMonster().getId() == entry.getValue().monsterId) {
                                    Executor.getInstance().scheduleTask(new MonsterRespawn(actMon), 3, TimeUnit.SECONDS);
                                    break;
                                }
                            }
                        }
                    }

                    Storage.getInstance().getJdbc().run(
                            "UPDATE monsters_bosses SET SpawnTime = NOW() WHERE MonsterID = ? AND MapID = ?",
                            entry.getValue().monsterId,
                            entry.getValue().mapId
                    );

                    // Discord Webhook post (spawn) + image + list (same “list of bosses” concept)
                    //KaidenDiscordWorldBossWebhook.postSpawn(entry.getValue(), bossRoom, deathTimes);

                }

                // === TIME LIMIT EXCEEDED ===
                if (System.currentTimeMillis() - spawnTimes.get(entry.getValue().monsterId) > (entry.getValue().timeLimit * 1000)
                        && entry.getValue().isActive) {

                    entry.getValue().isActive = false;
                    deathTimes.put(entry.getValue().monsterId, System.currentTimeMillis());

                    String baseMap = StorageCache.getInstance().worldBossMaps.get(entry.getValue().mapId);
                    if (baseMap == null) continue;

                    Room bossRoom = Kaiden_Extension.getInstance().getZone().getRoomByName(
                            baseMap.toLowerCase() + "-" + entry.getValue().roomNumber
                    );

                    if (bossRoom != null && bossRoom.getUserCount() > 0) {
                        // Kaiden WarpUser expects destination args; keep behavior = “kick everyone out”
                        User[] users = bossRoom.getAllUsers();
                        Executor.getInstance().scheduleTask(
                                new WarpUser(users, Configuration.DEFAULT_MAP, "Enter", "Spawn"),
                                2,
                                TimeUnit.SECONDS
                        );
                    }

                    if (bossRoom != null) {
                        Map<Integer, MonsterAI> monsters = (HashMap<Integer, MonsterAI>) bossRoom.properties.get("monsters");
                        if (monsters != null) {
                            for (MonsterAI actMon : monsters.values()) {
                                if (actMon != null && actMon.getMonster() != null
                                        && actMon.getMonster().getId() == entry.getValue().monsterId) {

                                    if (actMon.attacking != null) actMon.attacking.cancel(true);

                                    for (RemoveAura ra : actMon.auras) {
                                        try {
                                            ra.run();
                                            ra.cancel();
                                        } catch (Exception ignored) {}
                                    }

                                    Storage.getInstance().getJdbc().run(
                                            "UPDATE monsters_bosses SET DeathTime = NOW() WHERE MonsterID = ? AND MapID = ?",
                                            entry.getValue().monsterId,
                                            entry.getValue().mapId
                                    );

                                    actMon.getState().die();
                                    StorageCache.getInstance().worldbosses.get(actMon.getMonster().getId()).isActive = false;

                                    deathTimes.put(entry.getValue().monsterId, System.currentTimeMillis());
                                    break;
                                }
                            }
                        }

                        Kaiden_Extension.getInstance().send(
                                new String[]{"warning", "Time limit has exceeded. You may try again next time."},
                                bossRoom.getChannellList()
                        );
                    }
                }
            }
        } catch (Exception e) {
            SmartFoxServer.log.warning("WorldBossSpawner interrupted, reinitializing..");
            SmartFoxServer.log.warning("Error message: " + e.getMessage());
        }
    }
}
