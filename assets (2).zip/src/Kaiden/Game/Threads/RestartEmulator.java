package Kaiden.Game.Threads;

import Kaiden.Database.Storage;
import Kaiden.Kaiden_Extension;
import org.apache.log4j.Logger;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Canonical, cancellable Kaiden restart lifecycle. */
public class RestartEmulator implements Runnable {
    private static final Logger LOGGER = Logger.getLogger(RestartEmulator.class);
    private static final AtomicReference<Thread> ACTIVE = new AtomicReference<Thread>();
    private static volatile long restartAtMillis;
    private final boolean immediate;
    private final int delayMinutes;

    public RestartEmulator(){ this(false, 5); }
    private RestartEmulator(boolean immediate, int delayMinutes){
        this.immediate=immediate;
        this.delayMinutes=Math.max(1, delayMinutes);
    }
    public static RestartEmulator immediate(){ return new RestartEmulator(true, 1); }
    public static boolean isScheduled(){ Thread t=ACTIVE.get(); return t!=null && t.isAlive(); }
    public static long getRestartAtMillis(){ return restartAtMillis; }
    public static long getRemainingMillis(){ return isScheduled()?Math.max(0L,restartAtMillis-System.currentTimeMillis()):0L; }

    public static Thread schedule(){ return schedule(5); }
    public static Thread schedule(int minutes){
        minutes=Math.max(1, minutes);
        Thread existing=ACTIVE.get(); if(existing!=null && existing.isAlive()) return existing;
        Thread t=new Thread(new RestartEmulator(false,minutes),"Kaiden-RestartEmulator"); t.setDaemon(true);
        if(ACTIVE.compareAndSet(existing,t)){ t.start(); return t; }
        return ACTIVE.get();
    }
    public static boolean cancel(){
        Thread t=ACTIVE.getAndSet(null); restartAtMillis=0L;
        if(t==null || !t.isAlive()) return false;
        t.interrupt();
        try{ Kaiden_Extension.getInstance().send(new String[]{"server","Scheduled server restart cancelled."},Kaiden_Extension.getInstance().getZone().getChannelList()); }catch(Throwable ignored){}
        LOGGER.info("Scheduled server restart cancelled."); return true;
    }

    @Override public void run(){
        Thread me=Thread.currentThread();
        if(!immediate){
            if(!ACTIVE.compareAndSet(null,me) && ACTIVE.get()!=me) return;
            restartAtMillis=System.currentTimeMillis()+TimeUnit.MINUTES.toMillis(delayMinutes);
        }
        try{
            if(!immediate){
                Kaiden_Extension.getInstance().send(new String[]{"server","Server restarting in "+delayMinutes+" minute"+(delayMinutes==1?".":"s.")},Kaiden_Extension.getInstance().getZone().getChannelList());
                if(delayMinutes>1){
                    Thread.sleep(TimeUnit.MINUTES.toMillis(delayMinutes-1L));
                    Kaiden_Extension.getInstance().send(new String[]{"warning","Server restarting in 1 minute."},Kaiden_Extension.getInstance().getZone().getChannelList());
                }
                Thread.sleep(TimeUnit.MINUTES.toMillis(1L));
                Kaiden_Extension.getInstance().send(new String[]{"logoutWarning","","60"},Kaiden_Extension.getInstance().getZone().getChannelList());
                Thread.sleep(TimeUnit.SECONDS.toMillis(2L));
            } else {
                try{ Kaiden_Extension.getInstance().send(new String[]{"warning","Server restarting now."},Kaiden_Extension.getInstance().getZone().getChannelList()); }catch(Throwable ignored){}
            }
            Storage.getInstance().getJdbc().run("UPDATE users SET CurrentServer = 'Offline' WHERE CurrentServer = ?", Kaiden.Database.Configuration.Configuration.SERVER_NAME);
            Storage.getInstance().getJdbc().run("UPDATE servers SET Online=0, Count=0 WHERE Name=?", Kaiden.Database.Configuration.Configuration.SERVER_NAME);

            // A GUI-managed world must terminate its child JVM so Windows releases the
            // SmartFox and H2 listening sockets. ServerManagerUI observes the exit,
            // waits for the game port to become free, and starts a fresh child JVM.
            if(Boolean.getBoolean("kaiden.manager.child")){
                LOGGER.info("Managed restart countdown complete; shutting down child JVM for clean port release.");
                try{ Kaiden_Extension.getInstance().getHelper().rebootServer(); }catch(Throwable ex){ LOGGER.warn("SmartFox reboot hook returned an error before managed exit",ex); }
                Thread.sleep(1000L);
                System.exit(0);
                return;
            }
            Kaiden_Extension.getInstance().getHelper().rebootServer();
        }catch(InterruptedException ex){ Thread.currentThread().interrupt(); LOGGER.info("Scheduled restart interrupted/cancelled."); }
        catch(Throwable ex){ LOGGER.error("Restart failed",ex); }
        finally{ if(!immediate){ ACTIVE.compareAndSet(me,null); restartAtMillis=0L; } }
    }
}
