package Kaiden.Game.Threads;

import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * Keeps long AFK sessions warm without doing database work.
 *
 * Some SmartFox/socket stacks and proxies silently close idle TCP sessions after
 * roughly 20-30 minutes. Sending a tiny packet every few minutes keeps the
 * connection active so players can stay logged in as long as they want.
 */
public class SessionKeepAlive implements Runnable {

    private static final Logger LOGGER = Logger.getLogger(SessionKeepAlive.class);

    @Override
    public void run() {
        try {
            Kaiden_Extension ext = Kaiden_Extension.getInstance();
            if (ext == null || ext.getZone() == null) {
                return;
            }

            List users = ext.getZone().getUserList();
            if (users == null || users.isEmpty()) {
                return;
            }

            String now = String.valueOf(System.currentTimeMillis());
            for (Object object : users) {
                if (!(object instanceof User)) {
                    continue;
                }

                User user = (User) object;
                if (user == null || user.isBeingKicked) {
                    continue;
                }

                try {
                    ext.send(new String[]{"heartbeat", now}, user);
                } catch (Throwable ignored) {
                    // Never let one bad socket break the whole keepalive pass.
                }
            }
        } catch (Throwable t) {
            LOGGER.warn("[SessionKeepAlive] skipped: " + t.getMessage());
        }
    }
}
