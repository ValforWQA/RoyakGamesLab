package Kaiden.Game.Threads;

import java.util.concurrent.ScheduledFuture;

public interface CancellableTask {

    void setRunning(ScheduledFuture scheduledFuture);

    void cancel();
}
