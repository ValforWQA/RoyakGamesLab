package Kaiden.Game.Threads;

import Kaiden.Database.Beans.AuraBean;
import Kaiden.Database.Beans.AuraEffectsBean;
import Kaiden.Database.Beans.AuraPhaseBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Game.Server.Users.Utils.State;
import Kaiden.Game.Server.Users.Utils.Stats;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.log4j.Logger;

import Kaiden.Game.Threads.Executor;

import Kaiden.Game.Threads.HealOverTime;
import Kaiden.Game.Server.Combat.Player.CombatTrace;
import Kaiden.Game.Server.Combat.Player.CombatLockRegistry;

public class RemoveAura implements Runnable, CancellableTask {

    private static final Logger LOGGER = Logger.getLogger(RemoveAura.class);


    private static long NEXT_ID = 1L;
    private final long instanceId;

    private final AuraBean aura;
    private DamageOverTime dot;
    private HealOverTime hot;
    private ScheduledFuture hotRunning;
    private ScheduledFuture running;
    private User user;
    private MonsterAI ai;
    private final Room room;
    private long endTime;
    private final List<AuraEffectsBean> appliedEffects = new ArrayList<AuraEffectsBean>();
    private final List<AuraEffectsBean> activeRuntimePhaseEffects = new ArrayList<AuraEffectsBean>();
    private final List<ScheduledFuture> phaseRunnings = new ArrayList<ScheduledFuture>();
    private volatile int activeRuntimePhaseNo = 1;
    private String sourceInf = "";
    private volatile boolean finished;
    private volatile boolean refreshedOnly;
    private volatile int stackCount = 1;
    private volatile long scheduleVersion = 0L;

    /*
     * Data-driven combat counters from auras_effects.
     * Example:
     *   forcecrit  = 1 -> force outgoing auto attacks to crit
     *   hitcounter = 2 -> consume this aura after 2 successful auto attacks
     */
    private volatile boolean forceCrit = false;
    private volatile int hitCounter = 0;

    public RemoveAura(AuraBean aura, MonsterAI ai, Room room) {
        synchronized (RemoveAura.class) {
            this.instanceId = NEXT_ID++;
        }
        this.aura = aura;
        this.ai = ai;
        this.room = room;
    }

    public RemoveAura(AuraBean aura, User user, Room room) {
        synchronized (RemoveAura.class) {
            this.instanceId = NEXT_ID++;
        }
        this.aura = aura;
        this.user = user;
        this.room = room;
    }

    public synchronized void run() {
        ReentrantLock combatLock = null;
        boolean locked = false;

        try {
            combatLock = getCombatLock(this.user);
            if (combatLock != null) {
                locked = combatLock.tryLock(3L, TimeUnit.SECONDS);
                if (!locked) {
                    CombatTrace.warn("RemoveAura.run", "combat lock busy; rescheduling safe cleanup " + CombatTrace.aura(this));
                    try {
                        this.running = Executor.getInstance().scheduleTask(this, 1L, TimeUnit.SECONDS);
                    } catch (Throwable ignored) {}
                    return;
                }
            }

            long now = System.currentTimeMillis();
            if (this.finished) {
                CombatTrace.warn("RemoveAura.run", "already finished " + CombatTrace.aura(this));
                return;
            }
            if (this.endTime > 0L && now + 25L < this.endTime) {
                CombatTrace.info("RemoveAura.run", "stale early fire ignored " + CombatTrace.aura(this));
                return;
            }

            CombatTrace.info("RemoveAura.run", "start " + CombatTrace.aura(this) + ", user=" + CombatTrace.who(this.user) + ", monster=" + CombatTrace.who(this.ai));
            this.finished = true;

            final String auraCatRaw = (this.aura == null || this.aura.getCategory() == null) ? "" : this.aura.getCategory();
            final String auraCat = auraCatRaw.trim();
            final String __cat = auraCat.toLowerCase();

            JSONObject ct = new JSONObject();
            JSONArray a = new JSONArray();
            JSONObject o = new JSONObject();
            JSONObject auraInfo = new JSONObject();

            if (!auraCat.isEmpty() && !auraCat.equals("d")) {
                auraInfo.put("cat", auraCat);
                if (auraCat.equalsIgnoreCase("stun")) {
                    auraInfo.put("s", "s");
                }
            }
            auraInfo.put("nam", (this.aura != null ? this.aura.getName() : ""));
            o.put("cmd", "aura-");
            o.put("aura", auraInfo);

            if (this.user != null) {
                o.put("tInf", "p:" + this.user.getUserId());
            }
            if (this.ai != null && this.ai.getMapMonster() != null) {
                o.put("tInf", "m:" + this.ai.getMapMonster().getMonMapId());
            }

            a.add(o);
            ct.put("cmd", "ct");
            ct.put("a", a);

            Room sendRoom = safeRoom();

            if (this.user != null) {
                boolean shouldSendAuraRemove = true;
                boolean shouldSendFxOff = true;

                CombatTrace.info("RemoveAura.run", "user remove begin " + CombatTrace.aura(this));
                try {
                    Users.getInstance().removeAura(this.user, this);
                } catch (Throwable t) {
                    CombatTrace.warn("RemoveAura.run", "user remove skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }

                try {
                    State state = null;
                    if (this.user.properties != null) {
                        state = (State) this.user.properties.get("state");
                    }
                    if (state != null) {
                        shouldSendAuraRemove = (this.aura == null) || !state.hasAura(this.aura.getId());
                        shouldSendFxOff = !state.hasAuraCategory(__cat, this.instanceId);
                        state.refreshCombatState();
                    }
                } catch (Throwable t) {
                    CombatTrace.warn("RemoveAura.run", "user state cleanup skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
                CombatTrace.info("RemoveAura.run", "user remove done " + CombatTrace.aura(this));

                removeUserStatEffectsSafely(this.user);

                if (sendRoom != null && shouldSendFxOff && isClientFxCategory(__cat)) {
                    try {
                        JSONObject off = new JSONObject();
                        off.put("cmd", "fx");
                        off.put("targetType", "player");
                        off.put("target", this.user.getName());
                        off.put("on", String.valueOf(0));
                        off.put("effect", String.valueOf(__cat));
                        Kaiden_Extension.getInstance().send(off, sendRoom.getChannellList());
                    } catch (Throwable t) {
                        CombatTrace.warn("RemoveAura.run", "player fx-off skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }

                if (sendRoom != null && shouldSendAuraRemove) {
                    try {
                        Kaiden_Extension.getInstance().send(ct, sendRoom.getChannellList());
                    } catch (Throwable t) {
                        CombatTrace.warn("RemoveAura.run", "player aura- packet skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            }

            if (this.ai != null) {
                boolean shouldSendAuraRemove = true;
                boolean shouldSendFxOff = true;

                CombatTrace.info("RemoveAura.run", "monster remove begin " + CombatTrace.aura(this));
                try {
                    State monsterState = this.ai.getState();
                    if (monsterState != null) {
                        monsterState.removeAura(this);
                        shouldSendAuraRemove = (this.aura == null) || !monsterState.hasAura(this.aura.getId());
                        shouldSendFxOff = !monsterState.hasAuraCategory(__cat, this.instanceId);
                        monsterState.refreshCombatState();
                    }
                } catch (Throwable t) {
                    CombatTrace.warn("RemoveAura.run", "monster cleanup skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
                CombatTrace.info("RemoveAura.run", "monster remove done " + CombatTrace.aura(this));
                if (CombatTrace.isCharmAura(this.aura)) {
                    try {
                        Kaiden.Game.Server.Rooms.Monsters.MonsterState monsterState = this.ai.getState();
                        boolean stillCharmed = monsterState != null && monsterState.hasAuraEffect("charm");
                        int sourceUserId = parseSourceUserId(this.sourceInf);
                        if (!stillCharmed && monsterState != null && sourceUserId > 0) {
                            monsterState.addTarget(sourceUserId);
                            CombatTrace.charm("Expire", CombatTrace.who(this.ai) + " charm expired; restored player target p:" + sourceUserId);
                        } else {
                            CombatTrace.charm("Expire", CombatTrace.who(this.ai) + " charm expired; restored=" + (!stillCharmed && sourceUserId > 0) + " source=" + this.sourceInf);
                        }
                    } catch (Throwable t) {
                        CombatTrace.charm("Expire", "restore player target skipped for " + CombatTrace.who(this.ai) + " error=" + t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }

                if (sendRoom != null && shouldSendFxOff && isClientFxCategory(__cat) && this.ai.getMapMonster() != null) {
                    try {
                        JSONObject off = new JSONObject();
                        off.put("cmd", "fx");
                        off.put("targetType", "monster");
                        off.put("target", String.valueOf(this.ai.getMapMonster().getMonMapId()));
                        off.put("on", String.valueOf(0));
                        off.put("effect", String.valueOf(__cat));
                        Kaiden_Extension.getInstance().send(off, sendRoom.getChannellList());
                    } catch (Throwable t) {
                        CombatTrace.warn("RemoveAura.run", "monster fx-off skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }

                if (sendRoom != null && shouldSendAuraRemove) {
                    try {
                        Kaiden_Extension.getInstance().send(ct, sendRoom.getChannellList());
                    } catch (Throwable t) {
                        CombatTrace.warn("RemoveAura.run", "monster aura- packet skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                }
            }

            this.cancel();
            CombatTrace.info("RemoveAura.run", "end " + CombatTrace.aura(this));
        } catch (Throwable t) {
            try {
                this.finished = true;
                this.cancel();
            } catch (Throwable ignored) {}
            try {
                LOGGER.error("RemoveAura hard-safe caught exception; cleanup skipped instead of crashing emulator", t);
                CombatTrace.warn("RemoveAura.run", "hard-safe caught " + t.getClass().getSimpleName() + ": " + t.getMessage() + " " + CombatTrace.aura(this));
            } catch (Throwable ignored) {}
        } finally {
            try {
                if (locked && combatLock != null) combatLock.unlock();
            } catch (Throwable ignored) {}
        }
    }

    private int parseSourceUserId(String value) {
        if (value == null) return -1;
        String source = value.trim().toLowerCase();
        if (!source.startsWith("p:")) return -1;
        try {
            return Integer.parseInt(source.substring(2));
        } catch (Throwable ignored) {
            return -1;
        }
    }

    private Room safeRoom() {
        try {
            if (this.room != null) return this.room;
        } catch (Throwable ignored) {}
        try {
            if (this.user != null && this.user.getRoom() > 0) {
                Room r = Kaiden_Extension.getInstance().getZone().getRoom(this.user.getRoom());
                if (r != null) return r;
            }
        } catch (Throwable ignored) {}
        try {
            if (this.ai != null && this.ai.getRoom() != null) return this.ai.getRoom();
        } catch (Throwable ignored) {}
        return null;
    }

    private boolean isClientFxCategory(String cat) {
        if (cat == null) return false;
        return cat.equals("freeze") || cat.equals("frozen") || cat.equals("stun") || cat.equals("stone") || cat.equals("disabled") || cat.equals("disable")
                || cat.equals("poison") || cat.equals("dot") || cat.equals("burn") || cat.equals("bleed") || cat.equals("d");
    }

    private void removeUserStatEffectsSafely(User targetUser) {
        try {
            if (targetUser == null || targetUser.properties == null) return;
            if (this.aura == null || this.aura.effects == null || this.aura.effects.isEmpty()) return;

            Stats stats = (Stats) targetUser.properties.get("stats");
            if (stats == null) return;

            Set<AuraEffectsBean> auraEffects = new HashSet<AuraEffectsBean>();
            if (!this.activeRuntimePhaseEffects.isEmpty()) {
                for (AuraEffectsBean ae : new ArrayList<AuraEffectsBean>(this.activeRuntimePhaseEffects)) {
                    if (ae == null) continue;
                    try { stats.removeEffect(ae); auraEffects.add(ae); } catch (Throwable ignored) {}
                }
                this.activeRuntimePhaseEffects.clear();
            }
            if (!this.appliedEffects.isEmpty()) {
                for (AuraEffectsBean ae : new ArrayList<AuraEffectsBean>(this.appliedEffects)) {
                    if (ae == null) continue;
                    try {
                        stats.removeEffect(ae);
                        auraEffects.add(ae);
                    } catch (Throwable ignored) {}
                }
                this.appliedEffects.clear();
            } else {
                for (int effectId : this.aura.effects) {
                    try {
                        AuraEffectsBean ae = StorageCache.getInstance().getAuraEffect(effectId);
                        if (ae == null) continue;
                        stats.removeEffect(ae);
                        auraEffects.add(ae);
                    } catch (Throwable ignored) {}
                }
            }

            CombatTrace.info("RemoveAura.run", "queued stat removal count=" + auraEffects.size() + " for " + CombatTrace.who(targetUser));
            stats.markDirty();
            if (safeRoom() != null) {
                try {
                    Users.getInstance().sendStatsIfDirty(targetUser);
                } catch (Throwable t) {
                    CombatTrace.warn("RemoveAura.run", "sendStatsIfDirty skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
            }
        } catch (Throwable t) {
            CombatTrace.warn("RemoveAura.run", "removeUserStatEffectsSafely skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
    }

    private ReentrantLock getCombatLock(User user) {
        return CombatLockRegistry.get(this.room, user);
    }

    public void cancel() {
        try {
            CombatTrace.info("RemoveAura.cancel", CombatTrace.aura(this));
            if (this.dot != null) {
                this.dot.cancel();
            }
            if (this.hot != null) {
                this.hot.cancel();
            }
            if (this.hotRunning != null) {
                this.hotRunning.cancel(false);
            }
            if (this.running != null) {
                this.running.cancel(false);
            }
            synchronized (this.phaseRunnings) {
                for (ScheduledFuture f : this.phaseRunnings) { try { if (f != null) f.cancel(false); } catch (Throwable ignored) {} }
                this.phaseRunnings.clear();
            }
        } catch (Exception e) { LOGGER.error("RemoveAura exception", e); }
    }

    public void setRunning(ScheduledFuture running) {
        this.running = running;
        if (this.aura != null) {
            this.endTime = System.currentTimeMillis()
                    + java.util.concurrent.TimeUnit.SECONDS.toMillis(this.aura.getRuntimeDuration());
        }
    }

    public synchronized void scheduleToEndTime(long targetEndTimeMs) {
        long now = System.currentTimeMillis();
        CombatTrace.info("RemoveAura.schedule", "targetEnd=" + targetEndTimeMs + ", now=" + now + ", " + CombatTrace.aura(this));
        long delayMs = Math.max(0L, targetEndTimeMs - now);
        long delaySeconds = Math.max(0L, (long) Math.ceil(delayMs / 1000.0D));
        try {
            if (this.running != null) {
                this.running.cancel(false);
            }
        } catch (Exception e) { LOGGER.error("RemoveAura exception", e); }
        this.finished = false;
        this.scheduleVersion++;
        this.running = Executor.getInstance().scheduleTask(this, delaySeconds, TimeUnit.SECONDS);
        this.endTime = targetEndTimeMs;
        refreshCombatEffectCountersFromAura();
    }

    public long getEndTime() {
        return this.endTime;
    }

    public synchronized void refreshDuration(int seconds) {
        int duration = Math.max(0, seconds);
        CombatTrace.info("RemoveAura.refresh", "seconds=" + seconds + ", " + CombatTrace.aura(this));
        try {
            if (this.running != null) {
                this.running.cancel(false);
            }
        } catch (Exception e) { LOGGER.error("RemoveAura exception", e); }
        if (duration > 0) {
            this.finished = false;
            this.scheduleVersion++;
            this.running = Executor.getInstance().scheduleTask(this, duration, TimeUnit.SECONDS);
            this.endTime = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(duration);
            refreshCombatEffectCountersFromAura();
        } else {
            this.endTime = 0L;
        }
    }



    /** Reset to the base aura phase when the aura is refreshed/reapplied. */
    public synchronized void resetRuntimePhases() {
        synchronized (this.phaseRunnings) {
            for (ScheduledFuture f : this.phaseRunnings) { try { if (f != null) f.cancel(false); } catch (Throwable ignored) {} }
            this.phaseRunnings.clear();
        }
        if (!this.activeRuntimePhaseEffects.isEmpty() && this.user != null) {
            try {
                Stats stats = (Stats) this.user.properties.get("stats");
                if (stats != null) {
                    for (AuraEffectsBean ae : new ArrayList<AuraEffectsBean>(this.activeRuntimePhaseEffects)) stats.removeEffect(ae);
                    for (AuraEffectsBean ae : new ArrayList<AuraEffectsBean>(this.appliedEffects)) stats.addEffect(ae);
                    stats.markDirty();
                    stats.update();
                    try { Users.getInstance().sendStats(this.user); } catch (Throwable ignored) {}
                }
            } catch (Throwable ignored) {}
        }
        this.activeRuntimePhaseEffects.clear();
        this.activeRuntimePhaseNo = 1;
        scheduleRuntimePhases();
    }

    /** Schedule optional later phases stored in auras_wiki_phases. */
    public synchronized void scheduleRuntimePhases() {
        if (this.aura == null || this.aura.phases == null || this.aura.phases.isEmpty()) return;
        synchronized (this.phaseRunnings) {
            for (ScheduledFuture f : this.phaseRunnings) { try { if (f != null) f.cancel(false); } catch (Throwable ignored) {} }
            this.phaseRunnings.clear();
            final java.util.Map<Integer, java.util.List<AuraPhaseBean>> grouped = new java.util.TreeMap<Integer, java.util.List<AuraPhaseBean>>();
            for (AuraPhaseBean p : this.aura.phases) {
                if (p == null || p.getPhaseNo() <= 1) continue;
                java.util.List<AuraPhaseBean> list = grouped.get(p.getPhaseNo());
                if (list == null) { list = new ArrayList<AuraPhaseBean>(); grouped.put(p.getPhaseNo(), list); }
                list.add(p);
            }
            for (final java.util.Map.Entry<Integer, java.util.List<AuraPhaseBean>> e : grouped.entrySet()) {
                double after = 0.0D;
                for (AuraPhaseBean p : e.getValue()) after = Math.max(after, p.getAfterSeconds());
                long delayMs = Math.max(0L, Math.round(after * 1000.0D));
                ScheduledFuture f = Executor.getInstance().scheduleTask(new Runnable() {
                    @Override public void run() { activateRuntimePhase(e.getKey().intValue(), e.getValue()); }
                }, delayMs, TimeUnit.MILLISECONDS);
                this.phaseRunnings.add(f);
            }
        }
    }

    private synchronized void activateRuntimePhase(int phaseNo, java.util.List<AuraPhaseBean> rows) {
        if (this.finished || this.isExpired() || rows == null || rows.isEmpty()) return;
        this.activeRuntimePhaseNo = Math.max(2, phaseNo);
        this.activeRuntimePhaseEffects.clear();
        int virtualId = -1000000 - (this.aura.getId() * 100) - this.activeRuntimePhaseNo;
        for (AuraPhaseBean p : rows) {
            if (p == null || p.getStat().isEmpty()) continue;
            this.activeRuntimePhaseEffects.add(AuraEffectsBean.runtime(virtualId--, p.getStat(), p.getType(), p.getValue()));
        }

        if (this.user != null) {
            try {
                Stats stats = (Stats) this.user.properties.get("stats");
                if (stats != null) {
                    for (AuraEffectsBean ae : new ArrayList<AuraEffectsBean>(this.appliedEffects)) stats.removeEffect(ae);
                    for (AuraEffectsBean ae : this.activeRuntimePhaseEffects) stats.addEffect(ae);
                    stats.markDirty();
                    stats.update();
                    java.util.Set<AuraEffectsBean> changed = new java.util.HashSet<AuraEffectsBean>(this.activeRuntimePhaseEffects);
                    try { stats.sendStatChanges(changed); } catch (Throwable ignored) {}
                    try { Users.getInstance().sendStats(this.user); } catch (Throwable ignored) {}
                }
            } catch (Throwable t) {
                CombatTrace.warn("RemoveAura.phase", "user phase activation skipped " + t.getClass().getSimpleName() + ": " + t.getMessage());
            }
        }
        CombatTrace.info("RemoveAura.phase", "activated phase=" + this.activeRuntimePhaseNo + " aura=" + (this.aura != null ? this.aura.getName() : "?") + " effects=" + this.activeRuntimePhaseEffects.size());
    }

    public synchronized boolean hasActiveRuntimePhase() { return this.activeRuntimePhaseNo > 1 && !this.activeRuntimePhaseEffects.isEmpty(); }
    public synchronized int getActiveRuntimePhaseNo() { return this.activeRuntimePhaseNo; }
    public synchronized List<AuraEffectsBean> getActiveRuntimePhaseEffects() { return new ArrayList<AuraEffectsBean>(this.activeRuntimePhaseEffects); }


    public String getSourceInf() {
        return this.sourceInf;
    }

    public void setSourceInf(String sourceInf) {
        this.sourceInf = sourceInf == null ? "" : sourceInf.trim().toLowerCase();
    }

    public boolean isFinished() {
        return this.finished;
    }

    public boolean isExpired() {
        long end = this.endTime;
        return end > 0L && end <= System.currentTimeMillis();
    }

    public boolean isRefreshedOnly() {
        return this.refreshedOnly;
    }

    public void setRefreshedOnly(boolean refreshedOnly) {
        this.refreshedOnly = refreshedOnly;
    }

    public AuraBean getAura() {
        return this.aura;
    }

    public void setDot(DamageOverTime dot) {
        this.dot = dot;
    }

    public DamageOverTime getDot() {
        return this.dot;
    }

    public void setHot(HealOverTime hot) {
        this.hot = hot;
    }

    public HealOverTime getHot() {
        return this.hot;
    }

    public void setHotRunning(ScheduledFuture hotRunning) {
        this.hotRunning = hotRunning;
    }

    public ScheduledFuture getHotRunning() {
        return this.hotRunning;
    }

    public ScheduledFuture getRunning() {
        return this.running;
    }


    public void addAppliedEffect(AuraEffectsBean effect) {
        if (effect != null) {
            this.appliedEffects.add(effect);
            applyCombatCounterEffect(effect);
        }
    }


    public synchronized void refreshCombatEffectCountersFromAura() {
        this.forceCrit = false;
        this.hitCounter = 0;

        try {
            if (this.aura == null || this.aura.effects == null || this.aura.effects.isEmpty()) {
                return;
            }

            for (int effectId : this.aura.effects) {
                AuraEffectsBean effect = StorageCache.getInstance().getAuraEffect(effectId);
                applyCombatCounterEffect(effect);
            }
        } catch (Throwable t) {
            CombatTrace.warn("RemoveAura.combatCounters", "refresh skipped " + t.getClass().getSimpleName() + ": " + t.getMessage() + " " + CombatTrace.aura(this));
        }
    }

    private synchronized void applyCombatCounterEffect(AuraEffectsBean effect) {
        if (effect == null || effect.getStat() == null) return;

        String stat = effect.getStat().trim().toLowerCase();
        double value = effect.getValue();

        if ("forcecrit".equals(stat) || "force_crit".equals(stat) || "forcedcrit".equals(stat)) {
            this.forceCrit = value > 0.0D;
            return;
        }

        if ("hitcounter".equals(stat) || "hit_count".equals(stat) || "hitcount".equals(stat)) {
            this.hitCounter = Math.max(0, (int) Math.round(Math.abs(value)));
        }
    }

    public boolean isForceCrit() {
        return this.forceCrit;
    }

    public synchronized int getHitCounter() {
        return this.hitCounter;
    }

    public synchronized void setHitCounter(int hitCounter) {
        this.hitCounter = Math.max(0, hitCounter);
    }

    public synchronized int decrementHitCounter() {
        if (this.hitCounter <= 0) return 0;
        this.hitCounter--;
        return this.hitCounter;
    }

    public boolean hasHitCounter() {
        return this.hitCounter > 0;
    }

    public List<AuraEffectsBean> getAppliedEffects() {
        return this.appliedEffects;
    }

    public long getInstanceId() {
        return this.instanceId;
    }


    public synchronized int getStackCount() {
        return Math.max(1, this.stackCount);
    }

    public synchronized void setStackCount(int stackCount) {
        this.stackCount = Math.max(1, stackCount);
    }

    public synchronized int incrementStackCount(int delta, int maxStacks) {
        int next = Math.max(1, this.stackCount + Math.max(0, delta));
        if (maxStacks > 0) next = Math.min(next, maxStacks);
        this.stackCount = next;
        return this.stackCount;
    }

    public long getRemainingDurationSeconds() {
        if (this.endTime <= 0L) return 0L;
        long remainingMs = Math.max(0L, this.endTime - System.currentTimeMillis());
        return (long) Math.ceil(remainingMs / 1000.0D);
    }

    public int hashCode() {
        return (int) (this.instanceId ^ (this.instanceId >>> 32));
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (this.getClass() != obj.getClass()) return false;
        RemoveAura other = (RemoveAura) obj;
        return this.instanceId == other.instanceId;
    }
}