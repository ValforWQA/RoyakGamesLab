package Kaiden.Game.Threads;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Storage;
import Kaiden.Game.Server.Users.Utils.ServerCountManager;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.concurrent.atomic.AtomicBoolean;

public class DeadConnection implements Runnable {
    private static final Logger LOGGER = Logger.getLogger(DeadConnection.class);
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    public void run() {
        if (!RUNNING.compareAndSet(false, true)) {
            return;
        }

        try {
            int count = ServerCountManager.getOnlineCount();

            Storage.getInstance().getJdbc().run(
                    "UPDATE servers SET Count = ? WHERE Name = ?",
                    count,
                    Configuration.SERVER_NAME
            );
        } catch (Exception e) {
            LOGGER.warn("DeadConnection count sync skipped: " + e.getMessage());
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                    "yellow",
                    "[DeadConnection] Count sync skipped: " + e.getMessage()
            );
        } finally {
            RUNNING.set(false);
        }
    }
}