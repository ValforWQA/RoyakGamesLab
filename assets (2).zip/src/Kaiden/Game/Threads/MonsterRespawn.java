package Kaiden.Game.Threads;

import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Kaiden_Extension;

public class MonsterRespawn implements Runnable {

    private final MonsterAI ai;

    public MonsterRespawn(MonsterAI ai) {
        this.ai = ai;
    }

    public void run() {
        this.ai.restore();
        Kaiden_Extension.getInstance().send(new String[]{"respawnMon", Integer.toString(this.ai.getMapMonster().getMonMapId())}, this.ai.getRoom().getChannellList());
        //Kaiden.//Kaiden_Engine.LOGGER.info("[Respawn Test : Respawning monster : "+ this.ai.getMonster().getName());
    }
}
