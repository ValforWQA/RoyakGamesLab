package Kaiden.Game.Threads;

import Kaiden.Game.Server.Packets.Manager.ThreadPacketManager;


public class ThreadManager {
    private static ThreadManager instance;

    public static ThreadManager getInstance() {
        if (instance == null) {
            instance = new ThreadManager();
        }
        return instance;
    }

    public void InitializeThreads() {
        ThreadPacketManager.getInstance().initializeThreads();
    }

    public void initializeThreads() {
        ThreadPacketManager.getInstance().initializeThreads();
    }

    public void loadThreads() {
        ThreadPacketManager.getInstance().initializeThreads();
    }

    public void stopAll() {
        ThreadPacketManager.getInstance().stopAll();
    }

    public int getRunningCount() {
        return ThreadPacketManager.getInstance().getRunningCount();
    }
}
