package Kaiden.Game.Threads;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Kaiden_Engine;
import org.apache.log4j.Logger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Central scheduled task executor.
 *
 * Important change:
 * - Repeating tasks use scheduleWithFixedDelay instead of scheduleAtFixedRate.
 *   This means the next run only starts AFTER the previous run fully finishes.
 *   It prevents thread pileups when a task takes longer than its delay.
 * - Every task is wrapped so exceptions do not kill the scheduler thread.
 */
public class Executor {
    private static final Logger LOGGER = Logger.getLogger(Executor.class);
    private static Executor instance;

    public static Executor getInstance() {
        if (instance == null) {
            instance = new Executor();
        }
        return instance;
    }

    private final ScheduledExecutorService tasks;

    public Executor() {
        this.tasks = Executors.newScheduledThreadPool(
                Configuration.EXECUTOR_THREADS,
                new ThreadFactory() {
                    private final AtomicInteger ids = new AtomicInteger(1);

                    @Override
                    public Thread newThread(Runnable runnable) {
                        Thread thread = new Thread(runnable, "KaidenTask-" + ids.getAndIncrement());
                        thread.setDaemon(false);
                        return thread;
                    }
                }
        );
    }

    public ScheduledFuture scheduleTask(Runnable task, long delay, TimeUnit tu) {
        return this.scheduleTask(task, delay, tu, false);
    }

    public ScheduledFuture scheduleTask(Runnable task, long delay, TimeUnit tu, boolean repeat) {
        return this.scheduleTask(task, delay, delay, tu, repeat);
    }

    public ScheduledFuture scheduleTask(Runnable task, long start, long delay, TimeUnit tu, boolean repeat) {
        Runnable safeTask = guarded(task);

        if (repeat) {
            /*
             * scheduleWithFixedDelay is safer than scheduleAtFixedRate for emulator work.
             * The task finishes, the worker returns to the pool, then the delay starts.
             * No overlap, no stacking runs, no thread flood.
             */
            return this.tasks.scheduleWithFixedDelay(
                    safeTask,
                    Math.max(0L, start),
                    Math.max(1L, delay),
                    tu
            );
        }

        return this.tasks.schedule(
                safeTask,
                Math.max(0L, delay),
                tu
        );
    }

    private Runnable guarded(final Runnable task) {
        return new Runnable() {
            private final AtomicBoolean running = new AtomicBoolean(false);

            @Override
            public void run() {
                if (task == null) {
                    return;
                }

                if (!running.compareAndSet(false, true)) {
                    return;
                }

                long start = System.currentTimeMillis();

                try {
                    task.run();
                } catch (Throwable t) {
                    LOGGER.error("[Executor] Task failed: " + task.getClass().getName(), t);
                    try {
                        Kaiden_Engine.getInstance().sendEmulatorMessage(
                                "red",
                                "[Executor] Task failed: " + task.getClass().getSimpleName() + " - " + t.getMessage()
                        );
                    } catch (Throwable ignored) {}
                } finally {
                    running.set(false);

                    long took = System.currentTimeMillis() - start;
                    if (took > 5000L) {
                        LOGGER.warn("[Executor] Slow task " + task.getClass().getName() + " took " + took + "ms");
                    }
                }
            }
        };
    }

    public void destroy() {
        instance = null;
        this.tasks.shutdownNow();
    }
}
