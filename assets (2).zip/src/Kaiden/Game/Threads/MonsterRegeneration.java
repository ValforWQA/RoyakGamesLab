package Kaiden.Game.Threads;

import Kaiden.Database.Beans.MapMonsterBean;
import Kaiden.Database.Beans.MonsterBean;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Rooms.Monsters.MonsterAI;
import Kaiden.Game.Server.Rooms.Monsters.MonsterState;

import java.util.concurrent.ScheduledFuture;

/**
 * Periodic regeneration for a single monster instance.
 * - Uses the live MonsterState from MonsterAI (no local copy).
 * - Regens while the monster has targets (in combat).
 * - Stops when there are no more targets or the monster dies.
 */
public class MonsterRegeneration implements Runnable, CancellableTask {

    private final MapMonsterBean mapMonster;
    private final MonsterBean monster;
    private final MonsterAI monsterAI;
    private final MonsterState state;    // live state from MonsterAI
    private ScheduledFuture<?> running;

    public MonsterRegeneration(MapMonsterBean mapMon, MonsterAI monsterAI) {
        this.mapMonster = mapMon;
        this.monsterAI = monsterAI;
        this.monster = StorageCache.getInstance().getMonster(mapMon.getMonsterId());
        this.state = monsterAI.getState();
    }

    @Override
    public void run() {
        if (this.running == null || this.monster == null || this.state == null) {
            throw new RuntimeException("regen handle for monster is null, unable to continue.");
        }

        // If monster died, stop regen
        if (state.isDead()) {
            cancel();
            return;
        }

        // Use hasTargets() as "in combat" flag
        if (state.hasTargets()) {
            state.increaseHealthByPercent(0.065D);
            state.increaseManaByPercent(0.065D);
            //Kaiden_Engine.LOGGER.debug(this.monster.getName() + " is regenerating (combat regen).");
        } else {
            // No more targets -> stop regeneration
            cancel();
        }
    }

    public boolean isRegenerating() {
        return this.running != null && !this.running.isDone();
    }

    public void setRunning(ScheduledFuture running) {
        if (this.running != null && !this.running.isDone()) {
            running.cancel(true);
        } else {
            this.running = running;
        }
    }

    @Override
    public void cancel() {
        if (this.running != null && !this.running.isDone()) {
            this.running.cancel(false);
        }
    }
}
