package Kaiden.Game.Threads;

import Kaiden.Database.Beans.ItemBean;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.External.Quest.GetDrop;
import Kaiden.Game.Server.Users.Properties;
import Kaiden.Game.Server.Users.UserDrop;
import Kaiden.Game.Server.Users.Users;
import Kaiden.Kaiden_Engine;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.data.User;
import jdbchelper.QueryResult;
import net.sf.json.JSONObject;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Delivers website/account-management rewards to players while they are online.
 *
 * users_live_drops remains the single bridge table. The account management UI can
 * queue into that table and this thread uses the emulator's normal reward,
 * achievement, inventory and packet systems so the client updates in real time.
 */
public class LiveRewards implements Runnable {

    private static final Logger LOGGER = Logger.getLogger(LiveRewards.class);
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);

    /**
     * Allows the achievement bridge to wake the live reward worker immediately
     * instead of waiting for the next servers_threads poll.
     */
    public static void scheduleImmediate() {
        try {
            Executor.getInstance().scheduleTask(new LiveRewards(), 0L, TimeUnit.MILLISECONDS);
        } catch (Exception ignored) {}
    }

    @Override
    public void run() {
        if (!RUNNING.compareAndSet(false, true)) {
            return;
        }

        QueryResult liveDrops = null;
        List<LiveDropRow> pending = new ArrayList<LiveDropRow>();

        try {
            liveDrops = Storage.getInstance().getJdbc().query(
                    "SELECT * FROM users_live_drops " +
                    "WHERE Claimed = ? " +
                    "AND (AvailableAt IS NULL OR AvailableAt <= NOW()) " +
                    "ORDER BY id ASC LIMIT 250",
                    0
            );

            while (liveDrops.next()) {
                pending.add(new LiveDropRow(
                        liveDrops.getInt("id"),
                        liveDrops.getInt("UserID"),
                        liveDrops.getInt("ItemID"),
                        liveDrops.getInt("Quantity"),
                        liveDrops.getInt("Coins"),
                        liveDrops.getInt("Gold"),
                        liveDrops.getInt("Experience"),
                        liveDrops.getInt("ClassPoints"),
                        liveDrops.getInt("UpgradeDays"),
                        liveDrops.getInt("AchievementID"),
                        liveDrops.getInt("RequiredAchievementID"),
                        liveDrops.getInt("RewardID"),
                        safeString(liveDrops, "RewardKey"),
                        safeString(liveDrops, "RewardName"),
                        safeString(liveDrops, "RewardMessage"),
                        safeString(liveDrops, "Source"),
                        liveDrops.getInt("SourceID"),
                        liveDrops.getInt("Claimed")
                ));
            }
        } catch (Exception e) {
            LOGGER.warn("LiveRewards query skipped: " + e.getMessage());
            sendEngineMessage("yellow", "[LiveRewards] Query skipped: " + e.getMessage());
        } finally {
            if (liveDrops != null) {
                try { liveDrops.close(); } catch (Exception ignored) {}
            }
        }

        try {
            for (LiveDropRow row : pending) {
                User user = getOnlineUserByDatabaseId(row.userId);

                // Offline rewards remain queued and are delivered after the player logs in.
                if (user == null) {
                    continue;
                }

                try {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_live_drops SET DeliveryAttempts = DeliveryAttempts + 1, LastError = NULL WHERE id = ?",
                            row.id
                    );
                } catch (Exception ignored) {}

                // Optional server-side eligibility guard used by achievement-linked web rewards.
                if (row.requiredAchievementId > 0 && !hasAchievement(user, row.requiredAchievementId)) {
                    markError(row.id, "Required achievement " + row.requiredAchievementId + " is not unlocked.");
                    continue;
                }

                boolean delivered = deliverLiveDrop(row, user);

                if (delivered) {
                    Storage.getInstance().getJdbc().run(
                            "UPDATE users_live_drops " +
                            "SET Claimed = 1, dropped_at = NOW(), ClaimedAt = NOW(), LastError = NULL " +
                            "WHERE id = ? AND Claimed = 0",
                            row.id
                    );

                    if (row.rewardId > 0) {
                        try {
                            Storage.getInstance().getJdbc().run(
                                    "INSERT INTO account_reward_claims (UserID, RewardID, Status, ClaimedAt, DeliveredAt) " +
                                    "VALUES (?, ?, 'delivered', NOW(), NOW()) " +
                                    "ON DUPLICATE KEY UPDATE Status = 'delivered', DeliveredAt = NOW()",
                                    row.userId,
                                    row.rewardId
                            );
                        } catch (Exception e) {
                            LOGGER.warn("LiveRewards claim sync failed rewardId=" + row.rewardId + ": " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.warn("LiveRewards sync skipped: " + e.getMessage());
            sendEngineMessage("yellow", "[LiveRewards] Sync skipped: " + e.getMessage());
        } finally {
            RUNNING.set(false);
        }
    }

    private boolean deliverLiveDrop(LiveDropRow row, User user) {
        if (row == null || user == null || user.properties == null) {
            return false;
        }

        boolean gaveSomething = false;

        try {
            if (row.gold > 0) {
                Users.getInstance().giveRewards(user, 0, row.gold, 0, 0, 0, 0, 0, 0, user.getUserId(), "p");
                gaveSomething = true;
            }

            if (row.coins > 0) {
                Users.getInstance().giveRewards(user, 0, 0, 0, 0, row.coins, 0, 0, 0, user.getUserId(), "p");
                gaveSomething = true;
            }

            if (row.experience > 0) {
                Users.getInstance().giveRewards(user, row.experience, 0, 0, 0, 0, 0, 0, 0, user.getUserId(), "p");
                gaveSomething = true;
            }

            if (row.classpoints > 0) {
                Users.getInstance().giveRewards(user, 0, 0, row.classpoints, 0, 0, 0, 0, 0, user.getUserId(), "p");
                gaveSomething = true;
            }

            if (row.upgradeDays > 0) {
                Users.getInstance().giveUpgradeDays(user, row.upgradeDays);
                gaveSomething = true;
            }

            // This uses your existing achievement system. It updates users_achievements,
            // legacy achievement fields/quest values, the in-memory set and sends givebadge.
            if (row.achievementId > 0) {
                Users.getInstance().giveAchievement(user, row.achievementId);
                gaveSomething = true;
            }

            if (row.itemId > 0) {
                int safeQuantity = row.quantity <= 0 ? 1 : row.quantity;
                ItemBean itemObj = StorageCache.getInstance().getItem(row.itemId);

                if (itemObj == null) {
                    markError(row.id, "Item " + row.itemId + " does not exist in StorageCache.");
                    return false;
                }

                boolean ownsNonStackable = itemObj.getStack() == 1 && ownsItemAnywhere(row.userId, row.itemId);

                // Non-stackable duplicate rewards are treated as already fulfilled.
                // This prevents the same live row retrying forever when the player owns it
                // in either inventory OR bank.
                if (ownsNonStackable) {
                    gaveSomething = true;
                } else {
                    boolean accepted = queueAndAcceptRewardItem(user, row.itemId, safeQuantity);

                    if (!accepted) {
                        markError(row.id,
                                "Item delivery failed. itemId=" + row.itemId + " qty=" + safeQuantity);
                        return false;
                    }

                    gaveSomething = true;
                }
            }

            // A reward row containing only metadata should not be consumed accidentally.
            if (!gaveSomething) {
                markError(row.id, "Reward row does not contain anything deliverable.");
                return false;
            }

            sendRewardPacket(row, user);

            String message = row.rewardMessage;
            if (message == null || message.trim().isEmpty()) {
                if (row.rewardName != null && !row.rewardName.trim().isEmpty()) {
                    message = "You received " + row.rewardName + "!";
                } else {
                    message = "You received a live reward!";
                }
            }

            Kaiden_Extension.getInstance().sendZoneMessage("server", message, user);

            sendEngineMessage(
                    "cyan",
                    "[LiveRewards] Delivered id=" + row.id +
                            " rewardId=" + row.rewardId +
                            " user=" + user.getName() +
                            " itemId=" + row.itemId +
                            " qty=" + row.quantity +
                            " coins=" + row.coins +
                            " gold=" + row.gold +
                            " xp=" + row.experience +
                            " cp=" + row.classpoints +
                            " upgradeDays=" + row.upgradeDays +
                            " achievementId=" + row.achievementId
            );

            return true;
        } catch (Exception e) {
            String error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            markError(row.id, error);
            LOGGER.warn("LiveRewards delivery failed id=" + row.id + " user=" + user.getName() + ": " + error);
            sendEngineMessage("yellow", "[LiveRewards] Delivery failed id=" + row.id + " user=" + user.getName() + ": " + error);
            return false;
        }
    }

    /**
     * Extra packet for your client/UI. Existing clients can safely ignore it.
     * It gives a future Account Management/client popup enough information to
     * immediately flip an AVAILABLE reward to CLAIMED without relogging.
     */
    private void sendRewardPacket(LiveDropRow row, User user) {
        try {
            JSONObject packet = new JSONObject();
            packet.put("cmd", "accountRewardClaimed");
            packet.put("rewardId", row.rewardId);
            packet.put("rewardKey", row.rewardKey == null ? "" : row.rewardKey);
            packet.put("rewardName", row.rewardName == null ? "" : row.rewardName);
            packet.put("source", row.source == null ? "" : row.source);
            packet.put("sourceId", row.sourceId);
            packet.put("itemId", row.itemId);
            packet.put("quantity", row.quantity <= 0 ? 1 : row.quantity);
            packet.put("coins", row.coins);
            packet.put("gold", row.gold);
            packet.put("experience", row.experience);
            packet.put("classPoints", row.classpoints);
            packet.put("upgradeDays", row.upgradeDays);
            packet.put("achievementId", row.achievementId);
            Kaiden_Extension.getInstance().send(packet, user);
        } catch (Exception ignored) {}
    }



    /**
     * Put the item directly into the normal pending-drop map, then pass it through
     * GetDrop.acceptPendingDrop(). This keeps the normal users_items/in-memory/client
     * update path but intentionally bypasses quest-only drop filtering because an
     * Account Management reward is not a monster/quest drop.
     */
    private boolean queueAndAcceptRewardItem(User user, int itemId, int quantity) {
        try {
            ConcurrentHashMap<Integer, UserDrop> drops =
                    (ConcurrentHashMap<Integer, UserDrop>) user.properties.get("drops");

            if (drops == null) {
                return false;
            }

            UserDrop existing = drops.get(itemId);
            if (existing != null) {
                existing.addQuantity(quantity);
            } else {
                drops.put(itemId, new UserDrop(itemId, quantity, false));
            }

            return GetDrop.acceptPendingDrop(user, itemId, false);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean ownsItemAnywhere(int userId, int itemId) {
        QueryResult result = null;
        try {
            result = Storage.getInstance().getJdbc().query(
                    "SELECT id FROM users_items WHERE UserID = ? AND ItemID = ? LIMIT 1",
                    userId,
                    itemId
            );
            return result.next();
        } catch (Exception e) {
            return false;
        } finally {
            if (result != null) {
                try { result.close(); } catch (Exception ignored) {}
            }
        }
    }

    private boolean hasAchievement(User user, int achievementId) {
        try {
            Set<Integer> achievements = (Set<Integer>) user.properties.get(Properties.ACHIEVEMENTS);
            if (achievements != null && achievements.contains(achievementId)) {
                return true;
            }
            return Users.getInstance().checkAchievements(user, achievementId);
        } catch (Exception e) {
            return false;
        }
    }

    private void markError(int rowId, String error) {
        try {
            if (error == null) {
                error = "Unknown delivery error";
            }
            if (error.length() > 500) {
                error = error.substring(0, 500);
            }
            Storage.getInstance().getJdbc().run(
                    "UPDATE users_live_drops SET LastError = ? WHERE id = ?",
                    error,
                    rowId
            );
        } catch (Exception ignored) {}
    }

    private User getOnlineUserByDatabaseId(int databaseUserId) {
        try {
            Collection<User> users = Kaiden_Extension.getInstance().getAllUsers();

            if (users == null || users.isEmpty()) {
                return null;
            }

            for (User user : users) {
                if (user == null || user.properties == null) {
                    continue;
                }

                Object idObj = user.properties.get(Properties.ID);

                if (idObj instanceof Number && ((Number) idObj).intValue() == databaseUserId) {
                    return user;
                }

                if (idObj != null && String.valueOf(idObj).equals(String.valueOf(databaseUserId))) {
                    return user;
                }
            }
        } catch (Exception ignored) {}

        return null;
    }

    private static String safeString(QueryResult result, String column) {
        try {
            String value = result.getString(column);
            return value == null ? "" : value;
        } catch (Exception ignored) {
            return "";
        }
    }

    private static void sendEngineMessage(String color, String message) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(color, message);
        } catch (Exception ignored) {}
    }

    private static class LiveDropRow {
        final int id;
        final int userId;
        final int itemId;
        final int quantity;
        final int coins;
        final int gold;
        final int experience;
        final int classpoints;
        final int upgradeDays;
        final int achievementId;
        final int requiredAchievementId;
        final int rewardId;
        final String rewardKey;
        final String rewardName;
        final String rewardMessage;
        final String source;
        final int sourceId;
        final int claimed;

        LiveDropRow(int id, int userId, int itemId, int quantity, int coins, int gold,
                    int experience, int classpoints, int upgradeDays, int achievementId,
                    int requiredAchievementId, int rewardId, String rewardKey,
                    String rewardName, String rewardMessage, String source, int sourceId,
                    int claimed) {
            this.id = id;
            this.userId = userId;
            this.itemId = itemId;
            this.quantity = quantity;
            this.coins = coins;
            this.gold = gold;
            this.experience = experience;
            this.classpoints = classpoints;
            this.upgradeDays = upgradeDays;
            this.achievementId = achievementId;
            this.requiredAchievementId = requiredAchievementId;
            this.rewardId = rewardId;
            this.rewardKey = rewardKey;
            this.rewardName = rewardName;
            this.rewardMessage = rewardMessage;
            this.source = source;
            this.sourceId = sourceId;
            this.claimed = claimed;
        }
    }
}
