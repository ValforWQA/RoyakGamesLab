package Kaiden.Game.Discord;

import Kaiden.Kaiden_Engine;
import org.javacord.api.event.message.MessageCreateEvent;
import org.javacord.api.listener.message.MessageCreateListener;

public class Listener implements MessageCreateListener {

    @Override
    public void onMessageCreate(MessageCreateEvent event) {
        // ignore bot messages
        if (event.getMessageAuthor().isBotUser()) return;

        String content = event.getMessageContent();
        if (content == null) return;

        content = content.trim();
        if (content.isEmpty()) return;

        String prefix = Discord.getInstance().getPrefix();
        if (!content.startsWith(prefix)) return;

        String[] args = content.split("\\s+");
        if (args.length == 0) return;

        String cmdName = args[0].substring(prefix.length()).trim().toLowerCase();
        if (cmdName.isEmpty()) return;

        Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",
                "Recieved request from: " + event.getMessageAuthor().getDisplayName() + " - " + cmdName
        );

        DiscordCommandDispatcher.dispatchPrefix(event, cmdName);
    }
}
