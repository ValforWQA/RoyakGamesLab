package Kaiden.Game.Discord;

import Kaiden.Database.Beans.DiscordCommandBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.StorageCache;
import Kaiden.Kaiden_Engine;
import org.javacord.api.DiscordApi;
import org.javacord.api.DiscordApiBuilder;
import org.javacord.api.entity.activity.ActivityType;
import org.javacord.api.interaction.SlashCommand;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Discord {

    public static String prefix = "/";
    public static DiscordApi api;

    public static Discord instance;
    public static long START_TIME = System.currentTimeMillis();

    public static Discord getInstance() {
        if (instance == null) instance = new Discord();
        return instance;
    }

    public void start() {
        // Restrict intents to those required for basic announcements and bot commands.
        // Privileged intents must be enabled separately in the Discord Developer Portal.
        String token = Configuration.DISCORD_BOT_TOKEN == null ? "" : Configuration.DISCORD_BOT_TOKEN.trim();
        if (token.isEmpty() || token.startsWith("Bot ")) {
            throw new IllegalStateException("Invalid Discord bot token configuration (empty or includes Bot prefix).");
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[Discord] Token present: " + (token != null && !token.trim().isEmpty()));
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[Discord] Token length: " + (token == null ? 0 : token.trim().length()));
        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "[Discord] Working directory: " + System.getProperty("user.dir"));

        if (api != null) return; // Prevent duplicate gateway sessions in this JVM.
        api = new DiscordApiBuilder()
                .setToken(token)
                .login()
                .join();

        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Discord Server is ready!");
        api.updateActivity(ActivityType.PLAYING, Configuration.DISCORD_BOT_STATUS);

        // 1) Register slash commands from DB
        registerSlashCommandsFromDb();

        // 2) Slash command dispatcher (DB-driven)
        api.addSlashCommandCreateListener(event -> {
            String cmdName = event.getSlashCommandInteraction().getCommandName();
            DiscordCommandDispatcher.dispatchSlash(event, cmdName);
        });

        // 3) Prefix command listener (DB-driven)
        api.addMessageCreateListener(new Listener());
    }

    public void startUptimeUpdater(long messageId, long channelId) {
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

        scheduler.scheduleAtFixedRate(() -> {
            long uptimeMs = System.currentTimeMillis() - START_TIME;

            String uptime = formatUptime(uptimeMs);

            api.getTextChannelById(channelId).ifPresent(ch ->
                    ch.getMessageById(messageId).thenAccept(msg ->
                            msg.edit("**Kaiden Engine ONLINE**\n Uptime: **" + uptime + "**")
                    )
            );

        }, 0, 2, TimeUnit.SECONDS); // update every 10s
    }

    private String formatUptime(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        seconds %= 60;
        minutes %= 60;
        hours %= 24;

        if (days > 0)
            return days + "d " + hours + "h " + minutes + "m " + seconds + "s";

        if (hours > 0)
            return hours + "h " + minutes + "m " + seconds + "s";

        return minutes + "m " + seconds + "s";
    }

    private void registerSlashCommandsFromDb() {
        Map<String, DiscordCommandBean> all = StorageCache.getInstance().getDiscordCommandsMap();

        if (all == null || all.isEmpty()) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("yellow", "No discord_commands found to register.");
            return;
        }

        for (Map.Entry<String, DiscordCommandBean> e : all.entrySet()) {
            String cmd = e.getKey();
            if (cmd == null) continue;

            cmd = cmd.trim().toLowerCase();
            if (cmd.isEmpty()) continue;

            try {
                // Javacord 3.8.0 global slash command registration
                SlashCommand.with(cmd, "Kaiden command: " + cmd).createGlobal(api);
            } catch (Throwable t) {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "red",
                        "Failed to register slash command: " + cmd + " -> " + t.getMessage()
                );
            }
        }

        Kaiden_Engine.getInstance().sendEmulatorMessage("green", "Slash commands registration requested.");
    }

    public DiscordApi getApi() {
        return api;
    }

    public String getPrefix() {
        return prefix;
    }
}
