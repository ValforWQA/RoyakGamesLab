package Kaiden.Game.Discord;

import Kaiden.Database.Beans.DiscordCommandBean;
import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.StorageCache;
import Kaiden.Game.Server.Packets.Manager.Handlers.DiscordManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.DiscordException;
import Kaiden.Game.Server.Packets.Manager.Handlers.SlashDiscordManager;
import Kaiden.Kaiden_Engine;
import org.javacord.api.entity.permission.Role;
import org.javacord.api.entity.server.Server;
import org.javacord.api.entity.user.User;
import org.javacord.api.event.message.MessageCreateEvent;

import java.util.List;
import java.util.Optional;

public final class DiscordCommandDispatcher {

    private DiscordCommandDispatcher() {}

    // ----------------------------
    // PREFIX DISPATCH
    // ----------------------------
    public static void dispatchPrefix(MessageCreateEvent event, String cmdName) {
        DiscordCommandBean command = StorageCache.getInstance().getDiscordcommands(cmdName);
        if (command == null) return;

        int access = resolveUserAccessForMessage(event);
        if (access < command.getAccess()) return;

        runPrefix(event, command);
    }

    // ----------------------------
    // SLASH DISPATCH
    // ----------------------------
    public static void dispatchSlash(Object slashEvent, String cmdName) {
        DiscordCommandBean command = StorageCache.getInstance().getDiscordcommands(cmdName);
        if (command == null) {
            respondSlash(slashEvent, "Unknown command.");
            return;
        }

        int access = resolveUserAccessForSlash(slashEvent);
        if (access < command.getAccess()) {
            respondSlash(slashEvent, "You do not have permission to use this command.");
            return;
        }

        runSlash(slashEvent, command);
    }

    // ----------------------------
    // RUN PREFIX
    // ----------------------------
    private static void runPrefix(MessageCreateEvent event, DiscordCommandBean command) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",("Discord Command : " + command.getCommand() + " -> " + command.getFileName()));

            DiscordManager request = (DiscordManager) command.getFile().newInstance();
            request.process(event);

        } catch (ClassNotFoundException e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red","Class not found: " + e.getMessage());
        } catch (InstantiationException e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red","Instantiation error: " + e.getMessage());
        } catch (IllegalAccessException e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red","Illegal access error: " + e.getMessage());
        } catch (DiscordException e) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red","Command exception: " + e.getMessage());
        } catch (Throwable t) {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "red","Unknown command error: " + t.getMessage());
        }
    }

    // ----------------------------
    // RUN SLASH
    // ----------------------------
    private static void runSlash(Object slashEvent, DiscordCommandBean command) {
        try {
            Kaiden_Engine.getInstance().sendEmulatorMessage(
                "green",("Discord Command:  " + command.getCommand() + " | " + command.getFileName()));

            Object obj = command.getFile().newInstance();

            if (obj instanceof SlashDiscordManager) {
                ((SlashDiscordManager) obj).processSlash(slashEvent);
            } else {
                respondSlash(slashEvent, "This command is prefix-only right now.");
            }

        } catch (Throwable t) {
            Kaiden_Engine.getInstance().sendEmulatorMessage("red", "Slash command failed: " + t.getMessage());
            respondSlash(slashEvent, "Command failed.");
        }
    }

    // ----------------------------
    // ACCESS: PREFIX
    // ----------------------------
    private static int resolveUserAccessForMessage(MessageCreateEvent event) {
        // Owner -> 4
        if (event.getMessageAuthor().isBotOwner()) return 4;

        Optional<Server> optServer = event.getServer();
        Optional<User> optUser = event.getMessageAuthor().asUser();
        if (!optServer.isPresent() || !optUser.isPresent()) return 1;

        Server server = optServer.get();
        User user = optUser.get();

        // Discord admin -> 3
        if (event.getMessageAuthor().isServerAdmin()) return 3;

        List<Role> roles = user.getRoles(server);

        if (hasRoleMatch(roles, Configuration.DISCORD_ROLE_ADMINISTRATOR)) return 3;
        if (hasRoleMatch(roles, Configuration.DISCORD_ROLE_MODERATOR)) return 2;

        return 1;
    }

    // ----------------------------
    // ACCESS: SLASH
    // Uses reflection so we don't depend on event package naming differences.
    // ----------------------------
    @SuppressWarnings("unchecked")
    private static int resolveUserAccessForSlash(Object slashEvent) {
        try {
            Object interaction = slashEvent.getClass().getMethod("getSlashCommandInteraction").invoke(slashEvent);

            User user = (User) interaction.getClass().getMethod("getUser").invoke(interaction);
            if (user.isBotOwner()) return 4;

            Optional<Server> optServer = (Optional<Server>) interaction.getClass().getMethod("getServer").invoke(interaction);
            if (!optServer.isPresent()) return 1;

            Server server = optServer.get();

            List<Role> roles = user.getRoles(server);

            if (hasRoleMatch(roles, Configuration.DISCORD_ROLE_ADMINISTRATOR)) return 3;
            if (hasRoleMatch(roles, Configuration.DISCORD_ROLE_MODERATOR)) return 2;

            return 1;

        } catch (Throwable t) {
            return 1;
        }
    }

    // ----------------------------
    // ROLE MATCH helper:
    // supports role ID ("123...") or role name ("Administrator")
    // ----------------------------
    private static boolean hasRoleMatch(List<Role> roles, String configured) {
        if (configured == null) return false;
        String v = configured.trim();
        if (v.isEmpty()) return false;

        // If it's numeric, treat as role ID
        String digits = v.replaceAll("[^0-9]", "");
        boolean looksLikeId = digits.length() >= 10;

        if (looksLikeId) {
            final String roleId = digits;
            return roles.stream().anyMatch(r -> String.valueOf(r.getId()).equals(roleId));
        }

        // Otherwise treat as role name (case-insensitive)
        final String roleName = v.toLowerCase();
        return roles.stream().anyMatch(r -> r.getName().toLowerCase().equals(roleName));
    }

    // ----------------------------
    // Respond to slash (best-effort reflection)
    // ----------------------------
    private static void respondSlash(Object slashEvent, String text) {
        try {
            Object interaction = slashEvent.getClass().getMethod("getSlashCommandInteraction").invoke(slashEvent);
            Object responder = interaction.getClass().getMethod("createImmediateResponder").invoke(interaction);
            responder.getClass().getMethod("setContent", String.class).invoke(responder, text);
            responder.getClass().getMethod("respond").invoke(responder);
        } catch (Throwable ignored) {}
    }
}
