package Kaiden.Discord;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Timer;
import java.util.TimerTask;

public final class DiscordHook {

    private DiscordHook() {}

    private static Timer timer;
    private static volatile String lastMessageId;
    private static volatile long startMs;

    /** Sends startup message and begins editing it every intervalMs to show uptime. */
    public static void start(String webhookUrl, String startupText, long intervalMs) {
        stop(webhookUrl, false); // stop any previous timer cleanly

        startMs = System.currentTimeMillis();

        // IMPORTANT: ?wait=true returns message JSON containing the ID
        lastMessageId = sendAndGetMessageId(webhookUrl, startupText);

        // If we couldn't get the ID (webhook blocked, etc), we can’t edit—just bail safely.
        if (lastMessageId == null || lastMessageId.trim().isEmpty()) {
            return;
        }

        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override public void run() {
                long secs = (System.currentTimeMillis() - startMs) / 1000L;
                String content = startupText + " | Uptime: " + formatUptime(secs);
                editMessage(webhookUrl, lastMessageId, content);
            }
        }, intervalMs, intervalMs);
    }

    /** Stops the updater. Optionally edits the message one last time to show offline. */
    public static void stop(String webhookUrl, boolean setOffline) {
        Timer t = timer;
        timer = null;
        if (t != null) {
            try { t.cancel(); } catch (Throwable ignored) {}
        }

        if (setOffline && webhookUrl != null && lastMessageId != null) {
            long secs = (System.currentTimeMillis() - startMs) / 1000L;
            editMessage(webhookUrl, lastMessageId,
                    "Kaiden Engine offline 🔴 | Last Uptime: " + formatUptime(secs));
        }
    }

    /** Sends a webhook message and returns its Discord message id (requires ?wait=true). */
    private static String sendAndGetMessageId(String webhookUrl, String content) {
        HttpURLConnection con = null;
        try {
            URL url = new URL(webhookUrl + "?wait=true");
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setDoOutput(true);

            writeJson(con, content);

            String response = readAll(con);
            return extractJsonString(response, "id");
        } catch (Throwable ignored) {
            return null;
        } finally {
            if (con != null) try { con.disconnect(); } catch (Throwable ignored) {}
        }
    }

    /** Edits a webhook message: PATCH /webhooks/{id}/{token}/messages/{message.id} */
    private static void editMessage(String webhookUrl, String messageId, String newContent) {
        HttpURLConnection con = null;
        try {
            URL url = new URL(webhookUrl + "/messages/" + messageId);
            con = (HttpURLConnection) url.openConnection();

            // Java 8 PATCH workaround
            setRequestMethod(con, "PATCH");

            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setDoOutput(true);

            writeJson(con, newContent);

            // force request + drain response/error
            int code = con.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? con.getInputStream() : con.getErrorStream();
            if (is != null) { try { while (is.read() != -1) {} } catch (Throwable ignored) {} finally { try { is.close(); } catch (Throwable ignored) {} } }

        } catch (Throwable ignored) {
            // ignore to avoid crashing emulator loops
        } finally {
            if (con != null) try { con.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private static void writeJson(HttpURLConnection con, String content) throws Exception {
        String safe = content == null ? "" : content.replace("\\", "\\\\").replace("\"", "\\\"");
        String json = "{ \"content\": \"" + safe + "\" }";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = con.getOutputStream()) {
            os.write(bytes);
            os.flush();
        }
    }

    private static String readAll(HttpURLConnection con) throws Exception {
        InputStream is = con.getInputStream();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder(256);
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    /** Tiny JSON string extractor for simple Discord webhook responses (no extra libs). */
    private static String extractJsonString(String json, String key) {
        if (json == null) return null;
        String needle = "\"" + key + "\":\"";
        int idx = json.indexOf(needle);
        if (idx < 0) return null;
        int start = idx + needle.length();
        int end = json.indexOf("\"", start);
        if (end < 0) return null;
        return json.substring(start, end);
    }

    private static void setRequestMethod(HttpURLConnection con, String method) throws Exception {
        try {
            con.setRequestMethod(method);
        } catch (java.net.ProtocolException pe) {
            // Reflection hack for JDK8: set private 'method' field
            Field f = HttpURLConnection.class.getDeclaredField("method");
            f.setAccessible(true);
            f.set(con, method);
        }
    }

    private static String formatUptime(long seconds) {
        long h = seconds / 3600L;
        long m = (seconds % 3600L) / 60L;
        long s = seconds % 60L;
        return pad2(h) + ":" + pad2(m) + ":" + pad2(s);
    }

    private static String pad2(long v) {
        return (v < 10) ? ("0" + v) : String.valueOf(v);
    }
}
