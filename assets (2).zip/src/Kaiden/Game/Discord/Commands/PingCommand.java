package Kaiden.Game.Discord.Commands;

import Kaiden.Game.Server.Packets.Manager.Handlers.DiscordManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.DiscordException;
import Kaiden.Game.Server.Packets.Manager.Handlers.SlashDiscordManager;
import org.javacord.api.event.message.MessageCreateEvent;

public class PingCommand extends DiscordManager implements SlashDiscordManager {

    @Override
    public void process(MessageCreateEvent event) throws DiscordException {
        long ws = event.getApi().getLatestGatewayLatency().toMillis();
        event.getChannel().sendMessage("🏓 Pong! WS: " + ws + "ms");
    }

    @Override
    public void processSlash(Object slashEvent) throws DiscordException {
        // reflection to avoid package name dependency
        try {
            Object interaction = slashEvent.getClass().getMethod("getSlashCommandInteraction").invoke(slashEvent);
            long ws = ((org.javacord.api.DiscordApi) slashEvent.getClass().getMethod("getApi").invoke(slashEvent))
                    .getLatestGatewayLatency().toMillis();

            Object responder = interaction.getClass().getMethod("createImmediateResponder").invoke(interaction);
            responder.getClass().getMethod("setContent", String.class).invoke(responder, "🏓 Pong! WS: " + ws + "ms");
            responder.getClass().getMethod("respond").invoke(responder);
        } catch (Throwable ignored) {}
    }
}
