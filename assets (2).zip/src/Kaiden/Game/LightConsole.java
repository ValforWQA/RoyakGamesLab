package Kaiden.Game;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Users.Utils.ServerCountManager;
import Kaiden.Kaiden_Engine;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.lang.management.ManagementFactory;
import java.text.DecimalFormat;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Lightweight per-instance Kaiden console.
 * Deliberately avoids charts, DB polling and large tables so several emulator
 * processes can stay open with very little UI overhead.
 */
public final class LightConsole extends JFrame {
    private static final AtomicReference<LightConsole> INSTANCE = new AtomicReference<>();
    private static final long STARTED = System.currentTimeMillis();

    private final JTextArea log = new JTextArea();
    private final JLabel server = new JLabel();
    private final JLabel players = new JLabel();
    private final JLabel memory = new JLabel();
    private final JLabel uptime = new JLabel();
    private final Timer timer;

    private LightConsole() {
        super("Kaiden - " + safe(Configuration.SERVER_NAME));
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setSize(780, 430);
        setMinimumSize(new Dimension(600, 320));
        setLocationByPlatform(true);

        JPanel top = new JPanel(new GridLayout(1, 4, 8, 0));
        top.setBorder(new EmptyBorder(8, 8, 8, 8));
        top.add(server); top.add(players); top.add(memory); top.add(uptime);

        log.setEditable(false);
        log.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        DefaultCaret caret = (DefaultCaret) log.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        JButton clear = new JButton("Clear");
        clear.addActionListener(e -> log.setText(""));
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(clear);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(log), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        timer = new Timer(1000, e -> refreshStats());
        timer.start();
        refreshStats();
    }

    public static void open(Kaiden_Engine engine) {
        SwingUtilities.invokeLater(() -> {
            LightConsole c = INSTANCE.get();
            if (c == null) {
                c = new LightConsole();
                if (!INSTANCE.compareAndSet(null, c)) c = INSTANCE.get();
            }
            c.setVisible(true);
            c.toFront();
            append("[SYSTEM] Light console attached to " + safe(Configuration.SERVER_NAME));
        });
    }

    public static void append(String message) {
        if (message == null) return;
        SwingUtilities.invokeLater(() -> {
            LightConsole c = INSTANCE.get();
            if (c != null) c.log.append(message + System.lineSeparator());
        });
    }

    public static void closeConsole() {
        SwingUtilities.invokeLater(() -> {
            LightConsole c = INSTANCE.getAndSet(null);
            if (c != null) {
                c.timer.stop();
                c.dispose();
            }
        });
    }

    private void refreshStats() {
        long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long max = Runtime.getRuntime().maxMemory();
        server.setText("Server: " + safe(Configuration.SERVER_NAME));
        players.setText("Players: " + ServerCountManager.getOnlineCount());
        memory.setText("RAM: " + mb(used) + " / " + mb(max) + " MB");
        uptime.setText("Uptime: " + formatDuration(System.currentTimeMillis() - STARTED));
    }

    private static long mb(long bytes) { return bytes / 1024L / 1024L; }
    private static String safe(String s) { return s == null || s.trim().isEmpty() ? "Unnamed" : s; }
    private static String formatDuration(long ms) {
        long sec = ms / 1000L;
        long h = sec / 3600L; sec %= 3600L;
        long m = sec / 60L; sec %= 60L;
        return String.format("%02d:%02d:%02d", h, m, sec);
    }
}
