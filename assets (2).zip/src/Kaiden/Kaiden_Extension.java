package Kaiden;

import Kaiden.Game.Server.Users.Properties;
import it.gotoandplay.smartfoxserver.data.Room;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import it.gotoandplay.smartfoxserver.extensions.AbstractExtension;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.nio.channels.SocketChannel;
import java.util.Collection;
import java.util.LinkedList;

public class Kaiden_Extension {
    private static Kaiden_Extension instance;
    public static Kaiden_Extension getInstance() {
        if (instance == null) {
            instance = new Kaiden_Extension();
        }
        return instance;
    }

    private Zone zone;
    private ExtensionHelper extensionHelper;
    private AbstractExtension extension;

    public AbstractExtension getExtension() {
        return extension;
    }

    public void setExtension(AbstractExtension extension) {
        this.extension = extension;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public void setExtensionHelper(ExtensionHelper extensionHelper) {
        this.extensionHelper = extensionHelper;
    }

    public Zone getZone() {
        return this.zone;
    }

    public ExtensionHelper getHelper() {
        return this.extensionHelper;
    }

    public Kaiden_Engine getEmulator() {
        return (Kaiden_Engine) extension;
    }

    // ============================================================
    // ✅ OUTBOUND PACKET LOGGING HELPERS (String[] + JSONObject)
    // ============================================================

    private void logOut(String tag, String[] params, User user, int roomId, LinkedList channels) {
        try {
            String uName = (user != null ? user.getName() : "null");
            int uId = (user != null ? user.getUserId() : -1);
            int chCount = (channels != null ? channels.size() : 0);

            // Most of your protocol is cmd in params[0]
            String cmd = (params != null && params.length > 0 ? params[0] : "null");

            //Kaiden_Engine.LOGGER.info(
                  //  "[XT ][OUT] tag=" + tag +
                          //  " cmd=" + cmd +
                           // " room=" + roomId +
                            //" user=" + uName + "(" + uId + ")" +
                           // " channels=" + chCount +
                           // " data=" + Arrays.toString(params)
            //);
        } catch (Exception e) {
            //Kaiden_Engine.LOGGER.warn("[XT ][OUT] logOut failed (String[]).", e);
        }
    }

    private void logOut(String tag, JSONObject params, User user, int roomId, LinkedList channels) {
        try {
            String uName = (user != null ? user.getName() : "null");
            int uId = (user != null ? user.getUserId() : -1);
            int chCount = (channels != null ? channels.size() : 0);

            String cmd = (params != null && params.has("cmd") ? params.getString("cmd") : "null");

            //Kaiden_Engine.LOGGER.info(
                   // "[JSON][OUT] tag=" + tag +
                     //       " cmd=" + cmd +
                       //     " room=" + roomId +
                         //   " user=" + uName + "(" + uId + ")" +
                           // " channels=" + chCount +
                            //" json=" + (params != null ? params.toString() : "null")
            //);
        } catch (Exception e) {
            //Kaiden_Engine.LOGGER.warn("[JSON][OUT] logOut failed (JSONObject).", e);
        }
    }

    // ============================================================
    // Existing methods with logging added
    // ============================================================

    public void sendToUsers(JSONObject params) {
        LinkedList channels = this.getZone().getChannelList();
        logOut("sendToUsers(JSONObject)", params, null, -1, channels);
        this.extension.sendResponse(params, -1, null, channels);
    }

    public void sendToUsers(String[] params) {
        LinkedList channels = this.getZone().getChannelList();
        logOut("sendToUsers(String[])", params, null, -1, channels);
        this.extension.sendResponse(params, -1, null, channels);
    }

    public void send(JSONObject params, LinkedList channels) {
        logOut("send(JSONObject, channels)", params, null, -1, channels);
        this.extension.sendResponse(params, -1, null, channels);
    }

    public void send(JSONObject params, User user) {
        if (user != null && params != null) {
            LinkedList channels = new LinkedList();
            channels.add(user.getChannel());
            logOut("send(JSONObject, user)", params, user, -1, channels);
            this.extension.sendResponse(params, -1, user, channels);
        }
    }

    public void send(String[] params, SocketChannel chan) {
        if (chan != null && params != null) {
            LinkedList channels = new LinkedList();
            channels.add(chan);
            logOut("send(String[], chan)", params, null, -1, channels);
            this.extension.sendResponse(params, -1, null, channels);
        }
    }

    public void send(String[] params, User user) {
        if (user != null && params != null) {
            LinkedList channels = new LinkedList();
            channels.add(user.getChannel());
            logOut("send(String[], user)", params, user, -1, channels);
            this.extension.sendResponse(params, -1, user, channels);
        }
    }

    public void send(String[] params, LinkedList channels) {
        logOut("send(String[], channels)", params, null, -1, channels);
        this.extension.sendResponse(params, -1, null, channels);
    }

    public void sendToRoom(JSONObject params, User user, Room room) {
        if (user != null && room != null) {
            if (user.getRoom() == room.getId()) {
                LinkedList channels = room.getChannellList();
                logOut("sendToRoom(JSONObject)", params, user, room.getId(), channels);
                this.extension.sendResponse(params, room.getId(), user, channels);
            }
        }
    }

    public void sendZoneMessage(String zone, String message, User user) {
        this.send( new String[]{"server", message}, user
        );
    }

    public void sendToUser(String msgType, String msg, User user) {
        this.send(new String[]{msgType, msg}, user);
    }

    public void sendToStaffUser(String msgType, String msg, User user) {
        if((int)user.properties.get(Properties.ACCESS) >= 50) {
            this.send(new String[]{msgType, msg}, user);
        }
    }

    public void sendDangerAreaMessage(String msg, User user) {
            this.send(new String[]{"dangerarea", msg}, user);
    }

    public void sendModeratorMessage(String msg, User user) {
            this.send(new String[]{"moderator", msg}, user);
    }

    public void sendServerMessage(String msg, User user) {
        this.send(new String[]{"server", msg}, user);
    }

    public Collection<User> getAllUsers() {
        Collection<User> users = this.getZone().getUserList();
        return users;
    }

    public void sendToStaff(String[] params, User user) {
        LinkedList channels = new LinkedList();
        Collection<User> users = this.getZone().getUserList();
        for (User _user : users) {
            if ((int) user.properties.get("access") >= 15) {
                channels.add(_user.getChannel());
            }
        }
        logOut("sendToStaff(String[])", params, user, -1, channels);
        this.extension.sendResponse(params, -1, user, channels);
    }

    public void sendToRoom(String[] params, User user, Room room) {
        if (user != null && room != null) {
            if (user.getRoom() == room.getId()) {
                LinkedList channels = room.getChannellList();
                logOut("sendToRoom(String[])", params, user, room.getId(), channels);
                this.extension.sendResponse(params, room.getId(), user, channels);
            }
        }
    }

    public void sendToRoomButOne(JSONObject o, User _user, Room room) {
        if (_user != null && room != null) {
            User[] _users = room.getAllUsersButOne(_user);
            LinkedList channels = new LinkedList();
            for (User user : _users) {
                if (user != null) {
                    channels.add(user.getChannel());
                }
            }
            logOut("sendToRoomButOne(JSONObject)", o, _user, room.getId(), channels);
            this.extension.sendResponse(o, room.getId(), _user, channels);
        }
    }

    public void sendToRoomButOne(String[] o, User _user, Room room) {
        if (_user != null && room != null) {
            User[] _users = room.getAllUsersButOne(_user);
            LinkedList channels = new LinkedList();
            for (User user : _users) {
                if (user != null) {
                    channels.add(user.getChannel());
                }
            }
            logOut("sendToRoomButOne(String[])", o, _user, room.getId(), channels);
            this.extension.sendResponse(o, room.getId(), _user, channels);
        }
    }

    public void sendNormalModal(String msg, String Color, User user) {
        JSONObject modal = new JSONObject();
        modal.put("cmd", "modalmc");
        modal.put("msg", msg);
        modal.put("glow", Color);
        this.send(modal, user);
    }

    public void sendToGuild(JSONObject params, JSONObject guildObj) {
        JSONArray members = (JSONArray) guildObj.get("ul");
        if (members != null && members.size() > 0) {
            for (Object member1 : members) {
                JSONObject member = (JSONObject) member1;
                User guildMember = Kaiden_Extension.getInstance().getZone()
                        .getUserByName(member.get("userName").toString().toLowerCase());
                if (guildMember != null) {
                    this.send(params, guildMember);
                }
            }
        }
    }

    public void sendToGuild(String[] params, JSONObject guildObj) {
        JSONArray members = (JSONArray) guildObj.get("ul");
        if (members != null && members.size() > 0) {
            for (Object member1 : members) {
                JSONObject member = (JSONObject) member1;
                User guildMember = Kaiden_Extension.getInstance().getZone()
                        .getUserByName(member.get("userName").toString().toLowerCase());
                if (guildMember != null) {
                    this.send(params, guildMember);
                }
            }
        }
    }

    public void sendGuildUpdate(JSONObject guildObj) {
        this.sendGuildUpdateButOne(null, guildObj);
    }

    public void sendGuildUpdateButOne(User user, JSONObject guildObj) {
        JSONObject updateGuild = new JSONObject();
        JSONArray members = (JSONArray) guildObj.get("ul");
        if (members != null && members.size() > 0) {
            LinkedList channels = new LinkedList();
            for (Object member1 : members) {
                JSONObject member = (JSONObject) member1;
                User guildMember = Kaiden_Extension.getInstance().getZone()
                        .getUserByName(member.get("userName").toString().toLowerCase());
                if (guildMember != null && (!guildMember.equals(user))) {
                    guildMember.properties.put("guildobj", guildObj);
                    updateGuild.put("cmd", "updateGuild");
                    updateGuild.put("guild", guildObj);
                    channels.add(guildMember.getChannel());
                }
            }
            logOut("sendGuildUpdateButOne(JSONObject)", updateGuild, user, -1, channels);
            this.extension.sendResponse(updateGuild, -1, user, channels);
        }
    }
}
