package Kaiden;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Database.Configuration.Log.Ansi;
import Kaiden.Database.Configuration.Log.Log;
import Kaiden.Database.Storage;
import Kaiden.Database.StorageCache;
import Kaiden.Game.ServerManagerUI;
import Kaiden.Game.Discord.Discord;
import Kaiden.Game.Server.Packets.Manager.CommandPacketManager;
import Kaiden.Game.Server.Packets.Manager.ExternalPacketManager;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestExternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.RequestInternalPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.Exceptions.UnknownPacketException;
import Kaiden.Game.Server.Packets.Manager.Handlers.ExternalPacketHandler;
import Kaiden.Game.Server.Packets.Manager.Handlers.InternalPacketHandler;
import Kaiden.Game.Server.Packets.Manager.InternalPacketManager;
import Kaiden.Game.Server.Packets.Manager.ThreadPacketManager;
import Kaiden.Game.Server.Users.Utils.ServerCountManager;
import Kaiden.Game.Threads.Executor;
import Kaiden.Game.Threads.SessionKeepAlive;
import Kaiden.Game.Threads.WorldBossSpawner;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;
import it.gotoandplay.smartfoxserver.extensions.AbstractExtension;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import it.gotoandplay.smartfoxserver.lib.ActionscriptObject;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledFuture;

// Decompiled by AS3 Sorcerer 6.20
// www.as3sorcerer.com
//Game
////Vy9Z!Y0PB/3-89VPogtP1xhNz6wM34MC58b
//34.121.104.69
//npx electron-builder --publish always
//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

public class Kaiden_Engine extends AbstractExtension {

    private static final Logger LOGGER = Logger.getLogger("KaidenEngine");
    private static final Timestamp BOOT_TS = Timestamp.from(Instant.now());
    public static long getBootMillis() { return BOOT_TS.getTime(); }

    public static Kaiden_Engine instance;

    private ScheduledFuture<?> sessionKeepAliveTask;

    public static Kaiden_Engine getInstance() {
        if (instance == null) {
            instance = new Kaiden_Engine();
        }
        return instance;
    }

    private final List<String> allowed = Arrays.asList(
            "mv", "mtcid", "retrieveUserData", "retrieveUserDatas",
            "afk", "aggroMon", "gar", "emotea", "buyLoadoutSlots", "resTimed"
    );

    private static String prefix(String message) {
        return "[KaidenEngine] - " + message;
    }

    private void logInfo(String message) {
        LOGGER.info(prefix(message));
    }

    private static void logInfo(String color, String message) {
        LOGGER.info(color + prefix(message) + Ansi.RESET);
    }

    private void logWarn(String message) {
        LOGGER.warn(prefix(message));
    }

    private void logWarn(String color, String message) {
        LOGGER.warn(color + prefix(message) + Ansi.RESET);
    }

    private void logError(String message) {
        LOGGER.error(prefix(message));
    }

    private void logError(String color, String message) {
        LOGGER.error(color + prefix(message) + Ansi.RESET);
    }

    @Override
    public void init() {
        PropertyConfigurator.configure("Configuration/log4j.properties");

        logInfo(Ansi.GOLD, "Loading configuration...");
        if (!Configuration.load()) {
            logError(Ansi.RED, "Configuration failed to load.");
            return;
        }

        try {
            logInfo(Ansi.GOLD, "Binding SmartFox extensions...");
            Kaiden_Extension.getInstance().setExtension(this);
            Kaiden_Extension.getInstance().setExtensionHelper(ExtensionHelper.instance());
            Kaiden_Extension.getInstance().setZone(
                    ExtensionHelper.instance().getZone(this.getOwnerZone())
            );

            logInfo(Ansi.GOLD, "Loading server feature cache...");
            StorageCache.getInstance().RetrieveStorageBeans("features");

            logInfo(Ansi.GOLD, "Initializing packet managers...");
            InternalPacketManager.getInstance();
            ExternalPacketManager.getInstance();
            CommandPacketManager.getInstance();

            logInfo(Ansi.GOLD, "Loading storage cache...");
            StorageCache.getInstance().RetrieveStorageBeans("all");

            logInfo(Ansi.GOLD, "Starting background threads...");
            // Freeing idle DB connections too aggressively can stall JDBC work on older pool implementations.
            // Run this less often and let the task self-skip while connections are active.
            ThreadPacketManager.getInstance().initializeThreads();
            startSessionKeepAlive();
            Executor.getInstance().scheduleTask(new Kaiden.Game.Threads.PlayerAfkMonitor(), 30L, 30L, TimeUnit.SECONDS, true);

            // The GUI host is management-only. A DB server row is activated only by a child world
            // started from ServerManagerUI.
            if (Boolean.getBoolean("kaiden.manager.child") || !Configuration.ALLOW_INTERFACE) {
                logInfo(Ansi.GOLD, "Resetting server count...");
                ServerCountManager.resetOnBoot();
            } else {
                logInfo(Ansi.GOLD, "Manager host ready; no server row activated.");
            }

            notifyRuntime();

            if (Configuration.ALLOW_INTERFACE) {
                logInfo(Ansi.GOLD, "Launching admin control panel...");
                ServerManagerUI.open(this);
            } else {
                logWarn(Ansi.RED, "Skipping interface load.");
            }

            startDiscordSafely();

            logInfo(Ansi.BG_GREEN, "Kaiden is Running!!.");
        } catch (Exception e) {
            Log.error("Kaiden_Engine.init", e);
        }
    }

    private void startSessionKeepAlive() {
        try {
            if (this.sessionKeepAliveTask != null && !this.sessionKeepAliveTask.isCancelled()) {
                return;
            }

            this.sessionKeepAliveTask = Executor.getInstance().scheduleTask(
                    new SessionKeepAlive(),
                    60L,
                    240L,
                    TimeUnit.SECONDS,
                    true
            );

            sendEmulatorMessage("green", "[SessionKeepAlive] enabled every 240 seconds.");
        } catch (Exception e) {
            Log.error("SessionKeepAlive", e);
        }
    }

    private void startDiscordSafely() {
        if (Configuration.DISCORD_BOT_TOKEN == null || Configuration.DISCORD_BOT_TOKEN.trim().isEmpty()) {
            logWarn("Discord bot token is empty. Skipping Discord startup.");
            return;
        }

        try {
            logInfo(Ansi.GOLD, "Starting Discord integration...");
            Discord.getInstance().start();

            if (Discord.getInstance().getApi() == null) {
                logWarn("Discord API is not ready yet. Skipping startup announcement.");
                return;
            }

            if (Configuration.DISCORD_CHANNEL_ANNOUNCEMENT == null
                    || !Configuration.DISCORD_CHANNEL_ANNOUNCEMENT.matches("[0-9]{15,22}")) {
                logWarn("Discord announcement channel ID missing or invalid. Skipping startup announcement.");
                return;
            }
            Discord.getInstance()
                    .getApi()
                    .getTextChannelById(Configuration.DISCORD_CHANNEL_ANNOUNCEMENT)
                    .ifPresent(ch ->
                            ch.sendMessage("Starting Kaiden Engine…")
                                    .thenAccept(msg -> {
                                        Discord.getInstance().startUptimeUpdater(msg.getId(), ch.getId());
                                        ch.sendMessage("@everyone");
                                    })
                    );
        } catch (Exception e) {
            Log.error("Discord startup", e);
        }
    }

    @Override
    public void destroy() {
        logWarn(Ansi.RED, "Kaiden Engine stopped.");

        try {
            if (this.sessionKeepAliveTask != null) {
                this.sessionKeepAliveTask.cancel(false);
                this.sessionKeepAliveTask = null;
            }
        } catch (Exception ignored) {}

        try {
            ThreadPacketManager.getInstance().stopAll();
        } catch (Exception e) {
            Log.error("ThreadPacketManager.stopAll", e);
        }

        try {
            if (Discord.getInstance().getApi() != null
                    && Configuration.DISCORD_CHANNEL_ANNOUNCEMENT != null
                    && Configuration.DISCORD_CHANNEL_ANNOUNCEMENT.matches("[0-9]{15,22}")) {
                Discord.getInstance()
                        .getApi()
                        .getTextChannelById(Configuration.DISCORD_CHANNEL_ANNOUNCEMENT)
                        .ifPresent(ch ->
                                ch.sendMessage("Kaiden Engine stopped…")
                                        .thenAccept(msg -> ch.sendMessage("@everyone"))
                        );
            }
        } catch (Exception e) {
            Log.error("Kaiden_Engine.destroy", e);
        }
    }

    @Override
    public void handleRequest(String cmd, String[] params, User user, int fromRoom) {
        if (user != null && user.properties != null && cmd != null
                && !"afk".equalsIgnoreCase(cmd) && !"heartbeat".equalsIgnoreCase(cmd)
                && !"ping".equalsIgnoreCase(cmd) && !"resTimed".equalsIgnoreCase(cmd)) {
            user.properties.put("lastPlayerActivity", System.currentTimeMillis());
            if (Boolean.TRUE.equals(user.properties.get("afk"))) {
                Kaiden.Game.Threads.PlayerAfkMonitor.setAfk(user, false);
            }
        }
        ExternalPacketHandler handler = ExternalPacketManager.getInstance().get(cmd);
        logInfo(Ansi.GOLD, "[External packet: " + cmd + "]");

        if (handler != null) {
            try {
                if (!Kaiden.Database.StorageCache.getInstance().isServerFeatureEnabled(cmd)) {
                    throw new RequestExternalPacketException(" This feature has been disabled by the engine owner.");
                }

                handler.user = user;
                handler.params = params;
                handler.room = Kaiden_Extension.getInstance().getZone().getRoom(
                        (fromRoom != 1 && fromRoom != 32123 && fromRoom > 0)
                                ? fromRoom
                                : user.getRoom()
                );
                handler.handle();
            } catch (RequestExternalPacketException error) {
                Kaiden_Extension.getInstance().send(
                        new String[]{error.getType(), error.getMessage()}, user
                );
            } catch (Exception e) {
                Log.error(cmd, e);
            }
        } else {
            logError(Ansi.RED, "[Invalid external packet: " + cmd + "]");
        }
    }

    @Override
    public void handleInternalEvent(InternalEventObject ieo) {
        try {
            String name = ieo.getEventName();
            InternalPacketHandler handler = InternalPacketManager.getInstance().get(name);
            //logInfo(Ansi.GOLD, "[Internal packet: " + name + "]");

            if (handler != null) {
                handler.handle(ieo);
            } else {
                //logError(Ansi.RED, "[Invalid internal packet: " + name + "]");
            }
        } catch (UnknownPacketException | RequestInternalPacketException | NullPointerException e) {
            Log.error(ieo.getEventName(), e);
        }
    }

    public static void sendEmulatorMessage(String colorName, String message) {
        String color;

        switch (colorName.toLowerCase()) {
            case "red":
                color = Ansi.RED;
                break;
            case "green":
                color = Ansi.GREEN;
                break;
            case "yellow":
                color = Ansi.YELLOW;
                break;
            case "gold":
                color = Ansi.GOLD;
                break;
            case "blue":
                color = Ansi.BLUE;
                break;
            case "cyan":
                color = Ansi.CYAN;
                break;
            case "white":
                color = Ansi.WHITE;
                break;
            case "pink":
                color = Ansi.LIGHT_PINK;
                break;
            case "pinkd":
                color = Ansi.PINK;
                break;
            case"purple":
            color = Ansi.PURPLE;
                break;
            default:
                color = Ansi.RESET;
                break;
        }

        logInfo(color, message);
    }
    public synchronized void reloadRuntimeSystems() {
        long start = System.currentTimeMillis();

        try {
            sendEmulatorMessage("yellow", "[Reload] Safe runtime reload started.");
            sendEmulatorMessage("yellow", "[Reload] Reloading configuration...");
            Configuration.load();

            sendEmulatorMessage("yellow", "[Reload] Reloading server feature cache...");
            StorageCache.getInstance().RetrieveStorageBeans("features");

            sendEmulatorMessage("yellow", "[Reload] Reloading full storage cache...");
            StorageCache.getInstance().RetrieveStorageBeans("all");

            sendEmulatorMessage("yellow", "[Reload] Reloading internal packet handlers...");
            InternalPacketManager.getInstance().reload();

            sendEmulatorMessage("yellow", "[Reload] Reloading external packet handlers...");
            ExternalPacketManager.getInstance().reloadFromStorage();

            sendEmulatorMessage("yellow", "[Reload] Reloading command handlers...");
            CommandPacketManager.getInstance().reload();

            sendEmulatorMessage("green", "[Reload] Safe runtime reload completed in " + (System.currentTimeMillis() - start) + "ms. Online players, rooms, combat state, and data were not cleared.");
        } catch (Exception e) {
            sendEmulatorMessage("red", "[Reload] Runtime reload failed: " + e.getMessage());
            Log.error("reloadRuntimeSystems", e);
        }
    }


    public static void notifyRuntime() {
        if(!Configuration.SERVER_NAME.equals("Valfor Testing Realm")) {
            Storage.getInstance().getJdbc().run(
                    "UPDATE servers_runtime " +
                            "SET Status='operational', UpdatedAt=?, DownAt=NULL, StartedAt=? " +
                            "WHERE id=1",
                    Timestamp.from(Instant.now()),
                    BOOT_TS
            );
        }
    }

    public void notifyDowntime() {
        if(!Configuration.SERVER_NAME.equals("Valfor Testing Realm")) {
            Storage.getInstance().getJdbc().run(
                    "UPDATE servers_runtime " +
                            "SET downAt = NOW(), " +
                            "    downAt = CASE " +
                            "      WHEN StartedAt IS NULL THEN NOW() " +
                            "      WHEN StartedAt = '0000-00-00 00:00:00' THEN NOW() " +
                            "      ELSE StartedAt " +
                            "    END"
            );
        }
    }

    @Override
    public void handleRequest(String cmd, ActionscriptObject ao, User user, int fromRoom) {
        throw new UnsupportedOperationException("ActionScriptObject requests are not supported.");
    }
}
