package Kaiden;
// # ADDS #
// #Guild Command
// #Party Command
// #Aura Handler
// #Update MonsterAI (Skills And Aura Factory) \\ monster killing in a seperate room under the same id kills monsters in | room
// #Extension Update
// #User State + User State # fixed
// #Rest Healing Factory
// #Automated UpgradeDays Handler by expiredate
// # applied
// #set state for healing when moving cell's
// # adding double health regen for (Regeneration) task # currently testing
// #update stats uptime for stats in moderator command
// #combat action monster state (nuetral) after player kill
// #res player timed (fixed) # (next) auras clear aswell(in motion removes monster target if no character is bound or dead
//
// # map monster / NPC Scaling +X / Y
//
// # maybe add regen hp and mana based off monster kills only by 6%.
//
// # grabber #
// #remove swf list from shop button & create its own button for faster load time. \ items & swf togethe crashed load time # (finished) load time 0.3MS
//
//
// #user regen stuck during combat CombatAction line 338
//
// # Monster insert for panel
// # Req For items
// # Dankai's Storyline
//
// # crash site's defense #noob cutscene!
// # atleast 16 quest's 1 class and noobite items... + enhancements
// # element count is working properly.
// #add faction points/level
// #prestige system works based off level + collected souls
//
//
//
// #RoyakGames Website
// # fix browser side panel. - done
// # monster skills finished
// # fixed regen on map leave & monster targets
// # lifesteal,repell,heal,instantdeath, -> add more
//
// #update items cost, for each item for panel
// #update tables for npc's added backwards
// # rework buyitem
// #discord rpc for browser lastlocation - finished need rpc
// #HOT \ DOT cancels after aura removes - finished


// complete all proc auras.

/*
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('1', '1', '1', 'Radiance', '16', '0.00', '0.00');
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('1', '1', '1', 'Radiance', '16', '0.00', '0.00');
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('1', '1', '0', 'Energy Flow', '12', '0.00', '0.00');
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('2', '2', '0', 'Inhibition', '8', '0.00', '0.00');
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('1', '1', '1', 'Spiral Carve', '10', '0.00', '0.00');
INSERT INTO `auras` (`id`, `IconID`, `Self`, `Name`, `Duration`, `DamageIncrease`, `DamageTakenDecrease`) VALUES ('2', '2', '1', 'Radiance', '16', '0.00', '0.00');


Melee (low mana return rely on sustained hits)
Ranged (moderate mana return crits matter)
Caster (lower base high crit encourage burst damage)
Hybrid (balanced sustainable)
Dot (low crit steady mana)

  double healing for healing




  public class ManaRegenSystem {

    public enum CombatArchetype {
        MELEE(0.03, 0.4),
        RANGED(0.04, 0.6),
        CASTER(0.02, 0.8),
        HYBRID(0.035, 0.5),
        DOT(0.015, 0.0);

        private final double baseRate;
        private final double critScaling;

        CombatArchetype(double baseRate, double critScaling) {
            this.baseRate = baseRate;
            this.critScaling = critScaling;
        }

        public double getBaseRate() {
            return baseRate;
        }

        public double getCritScaling() {
            return critScaling;
        }
    }

    /**
     * Calculates mana returned from a hit.
     *
     * @param damage damage dealt
     * @param critMultiplier crit multiplier (1.0 = normal hit, 2.0 = 200% crit)
     * @param archetype combat archetype
     * @return mana restored

public static double calculateManaReturn(double damage, double critMultiplier, CombatArchetype archetype) {

    double baseRate = archetype.getBaseRate();
    double critScaling = archetype.getCritScaling();
   add browser achievements
    return damage * baseRate * (1 + (critMultiplier - 1) * critScaling);
}s
}
 maybe call other auras from auras???
 re work skill range
 pull / stop same room / multiple times
 double sync on monster base -> monster regener


 fix casting time for monsters skills

 stop skills from dealing final damages from players

 UPDATE ROYAKGAMES BROWSER.
 */



/*
 # june completions
 #Monster Skill & Mana sync
 #Quest Progression & Item Load
 #Reduce Emulator lag by 60%


 selfDamage = dealtDamage * 0.06;

// New
selfDamage = dealtDamage * 0.10;

and keep the protection:

int minSelfDamage = (int)(player.getMaxHealth() * 0.02);
int maxSelfDamage = (int)(player.getMaxHealth() * 0.12);

selfDamage = Math.max(minSelfDamage, selfDamage);
selfDamage = Math.min(maxSelfDamage, selfDamage);

// Never kill the player
selfDamage = Math.min(selfDamage, player.getHealth() - 1);


  ADD DEV PREV FOR ME CONSTANTLY IF IM NOT STAFF

  fix MapSnapshotSupport for panel connection issues 

all above is patched.

   check out Game.as:3936

   adjust session time for panel

   adjust protosatorium classs
 */



