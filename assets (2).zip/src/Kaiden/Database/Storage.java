package Kaiden.Database;

import Kaiden.Database.Configuration.Configuration;
import com.mysql.cj.jdbc.MysqlConnectionPoolDataSource;
import jdbchelper.ConnectionPool;
import jdbchelper.JdbcHelper;
import jdbchelper.PooledDataSource;
import org.apache.log4j.Logger;

import java.sql.SQLException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class Storage {
    private static Storage instance;
    private static final AtomicBoolean KEEPALIVE_RUNNING = new AtomicBoolean(false);
    private static final AtomicBoolean POOL_RECOVERING = new AtomicBoolean(false);
    private static final AtomicLong BUSY_SINCE = new AtomicLong(0L);
    private static final Logger LOGGER = Logger.getLogger(Storage.class);

    public static Storage getInstance() {
        if (instance == null) {
            instance = new Storage();
            LOGGER.debug("Running Connection For: [" + Configuration.DB_HOST + "]...");
            LOGGER.debug("Running Connection on Port: [" + Configuration.DB_PORT + "]...");
            LOGGER.debug("Setting Max Connections: [" + Configuration.DB_MAX_CONNECTIONS + "]...");
            LOGGER.debug("Testing Connection for server: [" + Configuration.DB_SERVER_NAME + "]...");
            // Do not let the GUI-host SFS claim/reset a playable server row.
            // Child worlds launched by ServerManagerUI set kaiden.manager.child=true.
            if (Boolean.getBoolean("kaiden.manager.child") || !Configuration.ALLOW_INTERFACE) {
                try {
                    instance.getJdbc().run("UPDATE servers SET Online = 0 WHERE Name = ?", Configuration.SERVER_NAME);
                } catch (Exception e) {
                    LOGGER.warn("[Storage Boot] Initial server online reset skipped: " + e.getMessage());
                }
            }
        }
        return instance;
    }

    private JdbcHelper jdbc;
    private ConnectionPool pool;

    public Storage() {
        rebuildPoolInternal("boot");
        this.startKeepAliveThread(); // Gentle keepalive + emergency pool recovery watchdog
    }

    public JdbcHelper getJdbc() {
        return this.jdbc;
    }

    public synchronized void destroyIdleConnections() {
        if (this.pool == null) {
            return;
        }
        this.pool.freeIdleConnections();
    }

    public synchronized void freeIdleConnections() {
        if (this.pool == null) {
            return;
        }
        this.pool.freeIdleConnections();
    }

    public synchronized int getActiveConnectionCount() {
        if (this.pool == null) {
            return 0;
        }
        return this.pool.getActiveConnections();
    }

    public synchronized int getMaxConnectionCount() {
        return Math.max(1, Configuration.DB_MAX_CONNECTIONS);
    }

    public synchronized boolean isPoolBusy() {
        return this.pool != null && getActiveConnectionCount() >= Math.max(1, getMaxConnectionCount() - 2);
    }

    public boolean shouldSkipNonCriticalDb() {
        int active = getActiveConnectionCount();
        int max = getMaxConnectionCount();
        return active >= Math.max(1, max - 2);
    }

    public void recoverPool(String reason) {
        if (!POOL_RECOVERING.compareAndSet(false, true)) {
            return;
        }
        try {
            synchronized (this) {
                int active = getActiveConnectionCount();
                int max = getMaxConnectionCount();
                LOGGER.warn("[Storage Recovery] rebuilding DB pool reason=" + reason + " active=" + active + "/" + max);
                rebuildPoolInternal(reason);
                BUSY_SINCE.set(0L);
            }
        } catch (Throwable t) {
            LOGGER.error("[Storage Recovery] failed: " + t.getMessage());
        } finally {
            POOL_RECOVERING.set(false);
        }
    }

    private MysqlConnectionPoolDataSource createDataSource() {
        MysqlConnectionPoolDataSource source = new MysqlConnectionPoolDataSource();
        source.setServerName(Configuration.DB_HOST);
        source.setPort(Configuration.DB_PORT);
        source.setUser(Configuration.DB_USERNAME);
        source.setPassword(Configuration.DB_PASSWORD);
        source.setDatabaseName(Configuration.DB_NAME);
        try {
            source.setAllowPublicKeyRetrieval(true);
            source.setUseSSL(false);
            source.setAutoReconnect(true);
            source.setConnectTimeout(15000);
            // 0 = no read timeout. This prevents long-lived sessions from being
            // dropped because MySQL had one slow/stale read during normal uptime.
            source.setSocketTimeout(0);
            source.setTcpKeepAlive(true);
        } catch (SQLException ex) {
            LOGGER.error("[Storage Error: SQL option setup failed: " + ex.getMessage() + ".]");
        }
        return source;
    }

    private synchronized void rebuildPoolInternal(String reason) {
        try {
            if (this.pool != null) {
                try { this.pool.dispose(); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}

        MysqlConnectionPoolDataSource source = createDataSource();
        this.pool = new ConnectionPool(source, Configuration.DB_MAX_CONNECTIONS);
        this.jdbc = new JdbcHelper(new PooledDataSource(this.pool));
        LOGGER.warn("[Storage] DB pool ready reason=" + reason + " max=" + Configuration.DB_MAX_CONNECTIONS);
    }

    public void destroy() {
        try {
            this.pool.dispose();
            this.pool = null;
            this.jdbc = null;
            LOGGER.debug("[Storage: DatabasePool has been disposed of. ]");
        } catch (SQLException ex) {
            LOGGER.debug("[Storage Error: An error occurred whilst disposing of the Database Pool: " + ex.getMessage() + ".]");
        }
    }

    private void startKeepAliveThread() {
        Thread keepAlive = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(600_000); // Every 10 minutes; this is only a gentle stale-connection check.
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    return;
                }

                if (!KEEPALIVE_RUNNING.compareAndSet(false, true)) {
                    continue;
                }

                try {
                    int active = getActiveConnectionCount();
                    int max = Math.max(1, Configuration.DB_MAX_CONNECTIONS);

                    // If the pool is under pressure, do NOT spend a connection on keepalive.
                    if (active >= Math.max(1, max - 2)) {
                        long now = System.currentTimeMillis();
                        long since = BUSY_SINCE.get();
                        if (since == 0L) {
                            BUSY_SINCE.compareAndSet(0L, now);
                            since = now;
                        }
                        LOGGER.warn("[KeepAlive] skipped because pool is busy active=" + active + "/" + max);

                        // If the pool is pegged for more than 2 minutes, assume leaked/stuck connections
                        // and rebuild the pool so login can recover instead of staying dead for hours.
                        if (now - since >= 120000L) {
                            recoverPool("busy-for-" + ((now - since) / 1000L) + "s");
                        }
                        continue;
                    } else {
                        BUSY_SINCE.set(0L);
                    }

                    LOGGER.debug("[KeepAlive] Pinging DB to keep connection alive...");
                    this.jdbc.run("SELECT 1");
                } catch (Exception e) {
                    LOGGER.warn("[KeepAlive Error] " + e.getMessage());
                } finally {
                    KEEPALIVE_RUNNING.set(false);
                }
            }
        });
        keepAlive.setDaemon(true);
        keepAlive.start();
    }
}
