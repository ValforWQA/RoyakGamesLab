package Kaiden.Database;

import Kaiden.Database.Configuration.Configuration;
import Kaiden.Game.Server.Users.Utils.ServerUtils;
import Kaiden.Kaiden_Extension;
import it.gotoandplay.smartfoxserver.config.ConfigData;

import java.lang.management.*;
import java.util.Locale;

public class ServerStats {

    private static final MemoryMXBean memMXbean = ManagementFactory.getMemoryMXBean();
    private static final ThreadMXBean threadMXbean = ManagementFactory.getThreadMXBean();
    private static final RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();

    public static String statsSystem() {
        MemoryUsage mem = memMXbean.getHeapMemoryUsage();

        final double maxMem = mem.getMax();
        final double allocated = mem.getCommitted();
        final double used = mem.getUsed();
        final double nonAllocated = maxMem - allocated;
        final double cached = allocated - used;
        final double useable = maxMem - used;
        final double usedPercent = (used / maxMem) * 100.0;

        final int threadCount = threadMXbean.getThreadCount();
        final int daemonCount = threadMXbean.getDaemonThreadCount();
        final int nonDaemonCount = threadCount - daemonCount;
        final int peakCount = threadMXbean.getPeakThreadCount();
        final long totalCount = threadMXbean.getTotalStartedThreadCount();

        long uptimeMs = runtimeMXBean.getUptime();
        String uptimeStr = formatDuration(uptimeMs);

        int playersOnline = 0;
        try { playersOnline = Kaiden_Extension.getInstance().getZone().getUserCount(); } catch (Exception ignored) {}

        String usedBar = buildBar(usedPercent, 20);

        return ""
                + "<font color='#ffd35a'><b>◆ KAIDEN ENGINE LIVE MONITOR ◆</b></font><br/>"
                + "<font color='#888888'>────────────────────────────────────</font><br/><br/>"

                + "<font color='#7efc59'><b>Remote Server</b></font><br/>"
                + "Players Online: <font color='#7efc59'><b>" + playersOnline + "</b></font><br/>"
                + "Restart Count: <font color='#ffcc66'>" + ConfigData.restartCount + "</font><br/><br/>"

                + "<font color='#7eb6ff'><b>SQL</b></font><br/>"
                + "Connections: <font color='#ffcc66'>"
                + Storage.getInstance().getActiveConnectionCount() + " / " +
                Configuration.DB_MAX_CONNECTIONS + "</font><br/><br/>"

                + "<font color='#ff9af2'><b>Network</b></font><br/>"
                + "Data IN: <font color='#7efc59'>" + ServerUtils.formatSize(ConfigData.dataIN) + "</font><br/>"
                + "Data OUT: <font color='#7efc59'>" + ServerUtils.formatSize(ConfigData.dataOUT) + "</font><br/>"
                + "Dropped IN: <font color='#ff6666'>" + ServerUtils.formatSize(ConfigData.inComingDroppedMessages) + "</font><br/>"
                + "Dropped OUT: <font color='#ff6666'>" + ServerUtils.formatSize(ConfigData.outGoingDroppedMessages) + "</font><br/>"
                + "Max Connections: <font color='#ffcc66'>" + ConfigData.maxSimultanousConnections + "</font><br/><br/>"

                + "<font color='#ffa94d'><b>Memory</b></font><br/>"
                + "Usage: " + usedBar + "<br/>"
                + "Used / Max: <font color='#7efc59'>" + ServerUtils.formatSize((long) used) + "</font> / "
                + "<font color='#ffcc66'>" + ServerUtils.formatSize((long) maxMem) + "</font><br/>"
                + "Allocated: <font color='#ffcc66'>" + ServerUtils.formatSize((long) allocated) + "</font><br/>"
                + "Cached: <font color='#7eb6ff'>" + ServerUtils.formatSize((long) cached) + "</font><br/>"
                + "Useable: <font color='#7efc59'>" + ServerUtils.formatSize((long) useable) + "</font><br/><br/>"

                + "<font color='#ffdd55'><b>Threads</b></font><br/>"
                + "Live: <font color='#ffcc66'>" + threadCount + "</font><br/>"
                + "Non-Daemon: <font color='#7efc59'>" + nonDaemonCount + "</font><br/>"
                + "Daemon: <font color='#7eb6ff'>" + daemonCount + "</font><br/>"
                + "Peak: <font color='#ffcc66'>" + peakCount + "</font><br/>"
                + "Total Started: <font color='#ffcc66'>" + totalCount + "</font><br/><br/>"

                + "<font color='#ff88aa'><b>Garbage Collectors</b></font><br/>"
                + buildGcSection() + "<br/>"

                + "<font color='#7efc59'><b>Uptime</b></font>: <font color='#ffcc66'>" + uptimeStr + "</font><br/>"

                + "<font color='#888888'>────────────────────────────────────</font>";
    }

    private static String buildBar(double percent, int length) {
        int filled = (int) Math.round((percent / 100.0) * length);
        String color = (percent < 60) ? "#7efc59" : (percent < 85 ? "#ffcc66" : "#ff6666");

        StringBuilder sb = new StringBuilder("<font color='" + color + "'>[");
        for (int i = 0; i < length; i++)
            sb.append(i < filled ? "■" : "·");
        sb.append("] ").append(String.format(Locale.US, "%.1f", percent)).append("%</font>");
        return sb.toString();
    }

    private static String buildGcSection() {
        StringBuilder sb = new StringBuilder();
        for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
            sb.append("• <font color='#ffcc66'>")
                    .append(gc.getName())
                    .append("</font> — Count: <font color='#7efc59'>")
                    .append(gc.getCollectionCount())
                    .append("</font>, Time: <font color='#7eb6ff'>")
                    .append(gc.getCollectionTime()).append(" ms</font><br/>");
        }
        return sb.toString();
    }

    private static String formatDuration(long ms) {
        long sec = ms / 1000;
        long min = sec / 60;
        long hr  = min / 60;
        long day = hr / 24;

        return String.format("%dd %02dh %02dm %02ds",
                day, hr % 24, min % 60, sec % 60);
    }
}
