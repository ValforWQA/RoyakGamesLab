package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;

import java.util.HashSet;

public class MapNpcBean {
    public static final BeanCreator<HashSet<MapNpcBean>> setCreator = (rs) -> {
        HashSet<MapNpcBean> MapNpcBeans = new HashSet<>();

        do {
            MapNpcBean MapNpcBean = new MapNpcBean();
            MapNpcBean.npcMapId = rs.getInt("id");
            MapNpcBean.npcId = rs.getInt("NpcID");
            MapNpcBean.scale = rs.getInt("Scale");
            if (rs.getObject("PosX") != null) {
                MapNpcBean.posX = rs.getDouble("PosX");
            } else {
                MapNpcBean.posX = Double.NaN;
            }

            if (rs.getObject("PosY") != null) {
                MapNpcBean.posY = rs.getDouble("PosY");
            } else {
                MapNpcBean.posY = Double.NaN;
            }
            MapNpcBean.frame = rs.getString("Frame");
            MapNpcBean.direction = rs.getInt("Direction");
            MapNpcBean.animation = rs.getString("Animation");

            MapNpcBeans.add(MapNpcBean);
        } while (rs.next());

        return MapNpcBeans;
    };

    private int npcMapId;
    private int npcId;
    private String frame;
    private double posX;
    private double posY;
    private int direction;
    private int scale;
    private String animation;

    public int getNpcId() {
        return this.npcId;
    }

    public String getFrame() {
        return this.frame;
    }

    public int getScale() { return this.scale; }

    public double getPosX() {
        return this.posX;
    }

    public double getPosY() {
        return this.posY;
    }

    public int getDirection() {
        return this.direction;
    }

    public int getNpcMapId() {
        return this.npcMapId;
    }

    public String getAnimation() {
        if (this.animation == null || this.animation.isEmpty()) {
            return "";
        }
        return this.animation;
    }

    // ======================
    //  NEW SETTERS FOR RUNTIME NPC SPAWN
    // ======================

    public void setNpcMapId(int npcMapId) {
        this.npcMapId = npcMapId;
    }

    public void setNpcId(int npcId) {
        this.npcId = npcId;
    }

    public void setFrame(String frame) {
        this.frame = frame;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }

    public void setPosY(double posY) {
        this.posY = posY;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public void setAnimation(String animation) {
        this.animation = animation;
    }
}
