package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class TitleBean {

    public static final ResultSetMapper<Integer, TitleBean> resultSetMapper = rs -> {
        TitleBean title = new TitleBean();
        title.id = rs.getInt("id");
        title.Name = rs.getString("Name");
        title.Color = rs.getString("Color");
        title.Description = rs.getString("Description");
        title.Strength = rs.getInt("Strength");
        title.Intellect = rs.getInt("Intellect");
        title.Endurance = rs.getInt("Endurance");
        title.Dexterity = rs.getInt("Dexterity");
        title.Wisdom = rs.getInt("Wisdom");
        title.Luck = rs.getInt("Luck");
        return new AbstractMap.SimpleEntry(title.getId(), title);
    };

    private int id;
    private int Strength;
    private int Intellect;
    private int Endurance;
    private int Dexterity;
    private int Wisdom;
    private int Luck;

    private String Name;
    private String Color;
    private String Description;

    public int getId() {
        return this.id;
    }

    public int getStrength() {
        return this.Strength;
    }

    public int getIntellect() {
        return this.Intellect;
    }

    public int getEndurance() {
        return this.Endurance;
    }

    public int getDexterity() {
        return this.Dexterity;
    }

    public int getWisdom() {
        return this.Wisdom;
    }

    public int getLuck() {
        return this.Luck;
    }

    public String getName() {
        return this.Name;
    }

    public String getColor() {
        return this.Color;
    }

    public String getDescription() {
        return this.Description;
    }
}
