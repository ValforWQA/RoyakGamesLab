package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class FactionBean {

    public static final ResultSetMapper<Integer, FactionBean> resultSetMapper = rs -> {
        FactionBean faction = new FactionBean();
        faction.id = rs.getInt("id");
        faction.name = rs.getString("Name");
        return new AbstractMap.SimpleEntry(faction.getId(), faction);
    };
    private int id;
    private String name;


    public int getId() { return this.id; }

    public String getName() { return this.name; }
}