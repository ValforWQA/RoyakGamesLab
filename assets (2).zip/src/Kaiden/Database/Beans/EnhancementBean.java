package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class EnhancementBean {
    public static final ResultSetMapper<Integer, EnhancementBean> resultSetMapper = rs -> {
        EnhancementBean enhancement = new EnhancementBean();
        enhancement.id = rs.getInt("id");
        enhancement.name = rs.getString("Name");
        enhancement.patternId = rs.getInt("PatternID");
        enhancement.rarity = rs.getInt("Rarity");
        enhancement.DPS = rs.getInt("DPS");
                //+ rs.getInt("Level");
        enhancement.level = rs.getInt("Level");
        enhancement.procid = rs.getInt("ProcID");
        return new AbstractMap.SimpleEntry<>(enhancement.id, enhancement);
    };

    private String name;
    private int id;
    private int patternId;
    private int rarity;
    private int DPS;
    private int procid;
    private int level;

    public String getName() {
        return this.name;
    }

    public int getPatternId() {
        return this.patternId;
    }

    public int getRarity() {
        return this.rarity;
    }

    public int getDPS() {
        return this.DPS;
    }

    public int getLevel() {
        return this.level;
    }

    public int getId() {
        return this.id;
    }

    public int getProcId() {
        return this.procid;
    }

    public int getClientPatternId() {
        String n = this.name != null ? this.name.toLowerCase() : "";
        if (n.startsWith("adventurer")) return 1;
        if (n.startsWith("fighter")) return 2;
        if (n.startsWith("thief")) return 3;
        if (n.startsWith("armsman")) return 4;
        if (n.startsWith("hybrid")) return 5;
        if (n.startsWith("wizard") || n.startsWith("mage")) return 6;
        if (n.startsWith("healer")) return 7;
        if (n.startsWith("spellbreaker") || n.startsWith("darkmage") || n.startsWith("dark mage")) return 8;
        if (n.startsWith("lucky")) return 9;
        if (n.startsWith("forge")) return 10;
        if (n.startsWith("absolution")) return 11;
        if (n.startsWith("awe blast")) return 12;
        if (n.startsWith("health vamp")) return 13;
        if (n.startsWith("mana vamp")) return 14;
        if (n.startsWith("spiral carve")) return 15;
        if (n.startsWith("powerword die")) return 16;
        if (n.startsWith("smite")) return 17;
        if (n.startsWith("valiance")) return 18;
        if (n.startsWith("arcana") || n.startsWith("arcana's concerto")) return 19;
        if (n.startsWith("acheron")) return 20;
        if (n.startsWith("elysium")) return 21;
        if (n.startsWith("praxis")) return 22;
        if (n.startsWith("depths")) return 23;
        if (n.startsWith("dauntless")) return 24;
        if (n.startsWith("ravenous")) return 25;
        return this.patternId;
    }
}