package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;
import java.util.AbstractMap;

/** Full player-style appearance used by avatar monsters. */
public class MonsterOutfitBean {
    public static final ResultSetMapper<Integer, MonsterOutfitBean> resultSetMapper = rs -> {
        MonsterOutfitBean o = new MonsterOutfitBean();
        o.id = rs.getInt("id");
        o.name = rs.getString("Name");
        o.armorId = rs.getInt("ArmorID");
        o.weaponId = rs.getInt("WeaponID");
        o.helmId = rs.getInt("HelmID");
        o.capeId = rs.getInt("CapeID");
        o.hairId = rs.getInt("HairID");
        o.miscId = rs.getInt("MiscID");
        o.gender = rs.getString("Gender");
        o.hairColor = rs.getString("HairColor");
        o.eyeColor = rs.getString("EyeColor");
        o.skinColor = rs.getString("SkinColor");
        o.baseColor = rs.getString("BaseColor");
        o.trimColor = rs.getString("TrimColor");
        o.accessoryColor = rs.getString("AccessoryColor");
        return new AbstractMap.SimpleEntry<>(o.id, o);
    };

    private int id, armorId, weaponId, helmId, capeId, hairId, miscId;
    private String name, gender, hairColor, eyeColor, skinColor, baseColor, trimColor, accessoryColor;
    public int getId(){return id;} public String getName(){return name;}
    public int getArmorId(){return armorId;} public int getWeaponId(){return weaponId;}
    public int getHelmId(){return helmId;} public int getCapeId(){return capeId;}
    public int getHairId(){return hairId;} public int getMiscId(){return miscId;}
    public String getGender(){return gender;} public String getHairColor(){return hairColor;}
    public String getEyeColor(){return eyeColor;} public String getSkinColor(){return skinColor;}
    public String getBaseColor(){return baseColor;} public String getTrimColor(){return trimColor;}
    public String getAccessoryColor(){return accessoryColor;}
}
