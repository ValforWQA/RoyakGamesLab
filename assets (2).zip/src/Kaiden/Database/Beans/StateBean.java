package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class StateBean {

    public static ResultSetMapper<Integer, StateBean> resultSetMapper = rs -> {
        StateBean skill = new StateBean();
        skill.level = rs.getInt("Level");
        skill.health = rs.getInt("Health");
        skill.mana = rs.getInt("Mana");
        skill.boost = rs.getInt("Boost");
        return new AbstractMap.SimpleEntry(skill.level, skill);
    };
   
    private int level;
    private int mana;
    private int boost;
    private int health;

    

    public int getLevel() {
        return this.level;
    }

    public int getMana() {
        return this.mana;
    }

    public int getHealth() {
        return this.health;
    }

    public int getBoost() {
        return this.boost;
    }
}
