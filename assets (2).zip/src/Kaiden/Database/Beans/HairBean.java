package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class HairBean {

    public static ResultSetMapper<Integer, HairBean> resultSetMapper = rs -> {
        HairBean hair = new HairBean();
        hair.id = rs.getInt("id");
        hair.name = rs.getString("Name");
        hair.file = rs.getString("File");
        hair.gender = rs.getString("Gender");
        return new AbstractMap.SimpleEntry(hair.id, hair);
    };

    private int id;
    private String name;
    private String file;
    private String gender;

    public String getName() {
        return this.name;
    }

    public String getFile() {
        return this.file;
    }

    public String getGender() {
        return this.gender;
    }

    public int getId() {
        return this.id;
    }
}
