package Kaiden.Database.Beans;

import jdbchelper.QueryResult;

public class QuestRewardBean {
    public int itemId;
    public int quantity;
    public double rate;
    public String type;

    public QuestRewardBean(QueryResult result) {
        this.itemId = result.getInt("ItemID");
        this.quantity = result.getInt("Quantity");
        this.rate = result.getDouble("Rate");
        this.type = result.getString("RewardType");
    }
}