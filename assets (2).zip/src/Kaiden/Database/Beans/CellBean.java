package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class CellBean {
    public static final ResultSetMapper<Integer, CellBean> resultSetMapper = rs -> new AbstractMap.SimpleEntry(rs.getInt("id"), new CellBean(rs.getString("Frame"), rs.getString("Pad")));
    private final String frame;
    private final String pad;

    private CellBean(String frame, String pad) {
        this.frame = frame;
        this.pad = pad;
    }

    public String getFrame() {
        return this.frame;
    }

    public String getPad() {
        return this.pad;
    }
}