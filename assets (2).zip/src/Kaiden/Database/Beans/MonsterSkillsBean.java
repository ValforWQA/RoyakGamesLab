package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class MonsterSkillsBean {

    public static ResultSetMapper<Integer, MonsterSkillsBean> resultSetMapper = rs -> {
        MonsterSkillsBean skill = new MonsterSkillsBean();
        skill.id = rs.getInt("id");
        skill.name = rs.getString("Name");
        skill.animation = rs.getString("Animation");
        skill.description = rs.getString("Description");
        skill.enddescription = rs.getString("EndDescription");
        skill.type = rs.getString("Type");
        skill.effects = rs.getString("Effects");
        skill.hitTargets = rs.getInt("HitTargets");
        skill.LifeSteal = rs.getInt("LifeSteal");
        skill.ManaSteal = rs.getInt("ManaSteal");
        skill.damage = rs.getDouble("Damage");
        skill.mana = rs.getInt("Mana");
        skill.strl = rs.getString("strl");
        skill.cooldown = rs.getInt("Cooldown");
        skill.auraId = rs.getInt("AuraID");
        skill.duration = rs.getInt("Duration");
        skill.priority = 0;
        return new AbstractMap.SimpleEntry(skill.id, skill);
    };
    private String name;
    private String animation;
    private String description;
    private String enddescription;
    private String strl;
    private int LifeSteal;
    private int ManaSteal;
    private int hitTargets;
    private int duration;
    private String effects;
    private String type;
    private int priority;
    private double damage;
    private int id;
    private int mana;
    private int cooldown;
    private int auraId;

    public boolean hasAuraId() {
        return this.auraId > 0;
    }

    public String getName() {
        return this.name;
    }

    public String getAnimation() {
        return this.animation;
    }

    public String getDescription() {
        return this.description;
    }

    public String getEndDescription() {
        return this.enddescription;
    }

    public String getStrl() {return this.strl;} //keep

    public String getType() {
        return this.type;
    }

    public int getDuration() {return this.duration;}

    public int getManaSteal() {return this.ManaSteal;}

    public int getLifeSteal() {return this.LifeSteal;}

    public double getDamage() {
        return this.damage;
    }

    public int getMana() {
        return this.mana;
    }


    public int getCooldown() {
        return this.cooldown;
    }

    public int getId() {
        return this.id;
    }

    public String getEffects() {
        return this.effects;
    }

    public int getHitTargets() {
        return this.hitTargets;
    }

    public int getAuraId() {
        return this.auraId;
    }

    public int getPriority() {
        return priority;
    }
}
