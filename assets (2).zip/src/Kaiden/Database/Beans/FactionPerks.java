package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class FactionPerks {

    public static final ResultSetMapper<String, ZoneBean> resultSetMapper = rs -> {
        FactionPerks perk = new FactionPerks();
        perk.id = rs.getInt("FactionID");
        perk.Name = rs.getString("Name");
        perk.HPBoost = rs.getInt("HPBoost");
        perk.MPBoost = rs.getInt("MPBoost");
        perk.RegenBoost = rs.getInt("RegenBoost");
        perk.DMGBoost = rs.getDouble("DMGBoost");

        return new AbstractMap.SimpleEntry(perk.getId(), perk);
    };

    private int id;
    private int HPBoost;
    private int MPBoost;
    private double DMGBoost;
    private int RegenBoost;
    private String Name;

    public int getId() {return this.id;}
    public int getHPBoost() {return this.HPBoost;}
    public int getMPBoost() {return this.MPBoost;}
    public double getDMGBoost() {return this.DMGBoost;}
    public int getRegenBoost() {return this.RegenBoost;}
    public String getName() {return this.Name;}


}
