package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class ChatChannelBean {

    public static final ResultSetMapper<String, ChatChannelBean> resultSetMapper = rs -> {
        ChatChannelBean bean = new ChatChannelBean();
        bean.id = rs.getInt("id");
        bean.key = rs.getString("ChannelKey");
        bean.color = rs.getInt("Color");
        bean.str = rs.getString("Str");
        bean.type = rs.getString("Type");
        bean.tag = rs.getString("Tag");
        bean.roomId = rs.getInt("RoomID");
        bean.active = rs.getInt("Active");
        bean.access = rs.getInt("Access");
        return new AbstractMap.SimpleEntry<String, ChatChannelBean>(bean.getKey().toLowerCase(), bean);
    };

    private String key;
    private int color;
    private String str;
    private String type;
    private String tag;
    private int roomId;
    private int active;
    private int access;
    private int id;

    public String getKey() {
        return this.key;
    }

    public int getColor() {
        return this.color;
    }

    public String getStr() {
        return this.str;
    }

    public String getType() {
        return this.type;
    }

    public String getTag() {
        return this.tag == null ? "" : this.tag;
    }

    public int getRoomId() {
        return this.roomId;
    }

    public int getActive() {
        return this.active;
    }

    public boolean isActive() {
        return this.active == 1;
    }

    public int getId() {
        return this.id;
    }
    public int getAccess() {
        return this.access;
    }
}
