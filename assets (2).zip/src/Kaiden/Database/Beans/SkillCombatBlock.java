package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class SkillCombatBlock {

    public static final ResultSetMapper<String, SkillCombatBlock> resultSetMapper = rs -> {
        SkillCombatBlock skill = new SkillCombatBlock();
        skill.id = rs.getInt("SkillID");
        skill.type = rs.getString("Race");
        return new AbstractMap.SimpleEntry(skill.getId() + ":" + skill.getName().trim().toLowerCase(java.util.Locale.ROOT), skill);
    };

    private int id;
    private String type;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.type;
    }

}
