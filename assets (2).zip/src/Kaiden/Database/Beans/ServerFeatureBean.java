package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class ServerFeatureBean {

    public static final ResultSetMapper<String, ServerFeatureBean> resultSetMapper = rs -> {
        ServerFeatureBean bean = new ServerFeatureBean();
        bean.featureKey = rs.getString("FeatureKey");
        bean.enabled = rs.getInt("Enabled");
        bean.featurePath = rs.getString("FeaturePath");

        /*
         * Optional DB-driven thread fields.
         *
         * These columns are optional so older servers_features tables still work:
         * ThreadStartDelay, ThreadDelay, ThreadTimeUnit, ThreadRepeat
         */
        try { bean.threadStartDelay = rs.getLong("ThreadStartDelay"); } catch (Exception ignored) {}
        try { bean.threadDelay = rs.getLong("ThreadDelay"); } catch (Exception ignored) {}
        try { bean.threadTimeUnit = rs.getString("ThreadTimeUnit"); } catch (Exception ignored) {}
        try { bean.threadRepeat = rs.getInt("ThreadRepeat"); bean.hasThreadRepeat = true; } catch (Exception ignored) {}

        return new AbstractMap.SimpleEntry(bean.getFeatureKey().toLowerCase(), bean);
    };

    private String featureKey;
    private int enabled;
    private String featurePath;

    private long threadStartDelay = -1L;
    private long threadDelay = -1L;
    private String threadTimeUnit;
    private int threadRepeat = 1;
    private boolean hasThreadRepeat = false;

    public String getFeatureKey() {
        return this.featureKey;
    }

    public int getEnabled() {
        return this.enabled;
    }

    public boolean isEnabled() {
        return this.enabled == 1;
    }

    public String getFeaturePath() {
        return this.featurePath;
    }

    public long getThreadStartDelay() {
        return this.threadStartDelay;
    }

    public long getThreadDelay() {
        return this.threadDelay;
    }

    public String getThreadTimeUnit() {
        return this.threadTimeUnit;
    }

    public boolean hasThreadRepeat() {
        return this.hasThreadRepeat;
    }

    public boolean isThreadRepeat() {
        return this.threadRepeat == 1;
    }
}
