package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;

import java.util.HashSet;
import java.util.Set;

public class MapMonsterBean {

    public static final BeanCreator<Set<MapMonsterBean>> setCreator = rs -> {
        Set<MapMonsterBean> monsters = new HashSet<>();

        MapMonsterBean mapMonster = new MapMonsterBean();
        mapMonster.frame     = rs.getString("Frame");
        mapMonster.monsterId = rs.getInt("MonsterID");
        mapMonster.monMapId  = rs.getInt("MonMapID");
        mapMonster.scale     = rs.getDouble("Scale");
        mapMonster.direction = rs.getInt("Direction");
        mapMonster.posx      = rs.getDouble("PosX");
        mapMonster.posy      = rs.getDouble("PosY");

        // linked group
        mapMonster.linkGroupId = rs.getInt("PartnerID");
        mapMonster.linkBoss    = rs.getBoolean("AllowPartner");

        monsters.add(mapMonster);

        while (rs.next()) {
            mapMonster = new MapMonsterBean();
            mapMonster.frame     = rs.getString("Frame");
            mapMonster.monsterId = rs.getInt("MonsterID");
            mapMonster.monMapId  = rs.getInt("MonMapID");
            mapMonster.scale     = rs.getDouble("Scale");
            mapMonster.direction = rs.getInt("Direction");
            mapMonster.posx      = rs.getDouble("PosX");
            mapMonster.posy      = rs.getDouble("PosY");

            mapMonster.linkGroupId = rs.getInt("PartnerID");
            mapMonster.linkBoss    = rs.getBoolean("AllowPartner");

            monsters.add(mapMonster);
        }
        return monsters;
    };

    private int monMapId;
    private int monsterId;
    private int direction;
    private String frame;
    private double scale;
    private double posx;
    private double posy;

    // linked group
    private int linkGroupId = 0;
    private boolean linkBoss = false;

    // ========================
    // GETTERS
    // ========================

    public int getMonMapId() {
        return this.monMapId;
    }

    public int getMonsterId() {
        return this.monsterId;
    }

    public double getScale() {
        return this.scale;
    }

    public String getFrame() {
        return this.frame;
    }

    public int getDirection() {
        return this.direction;
    }

    public double getPosX() {
        return this.posx;
    }

    public double getPosY() {
        return this.posy;
    }

    public int getLinkGroupId() {
        return this.linkGroupId;
    }

    public boolean isLinkBoss() {
        return this.linkBoss;
    }

    // ========================
    // SETTERS (required for dynamic spawn)
    // ========================

    public void setMonMapId(int monMapId) {
        this.monMapId = monMapId;
    }

    public void setMonsterId(int monsterId) {
        this.monsterId = monsterId;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public void setFrame(String frame) {
        this.frame = frame;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public void setPosX(double posx) {
        this.posx = posx;
    }

    public void setPosY(double posy) {
        this.posy = posy;
    }

    public void setLinkGroupId(int linkGroupId) {
        this.linkGroupId = linkGroupId;
    }

    public void setLinkBoss(boolean linkBoss) {
        this.linkBoss = linkBoss;
    }
}
