package Kaiden.Database.Beans;

import Kaiden.Game.Server.Users.Properties;
import jdbchelper.ResultSetMapper;
import net.sf.json.JSONObject;

import java.util.AbstractMap;
import java.util.concurrent.ConcurrentHashMap;

public class ItemBean {
    public static final ResultSetMapper<Integer, Integer> requirementMapper = rs -> new AbstractMap.SimpleEntry(rs.getInt("ReqItemID"), rs.getInt("Quantity"));

    public static final ResultSetMapper<Integer, ItemBean> resultSetMapper = rs -> {
        ItemBean item = new ItemBean();
        item.id = rs.getInt("id");
        item.name = rs.getString("Name");
        item.description = rs.getString("Description");
        item.type = rs.getString("Type");
        item.element = rs.getString("Element");
        item.file = rs.getString("File");
        item.link = rs.getString("Link");
        item.icon = rs.getString("Icon");
        item.equipment = rs.getString("Equipment");
        item.reqQuests = rs.getString("ReqQuests");
        item.meta = rs.getString("Meta");
        item.level = rs.getInt("Level");
        item.DPS = rs.getInt("DPS");
        item.range = rs.getInt("Range");
        item.rarity = rs.getInt("Rarity");
        item.cost = rs.getInt("Cost");
        item.quantity = rs.getInt("Quantity");
        item.stack = rs.getInt("Stack");
        item.enhId = rs.getInt("EnhID");
        item.factionId = rs.getInt("FactionID");
        item.reqReputation = rs.getInt("ReqReputation");
        item.reqClassId = rs.getInt("ReqClassID");
        item.reqClassPoints = rs.getInt("ReqClassPoints");
        item.questStringIndex = rs.getInt("QuestStringIndex");
        item.questStringValue = rs.getInt("QuestStringValue");
        item.coins = rs.getBoolean("Coins");
        item.upgrade = rs.getBoolean("Upgrade");
        item.staff = rs.getBoolean("Staff");
        item.classid = rs.getInt("ClassID");
        item.temporary = rs.getBoolean("Temporary");
        item.sell = rs.getBoolean("Sell");
        item.trade = rs.getBoolean("Trade");
        return new AbstractMap.SimpleEntry(item.getId(), item);
    };

    private ClassBean classObj;
    private ConcurrentHashMap<Integer, Integer> requirements = new ConcurrentHashMap();
    private String name;
    private String description;
    private String type;
    private String element;
    private String file;
    private String link;
    private String icon;
    private String equipment;
    private String reqQuests;
    private String meta;
    private int id;
    private int classid;
    private int level;
    private int DPS;
    private int range;
    private int rarity;
    private int cost;
    private int quantity;
    private int stack;
    private int enhId;
    private int factionId;
    private int reqReputation;
    private int reqClassId;
    private int reqClassPoints;
    private int questStringIndex;
    private int questStringValue;
    private boolean coins;
    private boolean upgrade;
    private boolean staff;
    private boolean temporary;
    private boolean sell;
    private boolean trade;

    public JSONObject getItemJSON() {
        return this.getItemJSON(null);
    }

    public JSONObject getEquipmentJson() {
        JSONObject obj = new JSONObject();
        obj.put("sLink", this.getLink());
        obj.put("sFile", this.getFile());
        obj.put("ItemID", this.getId());
        if (this.equipment.equals(Properties.ITEM_WEAPON)) {
            obj.put("sType", this.type);
        }

        //if (this.equipment.equals(Properties.ITEM_HELM)) {
            //obj.put("sType", this.type);
            //obj.put("sLink", this.link);
        //}
        return obj;
    }
    //testing only

    public static JSONObject getItemJSONs(ItemBean itemObj, EnhancementBean enhancement) {
        if (itemObj == null) throw new NullPointerException("itemObj is null");

        JSONObject item = new JSONObject();

        item.put("ItemID", itemObj.getId());
        item.put("bCoins", itemObj.isCoins() ? 1 : 0);
        item.put("bHouse", itemObj.isHouse() ? 1 : 0);
        item.put("bPTR", 0);
        item.put("bStaff", itemObj.isStaff() ? 1 : 0);
        item.put("bTrade", itemObj.isTradeable() ? 1 : 0);
        item.put("bSell", itemObj.isSellable() ? 1 : 0);
        //item.put("bMarket", itemObj.isMarketable() ? 1 : 0);
        item.put("bTemp", itemObj.isTemporary() ? 1 : 0);
        item.put("bUpg", itemObj.isUpgrade() ? 1 : 0);
        item.put("iCost", itemObj.getCost());
        item.put("iDPS", itemObj.getDPS());
        item.put("iLvl", itemObj.getLevel());
        item.put("iQSindex", itemObj.getQuestStringIndex());
        item.put("iQSvalue", itemObj.getQuestStringValue());
        item.put("iRng", itemObj.getClientRange());
        item.put("iRty", itemObj.getRarity());
        item.put("iStk", itemObj.getStack());
        item.put("sDesc", itemObj.getDescription());
        item.put("sES", itemObj.getEquipment());
        item.put("sElmt", itemObj.getElement());
        item.put("sFile", itemObj.getFile());
        item.put("sIcon", itemObj.getIcon());
        item.put("sLink", itemObj.getLink());
        item.put("sMeta", itemObj.getMeta());
        item.put("sName", itemObj.getName());
        item.put("sReqQuests", itemObj.getReqQuests());
        item.put("sType", itemObj.getType());

        if (enhancement != null) {
            if (itemObj.getType().equals("Enhancement")) {
                item.put("PatternID", enhancement.getClientPatternId());
                item.put("EnhPatternID", enhancement.getClientPatternId());
                item.put("ProcID", enhancement.getProcId());
                item.put("iDPS", enhancement.getDPS());
                item.put("iLvl", enhancement.getLevel());
                item.put("EnhLvl", enhancement.getLevel());
                item.put("iRty", enhancement.getRarity());
                item.put("EnhID", enhancement.getId());
                item.remove("sFile");
            } else {
                item.put("EnhID", enhancement.getId());
                item.put("EnhLvl", enhancement.getLevel());
                item.put("EnhPatternID", enhancement.getClientPatternId());
                item.put("EnhRty", enhancement.getRarity());
                item.put("ProcID", enhancement.getProcId());
                item.put("iRng", itemObj.getClientRange());
                item.put("EnhRng", itemObj.getClientRange());
                item.put("InvEnhPatternID", enhancement.getClientPatternId());
                item.put("EnhDPS", enhancement.getDPS());
            }
        }
        return item;
    }

    //testing only
    public JSONObject getItemJSON(EnhancementBean enhancement) {
        JSONObject item = new JSONObject();
        item.put("ItemID", this.getId());
        item.put("bCoins", this.isCoins() ? 1 : 0);
        item.put("bHouse", this.isHouse() ? 1 : 0);
        item.put("bPTR", 0);
        item.put("bStaff", this.isStaff() ? 1 : 0);
        item.put("bTemp", this.isTemporary() ? 1 : 0);
        item.put("bUpg", this.isUpgrade() ? 1 : 0);
        item.put("iCost", this.getCost());
        item.put("iDPS", this.getDPS());
        item.put("iLvl", this.getLevel());
        item.put("iQSindex", this.getQuestStringIndex());
        item.put("iQSvalue", this.getQuestStringValue());
        item.put("iRng", this.getClientRange());
        item.put("iRty", this.getRarity());
        item.put("iStk", this.getStack());
        item.put("sDesc", this.getDescription());
        item.put("sES", this.getEquipment());
        item.put("sElmt", this.getElement());
        item.put("sFile", this.getFile());
        item.put("sIcon", this.getIcon());
        item.put("sLink", this.getLink());
        item.put("sMeta", this.getMeta());
        item.put("sName", this.getName());
        item.put("sReqQuests", this.getReqQuests());
        item.put("sType", this.getType());
        if (enhancement != null) {
            if (this.getType().equals("Enhancement")) {
                item.put("PatternID", enhancement.getClientPatternId());
                item.put("EnhPatternID", enhancement.getClientPatternId());
                item.put("ProcID", enhancement.getProcId());
                item.put("iDPS", enhancement.getDPS());
                item.put("iLvl", enhancement.getLevel());
                item.put("EnhLvl", enhancement.getLevel());
                item.put("iRty", enhancement.getRarity());
                item.put("EnhID", enhancement.getId());
                item.remove("sFile");
            } else {
                item.put("EnhID", enhancement.getId());
                item.put("EnhLvl", enhancement.getLevel());
                item.put("EnhPatternID", enhancement.getClientPatternId());
                item.put("EnhRty", enhancement.getRarity());
                item.put("ProcID", enhancement.getProcId());
                item.put("iRng", this.getClientRange());
                item.put("EnhRng", this.getClientRange());
                item.put("InvEnhPatternID", enhancement.getClientPatternId());
                item.put("EnhDPS", enhancement.getDPS());
            }
        }
        return item;
    }



    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public String getType() {
        return this.type;
    }

    public String getElement() {
        return this.element;
    }

    public String getFile() {
        return this.file;
    }

    public String getLink() {
        return this.link;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getEquipment() {
        return this.equipment;
    }

    public int getClassId() {
        return this.classid;
    }
    public int getLevel() {
        return this.level;
    }

    public int getDPS() {
        return this.DPS;
    }

    public int getRange() {
        return this.range;
    }

    public int getClientRange() {
        int rawRange = this.range;
        if (rawRange > 50) {
            rawRange = (int) Math.round(rawRange / 10.0D);
        }
        if (rawRange < 0) {
            rawRange = 0;
        }
        if (rawRange > 100) {
            rawRange = 100;
        }
        return rawRange;
    }

    public int getRarity() {
        return this.rarity;
    }

    public int getCost() {
        return this.cost;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public int getStack() {
        return this.stack;
    }

    public int getEnhId() {
        return this.enhId;
    }

    public int getFactionId() {
        return this.factionId;
    }

    public int getReqReputation() {
        return this.reqReputation;
    }

    public int getReqClassId() {
        return this.reqClassId;
    }

    public int getReqClassPoints() {
        return this.reqClassPoints;
    }

    public int getQuestStringIndex() {
        return this.questStringIndex;
    }

    public int getQuestStringValue() {
        return this.questStringValue;
    }

    public boolean isCoins() {
        return this.coins;
    }

    public boolean isSellable() {
        return this.sell;
    }

    public boolean isUpgrade() {
        return this.upgrade;
    }

    public boolean isHouse() {
        return (getEquipment().equals("ho")) || (getEquipment().equals("hi"));
    }

    public boolean isStaff() {
        return this.staff;
    }

    public int getId() {
        return this.id;
    }

    public boolean isTemporary() {
        return this.temporary;
    }

    public boolean isTradeable() {return this.trade;}

    public String getReqQuests() {
        return this.reqQuests;
    }

    public String getMeta() {
        return this.meta;
    }

    public ClassBean getItemClass() {
        return this.classObj;
    }

    public ConcurrentHashMap<Integer, Integer> getRequirements() {
        return this.requirements;
    }

    public void setItemClass(ClassBean classObj) {
        this.classObj = classObj;
    }

    public void setRequirements(ConcurrentHashMap requirements) {
        this.requirements = requirements;
    }
}