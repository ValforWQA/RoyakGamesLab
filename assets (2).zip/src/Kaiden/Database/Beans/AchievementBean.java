package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class AchievementBean {

    public static final ResultSetMapper<String, ZoneBean> resultSetMapper = rs -> {
        AchievementBean achievements = new AchievementBean();
        achievements.id = rs.getInt("id");
        achievements.name = rs.getString("Name");
        achievements.description = rs.getString("Description");
        achievements.link = rs.getString("Link");
        achievements.value = rs.getInt("Value");
        achievements.index = rs.getInt("Index");
        achievements.field = rs.getString("Field");
        return new AbstractMap.SimpleEntry(achievements.getId(), achievements);
    };

    private int id;
    private String name;
    private String description;
    private String link;
    private String field;
    private int value;
    private int index;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public int getValue() {return this.value; }

    public int getIndex() {return this.index; }

    public String getField() {return this.field;}

    public String getDescription() {
        return this.description;
    }

    public String getLink() {
        return this.link;
    }

}
