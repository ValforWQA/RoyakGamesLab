package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class ServerThreadBean {

    public static final ResultSetMapper<String, ServerThreadBean> resultSetMapper = rs -> {
        ServerThreadBean bean = new ServerThreadBean();
        bean.threadKey = rs.getString("ThreadKey");
        bean.enabled = rs.getInt("Enabled");
        bean.threadPath = rs.getString("ThreadPath");
        bean.startDelay = rs.getLong("StartDelay");
        bean.delay = rs.getLong("Delay");
        bean.timeUnit = rs.getString("TimeUnit");
        bean.repeat = rs.getInt("RepeatTask");
        bean.description = rs.getString("Description");
        return new AbstractMap.SimpleEntry(bean.getThreadKey().toLowerCase(), bean);
    };

    private String threadKey;
    private int enabled;
    private String threadPath;
    private long startDelay;
    private long delay;
    private String timeUnit;
    private int repeat;
    private String description;

    public String getThreadKey() {
        return this.threadKey;
    }

    public int getEnabled() {
        return this.enabled;
    }

    public boolean isEnabled() {
        return this.enabled == 1;
    }

    public String getThreadPath() {
        return this.threadPath;
    }

    public long getStartDelay() {
        return this.startDelay;
    }

    public long getDelay() {
        return this.delay;
    }

    public String getTimeUnit() {
        return this.timeUnit;
    }

    public boolean isRepeat() {
        return this.repeat == 1;
    }

    public String getDescription() {
        return this.description;
    }
}
