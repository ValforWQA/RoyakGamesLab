package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class UsersAchievementsBean {

    public static final ResultSetMapper<String, ZoneBean> resultSetMapper = rs -> {
        UsersAchievementsBean uachievements = new UsersAchievementsBean();
        uachievements.id = rs.getInt("id");
        uachievements.achid = rs.getInt("AchID");
        return new AbstractMap.SimpleEntry(uachievements.getId(), uachievements);
    };

    private int id;
    private int achid;

    public int getAchid() {return this.achid;}

    public int getId() {
        return this.id;
    }



}
