package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;

import java.util.HashSet;
import java.util.Set;

public class ClassBean {
    public static final BeanCreator<Set<Integer>> beanSkills = rs -> {
        Set<Integer> set = new HashSet();
        set.add(rs.getInt("SkillID"));
        while (rs.next()) {
            set.add(rs.getInt("SkillID"));
        }
        return set;
    };
    public static final BeanCreator<ClassBean> beanCreator = rs -> {
        ClassBean _class = new ClassBean();
        _class.category = rs.getString("Category");
        _class.description = rs.getString("Description");
        _class.manaRegenerationMethods = rs.getString("ManaRegenerationMethods");
        _class.statsDescription = rs.getString("StatsDescription");
        return _class;
    };
    private Set<Integer> skills;
    private String category;
    private String description;
    private String manaRegenerationMethods;
    private String statsDescription;

    public String getCategory() {
        return this.category;
    }

    public String getDescription() {
        return this.description;
    }

    public String getManaRegenerationMethods() {
        return this.manaRegenerationMethods;
    }

    public String getStatsDescription() {
        return this.statsDescription;
    }

    public Set<Integer> getSkills() {
        return this.skills;
    }

    public void setSkills(Set skills) {
        this.skills = skills;
    }
}