package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.Collections;
import java.util.Set;

public class MapNpcBeanApop {

    public static final ResultSetMapper<Integer, MapNpcBeanApop> resultSetMapper = (rs) -> {
        MapNpcBeanApop MapNpcBeanApop = new MapNpcBeanApop();

        MapNpcBeanApop.NpcID = rs.getInt("NpcID");
        MapNpcBeanApop.MapNpcID = rs.getInt("MapNpcID");
        MapNpcBeanApop.MapNpcApopID = rs.getInt("MapNpcApopID");
        MapNpcBeanApop.subtitle = rs.getString("Subtitle");
        MapNpcBeanApop.message = rs.getString("Message");

        return new AbstractMap.SimpleEntry<>(MapNpcBeanApop.MapNpcID, MapNpcBeanApop);
    };

    private int MapNpcApopID;
    private int MapNpcID;
    private int NpcID;

    private String subtitle;
    private String message;

    public Set<MapNpcBeanApopAction> actions = Collections.emptySet();

    public int getNpcID() {
        return this.NpcID;
    }

    public int getMapNpcID() {
        return MapNpcID;
    }

    public int getMapNpcBeanApopID() {
        return MapNpcApopID;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public String getMessage() {
        return message;
    }

}
