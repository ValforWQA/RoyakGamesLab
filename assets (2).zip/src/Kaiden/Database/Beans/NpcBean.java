package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class NpcBean {
    public static final int TYPE_FILE = 0;
    public static final int TYPE_HUMAN = 1;

    public static final ResultSetMapper<Integer, NpcBean> resultSetMapper = rs -> {
        NpcBean NpcBean = new NpcBean();
        NpcBean.id = rs.getInt("id");
        NpcBean.name = rs.getString("Name");
        NpcBean.type = rs.getInt("Type");

        if (NpcBean.type == TYPE_FILE) {
            NpcBean.file = rs.getString("File");
            NpcBean.linkage = rs.getString("Linkage");
        }
        if (NpcBean.type == TYPE_HUMAN) {
            NpcBean.hairId = rs.getInt("HairID");
            NpcBean.gender = rs.getString("Gender");
            NpcBean.colorHair = rs.getString("ColorHair");
            NpcBean.colorSkin = rs.getString("ColorSkin");
            NpcBean.colorEye = rs.getString("ColorEye");
            NpcBean.colorBase = rs.getString("ColorBase");
            NpcBean.colorTrim = rs.getString("ColorTrim");
            NpcBean.colorAccessory = rs.getString("ColorAccessory");
            NpcBean.armorId = rs.getInt("ArmorID");
            NpcBean.helmId = rs.getInt("HelmID");
            NpcBean.weaponId = rs.getInt("WeaponID");
            NpcBean.capeId = rs.getInt("CapeID");
        }

        return new AbstractMap.SimpleEntry<>(rs.getInt("id"), NpcBean);
    };


    private int id;
    private String name;
    private int type;
    private String file;
    private String linkage;
    private String gender;
    private String colorHair;
    private String colorSkin;
    private String colorEye;
    private String colorBase;
    private String colorTrim;
    private String colorAccessory;
    private int armorId;
    private int helmId;
    private int weaponId;
    private int capeId;
    private int hairId;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public int getType() {
        return this.type;
    }

    public String getFile() {
        return this.file;
    }

    public String getLinkage() {
        return this.linkage;
    }

    public String getGender() {
        return this.gender;
    }

    public String getColorHair() {
        return this.colorHair;
    }

    public String getColorSkin() {
        return this.colorSkin;
    }

    public String getColorEye() {
        return this.colorEye;
    }

    public String getColorBase() {
        return this.colorBase;
    }

    public String getColorTrim() {
        return this.colorTrim;
    }

    public String getColorAccessory() {
        return this.colorAccessory;
    }

    public int getArmorId() {
        return this.armorId;
    }

    public int getHelmId() {
        return this.helmId;
    }

    public int getWeaponId() {
        return this.weaponId;
    }

    public int getCapeId() {
        return this.capeId;
    }

    public int getHairId() {
        return this.hairId;
    }

}
