package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;

import java.util.HashSet;

public class MapNpcBeanApopAction {

    public static String ACTION_LOADSHOP = "loadShop";
    public static String ACTION_TALK = "talk";
    public static String ACTION_LOADHAIRSHOP = "loadHairShop";
    public static String ACTION_LOADQUESTS = "loadQuests";
    public static String ACTION_JOINROOM = "joinRoom";
    public static String ACTION_LOADBANK = "loadBank";

    public static final BeanCreator<HashSet<MapNpcBeanApopAction>> setCreator = (rs) -> {
        HashSet<MapNpcBeanApopAction> MapNpcBeans = new HashSet<>();

        do {
            MapNpcBeanApopAction MapNpcBean = new MapNpcBeanApopAction();

            MapNpcBean.id = rs.getInt("id");
            MapNpcBean.MapNpcApopId = rs.getInt("MapNpcApopID");
            MapNpcBean.sortOrder = rs.getInt("SortOrder");
            MapNpcBean.caption = rs.getString("Caption");
            MapNpcBean.action = rs.getString("Action");
            MapNpcBean.questitem = rs.getInt("QuestItem");

            if (MapNpcBean.action.equalsIgnoreCase(ACTION_LOADSHOP) ||
                    MapNpcBean.action.equalsIgnoreCase(ACTION_LOADHAIRSHOP)) {
                MapNpcBean.shopId = rs.getInt("ShopID");
            }

            if (MapNpcBean.action.equalsIgnoreCase(ACTION_LOADQUESTS)) {
                MapNpcBean.questIds = rs.getString("QuestIDs");
            }

            if(MapNpcBean.action.equalsIgnoreCase(ACTION_TALK)) {
                MapNpcBean.questid = rs.getInt("QuestID");
            }

            if (MapNpcBean.action.equalsIgnoreCase(ACTION_JOINROOM)) {
                MapNpcBean.roomName = rs.getString("RoomName");
                MapNpcBean.roomFrame = rs.getString("RoomCell");
                MapNpcBean.roomPad = rs.getString("RoomPad");
            }

            // 🕒 Load start/end date for timed NPC buttons
            try {
                MapNpcBean.startDate = rs.getString("StartDate"); // e.g. "2025-10-18 12:00:00"
                MapNpcBean.endDate = rs.getString("EndDate");     // e.g. "2025-10-25 23:59:59"
            } catch (Exception e) {
                MapNpcBean.startDate = null;
                MapNpcBean.endDate = null;
            }

            MapNpcBeans.add(MapNpcBean);
        } while (rs.next());

        return MapNpcBeans;
    };

    private int id;
    private int MapNpcApopId;
    private int sortOrder;
    private String action;
    private String caption;
    private int shopId;
    private String questIds;
    private String roomName;
    private String roomFrame;
    private String roomPad;
    private int questitem;
    private int questid;

    // 🕒 New timed event fields
    private String startDate;
    private String endDate;

    // --- Getters ---
    public int getId() {
        return id;
    }

    public int getMapNpcBeanApopId() {
        return MapNpcApopId;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public int getShopId() {
        return shopId;
    }

    public String getQuestIds() {
        return questIds;
    }

    public String getRoomName() {
        return roomName;
    }

    public String getRoomFrame() {
        return roomFrame;
    }

    public String getRoomPad() {
        return roomPad;
    }

    public String getAction() {
        return action;
    }

    public int getQuestID() {return this.questid; }

    public int getQuestItem() {return this.questitem; }

    public String getCaption() {
        return caption;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }
}
