
package Kaiden.Database.Beans;

public class MonsterSkillBean {
  public int skillId;
   public boolean cooldown = false;

   public MonsterSkillBean() {
      super();
   }

   public void cooldown() {
      this.cooldown = true;
   }

   public boolean onCooldown() {
      return this.cooldown;
   }
}
   