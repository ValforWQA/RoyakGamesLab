
package Kaiden.Database.Beans;

import Kaiden.Database.StorageCache;
import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;

public class AuraBean {

 public static final BeanCreator<Set<Integer>> beanEffects = rs -> {
        Set<Integer> set = new HashSet();
        set.add(rs.getInt("id"));
        while (rs.next()) {
            set.add(rs.getInt("id"));
        }
        return set;
    };
    public static final ResultSetMapper<Integer, AuraBean> resultSetMapper = rs -> {
        AuraBean aura = new AuraBean();
        aura.id = rs.getInt("id");
        aura.duration = rs.getInt("Duration");
        aura.name = rs.getString("Name");
        aura.iconid = rs.getInt("IconID");
        aura.category = rs.getString("Category");
        aura.stack = rs.getInt("Stack");
        aura.target = rs.getString("Target");
        aura.damageIncrease = rs.getDouble("DamageIncrease");
        aura.damageTakenDecrease = rs.getDouble("DamageTakenDecrease");
        aura.auraChance = rs.getDouble("Chance");
        aura.lifeSteal = rs.getDouble("LifeSteal");
        aura.manaSteal = rs.getDouble("ManaSteal");
        return new AbstractMap.SimpleEntry(aura.id, aura);
    };
    //public final boolean selfCast = false;
    public Set<Integer> effects;
    public List<AuraPhaseBean> phases = new ArrayList<AuraPhaseBean>();
    private int id;
    private int iconid;
    private int duration;
    private int stack;
    private String name;
    private String category;
    private double damageIncrease;
    private double damageTakenDecrease;
    private double auraChance;
    private double lifeSteal;
    private double manaSteal;
    private String target;
    public long durtime;
    public long durtimemon;
    //public JSONArray auras = new JSONArray();

    public JSONArray getAuraArray(boolean isNew, long durationext) {
        JSONArray auras = new JSONArray();
        JSONObject auraInfo = new JSONObject();
        if (!this.getCategory().isEmpty() && !this.getCategory().equals("d")) {
            auraInfo.put("cat", this.getCategory());
            if (this.getCategory().equals("stun")) {
                auraInfo.put("s", "s");
            }
        }
        long effectiveDuration = durationext > 0 ? durationext : this.getDuration();
        auraInfo.put("nam", this.getName());
        auraInfo.put("icon", this.getIcon());
        auraInfo.put("t", "s");
        auraInfo.put("dur", String.valueOf(effectiveDuration));
        auraInfo.put("isNew", isNew);
        auras.add(auraInfo);
        return auras;
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }
    
    public String getIcon() {
        SkillIconBean skillIcon = StorageCache.getInstance().getSkillIcon(Integer.valueOf(this.iconid));
    return skillIcon.getName();
    }

    public String getCategory() {
        return this.category;
    }

    public String getTarget() {
        return this.target;
    }

    public double getDamageIncrease() {
        return this.damageIncrease;
    }

    public double getDamageTakenDecrease() {
        return this.damageTakenDecrease;
    }

    public double getAuraChance() {
        if (this.auraChance < 0.0D) return 0.0D;
        if (this.auraChance > 1.0D) return 1.0D;
        return this.auraChance;
    }

    public double getLifeSteal() { return this.lifeSteal; }

    public double getManaSteal() { return this.manaSteal; }

    public long getDurtimeEtensionTime() {
        return this.durtime;
    }

    public int getStack() {
        return this.stack <= 0 ? 1 : this.stack;
    }

    public int getDuration() {
        return this.duration;
    }

    /** Full runtime duration including optional later wiki phases. */
    public int getRuntimeDuration() {
        double max = Math.max(0, this.duration);
        if (this.phases != null) {
            for (AuraPhaseBean p : this.phases) {
                if (p == null) continue;
                max = Math.max(max, p.getAfterSeconds() + p.getDurationSeconds());
            }
        }
        return (int) Math.ceil(max);
    }

    public boolean hasRuntimePhases() {
        if (this.phases == null || this.phases.isEmpty()) return false;
        for (AuraPhaseBean p : this.phases) if (p != null && p.getPhaseNo() > 1) return true;
        return false;
    }


    public String normalizedTarget() {
        return target == null || target.trim().isEmpty() ? "target" : target.trim().toLowerCase();
    }

    public boolean isSelfTarget() { return "self".equals(normalizedTarget()); }

    /*
     * For monster skills, Target/Other means the current player target.
     * This keeps regular auras + auras_effects usable from monsters_skills.AuraID
     * and monsters_auras without requiring the old MonsterSkillEffectsBean path.
     */
    public boolean isPlayerTarget() {
        String t = normalizedTarget();
        return "player".equals(t) || "players".equals(t) || "target".equals(t) || "other".equals(t);
    }

    public boolean isMonsterTarget() { String t = normalizedTarget(); return "monster".equals(t) || "monsters".equals(t); }
    public boolean isOtherTarget() { return "other".equals(normalizedTarget()); }

} 