package Kaiden.Database.Beans;

public class MonsterDropBean {
    public int itemId;
    public int quantity;
    public double chance;
}