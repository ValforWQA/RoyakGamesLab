package Kaiden.Database.Beans;

import Kaiden.Game.Server.Rooms.Monsters.MonsterSkill;
import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;

import java.sql.SQLException;
import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Set;

public class MonsterBean {

    public static final BeanCreator<Set<MonsterDropBean>> beanDrops = rs -> {
        HashSet<MonsterDropBean> drops = new HashSet<>();
        MonsterDropBean md = new MonsterDropBean();
        md.itemId = rs.getInt("ItemID");
        md.quantity = rs.getInt("Quantity");
        md.chance = rs.getDouble("Chance");
        drops.add(md);
        while (rs.next()) {
            MonsterDropBean md2 = new MonsterDropBean();
            md2.itemId = rs.getInt("ItemID");
            md2.quantity = rs.getInt("Quantity");
            md2.chance = rs.getDouble("Chance");
            drops.add(md2);
        }
        return drops;
    };

    public static final ResultSetMapper<Integer, MonsterBean> resultSetMapper = rs -> {
        MonsterBean monster = new MonsterBean();
        monster.id = rs.getInt("id");
        monster.name = rs.getString("Name");
        monster.race = rs.getString("Race");
        monster.file = rs.getString("File");
        monster.linkage = rs.getString("Linkage");
        monster.element = rs.getString("Element");
        monster.health = rs.getInt("Health");
        monster.mana = rs.getInt("Mana");
        monster.level = rs.getInt("Level");
        monster.gold = rs.getInt("Gold");
        monster.coin = rs.getInt("Coins");
        monster.experience = rs.getInt("Experience");
        monster.reputation = rs.getInt("Reputation");
        monster.casspoint = rs.getInt("ClassPoints");
        monster.DPS = rs.getInt("DPS");
        monster.teamId = rs.getInt("TeamID");
        monster.respawn = rs.getInt("Respawn");
        monster.attack = rs.getInt("Attack");
        monster.avatar = rs.getInt("Avatar");
        // DPS is damage per second; Attack is the attack delay in milliseconds.
        // Keep these legacy min/max values aligned with the real per-swing damage
        // so older NPC/monster paths do not fall back to raw DPS-per-hit damage.
        double averageSwing = Math.max(1.0D, (double) monster.DPS * (Math.max(1, monster.attack) / 1000.0D));
        monster.minDmg = Math.max(1, (int) Math.floor(averageSwing * 0.92D));
        monster.maxDmg = Math.max(monster.minDmg, (int) Math.ceil(averageSwing * 1.12D));

        // Optional aura immunity columns (if present in monsters table)
        try {
            String immuneIds = rs.getString("AuraImmuneIds");
            if (immuneIds != null && !immuneIds.trim().isEmpty()) {
                for (String part : immuneIds.split(",")) {
                    part = part.trim();
                    if (!part.isEmpty()) {
                        try {
                            monster.auraImmuneIds.add(Integer.parseInt(part));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            }
        } catch (SQLException ignored) {
        }

        try {
            String immuneCats = rs.getString("AuraImmuneCats");
            if (immuneCats != null && !immuneCats.trim().isEmpty()) {
                for (String part : immuneCats.split(",")) {
                    part = part.trim().toLowerCase();
                    if (!part.isEmpty()) {
                        monster.auraImmuneCategories.add(part);
                    }
                }
            }
        } catch (SQLException ignored) {
        }

        return new AbstractMap.SimpleEntry<>(monster.id, monster);
    };

    public static final BeanCreator<Set<MonsterSkill>> beanSkills = rs -> {
        HashSet<MonsterSkill> skills = new HashSet<>();
        MonsterSkill md = new MonsterSkill();
        md.skillId = rs.getInt("SkillID");
        md.cooldown = false;
        skills.add(md);
        while (rs.next()) {
            MonsterSkill md2 = new MonsterSkill();
            md2.skillId = rs.getInt("SkillID");
            md2.cooldown = false;
            skills.add(md2);
        }
        return skills;
    };

    public Set<MonsterDropBean> drops;
    public Set<MonsterSkill> skills;
    private String name;
    private String race;
    private String file;
    private String linkage;
    private String element;
    private int id;
    private int health;
    private int mana;
    private int level;
    private int gold;
    private int coin;
    private int experience;
    private int reputation;
    private int casspoint;
    private int DPS;
    private int teamId;
    private int respawn;
    private int attack;
    private int avatar;
    private int minDmg;
    private int maxDmg;

    // Monster-level aura immunity
    // AuraImmuneIds: comma-separated list of aura IDs (e.g. "1,5,7")
    // AuraImmuneCats: comma-separated list of categories (e.g. "stun,poison,dot")
    private java.util.Set<Integer> auraImmuneIds = new java.util.HashSet<>();
    private java.util.Set<String> auraImmuneCategories = new java.util.HashSet<>();

    public String getName() {
        return this.name;
    }

    public String getRace() {
        return this.race;
    }

    public String getFile() {
        return this.file;
    }

    public String getLinkage() {
        return this.linkage;
    }

    public String getElement() {
        return this.element;
    }

    public int getHealth() {
        return this.health;
    }

    public int getMana() {
        return this.mana;
    }

    public int getLevel() {
        return this.level;
    }

    public int getGold() {
        return this.gold;
    }

    public int getCoin() {
        return this.coin;
    }

    public int getExperience() {
        return this.experience;
    }

    public int getReputation() {
        return this.reputation;
    }

    public int getClassPoint() {
        return this.casspoint;
    }

    public int getDPS() {
        return this.DPS;
    }

    public int getId() {
        return this.id;
    }

    public int getTeamId() {
        return this.teamId;
    }

    public int getRespawn() {
        return this.respawn;
    }


    public int getCoinDrop() {
        return this.coin;
    }

    public int getExperienceDrop() {
        return this.experience;
    }

    public int getReputationDrop() {
        return this.reputation;
    }

    public int getClassPointDrop() {
        return this.casspoint;
    }

    public int getDPSDrop() {
        return this.DPS;
    }

    public int getAttack() {
        return this.attack;
    }

    /**
     * 0 = regular monster SWF; > 0 = monsters_outfits.id for an avatar monster.
     */
    public int getAvatar() {
        return this.avatar;
    }

    public int getMaxDmg() {
        return this.maxDmg;
    }

    public java.util.Set<Integer> getAuraImmuneIds() {
        return this.auraImmuneIds;
    }

    public java.util.Set<String> getAuraImmuneCategories() {
        return this.auraImmuneCategories;
    }

    //public Collection<MonsterSkillBean> getSkills() {
    //    return this.skills;
    //}
    public int getMinDmg() {
        return this.minDmg;
    }
}
