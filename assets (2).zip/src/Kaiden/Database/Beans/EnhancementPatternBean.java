package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

/*
may have to refactor in the future.

 */
public class EnhancementPatternBean {
        public static final ResultSetMapper<Integer, EnhancementPatternBean> resultSetMapper = rs -> {
        EnhancementPatternBean ep = new EnhancementPatternBean();
        ep.id = rs.getInt("id");
        ep.name = rs.getString("Name");
        ep.description = rs.getString("Desc");
        ep.stats = new HashMap();
        ep.stats.put("WIS", rs.getDouble("Wisdom"));
        ep.stats.put("END", rs.getDouble("Endurance"));
        ep.stats.put("LCK", rs.getDouble("Luck"));
        ep.stats.put("STR", rs.getDouble("Strength"));
        ep.stats.put("DEX", rs.getDouble("Dexterity"));
        ep.stats.put("INT", rs.getDouble("Intelligence"));
        ep.normalizeToAqwDefaults();
        return new AbstractMap.SimpleEntry(ep.getId(), ep);
    };
    private int id;
    private String name;
    private String description;
    private Map<String, Double> stats;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Map<String, Double> getStats() {
        return this.stats;
    }

    private void normalizeToAqwDefaults() {
        int pid = this.id;
        String n = this.name == null ? "" : this.name.trim().toLowerCase();
        if (pid <= 0) {
            if (n.startsWith("adventurer") || n.startsWith("basic")) pid = 1;
            else if (n.startsWith("fighter")) pid = 2;
            else if (n.startsWith("thief")) pid = 3;
            else if (n.startsWith("armsman")) pid = 4;
            else if (n.startsWith("hybrid")) pid = 5;
            else if (n.startsWith("wizard") || n.startsWith("mage")) pid = 6;
            else if (n.startsWith("healer")) pid = 7;
            else if (n.startsWith("spellbreaker") || n.startsWith("dark mage") || n.startsWith("darkmage")) pid = 8;
            else if (n.startsWith("lucky")) pid = 9;
        }

        java.util.Map<String, Double> fixed = new java.util.HashMap<String, Double>();
        switch (pid) {
            case 1: this.name = "Adventurer"; this.description = "none"; fixed.put("WIS",4D); fixed.put("END",4D); fixed.put("LCK",4D); fixed.put("STR",4D); fixed.put("DEX",4D); fixed.put("INT",4D); break;
            case 2: this.name = "Fighter"; this.description = "M1"; fixed.put("WIS",0D); fixed.put("END",14D); fixed.put("LCK",0D); fixed.put("STR",18D); fixed.put("DEX",5D); fixed.put("INT",0D); break;
            case 3: this.name = "Thief"; this.description = "M2"; fixed.put("WIS",0D); fixed.put("END",8D); fixed.put("LCK",0D); fixed.put("STR",9D); fixed.put("DEX",18D); fixed.put("INT",0D); break;
            case 4: this.name = "Armsman"; this.description = "M4"; fixed.put("WIS",0D); fixed.put("END",10D); fixed.put("LCK",0D); fixed.put("STR",15D); fixed.put("DEX",14D); fixed.put("INT",0D); break;
            case 5: this.name = "Hybrid"; this.description = "M3"; fixed.put("WIS",0D); fixed.put("END",8D); fixed.put("LCK",0D); fixed.put("STR",10D); fixed.put("DEX",8D); fixed.put("INT",10D); break;
            case 6: this.name = "Wizard"; this.description = "C1"; fixed.put("WIS",8D); fixed.put("END",4D); fixed.put("LCK",5D); fixed.put("STR",0D); fixed.put("DEX",0D); fixed.put("INT",18D); break;
            case 7: this.name = "Healer"; this.description = "C2"; fixed.put("WIS",7D); fixed.put("END",14D); fixed.put("LCK",0D); fixed.put("STR",0D); fixed.put("DEX",0D); fixed.put("INT",16D); break;
            case 8: this.name = "Spellbreaker"; this.description = "C3"; fixed.put("WIS",9D); fixed.put("END",7D); fixed.put("LCK",3D); fixed.put("STR",0D); fixed.put("DEX",0D); fixed.put("INT",14D); break;
            case 9: this.name = "Lucky"; this.description = "S1"; fixed.put("WIS",3D); fixed.put("END",3D); fixed.put("LCK",18D); fixed.put("STR",3D); fixed.put("DEX",3D); fixed.put("INT",3D); break;
            default: return;
        }
        this.id = pid;
        this.stats = fixed;
    }

}