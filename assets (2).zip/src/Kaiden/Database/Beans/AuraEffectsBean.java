
package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;

public class AuraEffectsBean {
    public static final ResultSetMapper<Integer, AuraEffectsBean> resultSetMapper = new ResultSetMapper<Integer, AuraEffectsBean>() {

        @Override
        public AbstractMap.SimpleEntry<Integer, AuraEffectsBean> mapRow(ResultSet rs) throws SQLException {
            AuraEffectsBean ae = new AuraEffectsBean();

            ae.id = rs.getInt("id");
            ae.stat = rs.getString("Stat");
            ae.type = rs.getString("Type");
            ae.value = rs.getDouble("Value");

            return new AbstractMap.SimpleEntry<Integer, AuraEffectsBean>(ae.id, ae);
        }
    };

    private int id;
    private String stat, type;
    private double value;

    /** Build a runtime-only aura effect (used by wiki phase data). */
    public static AuraEffectsBean runtime(int id, String stat, String type, double value) {
        AuraEffectsBean ae = new AuraEffectsBean();
        ae.id = id;
        ae.stat = stat;
        ae.type = type;
        ae.value = value;
        return ae;
    }


    public int getId() {
        return id;
    }

    public String getStat() {
        return stat;
    }

    public String getType() {
        if (type == null || type.trim().isEmpty()) {
            return "+";
        }
        return type.trim();
    }

    public double getValue() {
        return value;
    }
}
