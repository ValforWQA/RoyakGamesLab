package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class QuestBean {

    public static final BeanCreator<HashSet<Integer>> beanLocations = rs -> {
        HashSet<Integer> set = new HashSet();
        set.add(rs.getInt("MapID"));
        while (rs.next()) {
            set.add(rs.getInt("MapID"));
        }
        return set;
    };
    public static final ResultSetMapper<Integer, Integer> requirementsRewardsMapper = rs -> new AbstractMap.SimpleEntry(rs.getInt("ItemID"), rs.getInt("Quantity"));
    public static final ResultSetMapper<Integer, QuestBean> resultSetMapper = rs -> {
        QuestBean quest = new QuestBean();
        quest.id = rs.getInt("id");
        quest.factionId = rs.getInt("FactionID");
        quest.reqReputation = rs.getInt("ReqReputation");
        quest.reqClassId = rs.getInt("ReqClassID");
        quest.reqClassPoints = rs.getInt("ReqClassPoints");
        quest.experience = rs.getInt("Experience");
        quest.gold = rs.getInt("Gold");
        quest.coin = rs.getInt("Coin");
        quest.reputation = rs.getInt("Reputation");
        quest.classPoints = rs.getInt("ClassPoints");
        quest.level = rs.getInt("Level");
        quest.slot = rs.getInt("Slot");
        quest.value = rs.getInt("Value");
        quest.index = rs.getInt("Index");
        quest.achievement = rs.getInt("AchID");
        quest.reqSouls = rs.getInt("ReqSouls");
        quest.name = rs.getString("Name");
        quest.description = rs.getString("Description");
        quest.endText = rs.getString("EndText");
        quest.field = rs.getString("Field");
        quest.once = rs.getBoolean("Once");
        quest.war = rs.getInt("War");
        quest.upgrade = rs.getBoolean("Upgrade");
        try { quest.timeLimitMinutes = rs.getInt("TimeLimitMinutes"); } catch (Exception ignored) {}
        try { quest.timeLimitSeconds = rs.getInt("TimeLimitSeconds"); } catch (Exception ignored) {}
        try {
            int legacyTimeLimit = rs.getInt("TimeLimit");
            if (quest.timeLimitMinutes <= 0 && quest.timeLimitSeconds <= 0 && legacyTimeLimit > 0) {
                quest.timeLimitMinutes = legacyTimeLimit / 60;
                quest.timeLimitSeconds = legacyTimeLimit % 60;
            }
        } catch (Exception ignored) {}
        quest.normalizeTimeLimit();
        return new AbstractMap.SimpleEntry(quest.getId(), quest);
    };
    public LinkedList<QuestRewardBean> rewards;
    public ConcurrentHashMap<Integer, Integer> required;
    public ConcurrentHashMap<Integer, Integer> requirements;
    public Set<Integer> locations;
    private int id;
    private int factionId;
    private int reqReputation;
    private int reqClassId;
    private int reqClassPoints;
    private int experience;
    private int gold;
    private int coin;
    private int reputation;
    private int classPoints;
    private int level;
    private int slot;
    private int value;
    private int index;
    private int achievement;
    private int war;
    private int timeLimitMinutes;
    private int timeLimitSeconds;
    private String name;
    private String description;
    private String endText;
    private String field;
    private int reqSouls;
    private boolean upgrade;
    private boolean once;

    public int getId() {
        return this.id;
    }

    public int getReqSouls() { return this.reqSouls; }
    public int getFactionId() {
        return this.factionId;
    }

    public int getReqReputation() {
        return this.reqReputation;
    }

    public int getReqClassId() {
        return this.reqClassId;
    }

    public int getReqClassPoints() {
        return this.reqClassPoints;
    }

    public int getExperience() {
        return this.experience;
    }

    public int getGold() {
        return this.gold;
    }

    public int getCoin() {
        return this.coin;
    }

    public int getReputation() {
        return this.reputation;
    }

    public int getClassPoints() {
        return this.classPoints;
    }

    public int getLevel() {
        return this.level;
    }

    public int getSlot() {
        return this.slot;
    }

    public int getValue() {
        return this.value;
    }

    public int getWar() {
        return this.war;
    }

    public int getIndex() {
        return this.index;
    }

    public int getAchievement() {
        return this.achievement;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public String getEndText() {
        return this.endText;
    }

    public String getField() {
        return this.field;
    }

    public boolean isUpgrade() {
        return this.upgrade;
    }

    public boolean isOnce() {
        return this.once;
    }
    private void normalizeTimeLimit() {
        if (this.timeLimitMinutes < 0) {
            this.timeLimitMinutes = 0;
        }
        if (this.timeLimitSeconds < 0) {
            this.timeLimitSeconds = 0;
        }
        if (this.timeLimitSeconds >= 60) {
            this.timeLimitMinutes += (this.timeLimitSeconds / 60);
            this.timeLimitSeconds = (this.timeLimitSeconds % 60);
        }
    }

    public int getTimeLimitMinutes() {
        return this.timeLimitMinutes;
    }

    public int getTimeLimitSeconds() {
        return this.timeLimitSeconds;
    }

    public int getTimeLimitTotalSeconds() {
        return Math.max(0, (this.timeLimitMinutes * 60) + this.timeLimitSeconds);
    }

    public boolean isTimed() {
        return getTimeLimitTotalSeconds() > 0;
    }

}