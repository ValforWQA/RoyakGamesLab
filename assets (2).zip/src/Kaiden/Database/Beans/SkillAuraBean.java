package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;

public class SkillAuraBean {
    public static final ResultSetMapper<Integer, SkillAuraBean> resultSetMapper = new ResultSetMapper<Integer, SkillAuraBean>() {
        @Override
        public AbstractMap.SimpleEntry<Integer, SkillAuraBean> mapRow(ResultSet rs) throws SQLException {
            SkillAuraBean sa = new SkillAuraBean();
            sa.id = rs.getInt("id");
            sa.skillId = rs.getInt("SkillID");
            sa.auraId = rs.getInt("AuraID");
            //private String target;
            //private double chance;
            //private int stacks;
            //sa.target = rs.getString("Target");
            //sa.chance = rs.getDouble("Chance");
            //sa.stacks = rs.getInt("Stacks");
            return new AbstractMap.SimpleEntry<Integer, SkillAuraBean>(sa.id, sa);
        }
    };

    private int id;
    private int skillId;
    private int auraId;
    //private String target;
    //private double chance;
    //private int stacks;

    public int getId() { return id; }
    public int getSkillId() { return skillId; }
    public int getAuraId() { return auraId; }

}
