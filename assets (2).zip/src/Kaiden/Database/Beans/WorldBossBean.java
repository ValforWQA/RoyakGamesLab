
package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class WorldBossBean {
    public static final ResultSetMapper resultSetMapper = rs -> {
        WorldBossBean worldboss = new WorldBossBean();
        worldboss.monsterId = rs.getInt("MonsterID");
        worldboss.spawnInterval = rs.getLong("SpawnInterval");
        worldboss.timeLimit = rs.getInt("TimeLimit");
        worldboss.description = rs.getString("Description");
        worldboss.mapId = rs.getInt("MapID");
        worldboss.image = rs.getString("Image");
        worldboss.kills = rs.getInt("Kills");
        worldboss.deaths = rs.getInt("Deaths");
        return new AbstractMap.SimpleEntry<Integer, WorldBossBean>(worldboss.monsterId, worldboss);
    };

    public int monsterId;
    public int mapId;
    public int roomNumber;
    public int kills;
    public int deaths;
    public long spawnInterval = 0;
    public long timeLimit = 0;
    public String description;
    public String image;
    public boolean isActive = false;
    public boolean isNotified = false;
           
   
    public int getMonsterId() {
        return this.monsterId;
    }
    
    public Long getSpawnInterval() {
        return this.spawnInterval;
    }
    
    public Long getTimeLimit() {
        return this.timeLimit;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public String getImage() {
        return this.image;
    }
    
    public int getMapId() {
        return this.mapId;
    }
    
    public int getKills() {
        return this.kills;
    }
    
    public int getDeaths() {
        return this.deaths;
    }
}