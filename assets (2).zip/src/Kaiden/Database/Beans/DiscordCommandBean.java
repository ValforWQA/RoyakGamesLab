package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class DiscordCommandBean {

    public static final ResultSetMapper<String, DiscordCommandBean> resultSetMapper = rs -> {
        DiscordCommandBean command = new DiscordCommandBean();
        command.access = rs.getInt("Access");
        command.command = rs.getString("Command");
        command.file = rs.getString("File");
        return new AbstractMap.SimpleEntry(command.getCommand(), command);
    };

    private int access;
    private String command;
    private String file;

    public int getAccess() {
        return this.access;
    }

    public String getCommand() {
        return this.command;
    }

    public String getFileName() {
        return this.file;
    }

    public java.lang.Class getFile() throws ClassNotFoundException {
        java.lang.Class ex = java.lang.Class.forName(this.file);
        return ex;
    }
}
