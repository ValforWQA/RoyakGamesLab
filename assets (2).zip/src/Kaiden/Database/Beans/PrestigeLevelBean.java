package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class PrestigeLevelBean {

    public static ResultSetMapper<Integer, PrestigeLevelBean> resultSetMapper = rs -> {
        PrestigeLevelBean prestige = new PrestigeLevelBean();
        prestige.level = rs.getInt("PrestigeLevel");
        prestige.souls = rs.getInt("Souls");

        return new AbstractMap.SimpleEntry(prestige.level, prestige);
    };

    private int level;
    private int souls;

    public int getPrestigeLevel() {return this.level;}
    public int getSouls() {return this.souls;}
}
