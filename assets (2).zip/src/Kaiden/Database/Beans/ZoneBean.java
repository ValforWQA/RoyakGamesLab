package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

public class ZoneBean {
    public static final ResultSetMapper<Integer, Integer> beanItems = rs -> new AbstractMap.SimpleEntry(rs.getInt("ItemID"), rs.getInt("Quantity"));

    public static final ResultSetMapper<String, ZoneBean> resultSetMapper = rs -> {
        ZoneBean zone = new ZoneBean();
        zone.name = rs.getString("Name").toLowerCase();
        zone.file = rs.getString("File");
        zone.id = rs.getInt("id");
        zone.maxPlayers = rs.getInt("MaxPlayers");
        zone.reqLevel = rs.getInt("ReqLevel");
        zone.upgrade = rs.getBoolean("Upgrade");
        zone.staff = rs.getBoolean("Staff");
        zone.PvP = rs.getBoolean("PvP");
        zone.PK = rs.getBoolean("PK");
        zone.WorldBoss = rs.getBoolean("WorldBoss");
        return new AbstractMap.SimpleEntry(zone.getName(), zone);
    };
    public Set<MapMonsterBean> monsters = Collections.EMPTY_SET;
    public Set<MapNpcBean> npcs = Collections.EMPTY_SET;
    public Map<Integer, CellBean> cells = Collections.EMPTY_MAP;
    public Map<Integer, Integer> items = Collections.EMPTY_MAP;
    public String file;
    private String name;
    private int id;
    private int maxPlayers;
    private int reqLevel;
    private boolean upgrade;
    private boolean staff;
    private boolean PvP;
    private boolean PK;
    private boolean WorldBoss;

    public String getName() {
        return this.name;
    }

    public String getFile() {
        return this.file;
    }

    public int getMaxPlayers() {
        return this.maxPlayers;
    }

    public int getReqLevel() {
        return this.reqLevel;
    }

    public boolean isUpgrade() {
        return this.upgrade;
    }

    public boolean isStaff() {
        return this.staff;
    }

    public int getId() {
        return this.id;
    }

    public int getZoneID() {
        return this.id;
    }
    
    public boolean isPvP() {
        return this.PvP;
    }

    public boolean isPK() {
        return this.PK;
    }

    public boolean isWorldBoss() {
        return this.WorldBoss;
    }
}