package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;

public class MonsterAurasBean {

    public static final ResultSetMapper<Integer, MonsterAurasBean> resultSetMapper = new ResultSetMapper<Integer, MonsterAurasBean>() {
        @Override
        public AbstractMap.SimpleEntry<Integer, MonsterAurasBean> mapRow(ResultSet rs) throws SQLException {
            MonsterAurasBean ma = new MonsterAurasBean();
            ma.id = rs.getInt("id");
            ma.monsterSkillId = rs.getInt("MonsterSkillID");
            ma.auraId = rs.getInt("AuraID");
            ma.target = rs.getString("Target");
            ma.chance = rs.getDouble("Chance");
            ma.stacks = rs.getInt("Stacks");
            return new AbstractMap.SimpleEntry<Integer, MonsterAurasBean>(ma.id, ma);
        }
    };

    private int id;
    private int monsterSkillId;
    private int auraId;
    private String target;
    private double chance;
    private int stacks;

    public int getId() { return id; }
    public int getMonsterSkillId() { return monsterSkillId; }
    public int getAuraId() { return auraId; }
    public String getTarget() { return target; }
    public double getChance() { return chance; }
    public int getStacks() { return stacks; }

    public boolean isSelfTarget() {
        return target != null && target.equalsIgnoreCase("self");
    }

    public boolean isPlayerTarget() {
        return target != null && (target.equalsIgnoreCase("player") || target.equalsIgnoreCase("players"));
    }

    public boolean isMonsterTarget() {
        return target != null && (target.equalsIgnoreCase("monster") || target.equalsIgnoreCase("monsters"));
    }

    public boolean isOtherTarget() {
        return target != null && target.equalsIgnoreCase("other");
    }

    public boolean isTargetTarget() {
        return target == null || target.trim().isEmpty() || target.equalsIgnoreCase("target");
    }
}

