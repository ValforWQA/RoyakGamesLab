package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;

public class SkillIconBean {

    public static final ResultSetMapper<String, SkillIconBean> resultSetMapper = rs -> {
        SkillIconBean icon = new SkillIconBean();
        icon.id = rs.getInt("id");
        icon.name = rs.getString("Icon");
        return new AbstractMap.SimpleEntry(icon.getId(), icon);
    };

    private int id;
    private String name;

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

}
