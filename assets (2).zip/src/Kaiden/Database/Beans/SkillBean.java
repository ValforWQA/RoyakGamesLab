package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SkillBean {
    
public static final ResultSetMapper<Integer, Integer> AuraSkillMapper = rs -> new AbstractMap.SimpleEntry(rs.getInt("AuraID"), rs.getInt("SkillID"));
    
    public static final BeanCreator<Set<Integer>> beanAuras = rs -> {
        Set<Integer> set = new HashSet();
        set.add(rs.getInt("SkillID"));
        while (rs.next()) {
            set.add(rs.getInt("SkillID"));
        }
        return set;
    };

    public static ResultSetMapper<Integer, SkillBean> resultSetMapper = rs -> {
        SkillBean skill = new SkillBean();
        skill.id = rs.getInt("id");
        skill.name = rs.getString("Name");
        skill.animation = rs.getString("Animation");
        skill.description = rs.getString("Description");
        skill.icon = rs.getString("Icon");
        skill.dsrc = rs.getString("Dsrc");
        skill.reference = rs.getString("Reference");
        skill.target = rs.getString("Target");
        skill.effects = rs.getString("Effects");
        skill.type = rs.getString("Type");
        skill.strl = rs.getString("Strl");
        skill.damage = rs.getDouble("Damage");
        skill.mana = rs.getInt("Mana");
        skill.range = rs.getInt("Range");
        skill.hitTargets = rs.getInt("HitTargets");
        skill.cooldown = rs.getInt("Cooldown");
        skill.auraId = rs.getInt("AuraID");
        skill.pet = rs.getInt("Pet");
        return new AbstractMap.SimpleEntry(skill.id, skill);
    };
    private String name;
    private String animation;
    private String description;
    private String icon;
    private String dsrc;
    private String reference;
    private String target;
    private String effects;
    private String type;
    private String strl;
    private double damage;
    private int id;
    private int mana;
    private int range;
    private int hitTargets;
    private int cooldown;
    private int auraId;
    private int pet;
    public Map<Integer, Integer> auras;
    public List<SkillAuraBean> auraLinks;

    public boolean hasAuraId() {
        return this.auraId > 0;
    }

    public String getName() {
        return this.name;
    }

    public String getAnimation() {
        return this.animation;
    }

    public String getDescription() {
        return this.description;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getDsrc() {
        return this.dsrc;
    }

    public String getReference() {
        return this.reference;
    }

    public String getTarget() {
        return this.target;
    }

    public String getEffects() {
        return this.effects;
    }

    public String getType() {
        return this.type;
    }

    public String getStrl() {
        return this.strl;
    }

    public double getDamage() {
        return this.damage;
    }

    public int getMana() {
        return this.mana;
    }

    public int getRange() {
        return this.range;
    }

    public int getPet() {
        return this.pet;
    }

    public int getHitTargets() {
        return this.hitTargets;
    }

    public int getCooldown() {
        return this.cooldown;
    }

    public int getId() {
        return this.id;
    }

    public int getAuraId() {
        return this.auraId;
    }
}
