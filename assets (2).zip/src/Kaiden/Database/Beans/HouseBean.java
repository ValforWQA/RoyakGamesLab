package Kaiden.Database.Beans;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class HouseBean extends ZoneBean {

    private final String ownerName;
    private final int ownerId;

    // ItemID of the equipped house (the one you're joining)
    private int houseItemId;

    // Placed items + inventory
    private JSONArray houseItems;

    // Raw house info string from DB
    private String houseInfo;

    /**
     * @param houseItems  JSON array of ho/hi items
     * @param houseInfo   sHouseInfo string from users.HouseInfo
     * @param ownerName   owner's name
     * @param ownerId     owner's users.id
     * @param houseItemId ItemID of the equipped house (Equipment='ho', Equipped=1)
     */
    public HouseBean(JSONArray houseItems,
                     String houseInfo,
                     String ownerName,
                     int ownerId,
                     int houseItemId) {
        super();
        this.houseItems = houseItems;
        this.houseInfo = houseInfo;
        this.ownerName = ownerName;
        this.ownerId = ownerId;
        this.houseItemId = houseItemId;
    }

    /**
     * JSON blob sent to the client when joining a house.
     */
    public JSONObject getData() {
        JSONObject house = new JSONObject();

        // ✅ ItemID of the house you are joining
        house.put("HouseItemID", this.houseItemId);

        // Map file comes from ZoneBean.file (set via setFile() in HouseJoin)
        house.put("strMapFileName", this.file);
        house.put("isPvP", true);

        house.put("strMapName", "house");
        house.put("sHouseInfo", this.houseInfo);
        house.put("items", this.houseItems);
        house.put("roomName", "house-" + this.ownerId);
        house.put("unm", this.ownerName.toLowerCase());
        house.put("CharID", this.ownerId);

        return house;
    }

    // ----- setters / getters -----

    public void setFile(String file) {
        this.file = file;
    }

    public void setHouseInfo(String houseInfo) {
        this.houseInfo = houseInfo;
    }

    public void setHouseItemId(int id) {
        this.houseItemId = id;
    }

    public int getHouseItemId() {
        return this.houseItemId;
    }

    public void setHouseItems(JSONArray houseItems) {
        this.houseItems = houseItems;
    }

    public int getReqLevel() {
        return 0;
    }

    public boolean isStaff() {
        return false;
    }

    public boolean isUpgrade() {
        return false;
    }

    public boolean isPvP() {
        return false;
    }

    public int getMaxPlayers() {
        return 100000;
    }

    public int getOwnerId() {
        return this.ownerId;
    }
}
