package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;

/** Optional runtime phase row generated from AQW wiki mechanics. */
public class AuraPhaseBean {
    public static final ResultSetMapper<Integer, AuraPhaseBean> resultSetMapper = new ResultSetMapper<Integer, AuraPhaseBean>() {
        @Override
        public AbstractMap.SimpleEntry<Integer, AuraPhaseBean> mapRow(ResultSet rs) throws SQLException {
            AuraPhaseBean p = new AuraPhaseBean();
            p.id = rs.getInt("id");
            p.auraId = rs.getInt("AuraID");
            p.phaseNo = rs.getInt("PhaseNo");
            p.afterSeconds = rs.getDouble("AfterSeconds");
            p.durationSeconds = rs.getDouble("DurationSeconds");
            p.stat = rs.getString("Stat");
            p.value = rs.getDouble("Value");
            p.type = rs.getString("Type");
            return new AbstractMap.SimpleEntry<Integer, AuraPhaseBean>(p.id, p);
        }
    };

    private int id, auraId, phaseNo;
    private double afterSeconds, durationSeconds, value;
    private String stat, type;

    public int getId() { return id; }
    public int getAuraId() { return auraId; }
    public int getPhaseNo() { return Math.max(1, phaseNo); }
    public double getAfterSeconds() { return Math.max(0.0D, afterSeconds); }
    public double getDurationSeconds() { return Math.max(0.0D, durationSeconds); }
    public String getStat() { return stat == null ? "" : stat.trim(); }
    public double getValue() { return value; }
    public String getType() { return type == null || type.trim().isEmpty() ? "+" : type.trim(); }
}
