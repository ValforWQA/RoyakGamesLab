package Kaiden.Database.Beans;

import jdbchelper.ResultSetMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractMap;

public class MonsterSkillEffectsBean {
    public static final ResultSetMapper<Integer, MonsterSkillEffectsBean> resultSetMapper = new ResultSetMapper<Integer, MonsterSkillEffectsBean>() {
        @Override
        public AbstractMap.SimpleEntry<Integer, MonsterSkillEffectsBean> mapRow(ResultSet rs) throws SQLException {
            MonsterSkillEffectsBean b = new MonsterSkillEffectsBean();
            b.id = rs.getInt("id");
            b.monsterSkillId = rs.getInt("MonsterSkillID");
            b.stat = rs.getString("Stat");
            b.value = rs.getDouble("Value");
            b.type = rs.getString("Type");
            b.duration = rs.getInt("Duration");
            b.chance = rs.getDouble("Chance");
            b.stack = rs.getInt("Stack");
            b.target = rs.getString("Target");
            return new AbstractMap.SimpleEntry<Integer, MonsterSkillEffectsBean>(b.id, b);
        }
    };

    private int id;
    private int monsterSkillId;
    private String stat;
    private double value;
    private String type;
    private int duration;
    private double chance;
    private int stack;
    private String target;

    public int getId() { return id; }
    public int getMonsterSkillId() { return monsterSkillId; }
    public String getStat() { return stat == null ? "" : stat.trim().toLowerCase(); }
    public double getValue() { return value; }
    public String getType() { return type == null ? "+" : type.trim(); }
    public int getDuration() { return duration; }
    public double getChance() { return chance; }
    public int getStack() { return stack < 1 ? 1 : stack; }
    public String getTarget() { return target == null ? "self" : target.trim().toLowerCase(); }
    public boolean isSelfTarget() { return "self".equals(getTarget()); }
    public boolean isPlayerTarget() { String t = getTarget(); return "player".equals(t) || "players".equals(t) || "target".equals(t) || "other".equals(t); }
    public boolean isMonsterTarget() { String t = getTarget(); return "monster".equals(t) || "monsters".equals(t); }
}
