package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Set;

public class HairshopBean {
    public static final BeanCreator<Set<Integer>> beanHairshopItems = rs -> {
        HashSet<Integer> set = new HashSet();
        set.add(rs.getInt("HairID"));
        while (rs.next()) {
            set.add(rs.getInt("HairID"));
        }
        return set;
    };
    public static final ResultSetMapper<Integer, HairshopBean> resultSetMapper = rs -> {
        HairshopBean hairshop = new HairshopBean();
        hairshop.id = rs.getInt("id");
        return new AbstractMap.SimpleEntry(hairshop.getId(), hairshop);
    };
    public Set<Integer> male;
    public Set<Integer> female;
    private int id;

    public Set getShopItems(String gender) {
        if (gender.equals("M")) {
            return this.male;
        }
        return this.female;
    }

    public int getId() {
        return this.id;
    }
}