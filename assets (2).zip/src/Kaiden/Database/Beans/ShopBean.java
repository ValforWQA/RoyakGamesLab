package Kaiden.Database.Beans;

import jdbchelper.BeanCreator;
import jdbchelper.ResultSetMapper;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ShopBean {

    public static final BeanCreator<Set<Integer>> beanLocations = rs -> {
        HashSet<Integer> set = new HashSet();
        set.add(rs.getInt("MapID"));
        while (rs.next()) {
            set.add(rs.getInt("MapID"));
        }
        return set;
    };
    public static final ResultSetMapper<Integer, Integer> shopItemsMapper = rs -> new AbstractMap.SimpleEntry(rs.getInt("id"), rs.getInt("ItemID"));
    public static final ResultSetMapper<Integer, ShopBean> resultSetMapper = rs -> {
        ShopBean shop = new ShopBean();
        shop.id = rs.getInt("id");
        shop.name = rs.getString("Name");
        shop.field = rs.getString("Field");
        shop.house = rs.getBoolean("House");
        shop.upgrade = rs.getBoolean("Upgrade");
        shop.staff = rs.getBoolean("Staff");
        shop.limited = rs.getBoolean("Limited");
        shop.index = rs.getInt("Index");
        return new AbstractMap.SimpleEntry(shop.getId(), shop);
    };
    public Map<Integer, Integer> items;
    public Set<Integer> locations;
    private int id;
    private int index;
    private String name;
    private String field;
    private boolean house;
    private boolean upgrade;
    private boolean staff;
    private boolean limited;

    public String getName() {
        return this.name;
    }

    public String getField() {
        return this.field;
    }

    public int getIndex() {
        return this.index;
    }

    public boolean isHouse() {
        return this.house;
    }

    public boolean isUpgrade() {
        return this.upgrade;
    }

    public boolean isStaff() {
        return this.staff;
    }

    public boolean isLimited() {
        return this.limited;
    }

    public int getId() {
        return this.id;
    }
}