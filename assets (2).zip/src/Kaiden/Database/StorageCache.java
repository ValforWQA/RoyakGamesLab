package Kaiden.Database;

import Kaiden.Database.Beans.*;
import Kaiden.Database.Configuration.Configuration;
import jdbchelper.BeanCreator;
import jdbchelper.QueryResult;
import jdbchelper.ResultSetMapper;

import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;


public class StorageCache {
    private static StorageCache instance;
    public static StorageCache getInstance() {
        if (instance == null) {
            instance = new StorageCache();
        }
        return instance;
    }
    private final ResultSetMapper<String, Double> coreValuesMapper = rs -> new AbstractMap.SimpleEntry<>(rs.getString("name"), (rs.getDouble("value")));
    private final ResultSetMapper<Integer, String> factionsMapper = rs -> new AbstractMap.SimpleEntry<>((rs.getInt("id")), rs.getString("Name"));
    private final BeanCreator<String> newsCreator = rs -> {
        StringBuilder sb = new StringBuilder();
        sb.append(rs.getString("name"));
        sb.append("=");
        sb.append(rs.getString("value"));

        while (rs.next()) {
            sb.append(",");
            sb.append(rs.getString("name"));
            sb.append("=");
            sb.append(rs.getString("value"));
        }

        return sb.toString();
    };
    private String messageOfTheDay;
    private String newsString;
    public int maxPlayers;
    private HashMap<String, ZoneBean> zones;
    private HashMap<Integer, NpcBean> npc;
    HashMap<Integer, MapNpcBeanApop> MapNpcApops;
    public HashMap<Integer, WorldBossBean> worldbosses = new HashMap<>();
    public HashMap<Integer, String> worldBossMaps = new HashMap<>();
    private HashMap<Integer, MonsterBean> monsters;
    private HashMap<Integer, MonsterOutfitBean> monsterOutfits;
    private HashMap<Integer, HairBean> hairs;
    private HashMap<String, Double> coreValues;
    private HashMap<Integer, String> factions;
    private HashMap<Integer, FactionBean> factioninfo;
    private HashMap<Integer, ItemBean> items;
    private HashMap<Integer, StateBean> state;
    private HashMap<Integer, SkillBean> skills;
    private HashMap<Integer, TitleBean> titles;
    private HashMap<String, SkillCombatBlock> skillCombat;
    private HashMap<Integer, MonsterSkillsBean> monsterskills;
    private HashMap<Integer, MonsterAurasBean> monsterAuras;
    private HashMap<Integer, List<MonsterAurasBean>> monsterAurasBySkillId;
    private HashMap<Integer, MonsterSkillEffectsBean> monsterSkillEffects;
    private HashMap<Integer, List<MonsterSkillEffectsBean>> monsterSkillEffectsBySkillId;
    private HashMap<Integer, EnhancementBean> enhancements;
    private HashMap<Integer, EnhancementPatternBean> enhancementPatterns;
    private HashMap<Integer, AuraEffectsBean> effects;
    private HashMap<Integer, AuraBean> auras;
    private HashMap<Integer, FactionPerks> perks;
    private HashMap<Integer, AchievementBean> achievements;
    private HashMap<String, DiscordCommandBean> discordcommands;
    private HashMap<Integer, ShopBean> shops;
    private HashMap<Integer, HairshopBean> hairshops;
    private HashMap<Integer, QuestBean> quests;
    private HashMap<Integer, SkillIconBean> skillicons;
    private HashMap<Integer, PrestigeLevelBean> prestige;
    private HashMap<String, ServerFeatureBean> serverFeatures;
    private HashMap<String, ServerThreadBean> serverThreads;
    private HashMap<String, ChatChannelBean> chatChannels;


    private SortedMap coreValuesMap;

    public boolean containsArea(String area) {
        return this.zones.containsKey(area);
    }

    public void addHouse(String houseName, HouseBean house) {
        this.zones.put(houseName, house);
    }

    public ZoneBean getArea(String area) {
        return this.zones.get(area);
    }

    public ItemBean getItem(int itemId) {
        return this.items.get(itemId);
    }

    public TitleBean getTitle(int titleid) { return this.titles.get(titleid); }

    public DiscordCommandBean getDiscordcommands(String command) {return this.discordcommands.get(command);}

    public SkillIconBean getSkillIcon(int iconid) { return this.skillicons.get(iconid);}

    public boolean hasSkillRaceLock(int skillid) {
        if (skillCombat == null) return false;
        for (SkillCombatBlock lock : skillCombat.values()) if (lock.getId() == skillid) return true;
        return false;
    }

    public String getSkillRequiredRaces(int skillid) {
        java.util.TreeSet<String> races = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        if (skillCombat != null) {
            for (SkillCombatBlock lock : skillCombat.values()) {
                if (lock.getId() == skillid && lock.getName() != null && !lock.getName().trim().isEmpty()) {
                    races.add(lock.getName().trim());
                }
            }
        }
        return String.join(" or ", races);
    }

    public boolean isSkillRaceAllowed(int skillid, String race) {
        if (!hasSkillRaceLock(skillid)) return true;
        return race != null && skillCombat.containsKey(skillid + ":" + race.trim().toLowerCase(java.util.Locale.ROOT));
    }

    public ItemBean getItemOrDefault(int npc) {
        return this.items.getOrDefault(npc, null);
    }

    public AchievementBean getAchievement(int achievement) {
        return this.achievements.get(achievement);
    }
    public ShopBean getShop(int shopId) {
        return this.shops.get(shopId);
    }

    /**
     * Adds a shop -> map location to both the database and the live cache.
     * Returns true only when a new location was created.
     */
    public synchronized boolean ensureShopLocation(int shopId, int mapId) {
        ShopBean shop = this.shops.get(shopId);
        if (shop == null || mapId <= 0) {
            return false;
        }

        if (shop.locations != null && shop.locations.contains(mapId)) {
            return false;
        }

        Storage.getInstance().getJdbc().execute(
                "INSERT INTO shops_locations (ShopID, MapID) VALUES (?, ?)",
                shopId, mapId
        );

        Set<Integer> updated = shop.locations == null
                ? new HashSet<Integer>()
                : new HashSet<Integer>(shop.locations);
        updated.add(mapId);
        shop.locations = updated;
        return true;
    }

    /**
     * Adds a quest -> map location to both the database and the live cache.
     * Returns true only when a new location was created.
     */
    public synchronized boolean ensureQuestLocation(int questId, int mapId) {
        QuestBean quest = this.quests.get(questId);
        if (quest == null || mapId <= 0) {
            return false;
        }

        if (quest.locations != null && quest.locations.contains(mapId)) {
            return false;
        }

        Storage.getInstance().getJdbc().execute(
                "INSERT INTO quests_locations (QuestID, MapID) VALUES (?, ?)",
                questId, mapId
        );

        Set<Integer> updated = quest.locations == null
                ? new HashSet<Integer>()
                : new HashSet<Integer>(quest.locations);
        updated.add(mapId);
        quest.locations = updated;
        return true;
    }
    public HairshopBean getHairShop(int shopId) {
        return this.hairshops.get(shopId);
    }

    public FactionBean getFactionInfo(int factionid){ return this.factioninfo.get(factionid); }

    public QuestBean getQuest(int questId) {
        return this.quests.get(questId);
    }

    public FactionPerks getPerks(int perkId) {return this.perks.get(perkId); }

    public PrestigeLevelBean getPrestigeLevel(int prestigeid) {return this.prestige.get(prestigeid);}

    public NpcBean getNpc(int Id) {
        return this.npc.get(Id);
    }

    public MapNpcBeanApop getMapNPC(int Id){
        return this.MapNpcApops.get(Id);
    }

    public AuraBean getAura(int auraId) {
        return this.auras.get(auraId);
    }

    public StateBean getState(int level) {
        return this.state.get(level);
    }

    public MonsterSkillsBean getMonsterSkills(int skillId) {
        return this.monsterskills.get(skillId);
    }

    public MonsterOutfitBean getMonsterOutfit(int outfitId) {
        if (this.monsterOutfits == null || outfitId <= 0) return null;
        return this.monsterOutfits.get(outfitId);
    }


    public List<MonsterAurasBean> getMonsterAurasForSkill(int monsterSkillId) {
        if (this.monsterAurasBySkillId == null) return Collections.emptyList();
        List<MonsterAurasBean> list = this.monsterAurasBySkillId.get(monsterSkillId);
        return list != null ? list : Collections.<MonsterAurasBean>emptyList();
    }

    public List<MonsterSkillEffectsBean> getMonsterSkillEffectsForSkill(int monsterSkillId) {
        if (this.monsterSkillEffectsBySkillId == null) return Collections.emptyList();
        List<MonsterSkillEffectsBean> list = this.monsterSkillEffectsBySkillId.get(monsterSkillId);
        return list != null ? list : Collections.<MonsterSkillEffectsBean>emptyList();
    }


    public Set<Entry<Integer, WorldBossBean>> getWorldBossEntrySet() {
        return this.worldbosses.entrySet();
    }

    public Collection<WorldBossBean> getWorldBosses() {
        return this.worldbosses.values();
    }

    public AuraEffectsBean getAuraEffect(int effectId) {
        return this.effects.get(effectId);
    }

    public HairBean getHair(int hairId) {
        return this.hairs.get(hairId);
    }

    public SkillBean getSkill(int skillId) {
        return this.skills.get(skillId);
    }

    public MonsterBean getMonster(int monsterid) {
        return this.monsters.get(monsterid);
    }
    public EnhancementBean getEnhancement(int enhancementId) {
        return this.enhancements.get(enhancementId);
    }

    public EnhancementPatternBean getEnhancementPattern(int patternId) {
        return this.enhancementPatterns.get(patternId);
    }

    // get sizes
    public int getAreaSize() {
        return this.zones.size();
    }

    public int getItemSize() {
        return this.items.size();
    }


    public int getAchievementSize() {
        return this.achievements.size();
    }
    public int getShopSize() {
        return this.shops.size();
    }
    public int getHairShopSize() {
        return this.hairshops.size();
    }

    public int getQuestSize() {
        return this.quests.size();
    }

    public int getNpcSize() {
        return this.npc.size();
    }

    public int getAuraSize() {
        return this.auras.size();
    }


    public int getAuraEffectSize() {
        return this.effects.size();
    }

    public int getHairSize() {
        return this.hairs.size();
    }

    public int getSkillSize() {
        return this.skills.size();
    }


    public int getMonsterSize() {
        return this.monsters.size();
    }
    public int getEnhancementSize() {
        return this.enhancements.size();
    }

    public int getEnhancementPatternSize() {
        return this.enhancementPatterns.size();
    }
    // end sizes

    public Collection<EnhancementPatternBean> getEnhancementPatterns() {
        return this.enhancementPatterns.values();
    }

    public String getFaction(int factionId) {
        return this.factions.get(factionId);
    }

    public Double getCoreValue(String value) {
        return this.coreValues.get(value);
    }

    public SortedMap<String, Double> getCoreValuesMap() {
        return this.coreValuesMap;
    }

    public Set<Entry<String, Double>> getCoreValues() {
        return this.coreValues.entrySet();
    }

    public String getMessageOfTheDay() {
        return this.messageOfTheDay;
    }

    public String getServerStrings() {
        return this.newsString;
    }

    public java.util.Map<String, ServerFeatureBean> getServerFeatures() {
        return this.serverFeatures;
    }

    public java.util.Map<String, ServerThreadBean> getServerThreads() {
        return this.serverThreads;
    }

    public ServerThreadBean getServerThread(String threadKey) {
        if (threadKey == null) {
            return null;
        }
        if (this.serverThreads == null) {
            return null;
        }
        return this.serverThreads.get(threadKey.trim().toLowerCase());
    }

    public java.util.Map<String, ChatChannelBean> getChatChannels() {
        return this.chatChannels;
    }

    public ChatChannelBean getChatChannel(String channelKey) {
        if (channelKey == null || this.chatChannels == null) {
            return null;
        }
        return this.chatChannels.get(channelKey.trim().toLowerCase());
    }

    public ServerFeatureBean getServerFeature(String featureKey) {
        if (featureKey == null) {
            return null;
        }
        if (this.serverFeatures == null) {
            return null;
        }
        return this.serverFeatures.get(featureKey.trim().toLowerCase());
    }

    public boolean isServerFeatureEnabled(String featureKey) {
        ServerFeatureBean feature = this.getServerFeature(featureKey);
        return feature == null || feature.isEnabled();
    }

    public java.util.Map<String, DiscordCommandBean> getDiscordCommandsMap() {
        return this.discordcommands;
    }




    public void RetrieveStorageBeans(String type) {
        switch (type) {
            case "settings":
                this.state = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM settings_levels", StateBean.resultSetMapper));
                this.messageOfTheDay = Storage.getInstance().getJdbc().queryForString("SELECT MOTD FROM servers WHERE Name LIKE ?", Configuration.SERVER_NAME);
                this.maxPlayers = Integer.parseInt(Storage.getInstance().getJdbc().queryForString("SELECT Max FROM servers WHERE Name LIKE ?", Configuration.SERVER_NAME));
                this.newsString = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM settings_login WHERE `Type` = 'external' OR `Type` = 'internal'", this.newsCreator);
                this.coreValuesMap = Storage.getInstance().getJdbc().queryForMap("SELECT * FROM settings_rates", this.coreValuesMapper);
                this.coreValues = new HashMap(this.coreValuesMap);
                this.factions = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM factions", this.factionsMapper));
                this.achievements = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM achievements", AchievementBean.resultSetMapper));
                this.prestige = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM settings_prestige_levels", PrestigeLevelBean.resultSetMapper));
                this.perks = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM settings_factions_perks", FactionPerks.resultSetMapper));
                this.serverFeatures = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM servers_features", ServerFeatureBean.resultSetMapper));
                this.factioninfo = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM factions", FactionBean.resultSetMapper));
                this.titles = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM title", TitleBean.resultSetMapper));
                try {
                    this.chatChannels = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM chat_channels WHERE Active >= 0 ORDER BY id ASC", ChatChannelBean.resultSetMapper));
                } catch (Exception ignored) {
                    this.chatChannels = new HashMap<String, ChatChannelBean>();
                }
                try {
                    this.serverThreads = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM servers_threads", ServerThreadBean.resultSetMapper));
                } catch (Exception ignored) {
                    this.serverThreads = new HashMap<String, ServerThreadBean>();
                }
                if(!Configuration.DISCORD_BOT_TOKEN.isEmpty()) {this.discordcommands = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM discord_commands", DiscordCommandBean.resultSetMapper));}
                break;
                case "royakgames":
                this.npc = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM npcs", NpcBean.resultSetMapper));
                this.monsterskills = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM monsters_skills", MonsterSkillsBean.resultSetMapper));

                // Monster skill -> auras bridge (multiple auras per monster skill)
                this.monsterAuras = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM monsters_auras", MonsterAurasBean.resultSetMapper));
                this.monsterAurasBySkillId = new HashMap<Integer, List<MonsterAurasBean>>();
                for (MonsterAurasBean link : this.monsterAuras.values()) {
                    if (link == null) continue;
                    List<MonsterAurasBean> list = this.monsterAurasBySkillId.get(link.getMonsterSkillId());
                    if (list == null) {
                        list = new ArrayList<MonsterAurasBean>();
                        this.monsterAurasBySkillId.put(link.getMonsterSkillId(), list);
                    }
                    list.add(link);
                }
                // Monster skill stat/effect handling now uses the regular aura system:
                // monsters_auras / monsters_skills.AuraID -> auras -> auras_effects.
                // Keep these maps empty for backward-safe API compatibility, but do not
                // query monsters_skills_effects anymore.
                this.monsterSkillEffects = new HashMap<Integer, MonsterSkillEffectsBean>();
                this.monsterSkillEffectsBySkillId = new HashMap<Integer, List<MonsterSkillEffectsBean>>();
                break;
            case"items":
                this.items = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM items", ItemBean.resultSetMapper));
                for (ItemBean item : this.items.values()) {
                    item.setRequirements(new ConcurrentHashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM items_requirements WHERE ItemID = ?", ItemBean.requirementMapper, item.getId())));
                    if (item.getEquipment().equals("ar") && !item.getType().equals("Enhancement")) {
                        item.setItemClass(Storage.getInstance().getJdbc().queryForObject("SELECT * FROM classes WHERE ClassID = ?", ClassBean.beanCreator, item.getClassId()));
                        if (item.getItemClass() == null) {
                            throw new NullPointerException("An item with the equipment type 'Class' does not have a matching id in the classes table. ItemID: " + item.getId());
                        }
                        item.getItemClass().setSkills(Storage.getInstance().getJdbc().queryForObject("SELECT * FROM classes_skills WHERE ClassID = ?", ClassBean.beanSkills, item.getClassId()));
                        if (item.getItemClass().getSkills() == null) {
                            throw new NullPointerException("A class contains an empty skill set, please delete this item first. ItemID: " + item.getId());
                        }
                    }
                }
                break;
            case"hairs":
                this.hairs = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM hairs", HairBean.resultSetMapper));
                break;
            case"skills":
                this.skills = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM skills", SkillBean.resultSetMapper));
                for (SkillBean auraskill : this.skills.values()) {
                    auraskill.auras = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT SkillID, AuraID FROM skills_auras WHERE SkillID = ?", SkillBean.AuraSkillMapper, auraskill.getId()));
                    auraskill.auraLinks = new ArrayList<SkillAuraBean>(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM skills_auras WHERE SkillID = ?", SkillAuraBean.resultSetMapper, auraskill.getId()).values());
                }
                this.skillCombat = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM classes_skills_locked", SkillCombatBlock.resultSetMapper));
                this.auras = new HashMap (Storage.getInstance().getJdbc().queryForMap("SELECT * FROM auras WHERE id > 0", AuraBean.resultSetMapper));
                //this.auras = auraMap;
                for (AuraBean aura : this.auras.values()) {

                    aura.effects = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM auras_effects WHERE AuraID = ? AND Enabled = 1", AuraBean.beanEffects, Integer.valueOf(aura.getId()));
                    if (aura.effects == null) {
                        aura.effects = Collections.EMPTY_SET;
                    }
                    // Optional Class Grabber wiki phases. Older databases do not need this table.
                    try {
                        aura.phases = new ArrayList<AuraPhaseBean>(Storage.getInstance().getJdbc().queryForMap(
                                "SELECT * FROM auras_wiki_phases WHERE AuraID = ? ORDER BY PhaseNo ASC, id ASC",
                                AuraPhaseBean.resultSetMapper, Integer.valueOf(aura.getId())).values());
                    } catch (Exception ignored) {
                        aura.phases = new ArrayList<AuraPhaseBean>();
                    }
                }
                this.skillicons = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM skills_icon_list", SkillIconBean.resultSetMapper));
                this.effects = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM auras_effects WHERE Enabled = 1", AuraEffectsBean.resultSetMapper));
                break;
            case"enhancements":
                this.enhancements = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM enhancements", EnhancementBean.resultSetMapper));
                this.enhancementPatterns = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM enhancements_patterns", EnhancementPatternBean.resultSetMapper));
                break;
            case "maps":
                this.zones = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM maps", ZoneBean.resultSetMapper));
                for (ZoneBean _area : this.zones.values()) {
                    _area.cells = Storage.getInstance().getJdbc().queryForMap("SELECT * FROM maps_cells WHERE MapID = ?", CellBean.resultSetMapper, _area.getId());
                    _area.monsters = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM maps_monsters WHERE MapID = ?", MapMonsterBean.setCreator, _area.getId());
                    if (_area.monsters == null) {
                        _area.monsters = Collections.EMPTY_SET;
                    }
                    _area.items = Storage.getInstance().getJdbc().queryForMap("SELECT * FROM maps_items WHERE MapID = ?", ZoneBean.beanItems, _area.getId());
                    if (_area.items == null) {
                        _area.items = Collections.EMPTY_MAP;
                    }

                    _area.npcs = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM maps_npcs WHERE MapID = ?", MapNpcBean.setCreator, _area.getId());
                    if (_area.npcs == null) {
                        _area.npcs = Collections.EMPTY_SET;
                    }
                }

                this.MapNpcApops = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT maps_npcs_apops.*, maps_npcs.NpcID FROM maps_npcs_apops JOIN maps_npcs ON maps_npcs_apops.MapNpcID = maps_npcs.id", MapNpcBeanApop.resultSetMapper));
                for(MapNpcBeanApop apopData : MapNpcApops.values()) {
                    apopData.actions = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM maps_npcs_apops_actions WHERE MapNpcApopID = ? ORDER BY SortOrder", MapNpcBeanApopAction.setCreator, apopData.getMapNpcBeanApopID());
                    if(apopData.actions == null) {
                        apopData.actions = Collections.emptySet();
                    }
                }
                this.monsterOutfits = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM monsters_outfits", MonsterOutfitBean.resultSetMapper));
                this.monsters = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM monsters", MonsterBean.resultSetMapper));
                for (MonsterBean monster : this.monsters.values()) {
                    monster.drops = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM monsters_drops WHERE MonsterID = ?", MonsterBean.beanDrops, monster.getId());
                    monster.skills = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM monster_assigned_skills WHERE MonsterID = ?", MonsterBean.beanSkills, monster.getId());
                    if (monster.drops == null) {
                        monster.drops = Collections.EMPTY_SET;
                    }
                    if (monster.skills == null) {
                        monster.skills = Collections.EMPTY_SET;
                    }
                }
                break;
            case "quests":
                this.quests = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM quests", QuestBean.resultSetMapper));
                for (QuestBean quest : this.quests.values()) {
                    quest.required = new ConcurrentHashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM quests_required WHERE QuestID = ?", QuestBean.requirementsRewardsMapper, quest.getId()));
                    quest.rewards = new LinkedList();
                    QueryResult quests_rewards = Storage.getInstance().getJdbc().query("SELECT * FROM quests_rewards WHERE QuestID = ?", quest.getId());
                    while (quests_rewards.next()) {
                        quest.rewards.add(new QuestRewardBean(quests_rewards));
                    }
                    quests_rewards.close();
                    quest.requirements = new ConcurrentHashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM quests_requirements WHERE QuestID = ?", QuestBean.requirementsRewardsMapper, quest.getId()));
                    quest.locations = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM quests_locations WHERE QuestID = ?", QuestBean.beanLocations, quest.getId());
                    if (quest.locations == null) {
                        quest.locations = Collections.EMPTY_SET;
                    }
                }
                break;
            case "worldboss":
                this.worldbosses = new HashMap(Storage.getInstance().getJdbc().queryForMap(
                        "SELECT * FROM monsters_bosses",
                        WorldBossBean.resultSetMapper
                ));

                // Always reset this cache
                this.worldBossMaps = new HashMap<>();

                // If maps already loaded, use that (fast)
                if (this.zones != null && !this.zones.isEmpty()) {
                    for (WorldBossBean boss : this.worldbosses.values()) {
                        ZoneBean area = null;

                        // zones is keyed by map name, not id, so we can’t direct lookup by mapId.
                        // We still want to avoid queries if possible, but without an id->name index, we must query.
                        // (If you want, we can add a mapId->mapName index later.)
                        String mapName = Storage.getInstance().getJdbc().queryForString(
                                "SELECT Name FROM maps WHERE id = ?",
                                Integer.valueOf(boss.mapId)
                        );

                        if (mapName != null) {
                            this.worldBossMaps.put(Integer.valueOf(boss.mapId), mapName);
                        }
                    }
                } else {
                    // maps not loaded yet - query for names like you already do
                    for (Map.Entry<Integer, WorldBossBean> entry : this.worldbosses.entrySet()) {
                        String mapName = Storage.getInstance().getJdbc().queryForString(
                                "SELECT Name FROM maps WHERE id = ?",
                                Integer.valueOf(entry.getValue().mapId)
                        );
                        if (mapName != null) {
                            this.worldBossMaps.put(Integer.valueOf(entry.getValue().mapId), mapName);
                        }
                    }
                }
                break;

            case "shops":

                this.shops = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM shops", ShopBean.resultSetMapper));
                for (ShopBean shop : this.shops.values()) {
                    shop.items = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT id, ItemID FROM shops_items WHERE ShopID = ?", ShopBean.shopItemsMapper, shop.getId()));
                    shop.locations = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM shops_locations WHERE ShopID = ?", ShopBean.beanLocations, shop.getId());
                    if (shop.locations == null) {
                        shop.locations = Collections.EMPTY_SET;
                    }
                }
                this.hairshops = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM hairs_shops", HairshopBean.resultSetMapper));
                for (HairshopBean hairshop : this.hairshops.values()) {
                    hairshop.female = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM hairs_shops_items WHERE Gender = ? AND ShopID = ?", HairshopBean.beanHairshopItems, "F", hairshop.getId());
                    hairshop.male = Storage.getInstance().getJdbc().queryForObject("SELECT * FROM hairs_shops_items WHERE Gender = ? AND ShopID = ?", HairshopBean.beanHairshopItems, "M", hairshop.getId());
                    if (hairshop.male == null) {
                        hairshop.male = Collections.EMPTY_SET;
                    }
                    if (hairshop.female == null) {
                        hairshop.female = Collections.EMPTY_SET;
                    }
                }
                break;
            case "features":
                this.serverFeatures = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM servers_features", ServerFeatureBean.resultSetMapper));
                break;
            case "chat_channels":
                try {
                    this.chatChannels = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM chat_channels WHERE Active >= 0 ORDER BY id ASC", ChatChannelBean.resultSetMapper));
                } catch (Exception ignored) {
                    this.chatChannels = new HashMap<String, ChatChannelBean>();
                }
                break;
            case "threads":
                try {
                    this.serverThreads = new HashMap(Storage.getInstance().getJdbc().queryForMap("SELECT * FROM servers_threads", ServerThreadBean.resultSetMapper));
                } catch (Exception ignored) {
                    this.serverThreads = new HashMap<String, ServerThreadBean>();
                }
                break;
            case"all":
                this.RetrieveStorageBeans("royakgames");
                this.RetrieveStorageBeans("shops");
                this.RetrieveStorageBeans("worldboss");
                this.RetrieveStorageBeans("maps");
                this.RetrieveStorageBeans("items");
                this.RetrieveStorageBeans("hairs");
                this.RetrieveStorageBeans("skills");
                this.RetrieveStorageBeans("quests");
                this.RetrieveStorageBeans("enhancements");
                this.RetrieveStorageBeans("features");
                this.RetrieveStorageBeans("chat_channels");
                this.RetrieveStorageBeans("threads");
                this.RetrieveStorageBeans("settings");
                break;
            default:
                throw new IllegalArgumentException("[StorageCache : Bean Retrieval Failed.]");
        }
    }
}
