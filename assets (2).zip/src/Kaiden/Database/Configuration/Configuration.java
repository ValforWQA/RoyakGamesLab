package Kaiden.Database.Configuration;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Configuration {

    public static String DEFAULT_MAP;
    public static String GEOIP_FILE;
    public static String DB_HOST;
    public static String GAME_NAME;
    public static String DB_NAME;
    public static String DB_USERNAME;
    public static String DB_PASSWORD;
    public static String DB_SERVER_NAME;
    public static int FLOOD_TIME;
    public static int FLOOD_WARN;
    public static int DB_PORT;
    public static int DB_MAX_CONNECTIONS;
    public static String EMULATOR_SERVER_ID;
    public static String SERVER_NAME;
    public static String DEFUALT_STARTER_MAP;
    public static String DEFAULT_STAFF_MAP;
    public static long MONSTER_ALLOWED_TIME;
    public static boolean ALLOW_INTERFACE;
    //public static boolea
    public static String DEFAULT_SQL_DATA;
    public static boolean STAFF_ONLY;
    public static boolean TESTING_ONLY;
    public static boolean SERVER_ACHIEVEMENT;
    public static boolean SERVER_PVP;
    public static int EXECUTOR_THREADS;
    public static int SERVER_ACHIEVEMENT_ID;
    public static int EXP_RATE;
    public static int CP_RATE;
    public static int GOLD_RATE;
    public static int REP_RATE;
    public static int DROP_RATE;
    public static int COIN_RATE;
    public static String DISCORD_BOT_TOKEN;
    public static String DISCORD_BOT_STATUS;
    public static String DISCORD_CHANNEL_ANNOUNCEMENT;
    public static String DISCORD_CHANNEL_AUCTION;
    public static String DISCORD_CHANNEL_CHAT;
    public static String DISCORD_CHANNEL_DONATION;
    public static String DISCORD_CHANNEL_GIVEAWAY;
    public static String DISCORD_CHANNEL_WORLDBOSS;

    public static String DISCORD_ROLE_MODERATOR;
    public static String DISCORD_ROLE_ADMINISTRATOR;
    public static boolean load() {
        try {
            Properties config = new Properties();
            String configPath = System.getProperty("kaiden.config");
            if (configPath == null || configPath.trim().isEmpty()) configPath = System.getenv("KAIDEN_CONFIG");
            if (configPath == null || configPath.trim().isEmpty()) {
                java.io.File upper = new java.io.File("Configuration/Config.osx");
                configPath = upper.exists() ? upper.getPath() : "Configuration/config.osx";
            }
            config.load(new FileInputStream(configPath));
            DEFAULT_SQL_DATA = ("kaiden_");
            DEFAULT_MAP = config.getProperty("init.map");
            DEFUALT_STARTER_MAP = config.getProperty("init.starter.map");
            DEFAULT_STAFF_MAP = config.getProperty("init.staff.map");
            MONSTER_ALLOWED_TIME = Long.parseLong(config.getProperty("init.monster.time"));
            GEOIP_FILE = config.getProperty("geoip.file");
            DB_HOST = config.getProperty("storage.host");
            DB_USERNAME = config.getProperty("storage.user");
            DB_PASSWORD = config.getProperty("storage.pass");
            DB_NAME = config.getProperty("storage.name");
            DB_SERVER_NAME = config.getProperty("storage.server");
            FLOOD_TIME = Integer.parseInt(config.getProperty("flood.time"));
            FLOOD_WARN = Integer.parseInt(config.getProperty("flood.warn"));
            DB_PORT = Integer.parseInt(config.getProperty("storage.port"));
            DB_MAX_CONNECTIONS = Integer.parseInt(config.getProperty("storage.connections.max"));
            SERVER_NAME = config.getProperty("server.name");
            STAFF_ONLY = Boolean.parseBoolean(config.getProperty("server.staffonly"));
            TESTING_ONLY = Boolean.parseBoolean(config.getProperty("server.testserver"));
            SERVER_PVP = Boolean.parseBoolean(config.getProperty("server.pvp"));
            SERVER_ACHIEVEMENT = Boolean.parseBoolean(config.getProperty("server.achievement"));
            SERVER_ACHIEVEMENT_ID = Integer.parseInt(config.getProperty("server.achievement.id"));
            EXP_RATE = Integer.parseInt(config.getProperty("server.rate.exp"));
            CP_RATE = Integer.parseInt(config.getProperty("server.rate.cp"));
            GOLD_RATE = Integer.parseInt(config.getProperty("server.rate.gold"));
            REP_RATE = Integer.parseInt(config.getProperty("server.rate.rep"));
            DROP_RATE = Integer.parseInt(config.getProperty("server.rate.drop"));
            COIN_RATE = Integer.parseInt(config.getProperty("server.rate.coin"));
            EXECUTOR_THREADS = Integer.parseInt(config.getProperty("executor.threads"));
            ALLOW_INTERFACE = Boolean.parseBoolean(config.getProperty("server.interface"));

            GAME_NAME = config.getProperty("game.name");
            EMULATOR_SERVER_ID = config.getProperty("discord.emu.server");
            // Environment variable takes precedence so tokens need not be stored in the source/config ZIP.
            String envDiscordToken = System.getenv("KAIDEN_DISCORD_BOT_TOKEN");
            DISCORD_BOT_TOKEN = envDiscordToken != null && !envDiscordToken.trim().isEmpty()
                    ? envDiscordToken.trim()
                    : config.getProperty("discord.bot.token", "").trim();
            DISCORD_BOT_STATUS = config.getProperty("discord.bot.status");
            DISCORD_CHANNEL_ANNOUNCEMENT = config.getProperty("discord.channel.announcement");
            DISCORD_CHANNEL_AUCTION = config.getProperty("discord.channel.auction");
            DISCORD_CHANNEL_CHAT = config.getProperty("discord.channel.chat");
            DISCORD_CHANNEL_DONATION = config.getProperty("discord.channel.donation");
            DISCORD_CHANNEL_GIVEAWAY = config.getProperty("discord.channel.giveaway");
            DISCORD_CHANNEL_WORLDBOSS = config.getProperty("discord.channel.worldboss");
            DISCORD_ROLE_MODERATOR = config.getProperty("discord.role.moderator");
            DISCORD_ROLE_ADMINISTRATOR = config.getProperty("discord.role.administrator");
        } catch (IOException error) {
            return false;
        }
        return true;
    }
}