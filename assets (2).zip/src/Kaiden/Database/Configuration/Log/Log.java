package Kaiden.Database.Configuration.Log;

import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Log {

    private static final Logger LOGGER = Logger.getLogger("KaidenEngine");

    public static void error(String c, Exception error) {
        try {
            if (error != null && (error.getMessage() == null || !error.getMessage().toLowerCase().contains("address already in use"))) {
                LOGGER.error("[KaidenEngine] - " + c + " - " + error.getMessage(), error);

                File file = new File("./errors/log.log");
                File parent = file.getParentFile();
                if (parent != null && !parent.exists()) {
                    parent.mkdirs();
                }

                try (FileWriter fw = new FileWriter(file, true);
                     PrintWriter pw = new PrintWriter(fw)) {
                    pw.println("============================================================");
                    pw.println("- Time: " + new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss").format(new Date()));
                    pw.println("- Error: " + c);
                    error.printStackTrace(pw);
                }
            }
        } catch (IOException e) {
            LOGGER.error("[KaidenEngine] - Failed writing error log file: " + e.getMessage(), e);
        }
    }
}
