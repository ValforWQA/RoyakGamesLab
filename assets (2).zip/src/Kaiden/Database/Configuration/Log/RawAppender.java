package Kaiden.Database.Configuration.Log;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;


public class RawAppender extends AppenderSkeleton {
        public static RawAppender instance;

        public static RawAppender getInstance() {
                if (instance == null) instance = new RawAppender();
                return instance;
        }

        @Override
        protected void append(LoggingEvent event) {
                System.out.println(event.getRenderedMessage());
        }

        @Override
        public void close() {}

        @Override
        public boolean requiresLayout() { return false; }
}
