package Kaiden.Database;

import Kaiden.Kaiden_Engine;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Small bounded async DB executor for non-critical writes.
 *
 * This prevents game/login/logout threads from blocking forever when the JDBC
 * connection pool is exhausted. Critical login SELECTs still run synchronously,
 * but logout saves, server-count syncs, and other maintenance writes can wait
 * safely on worker threads instead of freezing SmartFox event threads.
 */
public final class AsyncDbExecutor {

    private static final AtomicInteger THREAD_ID = new AtomicInteger(1);

    private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(
            4,
            8,
            60L,
            TimeUnit.SECONDS,
            new ArrayBlockingQueue<Runnable>(20000),
            runnable -> {
                Thread t = new Thread(runnable, "Kaiden-AsyncDb-" + THREAD_ID.getAndIncrement());
                t.setDaemon(true);
                return t;
            },
            (runnable, executor) -> {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "red",
                        "[AsyncDb] queue full; dropped non-critical DB task"
                );
            }
    );

    private AsyncDbExecutor() {}

    public static void submit(final String name, final Runnable task) {
        if (task == null) {
            return;
        }

        EXECUTOR.execute(() -> {
            try {
                // Non-critical async writes should never be allowed to pile up behind
                // an exhausted JDBC pool and make the emulator unresponsive.
                try {
                    Storage storage = Storage.getInstance();
                    boolean critical = "user-lost-save".equalsIgnoreCase(String.valueOf(name))
                            || "quest-save-all".equalsIgnoreCase(String.valueOf(name));
                    if (!critical && storage.shouldSkipNonCriticalDb()) {
                        Kaiden_Engine.getInstance().sendEmulatorMessage(
                                "yellow",
                                "[AsyncDb] skipped non-critical task" + (name == null ? "" : " [" + name + "]")
                                        + " because DB pool is busy active=" + storage.getActiveConnectionCount()
                                        + "/" + storage.getMaxConnectionCount()
                        );
                        return;
                    }
                } catch (Throwable ignored) {}

                task.run();
            } catch (Throwable t) {
                Kaiden_Engine.getInstance().sendEmulatorMessage(
                        "red",
                        "[AsyncDb] task failed" + (name == null ? "" : " [" + name + "]") + ": " + t.getMessage()
                );
            }
        });
    }

    public static int getQueueSize() {
        return EXECUTOR.getQueue().size();
    }

    public static int getActiveWorkerCount() {
        return EXECUTOR.getActiveCount();
    }
}
